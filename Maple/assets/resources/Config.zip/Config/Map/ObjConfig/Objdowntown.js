var Objdowntown = Objdowntown || { }; 
Objdowntown =   {
	"id":"downtown",
	"acc" :  {
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-0-0",
					"origin" : [256,87],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-1-0",
					"origin" : [285,135],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-2-0",
					"origin" : [364,135],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-3-0",
					"origin" : [144,176],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-4-0",
					"origin" : [115,148],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-5-0",
					"origin" : [372,137],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-6-0",
					"origin" : [401,135],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-7-0",
					"origin" : [363,196],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-8-0",
					"origin" : [247,153],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-9-0",
					"origin" : [93,139],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-10-0",
					"origin" : [388,138],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-11-0",
					"origin" : [26,32],
					"z" : 0,
					"delay" : 450,
				},
				"1" :  {
					"png_path": "downtown.img/acc-acc-11-1",
					"origin" : [18,32],
					"z" : 0,
					"delay" : 450,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-12-0",
					"origin" : [217,211],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-13-0",
					"origin" : [96,93],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-14-0",
					"origin" : [45,137],
					"z" : 0,
				},
				"1" :  {
					"png_path": "downtown.img/acc-acc-14-1",
					"origin" : [46,137],
					"z" : 0,
				},
				"2" :  {
					"png_path": "downtown.img/acc-acc-14-2",
					"origin" : [46,135],
					"z" : 0,
				},
				"3" :  {
					"png_path": "downtown.img/acc-acc-14-3",
					"origin" : [43,133],
					"z" : 0,
				},
				"4" :  {
					"png_path": "downtown.img/acc-acc-14-4",
					"origin" : [42,134],
					"z" : 0,
				},
				"5" :  {
					"png_path": "downtown.img/acc-acc-14-5",
					"origin" : [43,136],
					"z" : 0,
				},
				"6" :  {
					"png_path": "downtown.img/acc-acc-14-6",
					"origin" : [44,136],
					"z" : 0,
				},
				"7" :  {
					"png_path": "downtown.img/acc-acc-14-7",
					"origin" : [45,137],
					"z" : 0,
				},
				"8" :  {
					"png_path": "downtown.img/acc-acc-14-8",
					"origin" : [46,137],
					"z" : 0,
				},
				"9" :  {
					"png_path": "downtown.img/acc-acc-14-9",
					"origin" : [46,135],
					"z" : 0,
				},
				"10" :  {
					"png_path": "downtown.img/acc-acc-14-10",
					"origin" : [43,133],
					"z" : 0,
				},
				"11" :  {
					"png_path": "downtown.img/acc-acc-14-11",
					"origin" : [42,134],
					"z" : 0,
				},
				"12" :  {
					"png_path": "downtown.img/acc-acc-14-12",
					"origin" : [43,136],
					"z" : 0,
				},
				"13" :  {
					"png_path": "downtown.img/acc-acc-14-13",
					"origin" : [44,136],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-15-0",
					"origin" : [73,230],
					"z" : 0,
				},
				"1" :  {
					"png_path": "downtown.img/acc-acc-15-1",
					"origin" : [73,232],
					"z" : 0,
				},
				"2" :  {
					"png_path": "downtown.img/acc-acc-15-2",
					"origin" : [73,235],
					"z" : 0,
				},
				"3" :  {
					"png_path": "downtown.img/acc-acc-15-3",
					"origin" : [73,244],
					"z" : 0,
				},
				"4" :  {
					"png_path": "downtown.img/acc-acc-15-4",
					"origin" : [73,251],
					"z" : 0,
				},
				"5" :  {
					"png_path": "downtown.img/acc-acc-15-5",
					"origin" : [73,260],
					"z" : 0,
				},
				"6" :  {
					"png_path": "downtown.img/acc-acc-15-6",
					"origin" : [73,234],
					"z" : 0,
				},
				"7" :  {
					"png_path": "downtown.img/acc-acc-15-7",
					"origin" : [73,230],
					"z" : 0,
				},
				"8" :  {
					"png_path": "downtown.img/acc-acc-15-8",
					"origin" : [73,230],
					"z" : 0,
				},
				"9" :  {
					"png_path": "downtown.img/acc-acc-15-9",
					"origin" : [73,230],
					"z" : 0,
				},
				"10" :  {
					"png_path": "downtown.img/acc-acc-15-10",
					"origin" : [73,232],
					"z" : 0,
				},
				"11" :  {
					"png_path": "downtown.img/acc-acc-15-11",
					"origin" : [73,235],
					"z" : 0,
				},
				"12" :  {
					"png_path": "downtown.img/acc-acc-15-12",
					"origin" : [73,244],
					"z" : 0,
				},
				"13" :  {
					"png_path": "downtown.img/acc-acc-15-13",
					"origin" : [73,251],
					"z" : 0,
				},
				"14" :  {
					"png_path": "downtown.img/acc-acc-15-14",
					"origin" : [73,260],
					"z" : 0,
				},
				"15" :  {
					"png_path": "downtown.img/acc-acc-15-15",
					"origin" : [73,234],
					"z" : 0,
				},
				"16" :  {
					"png_path": "downtown.img/acc-acc-15-16",
					"origin" : [73,230],
					"z" : 0,
				},
				"17" :  {
					"png_path": "downtown.img/acc-acc-15-17",
					"origin" : [73,230],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-16-0",
					"origin" : [238,138],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-17-0",
					"origin" : [271,228],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "downtown.img/acc-acc-18-0",
					"origin" : [13,49],
					"z" : 0,
				},
				"1" :  {
					"png_path": "downtown.img/acc-acc-18-1",
					"origin" : [13,46],
					"z" : 0,
				},
				"2" :  {
					"png_path": "downtown.img/acc-acc-18-2",
					"origin" : [12,40],
					"z" : 0,
				},
				"3" :  {
					"png_path": "downtown.img/acc-acc-18-3",
					"origin" : [13,41],
					"z" : 0,
				},
				"4" :  {
					"png_path": "downtown.img/acc-acc-18-4",
					"origin" : [12,42],
					"z" : 0,
				},
				"5" :  {
					"png_path": "downtown.img/acc-acc-18-5",
					"origin" : [11,45],
					"z" : 0,
				},
				"6" :  {
					"png_path": "downtown.img/acc-acc-18-6",
					"origin" : [13,49],
					"z" : 0,
				},
			},
		},
		"accN" :  {
			"0" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-0-0",
					"origin" : [93,53],
					"z" : 0,
				},
				"spine" : "base_plant_01",
			},
			"1" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-1-0",
					"origin" : [83,37],
					"z" : 0,
				},
				"spine" : "base_plant_02",
			},
			"2" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-2-0",
					"origin" : [116,53],
					"z" : 0,
				},
				"spine" : "base_plant_03",
			},
			"3" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-3-0",
					"origin" : [68,30],
					"z" : 0,
				},
				"spine" : "base_plant_04",
			},
			"4" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-4-0",
					"origin" : [44,36],
					"z" : 0,
				},
				"spine" : "base_plant_05",
			},
			"5" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-5-0",
					"origin" : [28,31],
					"z" : 0,
				},
				"spine" : "flower_01",
			},
			"6" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-6-0",
					"origin" : [28,39],
					"z" : 0,
				},
				"spine" : "flower_02",
			},
			"7" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-7-0",
					"origin" : [271,275],
					"z" : 0,
				},
				"spine" : "tree_01",
			},
			"8" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-8-0",
					"origin" : [251,264],
					"z" : 0,
				},
				"spine" : "tree_02",
			},
			"9" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-9-0",
					"origin" : [193,181],
					"z" : 0,
				},
				"spine" : "tree_03",
			},
			"10" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-10-0",
					"origin" : [343,342],
					"z" : 0,
				},
				"spine" : "big_tree",
			},
			"11" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-11-0",
					"origin" : [343,342],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-12-0",
					"origin" : [271,275],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-13-0",
					"origin" : [250,264],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN-14-0",
					"origin" : [193,181],
					"z" : 0,
				},
			},
		},
		"accN2" :  {
			"0" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN2-0-0",
					"origin" : [93,53],
					"z" : 0,
				},
				"spine" : "base_plant_01",
			},
			"1" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN2-1-0",
					"origin" : [83,37],
					"z" : 0,
				},
				"spine" : "base_plant_02",
			},
			"2" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN2-2-0",
					"origin" : [116,53],
					"z" : 0,
				},
				"spine" : "base_plant_03",
			},
			"3" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN2-3-0",
					"origin" : [68,30],
					"z" : 0,
				},
				"spine" : "base_plant_04",
			},
			"4" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN2-4-0",
					"origin" : [44,36],
					"z" : 0,
				},
				"spine" : "base_plant_05",
			},
			"5" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN2-5-0",
					"origin" : [29,32],
					"z" : 0,
				},
				"spine" : "flower_01",
			},
			"6" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN2-6-0",
					"origin" : [29,40],
					"z" : 0,
				},
				"spine" : "flower_02",
			},
			"7" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN2-7-0",
					"origin" : [272,276],
					"z" : 0,
				},
				"spine" : "tree_01",
			},
			"8" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN2-8-0",
					"origin" : [252,265],
					"z" : 0,
				},
				"spine" : "tree_02",
			},
			"9" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN2-9-0",
					"origin" : [194,182],
					"z" : 0,
				},
				"spine" : "tree_03",
			},
		},
		"accN3" :  {
			"0" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN3-0-0",
					"origin" : [93,53],
					"z" : 0,
				},
				"spine" : "base_plant_01",
			},
			"1" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN3-1-0",
					"origin" : [83,37],
					"z" : 0,
				},
				"spine" : "base_plant_02",
			},
			"2" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN3-2-0",
					"origin" : [116,53],
					"z" : 0,
				},
				"spine" : "base_plant_03",
			},
			"3" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN3-3-0",
					"origin" : [66,30],
					"z" : 0,
				},
				"spine" : "base_plant_04",
			},
			"4" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN3-4-0",
					"origin" : [45,36],
					"z" : 0,
				},
				"spine" : "base_plant_05",
			},
			"5" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN3-5-0",
					"origin" : [29,32],
					"z" : 0,
				},
				"spine" : "flower_01",
			},
			"6" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN3-6-0",
					"origin" : [29,40],
					"z" : 0,
				},
				"spine" : "flower_02",
			},
			"7" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN3-7-0",
					"origin" : [272,276],
					"z" : 0,
				},
				"spine" : "tree_01",
			},
			"8" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN3-8-0",
					"origin" : [252,265],
					"z" : 0,
				},
				"spine" : "tree_02",
			},
			"9" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN3-9-0",
					"origin" : [194,182],
					"z" : 0,
				},
				"spine" : "tree_03",
			},
		},
		"accN4" :  {
			"0" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN4-0-0",
					"origin" : [86,133],
					"z" : 0,
				},
				"1" :  {
					"png_path": "downtown.img/acc-accN4-0-1",
					"origin" : [86,123],
					"z" : 0,
				},
				"2" :  {
					"png_path": "downtown.img/acc-accN4-0-2",
					"origin" : [86,127],
					"z" : 0,
				},
				"3" :  {
					"png_path": "downtown.img/acc-accN4-0-3",
					"origin" : [86,134],
					"z" : 0,
				},
				"4" :  {
					"png_path": "downtown.img/acc-accN4-0-4",
					"origin" : [86,137],
					"z" : 0,
				},
				"5" :  {
					"png_path": "downtown.img/acc-accN4-0-5",
					"origin" : [86,125],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN4-1-0",
					"origin" : [76,105],
					"z" : 0,
				},
				"1" :  {
					"png_path": "downtown.img/acc-accN4-1-1",
					"origin" : [76,127],
					"z" : 0,
				},
				"2" :  {
					"png_path": "downtown.img/acc-accN4-1-2",
					"origin" : [76,117],
					"z" : 0,
				},
				"3" :  {
					"png_path": "downtown.img/acc-accN4-1-3",
					"origin" : [76,135],
					"z" : 0,
				},
				"4" :  {
					"png_path": "downtown.img/acc-accN4-1-4",
					"origin" : [76,133],
					"z" : 0,
				},
				"5" :  {
					"png_path": "downtown.img/acc-accN4-1-5",
					"origin" : [76,117],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN4-2-0",
					"origin" : [105,79],
					"z" : 0,
				},
				"1" :  {
					"png_path": "downtown.img/acc-accN4-2-1",
					"origin" : [105,97],
					"z" : 0,
				},
				"2" :  {
					"png_path": "downtown.img/acc-accN4-2-2",
					"origin" : [105,95],
					"z" : 0,
				},
				"3" :  {
					"png_path": "downtown.img/acc-accN4-2-3",
					"origin" : [105,79],
					"z" : 0,
				},
				"4" :  {
					"png_path": "downtown.img/acc-accN4-2-4",
					"origin" : [105,67],
					"z" : 0,
				},
				"5" :  {
					"png_path": "downtown.img/acc-accN4-2-5",
					"origin" : [105,89],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN4-3-0",
					"origin" : [62,30],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN4-4-0",
					"origin" : [38,32],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN4-5-0",
					"origin" : [28,31],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN4-6-0",
					"origin" : [28,34],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN4-7-0",
					"origin" : [270,275],
					"z" : 0,
				},
				"1" :  {
					"png_path": "downtown.img/acc-accN4-7-1",
					"origin" : [270,275],
					"z" : 0,
				},
				"2" :  {
					"png_path": "downtown.img/acc-accN4-7-2",
					"origin" : [270,275],
					"z" : 0,
				},
				"3" :  {
					"png_path": "downtown.img/acc-accN4-7-3",
					"origin" : [270,275],
					"z" : 0,
				},
				"4" :  {
					"png_path": "downtown.img/acc-accN4-7-4",
					"origin" : [270,275],
					"z" : 0,
				},
				"5" :  {
					"png_path": "downtown.img/acc-accN4-7-5",
					"origin" : [270,275],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN4-8-0",
					"origin" : [250,305],
					"z" : 0,
				},
				"1" :  {
					"png_path": "downtown.img/acc-accN4-8-1",
					"origin" : [250,314],
					"z" : 0,
				},
				"2" :  {
					"png_path": "downtown.img/acc-accN4-8-2",
					"origin" : [250,296],
					"z" : 0,
				},
				"3" :  {
					"png_path": "downtown.img/acc-accN4-8-3",
					"origin" : [250,294],
					"z" : 0,
				},
				"4" :  {
					"png_path": "downtown.img/acc-accN4-8-4",
					"origin" : [250,304],
					"z" : 0,
				},
				"5" :  {
					"png_path": "downtown.img/acc-accN4-8-5",
					"origin" : [250,359],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "downtown.img/acc-accN4-9-0",
					"origin" : [215,307],
					"z" : 0,
				},
				"1" :  {
					"png_path": "downtown.img/acc-accN4-9-1",
					"origin" : [224,309],
					"z" : 0,
				},
				"2" :  {
					"png_path": "downtown.img/acc-accN4-9-2",
					"origin" : [247,311],
					"z" : 0,
				},
				"3" :  {
					"png_path": "downtown.img/acc-accN4-9-3",
					"origin" : [239,277],
					"z" : 0,
				},
				"4" :  {
					"png_path": "downtown.img/acc-accN4-9-4",
					"origin" : [241,278],
					"z" : 0,
				},
				"5" :  {
					"png_path": "downtown.img/acc-accN4-9-5",
					"origin" : [243,309],
					"z" : 0,
				},
			},
		},
	},
};

