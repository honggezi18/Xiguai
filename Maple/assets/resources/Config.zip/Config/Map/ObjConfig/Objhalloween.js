var Objhalloween = Objhalloween || { }; 
Objhalloween =   {
	"id":"halloween",
	"inside" :  {
		"roomFrame" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-0-0",
					"origin" : [466,109],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-1-0",
					"origin" : [60,173],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-2-0",
					"origin" : [61,173],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-3-0",
					"origin" : [466,18],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-4-0",
					"origin" : [47,300],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-5-0",
					"origin" : [47,300],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-6-0",
					"origin" : [33,116],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-7-0",
					"origin" : [30,102],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-8-0",
					"origin" : [29,103],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-9-0",
					"origin" : [34,116],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-10-0",
					"origin" : [275,37],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-11-0",
					"origin" : [256,37],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-12-0",
					"origin" : [103,103],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-13-0",
					"origin" : [137,92],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-14-0",
					"origin" : [116,98],
					"z" : 0,
					"delay" : 15000,
				},
				"1" :  {
					"png_path": "halloween.img/inside-roomFrame-14-1",
					"origin" : [116,98],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/inside-roomFrame-14-2",
					"origin" : [117,98],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/inside-roomFrame-14-3",
					"origin" : [118,98],
					"z" : 0,
					"delay" : 3000,
				},
				"4" :  {
					"png_path": "halloween.img/inside-roomFrame-14-4",
					"origin" : [117,98],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween.img/inside-roomFrame-14-5",
					"origin" : [116,98],
					"z" : 0,
					"delay" : 150,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-15-0",
					"origin" : [115,87],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "halloween.img/inside-roomFrame-15-1",
					"origin" : [115,92],
					"z" : 0,
					"delay" : 200,
				},
				"2" :  {
					"png_path": "halloween.img/inside-roomFrame-15-2",
					"origin" : [114,98],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "halloween.img/inside-roomFrame-15-3",
					"origin" : [116,92],
					"z" : 0,
					"delay" : 200,
				},
				"4" :  {
					"png_path": "halloween.img/inside-roomFrame-15-4",
					"origin" : [116,87],
					"z" : 0,
					"delay" : 200,
				},
				"5" :  {
					"png_path": "halloween.img/inside-roomFrame-15-5",
					"origin" : [116,92],
					"z" : 0,
					"delay" : 200,
				},
				"6" :  {
					"png_path": "halloween.img/inside-roomFrame-15-6",
					"origin" : [114,98],
					"z" : 0,
					"delay" : 200,
				},
				"7" :  {
					"png_path": "halloween.img/inside-roomFrame-15-7",
					"origin" : [116,92],
					"z" : 0,
					"delay" : 200,
				},
				"8" :  {
					"png_path": "halloween.img/inside-roomFrame-15-8",
					"origin" : [116,87],
					"z" : 0,
					"delay" : 200,
				},
				"9" :  {
					"png_path": "halloween.img/inside-roomFrame-15-9",
					"origin" : [116,92],
					"z" : 0,
					"delay" : 200,
				},
				"10" :  {
					"png_path": "halloween.img/inside-roomFrame-15-10",
					"origin" : [114,97],
					"z" : 0,
					"delay" : 200,
				},
				"11" :  {
					"png_path": "halloween.img/inside-roomFrame-15-11",
					"origin" : [115,91],
					"z" : 0,
					"delay" : 2000,
					"a0" : 255,
					"a1" : 0,
				},
				"12" :  {
					"png_path": "halloween.img/inside-roomFrame-15-12",
					"origin" : [115,91],
					"z" : 0,
					"a0" : 0,
					"a1" : 0,
					"delay" : 5000,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-16-0",
					"origin" : [-24,0],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "halloween.img/inside-roomFrame-16-1",
					"origin" : [93,58],
					"z" : 0,
					"delay" : 200,
				},
				"2" :  {
					"png_path": "halloween.img/inside-roomFrame-16-2",
					"origin" : [86,93],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "halloween.img/inside-roomFrame-16-3",
					"origin" : [-44,93],
					"z" : 0,
					"delay" : 200,
				},
				"4" :  {
					"png_path": "halloween.img/inside-roomFrame-16-4",
					"origin" : [-55,92],
					"z" : 0,
					"delay" : 200,
				},
				"5" :  {
					"png_path": "halloween.img/inside-roomFrame-16-5",
					"origin" : [-67,92],
					"z" : 0,
					"delay" : 200,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-17-0",
					"origin" : [466,109],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-18-0",
					"origin" : [60,173],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-19-0",
					"origin" : [61,173],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-20-0",
					"origin" : [466,18],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-21-0",
					"origin" : [47,300],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-22-0",
					"origin" : [47,300],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-23-0",
					"origin" : [275,37],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-24-0",
					"origin" : [256,37],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-25-0",
					"origin" : [84,334],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-26-0",
					"origin" : [155,48],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-27-0",
					"origin" : [155,53],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "halloween.img/inside-roomFrame-28-0",
					"origin" : [155,17],
					"z" : 0,
				},
			},
		},
		"foot" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot-0-0",
					"origin" : [99,56],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot-1-0",
					"origin" : [35,17],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween.img/inside-foot-1-1",
					"origin" : [39,17],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/inside-foot-1-2",
					"origin" : [42,17],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/inside-foot-1-3",
					"origin" : [42,17],
					"z" : 0,
					"delay" : 150,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot-2-0",
					"origin" : [32,17],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween.img/inside-foot-2-1",
					"origin" : [36,17],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/inside-foot-2-2",
					"origin" : [39,17],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/inside-foot-2-3",
					"origin" : [39,17],
					"z" : 0,
					"delay" : 150,
				},
			},
		},
		"foot2" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-0-0",
					"origin" : [0,0],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-1-0",
					"origin" : [42,18],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-2-0",
					"origin" : [12,15],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-3-0",
					"origin" : [18,30],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-4-0",
					"origin" : [0,0],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-5-0",
					"origin" : [45,18],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-6-0",
					"origin" : [35,24],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-7-0",
					"origin" : [35,24],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-8-0",
					"origin" : [35,30],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-9-0",
					"origin" : [28,22],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-10-0",
					"origin" : [22,18],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-11-0",
					"origin" : [0,0],
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-12-0",
					"origin" : [34,30],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-13-0",
					"origin" : [28,22],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-14-0",
					"origin" : [32,22],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-15-0",
					"origin" : [26,22],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-16-0",
					"origin" : [18,30],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-17-0",
					"origin" : [0,0],
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-18-0",
					"origin" : [32,22],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-19-0",
					"origin" : [29,45],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-20-0",
					"origin" : [18,6],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-21-0",
					"origin" : [16,15],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-22-0",
					"origin" : [18,6],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "halloween.img/inside-foot2-23-0",
					"origin" : [18,4],
					"z" : 0,
				},
			},
		},
		"chimney" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-0-0",
					"origin" : [21,19],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-1-0",
					"origin" : [16,15],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-2-0",
					"origin" : [8,10],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-3-0",
					"origin" : [45,10],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-4-0",
					"origin" : [45,14],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-5-0",
					"origin" : [29,10],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-6-0",
					"origin" : [19,15],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-7-0",
					"origin" : [0,0],
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-8-0",
					"origin" : [19,12],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-9-0",
					"origin" : [15,40],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-10-0",
					"origin" : [11,40],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-11-0",
					"origin" : [15,14],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-12-0",
					"origin" : [18,14],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-13-0",
					"origin" : [16,11],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-14-0",
					"origin" : [18,11],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-15-0",
					"origin" : [18,14],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-16-0",
					"origin" : [16,14],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-17-0",
					"origin" : [56,20],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-18-0",
					"origin" : [56,18],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-19-0",
					"origin" : [66,74],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-20-0",
					"origin" : [59,56],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-21-0",
					"origin" : [50,48],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "halloween.img/inside-chimney-22-0",
					"origin" : [67,54],
					"z" : 0,
				},
			},
		},
		"stairs" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-0-0",
					"origin" : [312,170],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-1-0",
					"origin" : [149,136],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-2-0",
					"origin" : [135,136],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-3-0",
					"origin" : [165,91],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-4-0",
					"origin" : [164,92],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-5-0",
					"origin" : [468,134],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-6-0",
					"origin" : [283,183],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-7-0",
					"origin" : [168,183],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-8-0",
					"origin" : [273,184],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-9-0",
					"origin" : [168,183],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-10-0",
					"origin" : [95,28],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-11-0",
					"origin" : [103,28],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-12-0",
					"origin" : [103,28],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-13-0",
					"origin" : [103,28],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-14-0",
					"origin" : [95,28],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-15-0",
					"origin" : [103,24],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "halloween.img/inside-stairs-16-0",
					"origin" : [103,24],
					"z" : 0,
				},
			},
		},
		"door" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-door-0-0",
					"origin" : [95,115],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-door-1-0",
					"origin" : [95,115],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-door-2-0",
					"origin" : [0,0],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-door-3-0",
					"origin" : [61,115],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-door-4-0",
					"origin" : [88,115],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-door-5-0",
					"origin" : [36,114],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-door-6-0",
					"origin" : [0,0],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-door-7-0",
					"origin" : [0,0],
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-door-8-0",
					"origin" : [47,71],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-door-9-0",
					"origin" : [107,84],
					"z" : 0,
				},
			},
		},
		"room1" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-0-0",
					"origin" : [83,50],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room1-0-1",
					"origin" : [83,47],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room1-0-2",
					"origin" : [83,50],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room1-0-3",
					"origin" : [83,47],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room1-0-4",
					"origin" : [83,50],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween.img/inside-room1-0-5",
					"origin" : [83,47],
					"z" : 0,
					"delay" : 150,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-1-0",
					"origin" : [85,79],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room1-1-1",
					"origin" : [88,79],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room1-1-2",
					"origin" : [99,79],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room1-1-3",
					"origin" : [101,79],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room1-1-4",
					"origin" : [103,79],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween.img/inside-room1-1-5",
					"origin" : [105,79],
					"z" : 0,
					"delay" : 150,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-2-0",
					"origin" : [116,76],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room1-2-1",
					"origin" : [116,76],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room1-2-2",
					"origin" : [116,76],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room1-2-3",
					"origin" : [116,76],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room1-2-4",
					"origin" : [116,76],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween.img/inside-room1-2-5",
					"origin" : [116,76],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "halloween.img/inside-room1-2-6",
					"origin" : [116,76],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "halloween.img/inside-room1-2-7",
					"origin" : [116,76],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "halloween.img/inside-room1-2-8",
					"origin" : [116,76],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "halloween.img/inside-room1-2-9",
					"origin" : [116,76],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "halloween.img/inside-room1-2-10",
					"origin" : [116,76],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "halloween.img/inside-room1-2-11",
					"origin" : [116,76],
					"z" : 0,
					"delay" : 150,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-3-0",
					"origin" : [100,44],
					"z" : 0,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room1-3-1",
					"origin" : [100,49],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room1-3-2",
					"origin" : [100,44],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room1-3-1",
					"origin" : [100,49],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room1-3-2",
					"origin" : [100,44],
					"z" : 0,
					"delay" : 150,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-4-0",
					"origin" : [109,142],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-5-0",
					"origin" : [128,144],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-6-0",
					"origin" : [130,143],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-7-0",
					"origin" : [138,143],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-8-0",
					"origin" : [81,108],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-9-0",
					"origin" : [128,158],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-10-0",
					"origin" : [130,135],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-11-0",
					"origin" : [59,158],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-12-0",
					"origin" : [41,78],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-13-0",
					"origin" : [24,17],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room1-13-1",
					"origin" : [24,17],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room1-13-2",
					"origin" : [24,17],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room1-13-3",
					"origin" : [24,17],
					"z" : 0,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room1-13-4",
					"origin" : [24,17],
					"z" : 0,
				},
				"5" :  {
					"png_path": "halloween.img/inside-room1-13-5",
					"origin" : [24,17],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween.img/inside-room1-13-6",
					"origin" : [24,17],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-14-0",
					"origin" : [38,17],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room1-14-1",
					"origin" : [38,17],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room1-14-2",
					"origin" : [38,17],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room1-14-3",
					"origin" : [38,17],
					"z" : 0,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room1-14-4",
					"origin" : [38,17],
					"z" : 0,
				},
				"5" :  {
					"png_path": "halloween.img/inside-room1-14-5",
					"origin" : [38,17],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween.img/inside-room1-14-6",
					"origin" : [38,17],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-15-0",
					"origin" : [178,34],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room1-15-1",
					"origin" : [178,34],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room1-15-2",
					"origin" : [178,34],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room1-15-3",
					"origin" : [178,34],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-16-0",
					"origin" : [62,49],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room1-16-1",
					"origin" : [62,49],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room1-16-2",
					"origin" : [62,49],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room1-16-3",
					"origin" : [62,49],
					"z" : 0,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room1-16-4",
					"origin" : [62,49],
					"z" : 0,
				},
				"5" :  {
					"png_path": "halloween.img/inside-room1-16-5",
					"origin" : [62,49],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween.img/inside-room1-16-6",
					"origin" : [62,49],
					"z" : 0,
				},
				"7" :  {
					"png_path": "halloween.img/inside-room1-16-7",
					"origin" : [62,49],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-17-0",
					"origin" : [29,54],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room1-17-1",
					"origin" : [29,54],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room1-17-2",
					"origin" : [29,54],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-18-0",
					"origin" : [53,53],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room1-18-1",
					"origin" : [53,53],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room1-18-2",
					"origin" : [53,53],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-19-0",
					"origin" : [26,28],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room1-19-1",
					"origin" : [26,28],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room1-19-2",
					"origin" : [26,28],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room1-19-3",
					"origin" : [26,28],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-20-0",
					"origin" : [84,71],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-21-0",
					"origin" : [84,41],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-22-0",
					"origin" : [35,69],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-23-0",
					"origin" : [92,85],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-24-0",
					"origin" : [92,76],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-25-0",
					"origin" : [50,95],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-26-0",
					"origin" : [82,31],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-27-0",
					"origin" : [47,20],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-28-0",
					"origin" : [51,35],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-29-0",
					"origin" : [48,19],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room1-30-0",
					"origin" : [48,18],
					"z" : 0,
				},
			},
		},
		"room2" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-0-0",
					"origin" : [40,79],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-1-0",
					"origin" : [132,111],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-2-0",
					"origin" : [128,183],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-3-0",
					"origin" : [128,183],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-4-0",
					"origin" : [161,78],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-5-0",
					"origin" : [138,91],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room2-5-1",
					"origin" : [138,91],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room2-5-2",
					"origin" : [138,91],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room2-5-3",
					"origin" : [138,91],
					"z" : 0,
					"delay" : 150,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-6-0",
					"origin" : [82,34],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-7-0",
					"origin" : [19,38],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-8-0",
					"origin" : [0,0],
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-9-0",
					"origin" : [76,58],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-10-0",
					"origin" : [50,75],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-11-0",
					"origin" : [53,63],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-12-0",
					"origin" : [76,40],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-13-0",
					"origin" : [47,39],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-14-0",
					"origin" : [38,70],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-15-0",
					"origin" : [33,60],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-16-0",
					"origin" : [37,37],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-17-0",
					"origin" : [50,96],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-18-0",
					"origin" : [22,62],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-19-0",
					"origin" : [0,0],
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-20-0",
					"origin" : [90,126],
					"z" : 0,
					"delay" : 6000,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room2-20-1",
					"origin" : [100,126],
					"z" : 0,
					"delay" : 2000,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-21-0",
					"origin" : [0,0],
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-22-0",
					"origin" : [0,0],
				},
				"1" :  {
					"png_path": "halloween.img/inside-room2-22-1",
					"origin" : [28,17],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room2-22-2",
					"origin" : [32,14],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room2-22-3",
					"origin" : [35,12],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room2-22-4",
					"origin" : [35,11],
					"z" : 0,
					"delay" : 150,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-23-0",
					"origin" : [22,20],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room2-23-1",
					"origin" : [32,17],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room2-23-2",
					"origin" : [36,14],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room2-23-3",
					"origin" : [39,12],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room2-23-4",
					"origin" : [39,11],
					"z" : 0,
					"delay" : 150,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room2-24-0",
					"origin" : [25,20],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room2-24-1",
					"origin" : [35,17],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room2-24-2",
					"origin" : [39,14],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room2-24-3",
					"origin" : [42,12],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room2-24-4",
					"origin" : [42,11],
					"z" : 0,
					"delay" : 150,
				},
			},
		},
		"room3" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-0-0",
					"origin" : [0,0],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-1-0",
					"origin" : [0,0],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-2-0",
					"origin" : [0,0],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-3-0",
					"origin" : [0,0],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-4-0",
					"origin" : [0,0],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-5-0",
					"origin" : [126,142],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-6-0",
					"origin" : [50,96],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-7-0",
					"origin" : [0,0],
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-8-0",
					"origin" : [17,19],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-9-0",
					"origin" : [34,25],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-10-0",
					"origin" : [34,25],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-11-0",
					"origin" : [34,47],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-12-0",
					"origin" : [59,39],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-13-0",
					"origin" : [29,36],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-14-0",
					"origin" : [52,49],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-15-0",
					"origin" : [66,76],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-16-0",
					"origin" : [38,70],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-17-0",
					"origin" : [33,38],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-18-0",
					"origin" : [0,0],
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-19-0",
					"origin" : [39,13],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-20-0",
					"origin" : [185,13],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-21-0",
					"origin" : [68,36],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-22-0",
					"origin" : [0,0],
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-23-0",
					"origin" : [53,63],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-24-0",
					"origin" : [103,80],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-25-0",
					"origin" : [99,95],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-26-0",
					"origin" : [23,33],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room3-27-0",
					"origin" : [257,108],
					"z" : 0,
				},
			},
		},
		"room4" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-0-0",
					"origin" : [154,157],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-1-0",
					"origin" : [117,148],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-2-0",
					"origin" : [0,0],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-3-0",
					"origin" : [273,155],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-4-0",
					"origin" : [91,25],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-5-0",
					"origin" : [41,64],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-6-0",
					"origin" : [61,71],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-7-0",
					"origin" : [53,63],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-8-0",
					"origin" : [53,63],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-9-0",
					"origin" : [50,26],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-10-0",
					"origin" : [33,30],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-11-0",
					"origin" : [51,42],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-12-0",
					"origin" : [34,40],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-13-0",
					"origin" : [30,34],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room4-14-0",
					"origin" : [25,25],
					"z" : 0,
				},
			},
		},
		"room5" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-0-0",
					"origin" : [0,0],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-1-0",
					"origin" : [0,0],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-2-0",
					"origin" : [35,43],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-3-0",
					"origin" : [52,59],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-4-0",
					"origin" : [84,59],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-5-0",
					"origin" : [34,60],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-6-0",
					"origin" : [40,45],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-7-0",
					"origin" : [50,96],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-8-0",
					"origin" : [30,78],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-9-0",
					"origin" : [54,50],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-10-0",
					"origin" : [47,38],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-11-0",
					"origin" : [114,123],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-12-0",
					"origin" : [137,60],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-13-0",
					"origin" : [0,0],
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-14-0",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room5-14-1",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room5-14-2",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room5-14-3",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room5-14-4",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"5" :  {
					"png_path": "halloween.img/inside-room5-14-5",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"6" :  {
					"png_path": "halloween.img/inside-room5-14-6",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"7" :  {
					"png_path": "halloween.img/inside-room5-14-7",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"8" :  {
					"png_path": "halloween.img/inside-room5-14-8",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"9" :  {
					"png_path": "halloween.img/inside-room5-14-9",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"10" :  {
					"png_path": "halloween.img/inside-room5-14-10",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"11" :  {
					"png_path": "halloween.img/inside-room5-14-11",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"12" :  {
					"png_path": "halloween.img/inside-room5-14-12",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"13" :  {
					"png_path": "halloween.img/inside-room5-14-13",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"14" :  {
					"png_path": "halloween.img/inside-room5-14-14",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"15" :  {
					"png_path": "halloween.img/inside-room5-14-15",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"16" :  {
					"png_path": "halloween.img/inside-room5-14-16",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"17" :  {
					"png_path": "halloween.img/inside-room5-14-17",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"18" :  {
					"png_path": "halloween.img/inside-room5-14-18",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"19" :  {
					"png_path": "halloween.img/inside-room5-14-19",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"20" :  {
					"png_path": "halloween.img/inside-room5-14-20",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"21" :  {
					"png_path": "halloween.img/inside-room5-14-21",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"22" :  {
					"png_path": "halloween.img/inside-room5-14-22",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"23" :  {
					"png_path": "halloween.img/inside-room5-14-23",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"24" :  {
					"png_path": "halloween.img/inside-room5-14-24",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"25" :  {
					"png_path": "halloween.img/inside-room5-14-25",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"26" :  {
					"png_path": "halloween.img/inside-room5-14-26",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"27" :  {
					"png_path": "halloween.img/inside-room5-14-27",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"28" :  {
					"png_path": "halloween.img/inside-room5-14-28",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"29" :  {
					"png_path": "halloween.img/inside-room5-14-29",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"30" :  {
					"png_path": "halloween.img/inside-room5-14-30",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"31" :  {
					"png_path": "halloween.img/inside-room5-14-31",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"32" :  {
					"png_path": "halloween.img/inside-room5-14-32",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"33" :  {
					"png_path": "halloween.img/inside-room5-14-33",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"34" :  {
					"png_path": "halloween.img/inside-room5-14-34",
					"origin" : [19,27],
					"z" : 0,
					"delay" : 200,
				},
				"35" :  {
					"png_path": "halloween.img/inside-room5-14-35",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"36" :  {
					"png_path": "halloween.img/inside-room5-14-36",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"37" :  {
					"png_path": "halloween.img/inside-room5-14-37",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
				"38" :  {
					"png_path": "halloween.img/inside-room5-14-38",
					"origin" : [18,27],
					"z" : 0,
					"delay" : 200,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-15-0",
					"origin" : [0,0],
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-16-0",
					"origin" : [0,0],
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-17-0",
					"origin" : [0,0],
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-18-0",
					"origin" : [80,25],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-19-0",
					"origin" : [34,40],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-20-0",
					"origin" : [149,41],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-21-0",
					"origin" : [22,62],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-22-0",
					"origin" : [103,104],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-23-0",
					"origin" : [114,104],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-24-0",
					"origin" : [0,0],
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room5-25-0",
					"origin" : [0,0],
				},
			},
		},
		"room6" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room6-0-0",
					"origin" : [101,81],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room6-1-0",
					"origin" : [96,162],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room6-2-0",
					"origin" : [75,145],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room6-3-0",
					"origin" : [102,155],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room6-4-0",
					"origin" : [79,72],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room6-5-0",
					"origin" : [120,36],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room6-6-0",
					"origin" : [61,115],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room6-7-0",
					"origin" : [51,127],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room6-8-0",
					"origin" : [37,45],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room6-8-1",
					"origin" : [37,45],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room6-8-2",
					"origin" : [37,45],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room6-8-3",
					"origin" : [37,45],
					"z" : 0,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room6-8-4",
					"origin" : [37,45],
					"z" : 0,
				},
				"5" :  {
					"png_path": "halloween.img/inside-room6-8-5",
					"origin" : [37,45],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween.img/inside-room6-8-6",
					"origin" : [37,45],
					"z" : 0,
				},
				"7" :  {
					"png_path": "halloween.img/inside-room6-8-7",
					"origin" : [37,45],
					"z" : 0,
				},
				"8" :  {
					"png_path": "halloween.img/inside-room6-8-8",
					"origin" : [37,45],
					"z" : 0,
				},
				"9" :  {
					"png_path": "halloween.img/inside-room6-8-9",
					"origin" : [37,45],
					"z" : 0,
				},
				"10" :  {
					"png_path": "halloween.img/inside-room6-8-10",
					"origin" : [37,45],
					"z" : 0,
				},
				"11" :  {
					"png_path": "halloween.img/inside-room6-8-11",
					"origin" : [37,45],
					"z" : 0,
				},
				"12" :  {
					"png_path": "halloween.img/inside-room6-8-12",
					"origin" : [37,45],
					"z" : 0,
				},
				"13" :  {
					"png_path": "halloween.img/inside-room6-8-13",
					"origin" : [37,45],
					"z" : 0,
				},
				"14" :  {
					"png_path": "halloween.img/inside-room6-8-14",
					"origin" : [37,45],
					"z" : 0,
				},
				"15" :  {
					"png_path": "halloween.img/inside-room6-8-15",
					"origin" : [37,45],
					"z" : 0,
				},
				"16" :  {
					"png_path": "halloween.img/inside-room6-8-16",
					"origin" : [37,45],
					"z" : 0,
				},
				"17" :  {
					"png_path": "halloween.img/inside-room6-8-17",
					"origin" : [37,45],
					"z" : 0,
				},
				"18" :  {
					"png_path": "halloween.img/inside-room6-8-18",
					"origin" : [37,45],
					"z" : 0,
				},
				"19" :  {
					"png_path": "halloween.img/inside-room6-8-19",
					"origin" : [37,45],
					"z" : 0,
				},
				"20" :  {
					"png_path": "halloween.img/inside-room6-8-20",
					"origin" : [37,45],
					"z" : 0,
				},
				"21" :  {
					"png_path": "halloween.img/inside-room6-8-21",
					"origin" : [37,45],
					"z" : 0,
				},
			},
		},
		"room7" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-0-0",
					"origin" : [90,147],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-1-0",
					"origin" : [50,75],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-2-0",
					"origin" : [86,83],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-3-0",
					"origin" : [91,122],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-4-0",
					"origin" : [62,90],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-5-0",
					"origin" : [54,64],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-6-0",
					"origin" : [62,76],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-7-0",
					"origin" : [89,131],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-8-0",
					"origin" : [74,115],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-9-0",
					"origin" : [0,0],
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-10-0",
					"origin" : [66,76],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-11-0",
					"origin" : [136,163],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-12-0",
					"origin" : [0,0],
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room7-13-0",
					"origin" : [60,88],
					"z" : 0,
				},
				"remover" :  {
					"png_path": "halloween.img/inside-room7-13-remover",
					"origin" : [60,88],
				},
				"alpha" : 100,
				"dx" : -30,
				"dy" : 0,
			},
		},
		"room8" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room8-0-0",
					"origin" : [531,356],
					"z" : 0,
				},
			},
		},
		"common" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-0-0",
					"origin" : [41,31],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-1-0",
					"origin" : [41,31],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-2-0",
					"origin" : [30,28],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-3-0",
					"origin" : [30,28],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-4-0",
					"origin" : [30,28],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-5-0",
					"origin" : [48,49],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-6-0",
					"origin" : [34,47],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-7-0",
					"origin" : [55,76],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-8-0",
					"origin" : [54,97],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-9-0",
					"origin" : [76,40],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-10-0",
					"origin" : [47,39],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-11-0",
					"origin" : [0,0],
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-12-0",
					"origin" : [76,40],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-13-0",
					"origin" : [47,39],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-14-0",
					"origin" : [76,40],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-15-0",
					"origin" : [47,39],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-16-0",
					"origin" : [0,0],
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-17-0",
					"origin" : [0,0],
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-18-0",
					"origin" : [119,104],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-19-0",
					"origin" : [131,109],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-20-0",
					"origin" : [72,73],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-21-0",
					"origin" : [50,75],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-22-0",
					"origin" : [121,56],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-23-0",
					"origin" : [20,29],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-24-0",
					"origin" : [32,18],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-25-0",
					"origin" : [38,70],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-26-0",
					"origin" : [38,70],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-27-0",
					"origin" : [33,60],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-28-0",
					"origin" : [30,53],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-29-0",
					"origin" : [39,76],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-30-0",
					"origin" : [39,77],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "halloween.img/inside-common-31-0",
					"origin" : [40,79],
					"z" : 0,
				},
			},
		},
		"trap" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-trap-0-0",
					"origin" : [35,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"1" :  {
					"png_path": "halloween.img/inside-trap-0-1",
					"origin" : [34,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"2" :  {
					"png_path": "halloween.img/inside-trap-0-2",
					"origin" : [34,31],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"3" :  {
					"png_path": "halloween.img/inside-trap-0-0",
					"origin" : [35,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"4" :  {
					"png_path": "halloween.img/inside-trap-0-1",
					"origin" : [34,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"5" :  {
					"png_path": "halloween.img/inside-trap-0-2",
					"origin" : [34,31],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"6" :  {
					"png_path": "halloween.img/inside-trap-0-0",
					"origin" : [35,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"7" :  {
					"png_path": "halloween.img/inside-trap-0-1",
					"origin" : [34,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"8" :  {
					"png_path": "halloween.img/inside-trap-0-2",
					"origin" : [34,31],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"9" :  {
					"png_path": "halloween.img/inside-trap-0-0",
					"origin" : [35,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"10" :  {
					"png_path": "halloween.img/inside-trap-0-1",
					"origin" : [34,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"11" :  {
					"png_path": "halloween.img/inside-trap-0-2",
					"origin" : [34,31],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"12" :  {
					"png_path": "halloween.img/inside-trap-0-0",
					"origin" : [35,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"13" :  {
					"png_path": "halloween.img/inside-trap-0-1",
					"origin" : [34,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"14" :  {
					"png_path": "halloween.img/inside-trap-0-2",
					"origin" : [34,31],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"15" :  {
					"png_path": "halloween.img/inside-trap-0-15",
					"origin" : [35,30],
					"z" : 0,
					"delay" : 2800,
				},
				"obstacle" : 1,
				"dir" : 3,
				"damage" : 1,
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-trap-1-0",
					"origin" : [35,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"1" :  {
					"png_path": "halloween.img/inside-trap-1-1",
					"origin" : [34,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"2" :  {
					"png_path": "halloween.img/inside-trap-1-2",
					"origin" : [34,31],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"3" :  {
					"png_path": "halloween.img/inside-trap-1-0",
					"origin" : [35,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"4" :  {
					"png_path": "halloween.img/inside-trap-1-1",
					"origin" : [34,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"5" :  {
					"png_path": "halloween.img/inside-trap-1-2",
					"origin" : [34,31],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"6" :  {
					"png_path": "halloween.img/inside-trap-1-0",
					"origin" : [35,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"7" :  {
					"png_path": "halloween.img/inside-trap-1-1",
					"origin" : [34,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"8" :  {
					"png_path": "halloween.img/inside-trap-1-2",
					"origin" : [34,31],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"9" :  {
					"png_path": "halloween.img/inside-trap-1-0",
					"origin" : [35,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"10" :  {
					"png_path": "halloween.img/inside-trap-1-1",
					"origin" : [34,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"11" :  {
					"png_path": "halloween.img/inside-trap-1-2",
					"origin" : [34,31],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"12" :  {
					"png_path": "halloween.img/inside-trap-1-0",
					"origin" : [35,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"13" :  {
					"png_path": "halloween.img/inside-trap-1-1",
					"origin" : [34,30],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"14" :  {
					"png_path": "halloween.img/inside-trap-1-2",
					"origin" : [34,31],
					"z" : 0,
					"delay" : 150,
					"lt" : [-35,-30],
					"rb" : [32,29],
				},
				"15" :  {
					"png_path": "halloween.img/inside-trap-1-15",
					"origin" : [35,30],
					"z" : 0,
					"delay" : 4000,
				},
				"obstacle" : 1,
				"dir" : 9,
				"damage" : 1,
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-trap-2-0",
					"origin" : [16,-6],
					"z" : 0,
					"delay" : 150,
					"lt" : [-16,6],
					"rb" : [-5,11],
				},
				"1" :  {
					"png_path": "halloween.img/inside-trap-2-1",
					"origin" : [15,-3],
					"z" : 0,
					"delay" : 150,
					"lt" : [-15,3],
					"rb" : [2,11],
				},
				"2" :  {
					"png_path": "halloween.img/inside-trap-2-2",
					"origin" : [10,11],
					"z" : 0,
					"delay" : 150,
					"lt" : [-10,-11],
					"rb" : [13,9],
				},
				"3" :  {
					"png_path": "halloween.img/inside-trap-2-3",
					"origin" : [9,12],
					"z" : 0,
					"delay" : 150,
					"lt" : [-9,-12],
					"rb" : [15,7],
				},
				"4" :  {
					"png_path": "halloween.img/inside-trap-2-4",
					"origin" : [6,14],
					"z" : 0,
					"delay" : 150,
					"lt" : [-6,-14],
					"rb" : [17,7],
				},
				"5" :  {
					"png_path": "halloween.img/inside-trap-2-5",
					"origin" : [4,16],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "halloween.img/inside-trap-2-6",
					"origin" : [0,0],
					"z" : 0,
					"delay" : 1900,
				},
				"obstacle" : 1,
				"dir" : 3,
				"damage" : 1,
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-trap-3-0",
					"origin" : [16,-6],
					"z" : 0,
					"delay" : 150,
					"lt" : [-16,6],
					"rb" : [-5,11],
				},
				"1" :  {
					"png_path": "halloween.img/inside-trap-3-1",
					"origin" : [15,-3],
					"z" : 0,
					"delay" : 150,
					"lt" : [-15,3],
					"rb" : [2,11],
				},
				"2" :  {
					"png_path": "halloween.img/inside-trap-3-2",
					"origin" : [10,11],
					"z" : 0,
					"delay" : 150,
					"lt" : [-10,-11],
					"rb" : [13,9],
				},
				"3" :  {
					"png_path": "halloween.img/inside-trap-3-3",
					"origin" : [9,12],
					"z" : 0,
					"delay" : 150,
					"lt" : [-9,-12],
					"rb" : [15,7],
				},
				"4" :  {
					"png_path": "halloween.img/inside-trap-3-4",
					"origin" : [6,14],
					"z" : 0,
					"delay" : 150,
					"lt" : [-6,-14],
					"rb" : [17,7],
				},
				"5" :  {
					"png_path": "halloween.img/inside-trap-3-5",
					"origin" : [4,16],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "halloween.img/inside-trap-3-6",
					"origin" : [0,0],
					"z" : 0,
					"delay" : 2700,
				},
				"obstacle" : 1,
				"dir" : 3,
				"damage" : 1,
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-trap-4-0",
					"origin" : [-3,-4],
					"z" : 0,
					"lt" : [3,4],
					"rb" : [15,10],
				},
				"1" :  {
					"png_path": "halloween.img/inside-trap-4-1",
					"origin" : [4,-1],
					"z" : 0,
					"lt" : [-4,1],
					"rb" : [14,10],
				},
				"2" :  {
					"png_path": "halloween.img/inside-trap-4-2",
					"origin" : [15,13],
					"z" : 0,
					"lt" : [-15,-13],
					"rb" : [9,8],
				},
				"3" :  {
					"png_path": "halloween.img/inside-trap-4-3",
					"origin" : [17,14],
					"z" : 0,
					"lt" : [-17,-14],
					"rb" : [8,6],
				},
				"4" :  {
					"png_path": "halloween.img/inside-trap-4-4",
					"origin" : [19,16],
					"z" : 0,
					"lt" : [-19,-16],
					"rb" : [5,6],
				},
				"5" :  {
					"png_path": "halloween.img/inside-trap-4-5",
					"origin" : [21,18],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween.img/inside-trap-4-6",
					"origin" : [0,0],
					"z" : 0,
					"delay" : 1900,
				},
				"obstacle" : 1,
				"dir" : 9,
				"damage" : 1,
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-trap-5-0",
					"origin" : [-3,-4],
					"z" : 0,
					"lt" : [3,4],
					"rb" : [15,10],
				},
				"1" :  {
					"png_path": "halloween.img/inside-trap-5-1",
					"origin" : [4,-1],
					"z" : 0,
					"lt" : [-4,1],
					"rb" : [14,10],
				},
				"2" :  {
					"png_path": "halloween.img/inside-trap-5-2",
					"origin" : [15,13],
					"z" : 0,
					"lt" : [-15,-13],
					"rb" : [9,8],
				},
				"3" :  {
					"png_path": "halloween.img/inside-trap-5-3",
					"origin" : [17,14],
					"z" : 0,
					"lt" : [-17,-14],
					"rb" : [8,6],
				},
				"4" :  {
					"png_path": "halloween.img/inside-trap-5-4",
					"origin" : [19,16],
					"z" : 0,
					"lt" : [-19,-16],
					"rb" : [5,6],
				},
				"5" :  {
					"png_path": "halloween.img/inside-trap-5-5",
					"origin" : [21,18],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween.img/inside-trap-5-6",
					"origin" : [0,0],
					"z" : 0,
					"delay" : 2700,
				},
				"obstacle" : 1,
				"dir" : 9,
				"damage" : 1,
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-trap-6-0",
					"origin" : [31,-1],
					"z" : 0,
					"lt" : [-31,1],
					"rb" : [-8,5],
				},
				"1" :  {
					"png_path": "halloween.img/inside-trap-6-1",
					"origin" : [33,0],
					"z" : 0,
					"lt" : [-33,0],
					"rb" : [17,7],
				},
				"2" :  {
					"png_path": "halloween.img/inside-trap-6-2",
					"origin" : [10,15],
					"z" : 0,
					"lt" : [6,-15],
					"rb" : [39,17],
				},
				"3" :  {
					"png_path": "halloween.img/inside-trap-6-3",
					"origin" : [1,14],
					"z" : 0,
					"lt" : [16,-14],
					"rb" : [42,16],
				},
				"4" :  {
					"png_path": "halloween.img/inside-trap-6-4",
					"origin" : [-11,13],
					"z" : 0,
					"lt" : [20,-13],
					"rb" : [41,15],
				},
				"5" :  {
					"png_path": "halloween.img/inside-trap-6-5",
					"origin" : [-15,13],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween.img/inside-trap-6-6",
					"origin" : [0,0],
					"z" : 0,
					"delay" : 1900,
				},
				"obstacle" : 1,
				"dir" : 3,
				"damage" : 1,
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-trap-7-0",
					"origin" : [31,-1],
					"z" : 0,
					"lt" : [-31,1],
					"rb" : [-8,5],
				},
				"1" :  {
					"png_path": "halloween.img/inside-trap-7-1",
					"origin" : [33,0],
					"z" : 0,
					"lt" : [-33,0],
					"rb" : [17,7],
				},
				"2" :  {
					"png_path": "halloween.img/inside-trap-7-2",
					"origin" : [10,15],
					"z" : 0,
					"lt" : [6,-15],
					"rb" : [39,17],
				},
				"3" :  {
					"png_path": "halloween.img/inside-trap-7-3",
					"origin" : [1,14],
					"z" : 0,
					"lt" : [16,-14],
					"rb" : [42,16],
				},
				"4" :  {
					"png_path": "halloween.img/inside-trap-7-4",
					"origin" : [-11,13],
					"z" : 0,
					"lt" : [20,-13],
					"rb" : [41,15],
				},
				"5" :  {
					"png_path": "halloween.img/inside-trap-7-5",
					"origin" : [-15,13],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween.img/inside-trap-7-6",
					"origin" : [0,0],
					"z" : 0,
					"delay" : 2700,
				},
				"obstacle" : 1,
				"dir" : 3,
				"damage" : 1,
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-trap-8-0",
					"origin" : [-9,-1],
					"z" : 0,
					"lt" : [9,1],
					"rb" : [32,5],
				},
				"1" :  {
					"png_path": "halloween.img/inside-trap-8-1",
					"origin" : [16,0],
					"z" : 0,
					"lt" : [-16,0],
					"rb" : [34,7],
				},
				"2" :  {
					"png_path": "halloween.img/inside-trap-8-2",
					"origin" : [38,15],
					"z" : 0,
					"lt" : [-38,-15],
					"rb" : [-5,17],
				},
				"3" :  {
					"png_path": "halloween.img/inside-trap-8-3",
					"origin" : [41,14],
					"z" : 0,
					"lt" : [-41,-14],
					"rb" : [-15,16],
				},
				"4" :  {
					"png_path": "halloween.img/inside-trap-8-4",
					"origin" : [40,13],
					"z" : 0,
					"lt" : [-40,-13],
					"rb" : [-10,15],
				},
				"5" :  {
					"png_path": "halloween.img/inside-trap-8-5",
					"origin" : [40,13],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween.img/inside-trap-8-6",
					"origin" : [0,0],
					"z" : 0,
					"delay" : 1900,
				},
				"obstacle" : 1,
				"dir" : 9,
				"damage" : 1,
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-trap-9-0",
					"origin" : [-9,-1],
					"z" : 0,
					"lt" : [9,1],
					"rb" : [32,5],
				},
				"1" :  {
					"png_path": "halloween.img/inside-trap-9-1",
					"origin" : [16,0],
					"z" : 0,
					"lt" : [-16,0],
					"rb" : [34,7],
				},
				"2" :  {
					"png_path": "halloween.img/inside-trap-9-2",
					"origin" : [38,15],
					"z" : 0,
					"lt" : [-38,-15],
					"rb" : [-5,17],
				},
				"3" :  {
					"png_path": "halloween.img/inside-trap-9-3",
					"origin" : [41,14],
					"z" : 0,
					"lt" : [-41,-14],
					"rb" : [-15,16],
				},
				"4" :  {
					"png_path": "halloween.img/inside-trap-9-4",
					"origin" : [40,13],
					"z" : 0,
					"lt" : [-40,-13],
					"rb" : [-10,15],
				},
				"5" :  {
					"png_path": "halloween.img/inside-trap-9-5",
					"origin" : [40,13],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween.img/inside-trap-9-6",
					"origin" : [0,0],
					"z" : 0,
					"delay" : 2700,
				},
				"obstacle" : 1,
				"dir" : 9,
				"damage" : 1,
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-trap-10-0",
					"origin" : [28,20],
					"z" : 0,
					"lt" : [-28,-10],
					"rb" : [33,17],
				},
				"1" :  {
					"png_path": "halloween.img/inside-trap-10-1",
					"origin" : [39,14],
					"z" : 0,
					"lt" : [-39,-13],
					"rb" : [45,24],
				},
				"2" :  {
					"png_path": "halloween.img/inside-trap-10-2",
					"origin" : [62,20],
					"z" : 0,
					"lt" : [-62,-20],
					"rb" : [64,26],
				},
				"3" :  {
					"png_path": "halloween.img/inside-trap-10-3",
					"origin" : [105,37],
					"z" : 0,
					"lt" : [-96,-37],
					"rb" : [112,22],
				},
				"4" :  {
					"png_path": "halloween.img/inside-trap-10-4",
					"origin" : [105,39],
					"z" : 0,
					"lt" : [-96,-39],
					"rb" : [116,20],
				},
				"5" :  {
					"png_path": "halloween.img/inside-trap-10-5",
					"origin" : [107,42],
					"z" : 0,
					"lt" : [-104,-42],
					"rb" : [116,18],
				},
				"6" :  {
					"png_path": "halloween.img/inside-trap-10-6",
					"origin" : [108,43],
					"z" : 0,
					"lt" : [-108,-43],
					"rb" : [116,18],
				},
				"7" :  {
					"png_path": "halloween.img/inside-trap-10-7",
					"origin" : [107,43],
					"z" : 0,
				},
				"8" :  {
					"png_path": "halloween.img/inside-trap-10-8",
					"origin" : [106,43],
					"z" : 0,
				},
				"9" :  {
					"png_path": "halloween.img/inside-trap-10-9",
					"origin" : [0,0],
					"z" : 0,
					"delay" : 5000,
				},
				"obstacle" : 1,
				"dir" : 3,
				"damage" : 1,
			},
		},
		"npc" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-npc-0-0",
					"origin" : [24,21],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-npc-1-0",
					"origin" : [8,10],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-npc-2-0",
					"origin" : [3,4],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween.img/inside-npc-2-1",
					"origin" : [4,5],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/inside-npc-2-2",
					"origin" : [5,6],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/inside-npc-2-3",
					"origin" : [7,8],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween.img/inside-npc-2-4",
					"origin" : [15,16],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween.img/inside-npc-2-5",
					"origin" : [18,19],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "halloween.img/inside-npc-2-6",
					"origin" : [19,20],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "halloween.img/inside-npc-2-7",
					"origin" : [18,19],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "halloween.img/inside-npc-2-8",
					"origin" : [13,14],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "halloween.img/inside-npc-2-9",
					"origin" : [9,10],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "halloween.img/inside-npc-2-10",
					"origin" : [7,8],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "halloween.img/inside-npc-2-11",
					"origin" : [4,5],
					"z" : 0,
					"delay" : 150,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-npc-3-0",
					"origin" : [154,58],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-npc-4-0",
					"origin" : [40,26],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-npc-5-0",
					"origin" : [41,44],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-npc-6-0",
					"origin" : [53,29],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-npc-7-0",
					"origin" : [43,23],
					"z" : 0,
				},
			},
		},
		"room9" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-0-0",
					"origin" : [487,226],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-1-0",
					"origin" : [481,320],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-2-0",
					"origin" : [120,114],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-3-0",
					"origin" : [39,114],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-4-0",
					"origin" : [63,65],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-5-0",
					"origin" : [136,92],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-6-0",
					"origin" : [48,29],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-7-0",
					"origin" : [47,54],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room9-7-1",
					"origin" : [46,53],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room9-7-2",
					"origin" : [46,53],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room9-7-3",
					"origin" : [45,53],
					"z" : 0,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room9-7-4",
					"origin" : [46,53],
					"z" : 0,
				},
				"5" :  {
					"png_path": "halloween.img/inside-room9-7-5",
					"origin" : [46,53],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-8-0",
					"origin" : [121,115],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-9-0",
					"origin" : [172,104],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-10-0",
					"origin" : [77,58],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-11-0",
					"origin" : [77,58],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-12-0",
					"origin" : [77,58],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-13-0",
					"origin" : [97,115],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-14-0",
					"origin" : [52,32],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-15-0",
					"origin" : [103,32],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-16-0",
					"origin" : [103,32],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-17-0",
					"origin" : [29,24],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-18-0",
					"origin" : [130,109],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-19-0",
					"origin" : [20,15],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room9-19-1",
					"origin" : [28,14],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room9-19-2",
					"origin" : [34,14],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room9-19-3",
					"origin" : [37,13],
					"z" : 0,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room9-19-4",
					"origin" : [37,13],
					"z" : 0,
				},
				"5" :  {
					"png_path": "halloween.img/inside-room9-19-5",
					"origin" : [37,13],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween.img/inside-room9-19-6",
					"origin" : [34,14],
					"z" : 0,
				},
				"7" :  {
					"png_path": "halloween.img/inside-room9-19-7",
					"origin" : [28,14],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-20-0",
					"origin" : [49,74],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-21-0",
					"origin" : [24,37],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-22-0",
					"origin" : [34,14],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/inside-room9-22-1",
					"origin" : [37,13],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/inside-room9-22-2",
					"origin" : [37,13],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween.img/inside-room9-22-3",
					"origin" : [37,13],
					"z" : 0,
				},
				"4" :  {
					"png_path": "halloween.img/inside-room9-22-4",
					"origin" : [34,14],
					"z" : 0,
				},
				"5" :  {
					"png_path": "halloween.img/inside-room9-22-5",
					"origin" : [28,14],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween.img/inside-room9-22-6",
					"origin" : [20,15],
					"z" : 0,
				},
				"7" :  {
					"png_path": "halloween.img/inside-room9-22-7",
					"origin" : [28,14],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-23-0",
					"origin" : [79,75],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-24-0",
					"origin" : [94,104],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-25-0",
					"origin" : [78,19],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-26-0",
					"origin" : [38,19],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "halloween.img/inside-room9-27-0",
					"origin" : [21,19],
					"z" : 0,
				},
			},
		},
	},
	"field" :  {
		"wall" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-0-0",
					"origin" : [62,80],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-1-0",
					"origin" : [62,80],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-2-0",
					"origin" : [62,80],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-3-0",
					"origin" : [130,98],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-4-0",
					"origin" : [132,102],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-5-0",
					"origin" : [62,80],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-6-0",
					"origin" : [62,80],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-7-0",
					"origin" : [62,80],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-8-0",
					"origin" : [243,131],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-9-0",
					"origin" : [145,203],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-10-0",
					"origin" : [104,143],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-11-0",
					"origin" : [163,316],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-12-0",
					"origin" : [53,67],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/field-wall-13-0",
					"origin" : [153,198],
					"z" : 0,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/field-acc-0-0",
					"origin" : [37,19],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/field-acc-1-0",
					"origin" : [35,15],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/field-acc-2-0",
					"origin" : [21,32],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/field-acc-3-0",
					"origin" : [26,22],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/field-acc-4-0",
					"origin" : [25,20],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/field-acc-5-0",
					"origin" : [44,20],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/field-acc-6-0",
					"origin" : [0,0],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/field-acc-7-0",
					"origin" : [36,48],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/field-acc-8-0",
					"origin" : [36,48],
					"z" : 0,
				},
			},
		},
		"wood" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/field-wood-0-0",
					"origin" : [129,154],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/field-wood-1-0",
					"origin" : [92,134],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/field-wood-2-0",
					"origin" : [113,148],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/field-wood-3-0",
					"origin" : [98,150],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/field-wood-4-0",
					"origin" : [39,10],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/field-wood-5-0",
					"origin" : [86,132],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/field-wood-6-0",
					"origin" : [96,103],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/field-wood-7-0",
					"origin" : [102,108],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/field-wood-8-0",
					"origin" : [113,109],
					"z" : 0,
				},
			},
		},
		"house" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/field-house-0-0",
					"origin" : [253,129],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/field-house-1-0",
					"origin" : [246,115],
					"z" : 0,
				},
			},
		},
		"amber" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/field-amber-0-0",
					"origin" : [105,69],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/field-amber-1-0",
					"origin" : [211,58],
					"z" : 0,
					"ladder" :  {
						"0" : [-200,204],
						"1" : [-24,222],
						"2" : [146,206],
						"3" : [-122,98],
						"4" : [92,105],
						"5" : [-23,106],
					},
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/field-amber-2-0",
					"origin" : [65,120],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/field-amber-3-0",
					"origin" : [74,131],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/field-amber-4-0",
					"origin" : [78,125],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/field-amber-5-0",
					"origin" : [198,34],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/field-amber-6-0",
					"origin" : [208,43],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/field-amber-7-0",
					"origin" : [339,259],
					"z" : 0,
				},
			},
		},
		"2011halloween" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-0-0",
					"origin" : [86,132],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-1-0",
					"origin" : [96,103],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-2-0",
					"origin" : [102,108],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-3-0",
					"origin" : [113,109],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-4-0",
					"origin" : [70,70],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-5-0",
					"origin" : [64,71],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-6-0",
					"origin" : [64,72],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-7-0",
					"origin" : [64,70],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-8-0",
					"origin" : [70,72],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-9-0",
					"origin" : [64,70],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-10-0",
					"origin" : [64,72],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-11-0",
					"origin" : [64,71],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-12-0",
					"origin" : [207,250],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-13-0",
					"origin" : [215,252],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-14-0",
					"origin" : [351,51],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-15-0",
					"origin" : [284,190],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-16-0",
					"origin" : [284,159],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "halloween.img/field-2011halloween-17-0",
					"origin" : [260,60],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/field-2011halloween-17-1",
					"origin" : [179,105],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/field-2011halloween-17-2",
					"origin" : [143,38],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween.img/field-2011halloween-17-3",
					"origin" : [104,75],
					"z" : 0,
				},
				"4" :  {
					"png_path": "halloween.img/field-2011halloween-17-4",
					"origin" : [268,163],
					"z" : 0,
				},
			},
		},
	},
	"castle" :  {
		"mainHall" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/castle-mainHall-0-0",
					"origin" : [209,309],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/castle-mainHall-1-0",
					"origin" : [178,309],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/castle-mainHall-2-0",
					"origin" : [213,309],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/castle-mainHall-3-0",
					"origin" : [125,75],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/castle-mainHall-4-0",
					"origin" : [125,75],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/castle-mainHall-5-0",
					"origin" : [125,75],
					"z" : 0,
				},
			},
		},
		"ani" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/castle-ani-0-0",
					"origin" : [31,31],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 900,
				},
				"1" :  {
					"png_path": "halloween.img/castle-ani-0-1",
					"origin" : [29,29],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 900,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/castle-ani-1-0",
					"origin" : [31,31],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 900,
				},
				"1" :  {
					"png_path": "halloween.img/castle-ani-1-1",
					"origin" : [29,29],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 900,
				},
			},
		},
		"danceHall" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/castle-danceHall-0-0",
					"origin" : [66,53],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/castle-danceHall-1-0",
					"origin" : [91,53],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/castle-danceHall-2-0",
					"origin" : [91,62],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/castle-danceHall-3-0",
					"origin" : [66,54],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/castle-danceHall-4-0",
					"origin" : [418,141],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/castle-danceHall-5-0",
					"origin" : [120,138],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/castle-danceHall-6-0",
					"origin" : [44,88],
					"z" : 0,
					"delay" : 210,
				},
				"1" :  {
					"png_path": "halloween.img/castle-danceHall-6-1",
					"origin" : [48,88],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "halloween.img/castle-danceHall-6-2",
					"origin" : [50,88],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "halloween.img/castle-danceHall-6-3",
					"origin" : [48,88],
					"z" : 0,
					"delay" : 210,
				},
				"4" :  {
					"png_path": "halloween.img/castle-danceHall-6-4",
					"origin" : [44,88],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "halloween.img/castle-danceHall-6-5",
					"origin" : [26,87],
					"z" : 0,
					"delay" : 210,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/castle-danceHall-7-0",
					"origin" : [47,38],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/castle-danceHall-8-0",
					"origin" : [49,17],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "halloween.img/castle-danceHall-8-1",
					"origin" : [48,16],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "halloween.img/castle-danceHall-8-2",
					"origin" : [47,16],
					"z" : 0,
					"delay" : 180,
				},
			},
		},
	},
	"bistro" :  {
		"wall" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-wall-0-0",
					"origin" : [188,312],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-wall-1-0",
					"origin" : [188,312],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-wall-2-0",
					"origin" : [188,312],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-wall-3-0",
					"origin" : [188,312],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-wall-4-0",
					"origin" : [188,312],
					"z" : 0,
				},
			},
		},
		"roof" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-roof-0-0",
					"origin" : [205,84],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-roof-1-0",
					"origin" : [60,61],
					"z" : 0,
				},
			},
		},
		"foot" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot-0-0",
					"origin" : [125,75],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot-1-0",
					"origin" : [125,75],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot-2-0",
					"origin" : [125,75],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot-3-0",
					"origin" : [250,75],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot-4-0",
					"origin" : [125,75],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot-5-0",
					"origin" : [125,75],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot-6-0",
					"origin" : [125,75],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot-7-0",
					"origin" : [250,75],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot-8-0",
					"origin" : [33,18],
					"z" : 0,
				},
			},
		},
		"foot2" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot2-0-0",
					"origin" : [136,17],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot2-1-0",
					"origin" : [125,17],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot2-2-0",
					"origin" : [139,17],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot2-3-0",
					"origin" : [125,17],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot2-4-0",
					"origin" : [125,17],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot2-5-0",
					"origin" : [125,17],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-foot2-6-0",
					"origin" : [128,17],
					"z" : 0,
				},
			},
		},
		"sparkAni" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-sparkAni-0-0",
					"origin" : [4,28],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-sparkAni-0-1",
					"origin" : [3,28],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/bistro-sparkAni-0-2",
					"origin" : [2,32],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-sparkAni-1-0",
					"origin" : [-47,34],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-sparkAni-1-1",
					"origin" : [-47,34],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/bistro-sparkAni-1-2",
					"origin" : [-47,33],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-sparkAni-2-0",
					"origin" : [-107,38],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-sparkAni-2-1",
					"origin" : [-107,33],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/bistro-sparkAni-2-2",
					"origin" : [-107,31],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-sparkAni-3-0",
					"origin" : [-167,31],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-sparkAni-3-1",
					"origin" : [-167,37],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/bistro-sparkAni-3-2",
					"origin" : [-167,34],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-sparkAni-4-0",
					"origin" : [-227,32],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-sparkAni-4-1",
					"origin" : [-227,28],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/bistro-sparkAni-4-2",
					"origin" : [-227,28],
					"z" : 0,
				},
			},
		},
		"beltAni" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-beltAni-0-0",
					"origin" : [35,51],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-beltAni-0-1",
					"origin" : [34,51],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-beltAni-1-0",
					"origin" : [32,54],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-beltAni-1-1",
					"origin" : [31,54],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-beltAni-2-0",
					"origin" : [19,23],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-beltAni-2-1",
					"origin" : [19,23],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-beltAni-3-0",
					"origin" : [39,23],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-beltAni-3-1",
					"origin" : [39,23],
					"z" : 0,
				},
			},
		},
		"lightAni" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-lightAni-0-0",
					"origin" : [31,31],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 900,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-lightAni-0-1",
					"origin" : [31,31],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 900,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-lightAni-1-0",
					"origin" : [23,23],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 900,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-lightAni-1-1",
					"origin" : [23,23],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 900,
				},
			},
		},
		"Goal" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-Goal-0-0",
					"origin" : [144,125],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-Goal-1-0",
					"origin" : [-75,103],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-Goal-1-1",
					"origin" : [-74,103],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/bistro-Goal-1-2",
					"origin" : [-73,103],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween.img/bistro-Goal-1-3",
					"origin" : [-75,103],
					"z" : 0,
				},
				"4" :  {
					"png_path": "halloween.img/bistro-Goal-1-4",
					"origin" : [-74,103],
					"z" : 0,
				},
				"5" :  {
					"png_path": "halloween.img/bistro-Goal-1-5",
					"origin" : [-73,103],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-Goal-2-0",
					"origin" : [60,304],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-Goal-2-1",
					"origin" : [72,302],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween.img/bistro-Goal-2-2",
					"origin" : [88,301],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween.img/bistro-Goal-2-3",
					"origin" : [96,270],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween.img/bistro-Goal-2-4",
					"origin" : [102,239],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween.img/bistro-Goal-2-5",
					"origin" : [109,242],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "halloween.img/bistro-Goal-2-6",
					"origin" : [111,240],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "halloween.img/bistro-Goal-2-7",
					"origin" : [156,297],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "halloween.img/bistro-Goal-2-8",
					"origin" : [162,300],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "halloween.img/bistro-Goal-2-9",
					"origin" : [164,302],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "halloween.img/bistro-Goal-2-10",
					"origin" : [164,304],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "halloween.img/bistro-Goal-2-11",
					"origin" : [-12,305],
					"z" : 0,
					"delay" : 150,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween.img/bistro-Goal-3-0",
					"origin" : [-73,193],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween.img/bistro-Goal-3-1",
					"origin" : [-79,193],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween.img/bistro-Goal-3-2",
					"origin" : [-74,194],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween.img/bistro-Goal-3-3",
					"origin" : [-73,196],
					"z" : 0,
				},
				"4" :  {
					"png_path": "halloween.img/bistro-Goal-3-4",
					"origin" : [-79,195],
					"z" : 0,
				},
				"5" :  {
					"png_path": "halloween.img/bistro-Goal-3-5",
					"origin" : [-74,194],
					"z" : 0,
				},
			},
		},
	},
};

