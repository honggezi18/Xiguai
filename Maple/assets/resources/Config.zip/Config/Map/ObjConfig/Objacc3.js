var Objacc3 = Objacc3 || { }; 
Objacc3 =   {
	"id":"acc3",
	"snowyLightrock" :  {
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-0-0",
					"origin" : [94,157],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-1-0",
					"origin" : [97,153],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-2-0",
					"origin" : [94,143],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-3-0",
					"origin" : [119,147],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-4-0",
					"origin" : [55,68],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-5-0",
					"origin" : [49,51],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-6-0",
					"origin" : [95,32],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-7-0",
					"origin" : [64,49],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-8-0",
					"origin" : [66,37],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-9-0",
					"origin" : [84,45],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-10-0",
					"origin" : [67,45],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-11-0",
					"origin" : [48,16],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-12-0",
					"origin" : [86,48],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-13-0",
					"origin" : [81,49],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-14-0",
					"origin" : [65,38],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-15-0",
					"origin" : [49,41],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-16-0",
					"origin" : [52,44],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-17-0",
					"origin" : [47,46],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-18-0",
					"origin" : [45,21],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-19-0",
					"origin" : [54,36],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-20-0",
					"origin" : [50,24],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-21-0",
					"origin" : [93,113],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-22-0",
					"origin" : [60,91],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-23-0",
					"origin" : [79,87],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-24-0",
					"origin" : [60,60],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-nature-25-0",
					"origin" : [50,53],
					"z" : 0,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-0-0",
					"origin" : [37,25],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-1-0",
					"origin" : [24,25],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-2-0",
					"origin" : [107,43],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-3-0",
					"origin" : [15,43],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-4-0",
					"origin" : [50,71],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-7-0",
					"origin" : [89,37],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-10-0",
					"origin" : [0,0],
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-11-0",
					"origin" : [116,66],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-13-0",
					"origin" : [105,45],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-14-0",
					"origin" : [104,45],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-15-0",
					"origin" : [36,46],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-16-0",
					"origin" : [56,145],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-17-0",
					"origin" : [0,0],
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-18-0",
					"origin" : [32,25],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-19-0",
					"origin" : [0,0],
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-20-0",
					"origin" : [0,0],
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-21-0",
					"origin" : [36,16],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-22-0",
					"origin" : [38,65],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-23-0",
					"origin" : [0,0],
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-24-0",
					"origin" : [0,0],
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-25-0",
					"origin" : [0,0],
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-26-0",
					"origin" : [0,0],
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-27-0",
					"origin" : [0,0],
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-28-0",
					"origin" : [0,0],
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-29-0",
					"origin" : [209,152],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-30-0",
					"origin" : [43,23],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-19,23],
					"1" : [9,23],
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-31-0",
					"origin" : [165,97],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-74,91],
					"1" : [-52,91],
					"2" : [27,91],
					"3" : [52,91],
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-32-0",
					"origin" : [209,162],
					"z" : 0,
				},
			},
			"33" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-33-0",
					"origin" : [175,162],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-5-0",
					"origin" : [104,36],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-6-0",
					"origin" : [88,37],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-8-0",
					"origin" : [39,21],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-9-0",
					"origin" : [35,26],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-artificiality-12-0",
					"origin" : [59,37],
					"z" : 0,
				},
			},
		},
		"top" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-top-0-0",
					"origin" : [335,128],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-top-1-0",
					"origin" : [324,114],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-top-2-0",
					"origin" : [324,113],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-top-3-0",
					"origin" : [336,27],
					"z" : 0,
				},
			},
		},
		"quest" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-quest-0-0",
					"origin" : [81,163],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-quest-1-0",
					"origin" : [82,95],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-quest-2-0",
					"origin" : [83,162],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-quest-3-0",
					"origin" : [59,82],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-quest-4-0",
					"origin" : [59,82],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/snowyLightrock-quest-5-0",
					"origin" : [59,82],
					"z" : 0,
				},
			},
		},
	},
	"trunk" :  {
		"0" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/trunk-0-0-0",
					"origin" : [81,65],
					"z" : 0,
				},
			},
		},
		"1" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/trunk-1-0-0",
					"origin" : [138,67],
					"z" : 0,
				},
			},
		},
		"2" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/trunk-2-0-0",
					"origin" : [6,4],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "acc3.img/trunk-2-0-1",
					"origin" : [6,2],
					"z" : 0,
					"delay" : 50,
				},
				"2" :  {
					"png_path": "acc3.img/trunk-2-0-0",
					"origin" : [6,4],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "acc3.img/trunk-2-0-1",
					"origin" : [6,2],
					"z" : 0,
					"delay" : 50,
				},
				"4" :  {
					"png_path": "acc3.img/trunk-2-0-4",
					"origin" : [6,4],
					"z" : 0,
					"delay" : 3000,
				},
			},
		},
	},
	"skyStation" :  {
		"set1" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-0-0",
					"origin" : [33,53],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-1-0",
					"origin" : [32,53],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-2-0",
					"origin" : [33,53],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-3-0",
					"origin" : [25,46],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-4-0",
					"origin" : [25,46],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-5-0",
					"origin" : [25,46],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-6-0",
					"origin" : [25,46],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-7-0",
					"origin" : [25,35],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-8-0",
					"origin" : [32,54],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-9-0",
					"origin" : [33,54],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-10-0",
					"origin" : [32,54],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-11-0",
					"origin" : [96,28],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-12-0",
					"origin" : [151,29],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-13-0",
					"origin" : [151,28],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-14-0",
					"origin" : [35,53],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-15-0",
					"origin" : [25,46],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-16-0",
					"origin" : [32,54],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-17-0",
					"origin" : [151,28],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-18-0",
					"origin" : [45,96],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-19-0",
					"origin" : [85,79],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-20-0",
					"origin" : [85,111],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set1-21-0",
					"origin" : [35,245],
					"z" : 0,
				},
			},
		},
		"set2" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-0-0",
					"origin" : [0,0],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-1-0",
					"origin" : [32,53],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-2-0",
					"origin" : [33,53],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-3-0",
					"origin" : [25,46],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-4-0",
					"origin" : [0,0],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-5-0",
					"origin" : [0,0],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-6-0",
					"origin" : [25,46],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-7-0",
					"origin" : [0,0],
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-8-0",
					"origin" : [32,54],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-9-0",
					"origin" : [33,54],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-10-0",
					"origin" : [0,0],
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-11-0",
					"origin" : [0,0],
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-12-0",
					"origin" : [0,0],
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-13-0",
					"origin" : [0,0],
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-14-0",
					"origin" : [36,53],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-15-0",
					"origin" : [26,46],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-set2-16-0",
					"origin" : [33,54],
					"z" : 0,
				},
			},
		},
		"ivy" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-0-0",
					"origin" : [34,54],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-1-0",
					"origin" : [36,52],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-2-0",
					"origin" : [36,53],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-3-0",
					"origin" : [33,31],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-4-0",
					"origin" : [32,35],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-5-0",
					"origin" : [55,38],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-6-0",
					"origin" : [53,38],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-7-0",
					"origin" : [28,34],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-8-0",
					"origin" : [28,42],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-9-0",
					"origin" : [25,22],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-10-0",
					"origin" : [8,9],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-11-0",
					"origin" : [9,6],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-12-0",
					"origin" : [8,7],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-13-0",
					"origin" : [10,9],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-14-0",
					"origin" : [8,9],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-15-0",
					"origin" : [9,6],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-16-0",
					"origin" : [8,7],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-17-0",
					"origin" : [37,45],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-18-0",
					"origin" : [32,42],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-19-0",
					"origin" : [37,40],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-20-0",
					"origin" : [41,45],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-21-0",
					"origin" : [38,43],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-22-0",
					"origin" : [38,52],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-ivy-23-0",
					"origin" : [0,0],
				},
			},
		},
		"station" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-0-0",
					"origin" : [116,193],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-1-0",
					"origin" : [53,198],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-2-0",
					"origin" : [118,194],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-3-0",
					"origin" : [53,198],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-4-0",
					"origin" : [170,206],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-5-0",
					"origin" : [41,83],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-6-0",
					"origin" : [66,70],
					"z" : 0,
					"a0" : 0,
					"delay" : 2200,
				},
				"1" :  {
					"png_path": "acc3.img/skyStation-station-6-1",
					"origin" : [66,70],
					"z" : 0,
					"a0" : 255,
					"delay" : 2200,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-7-0",
					"origin" : [99,42],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-8-0",
					"origin" : [75,42],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-9-0",
					"origin" : [75,42],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-10-0",
					"origin" : [100,42],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-11-0",
					"origin" : [145,177],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-12-0",
					"origin" : [68,48],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-13-0",
					"origin" : [3,25],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-station-14-0",
					"origin" : [78,55],
					"z" : 0,
				},
			},
		},
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-0-0",
					"origin" : [56,117],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-1-0",
					"origin" : [57,119],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-2-0",
					"origin" : [56,116],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-3-0",
					"origin" : [57,117],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-4-0",
					"origin" : [56,119],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-5-0",
					"origin" : [56,116],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-6-0",
					"origin" : [53,117],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-7-0",
					"origin" : [53,119],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-8-0",
					"origin" : [56,116],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-9-0",
					"origin" : [32,38],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-10-0",
					"origin" : [26,26],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-11-0",
					"origin" : [34,13],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-12-0",
					"origin" : [22,12],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-13-0",
					"origin" : [19,11],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-nature-14-0",
					"origin" : [14,12],
					"z" : 0,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-0-0",
					"origin" : [140,178],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-1-0",
					"origin" : [0,0],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-2-0",
					"origin" : [30,52],
					"z" : 0,
					"moveType" : 2,
					"moveH" : 5,
					"delay" : 100,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-3-0",
					"origin" : [140,181],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-4-0",
					"origin" : [30,52],
					"z" : 0,
					"moveType" : 2,
					"moveH" : 5,
					"delay" : 100,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-5-0",
					"origin" : [53,27],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-6-0",
					"origin" : [53,27],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-7-0",
					"origin" : [56,27],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-8-0",
					"origin" : [50,33],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-9-0",
					"origin" : [87,23],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-10-0",
					"origin" : [0,0],
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-11-0",
					"origin" : [43,51],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-30,-11],
					"1" : [-13,-11],
					"2" : [4,-11],
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-12-0",
					"origin" : [87,32],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-26,8],
					"1" : [-10,8],
					"2" : [7,8],
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-13-0",
					"origin" : [101,45],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-14-0",
					"origin" : [79,33],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-15-0",
					"origin" : [130,111],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-16-0",
					"origin" : [85,111],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-17-0",
					"origin" : [130,108],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-18-0",
					"origin" : [88,106],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-19-0",
					"origin" : [127,100],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-20-0",
					"origin" : [38,70],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-21-0",
					"origin" : [127,101],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-22-0",
					"origin" : [46,71],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-29-0",
					"origin" : [185,109],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-30-0",
					"origin" : [47,23],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-31-0",
					"origin" : [24,24],
					"z" : 0,
					"moveType" : 2,
					"moveH" : 3,
					"delay" : 100,
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-32-0",
					"origin" : [30,52],
					"z" : 0,
					"moveType" : 2,
					"moveH" : 5,
					"delay" : 100,
				},
			},
			"33" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-33-0",
					"origin" : [25,35],
					"z" : 0,
				},
			},
			"34" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-34-0",
					"origin" : [31,36],
					"z" : 0,
				},
			},
			"35" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-35-0",
					"origin" : [29,20],
					"z" : 0,
				},
			},
			"36" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-36-0",
					"origin" : [31,36],
					"z" : 0,
				},
			},
			"37" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-37-0",
					"origin" : [22,27],
					"z" : 0,
				},
			},
			"38" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-38-0",
					"origin" : [76,96],
					"z" : 0,
				},
			},
			"39" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-39-0",
					"origin" : [33,28],
					"z" : 0,
				},
			},
			"40" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-40-0",
					"origin" : [54,39],
					"z" : 0,
					"moveType" : 2,
					"moveH" : 5,
					"moveP" : 3000,
				},
			},
			"41" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-artificiality-41-0",
					"origin" : [53,27],
					"z" : 0,
				},
			},
		},
		"cloud" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-0-0",
					"origin" : [89,51],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-1-0",
					"origin" : [82,51],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-2-0",
					"origin" : [150,73],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-3-0",
					"origin" : [95,44],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-4-0",
					"origin" : [92,49],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-5-0",
					"origin" : [152,60],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-6-0",
					"origin" : [200,75],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-7-0",
					"origin" : [371,79],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-8-0",
					"origin" : [294,75],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-9-0",
					"origin" : [89,51],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-10-0",
					"origin" : [82,51],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-11-0",
					"origin" : [150,73],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-12-0",
					"origin" : [95,44],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-13-0",
					"origin" : [92,49],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-14-0",
					"origin" : [152,60],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-15-0",
					"origin" : [200,75],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-16-0",
					"origin" : [89,51],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-17-0",
					"origin" : [82,51],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-18-0",
					"origin" : [150,73],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-19-0",
					"origin" : [95,44],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-20-0",
					"origin" : [92,49],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-21-0",
					"origin" : [0,0],
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-22-0",
					"origin" : [200,75],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-23-0",
					"origin" : [0,0],
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-cloud-24-0",
					"origin" : [294,75],
					"z" : 0,
				},
			},
		},
		"market" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-market-0-0",
					"origin" : [184,134],
					"z" : 0,
				},
			},
		},
		"harp" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-harp-0-0",
					"origin" : [211,197],
					"z" : 0,
				},
			},
		},
		"quest" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-quest-0-0",
					"origin" : [144,84],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-quest-1-0",
					"origin" : [80,521],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-quest-2-0",
					"origin" : [140,175],
					"z" : 0,
				},
			},
		},
		"jump" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-jump-0-0",
					"origin" : [38,70],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc3.img/skyStation-jump-0-1",
					"origin" : [38,63],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc3.img/skyStation-jump-0-2",
					"origin" : [38,67],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc3.img/skyStation-jump-0-3",
					"origin" : [38,72],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc3.img/skyStation-jump-0-4",
					"origin" : [38,76],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-jump-1-0",
					"origin" : [55,107],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc3.img/skyStation-jump-1-1",
					"origin" : [55,100],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc3.img/skyStation-jump-1-2",
					"origin" : [55,104],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc3.img/skyStation-jump-1-3",
					"origin" : [55,110],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc3.img/skyStation-jump-1-4",
					"origin" : [55,112],
					"z" : 0,
				},
			},
		},
		"pvp" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/skyStation-pvp-0-0",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc3.img/skyStation-pvp-0-1",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc3.img/skyStation-pvp-0-2",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc3.img/skyStation-pvp-0-3",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc3.img/skyStation-pvp-0-4",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc3.img/skyStation-pvp-0-5",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc3.img/skyStation-pvp-0-6",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 8000,
				},
				"7" :  {
					"png_path": "acc3.img/skyStation-pvp-0-7",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 130,
				},
				"8" :  {
					"png_path": "acc3.img/skyStation-pvp-0-8",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "acc3.img/skyStation-pvp-0-9",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "acc3.img/skyStation-pvp-0-10",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "acc3.img/skyStation-pvp-0-11",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"12" :  {
					"png_path": "acc3.img/skyStation-pvp-0-12",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 16000,
				},
				"13" :  {
					"png_path": "acc3.img/skyStation-pvp-0-13",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"14" :  {
					"png_path": "acc3.img/skyStation-pvp-0-14",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"15" :  {
					"png_path": "acc3.img/skyStation-pvp-0-15",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"16" :  {
					"png_path": "acc3.img/skyStation-pvp-0-16",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 150,
				},
				"17" :  {
					"png_path": "acc3.img/skyStation-pvp-0-17",
					"origin" : [61,119],
					"z" : 0,
					"delay" : 21000,
				},
			},
		},
	},
	"christmas" :  {
		"natuer" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-0-0",
					"origin" : [265,285],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-1-0",
					"origin" : [265,285],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-2-0",
					"origin" : [252,246],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-3-0",
					"origin" : [213,232],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-4-0",
					"origin" : [213,232],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-5-0",
					"origin" : [13,13],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-natuer-5-1",
					"origin" : [17,17],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-natuer-5-2",
					"origin" : [19,19],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-natuer-5-3",
					"origin" : [20,20],
					"z" : 0,
					"delay" : 150,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-6-0",
					"origin" : [13,13],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-natuer-6-1",
					"origin" : [17,17],
					"z" : 0,
					"delay" : 200,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-natuer-6-2",
					"origin" : [19,19],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-natuer-6-3",
					"origin" : [20,20],
					"z" : 0,
					"delay" : 200,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-7-0",
					"origin" : [12,13],
					"z" : 0,
					"delay" : 230,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-natuer-7-1",
					"origin" : [16,17],
					"z" : 0,
					"delay" : 230,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-natuer-7-2",
					"origin" : [18,19],
					"z" : 0,
					"delay" : 230,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-natuer-7-3",
					"origin" : [19,20],
					"z" : 0,
					"delay" : 230,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-8-0",
					"origin" : [94,142],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-natuer-8-1",
					"origin" : [94,142],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-natuer-8-2",
					"origin" : [94,142],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-natuer-8-3",
					"origin" : [94,142],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc3.img/christmas-natuer-8-4",
					"origin" : [94,142],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc3.img/christmas-natuer-8-5",
					"origin" : [94,142],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc3.img/christmas-natuer-8-6",
					"origin" : [94,142],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc3.img/christmas-natuer-8-7",
					"origin" : [94,142],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-9-0",
					"origin" : [97,142],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-natuer-9-1",
					"origin" : [97,142],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-natuer-9-2",
					"origin" : [97,142],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-natuer-9-3",
					"origin" : [97,142],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc3.img/christmas-natuer-9-4",
					"origin" : [97,142],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc3.img/christmas-natuer-9-5",
					"origin" : [97,142],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc3.img/christmas-natuer-9-6",
					"origin" : [97,142],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc3.img/christmas-natuer-9-7",
					"origin" : [97,142],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-10-0",
					"origin" : [94,142],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-natuer-10-1",
					"origin" : [94,142],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-natuer-10-2",
					"origin" : [94,142],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-natuer-10-3",
					"origin" : [94,142],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc3.img/christmas-natuer-10-4",
					"origin" : [94,142],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc3.img/christmas-natuer-10-5",
					"origin" : [94,142],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc3.img/christmas-natuer-10-6",
					"origin" : [94,142],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc3.img/christmas-natuer-10-7",
					"origin" : [94,142],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-11-0",
					"origin" : [94,144],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-natuer-11-1",
					"origin" : [94,144],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-natuer-11-2",
					"origin" : [94,144],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-natuer-11-3",
					"origin" : [94,144],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc3.img/christmas-natuer-11-4",
					"origin" : [94,144],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc3.img/christmas-natuer-11-5",
					"origin" : [94,144],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc3.img/christmas-natuer-11-6",
					"origin" : [94,144],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc3.img/christmas-natuer-11-7",
					"origin" : [94,144],
					"z" : 0,
					"delay" : 150,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-12-0",
					"origin" : [93,144],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-natuer-12-1",
					"origin" : [93,144],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-natuer-12-2",
					"origin" : [93,144],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-natuer-12-3",
					"origin" : [93,144],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc3.img/christmas-natuer-12-4",
					"origin" : [93,144],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc3.img/christmas-natuer-12-5",
					"origin" : [93,144],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc3.img/christmas-natuer-12-6",
					"origin" : [93,144],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc3.img/christmas-natuer-12-7",
					"origin" : [93,144],
					"z" : 0,
					"delay" : 150,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-13-0",
					"origin" : [109,60],
					"delay" : 400,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-natuer-13-1",
					"origin" : [109,60],
					"delay" : 400,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-natuer-14-0",
					"origin" : [6,45],
					"delay" : 300,
				},
			},
		},
		"house1" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house1-0-0",
					"origin" : [210,70],
					"z" : 0,
					"delay" : 500,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-house1-0-1",
					"origin" : [210,70],
					"z" : 0,
					"delay" : 500,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house1-1-0",
					"origin" : [212,82],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house1-2-0",
					"origin" : [48,38],
					"z" : 0,
					"delay" : 5000,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-house1-2-1",
					"origin" : [48,41],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-house1-2-2",
					"origin" : [48,48],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-house1-2-3",
					"origin" : [48,51],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc3.img/christmas-house1-2-4",
					"origin" : [48,54],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc3.img/christmas-house1-2-5",
					"origin" : [48,55],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc3.img/christmas-house1-2-6",
					"origin" : [48,41],
					"z" : 0,
					"delay" : 150,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house1-3-0",
					"origin" : [119,62],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-house1-3-1",
					"origin" : [119,62],
					"z" : 0,
					"delay" : 200,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-house1-3-2",
					"origin" : [119,62],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-house1-3-3",
					"origin" : [119,62],
					"z" : 0,
					"delay" : 200,
				},
				"4" :  {
					"png_path": "acc3.img/christmas-house1-3-4",
					"origin" : [119,62],
					"z" : 0,
					"delay" : 200,
				},
				"5" :  {
					"png_path": "acc3.img/christmas-house1-3-5",
					"origin" : [119,62],
					"z" : 0,
					"delay" : 200,
				},
				"6" :  {
					"png_path": "acc3.img/christmas-house1-3-6",
					"origin" : [119,62],
					"z" : 0,
					"delay" : 200,
				},
				"7" :  {
					"png_path": "acc3.img/christmas-house1-3-7",
					"origin" : [119,62],
					"z" : 0,
					"delay" : 200,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house1-4-0",
					"origin" : [129,121],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-house1-4-1",
					"origin" : [129,121],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 3000,
				},
			},
		},
		"house2" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house2-0-0",
					"origin" : [256,46],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house2-1-0",
					"origin" : [210,72],
					"z" : 0,
					"delay" : 500,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-house2-1-1",
					"origin" : [210,72],
					"z" : 0,
					"delay" : 500,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-house2-1-2",
					"origin" : [210,72],
					"z" : 0,
					"delay" : 500,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house2-2-0",
					"origin" : [149,172],
					"z" : 0,
					"delay" : 500,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-house2-2-1",
					"origin" : [149,172],
					"z" : 0,
					"delay" : 500,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-house2-2-2",
					"origin" : [149,172],
					"z" : 0,
					"delay" : 500,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house2-3-0",
					"origin" : [123,181],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-house2-3-1",
					"origin" : [123,181],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-house2-3-2",
					"origin" : [123,181],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-house2-3-3",
					"origin" : [123,181],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc3.img/christmas-house2-3-4",
					"origin" : [123,181],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc3.img/christmas-house2-3-5",
					"origin" : [123,181],
					"z" : 0,
					"delay" : 700,
				},
				"6" :  {
					"png_path": "acc3.img/christmas-house2-3-6",
					"origin" : [123,181],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc3.img/christmas-house2-3-7",
					"origin" : [123,181],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "acc3.img/christmas-house2-3-8",
					"origin" : [123,181],
					"z" : 0,
					"delay" : 150,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house2-4-0",
					"origin" : [184,110],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-house2-4-1",
					"origin" : [184,110],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 3000,
				},
			},
		},
		"house3" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house3-0-0",
					"origin" : [173,65],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house3-1-0",
					"origin" : [205,156],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-house3-1-1",
					"origin" : [205,156],
					"z" : 0,
					"delay" : 200,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-house3-1-2",
					"origin" : [205,156],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-house3-1-3",
					"origin" : [205,156],
					"z" : 0,
					"delay" : 200,
				},
				"4" :  {
					"png_path": "acc3.img/christmas-house3-1-4",
					"origin" : [205,156],
					"z" : 0,
					"delay" : 200,
				},
				"5" :  {
					"png_path": "acc3.img/christmas-house3-1-5",
					"origin" : [205,156],
					"z" : 0,
					"delay" : 200,
				},
				"6" :  {
					"png_path": "acc3.img/christmas-house3-1-6",
					"origin" : [205,156],
					"z" : 0,
					"delay" : 200,
				},
				"7" :  {
					"png_path": "acc3.img/christmas-house3-1-7",
					"origin" : [205,156],
					"z" : 0,
					"delay" : 200,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-house3-2-0",
					"origin" : [67,134],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 2600,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-house3-2-1",
					"origin" : [67,134],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 2600,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-0-0",
					"origin" : [77,86],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-1-0",
					"origin" : [12,44],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-2-0",
					"origin" : [14,45],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-3-0",
					"origin" : [82,45],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-4-0",
					"origin" : [82,46],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-5-0",
					"origin" : [17,44],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-6-0",
					"origin" : [10,44],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-7-0",
					"origin" : [8,44],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-8-0",
					"origin" : [48,118],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-9-0",
					"origin" : [47,78],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-10-0",
					"origin" : [133,55],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-11-0",
					"origin" : [102,69],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-acc-11-1",
					"origin" : [102,69],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-acc-11-2",
					"origin" : [102,69],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-acc-11-3",
					"origin" : [102,69],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc3.img/christmas-acc-11-4",
					"origin" : [102,69],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc3.img/christmas-acc-11-5",
					"origin" : [102,69],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc3.img/christmas-acc-11-6",
					"origin" : [102,69],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc3.img/christmas-acc-11-7",
					"origin" : [102,69],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "acc3.img/christmas-acc-11-8",
					"origin" : [102,69],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "acc3.img/christmas-acc-11-9",
					"origin" : [102,69],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "acc3.img/christmas-acc-11-10",
					"origin" : [102,69],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "acc3.img/christmas-acc-11-11",
					"origin" : [102,69],
					"z" : 0,
					"delay" : 150,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-12-0",
					"origin" : [45,8],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-13-0",
					"origin" : [31,9],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-acc-14-0",
					"origin" : [45,9],
					"z" : 0,
				},
			},
		},
		"inside" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-0-0",
					"origin" : [100,300],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-inside-0-1",
					"origin" : [100,300],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-1-0",
					"origin" : [100,300],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-inside-1-1",
					"origin" : [100,300],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-2-0",
					"origin" : [100,300],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-inside-2-1",
					"origin" : [100,300],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-3-0",
					"origin" : [100,300],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-4-0",
					"origin" : [100,300],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-5-0",
					"origin" : [184,70],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-6-0",
					"origin" : [24,24],
					"z" : 0,
					"delay" : 500,
					"a0" : 255,
					"a1" : 10,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-inside-6-1",
					"origin" : [24,24],
					"z" : 0,
					"delay" : 500,
					"a0" : 10,
					"a1" : 255,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-7-0",
					"origin" : [24,24],
					"z" : 0,
					"a0" : 10,
					"a1" : 255,
					"delay" : 500,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-inside-7-1",
					"origin" : [24,24],
					"z" : 0,
					"delay" : 500,
					"a0" : 255,
					"a1" : 10,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-8-0",
					"origin" : [24,24],
					"z" : 0,
					"a0" : 255,
					"a1" : 50,
					"delay" : 2000,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-inside-8-1",
					"origin" : [24,24],
					"z" : 0,
					"a0" : 50,
					"a1" : 255,
					"delay" : 2000,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-9-0",
					"origin" : [41,28],
					"z" : 0,
					"a0" : 255,
					"a1" : 50,
					"delay" : 2600,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-inside-9-1",
					"origin" : [41,28],
					"z" : 0,
					"a0" : 50,
					"a1" : 255,
					"delay" : 2000,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-10-0",
					"origin" : [37,32],
					"z" : 0,
					"a0" : 50,
					"a1" : 255,
					"delay" : 1700,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-inside-10-1",
					"origin" : [37,32],
					"z" : 0,
					"a0" : 255,
					"a1" : 50,
					"delay" : 2200,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-11-0",
					"origin" : [49,29],
					"z" : 0,
					"a0" : 50,
					"a1" : 255,
					"delay" : 2000,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-inside-11-1",
					"origin" : [49,29],
					"z" : 0,
					"a0" : 255,
					"a1" : 50,
					"delay" : 3000,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-inside-12-0",
					"origin" : [77,143],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc3.img/christmas-inside-12-1",
					"origin" : [76,143],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc3.img/christmas-inside-12-2",
					"origin" : [76,143],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc3.img/christmas-inside-12-3",
					"origin" : [75,143],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc3.img/christmas-inside-12-4",
					"origin" : [75,143],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc3.img/christmas-inside-12-5",
					"origin" : [74,143],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc3.img/christmas-inside-12-6",
					"origin" : [73,142],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc3.img/christmas-inside-12-7",
					"origin" : [74,143],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "acc3.img/christmas-inside-12-8",
					"origin" : [75,143],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "acc3.img/christmas-inside-12-9",
					"origin" : [75,143],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "acc3.img/christmas-inside-12-10",
					"origin" : [76,143],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "acc3.img/christmas-inside-12-11",
					"origin" : [76,143],
					"z" : 0,
					"delay" : 150,
				},
			},
		},
		"deco" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-deco-0-0",
					"origin" : [-4,28],
				},
				"1" :  {
					"png_path": "acc3.img/christmas-deco-0-1",
					"origin" : [-4,28],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-deco-1-0",
					"origin" : [-3,26],
				},
				"1" :  {
					"png_path": "acc3.img/christmas-deco-1-1",
					"origin" : [-3,26],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-deco-2-0",
					"origin" : [-6,28],
				},
				"1" :  {
					"png_path": "acc3.img/christmas-deco-2-1",
					"origin" : [-6,28],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-deco-3-0",
					"origin" : [-4,28],
				},
				"1" :  {
					"png_path": "acc3.img/christmas-deco-3-1",
					"origin" : [-4,28],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-deco-4-0",
					"origin" : [-5,27],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-deco-5-0",
					"origin" : [-3,28],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-deco-6-0",
					"origin" : [1,26],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/christmas-deco-7-0",
					"origin" : [-4,27],
				},
			},
		},
	},
	"snowyDarkrock" :  {
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-artificiality-0-0",
					"origin" : [178,148],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-artificiality-1-0",
					"origin" : [88,37],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-artificiality-2-0",
					"origin" : [89,37],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-artificiality-3-0",
					"origin" : [105,38],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-artificiality-4-0",
					"origin" : [106,46],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-artificiality-5-0",
					"origin" : [104,45],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-artificiality-6-0",
					"origin" : [59,38],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-artificiality-7-0",
					"origin" : [116,66],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-artificiality-8-0",
					"origin" : [35,26],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-artificiality-9-0",
					"origin" : [30,31],
					"z" : 0,
				},
			},
		},
		"christmas" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-christmas-0-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-christmas-1-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-christmas-2-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-christmas-3-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-christmas-4-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-christmas-5-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-christmas-6-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc3.img/snowyDarkrock-christmas-7-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
		},
	},
};

