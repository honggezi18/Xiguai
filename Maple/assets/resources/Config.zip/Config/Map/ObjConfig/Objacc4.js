var Objacc4 = Objacc4 || { }; 
Objacc4 =   {
	"id":"acc4",
	"toyCastle" :  {
		"cloud" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-cloud-0-0",
					"origin" : [53,52],
					"z" : 0,
					"moveType" : 2,
					"moveH" : 50,
					"delay" : 1000,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-cloud-1-0",
					"origin" : [52,33],
					"z" : 0,
					"moveType" : 2,
					"moveH" : 30,
					"delay" : 1000,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-cloud-2-0",
					"origin" : [121,59],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-cloud-3-0",
					"origin" : [0,0],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-cloud-4-0",
					"origin" : [0,0],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-cloud-5-0",
					"origin" : [63,43],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-cloud-6-0",
					"origin" : [25,18],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-cloud-7-0",
					"origin" : [121,59],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-cloud-8-0",
					"origin" : [112,64],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-cloud-9-0",
					"origin" : [89,36],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-cloud-10-0",
					"origin" : [63,43],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-cloud-11-0",
					"origin" : [25,18],
					"z" : 0,
				},
			},
		},
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-0-0",
					"origin" : [30,30],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-1-0",
					"origin" : [50,78],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-2-0",
					"origin" : [36,54],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-3-0",
					"origin" : [19,32],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-4-0",
					"origin" : [19,32],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-5-0",
					"origin" : [27,34],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-6-0",
					"origin" : [19,34],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-7-0",
					"origin" : [19,33],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-8-0",
					"origin" : [0,0],
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-9-0",
					"origin" : [30,29],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-10-0",
					"origin" : [19,32],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-11-0",
					"origin" : [28,32],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-12-0",
					"origin" : [19,32],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-13-0",
					"origin" : [0,0],
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-14-0",
					"origin" : [26,30],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-15-0",
					"origin" : [25,30],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-16-0",
					"origin" : [19,30],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-17-0",
					"origin" : [32,52],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-18-0",
					"origin" : [45,77],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-19-0",
					"origin" : [33,54],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-nature-20-0",
					"origin" : [48,80],
					"z" : 0,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-0-0",
					"origin" : [25,31],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-1-0",
					"origin" : [29,42],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-2-0",
					"origin" : [41,26],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-3-0",
					"origin" : [0,0],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-4-0",
					"origin" : [44,26],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-5-0",
					"origin" : [41,26],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-6-0",
					"origin" : [44,26],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-7-0",
					"origin" : [53,71],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-8-0",
					"origin" : [56,96],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-9-0",
					"origin" : [27,135],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-10-0",
					"origin" : [15,20],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-11-0",
					"origin" : [21,29],
					"z" : 0,
					"a0" : 10,
					"a1" : 255,
					"delay" : 2500,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle-artificiality-11-1",
					"origin" : [21,29],
					"z" : 0,
					"a0" : 255,
					"a1" : 10,
					"delay" : 2500,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-12-0",
					"origin" : [146,170],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-13-0",
					"origin" : [98,139],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-14-0",
					"origin" : [148,188],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-15-0",
					"origin" : [134,64],
					"z" : 0,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle-artificiality-15-1",
					"origin" : [134,64],
					"z" : 0,
					"delay" : 3000,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-16-0",
					"origin" : [74,37],
					"z" : 0,
					"a0" : 10,
					"a1" : 255,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle-artificiality-16-1",
					"origin" : [74,37],
					"z" : 0,
					"a0" : 255,
					"a1" : 10,
					"delay" : 3000,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-17-0",
					"origin" : [143,164],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-18-0",
					"origin" : [59,132],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle-artificiality-18-1",
					"origin" : [59,106],
					"z" : 0,
					"delay" : 200,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle-artificiality-18-2",
					"origin" : [76,38],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle-artificiality-18-3",
					"origin" : [59,106],
					"z" : 0,
					"delay" : 200,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-19-0",
					"origin" : [56,170],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-20-0",
					"origin" : [65,28],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 2500,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle-artificiality-20-1",
					"origin" : [65,28],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 2500,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-21-0",
					"origin" : [31,11],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-22-0",
					"origin" : [0,0],
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-23-0",
					"origin" : [58,133],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-24-0",
					"origin" : [58,133],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-25-0",
					"origin" : [0,0],
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-artificiality-26-0",
					"origin" : [58,133],
					"z" : 0,
				},
			},
		},
		"seat" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-seat-0-0",
					"origin" : [18,18],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-9,14],
					"1" : [3,14],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-seat-1-0",
					"origin" : [18,18],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-9,14],
					"1" : [3,14],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-seat-2-0",
					"origin" : [38,26],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-22,14],
					"1" : [-3,14],
					"2" : [15,14],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-seat-3-0",
					"origin" : [37,19],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-22,14],
					"1" : [-3,14],
					"2" : [15,14],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-seat-4-0",
					"origin" : [38,18],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-22,14],
					"1" : [-3,14],
					"2" : [15,14],
				},
			},
		},
		"station" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-0-0",
					"origin" : [562,80],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-1-0",
					"origin" : [157,101],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-2-0",
					"origin" : [562,80],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-3-0",
					"origin" : [68,101],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-4-0",
					"origin" : [271,62],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-5-0",
					"origin" : [59,62],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-6-0",
					"origin" : [193,60],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-7-0",
					"origin" : [147,116],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-8-0",
					"origin" : [41,116],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-9-0",
					"origin" : [191,122],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-10-0",
					"origin" : [72,43],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-11-0",
					"origin" : [84,68],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-12-0",
					"origin" : [41,170],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-13-0",
					"origin" : [131,122],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-14-0",
					"origin" : [72,91],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-15-0",
					"origin" : [228,59],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-16-0",
					"origin" : [70,89],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-17-0",
					"origin" : [70,216],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-18-0",
					"origin" : [79,216],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-19-0",
					"origin" : [113,140],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-station-20-0",
					"origin" : [35,43],
					"z" : 0,
				},
			},
		},
		"market" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-market-0-0",
					"origin" : [226,129],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-market-1-0",
					"origin" : [103,93],
					"z" : 0,
				},
			},
		},
		"npc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-npc-0-0",
					"origin" : [33,14],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle-npc-0-1",
					"origin" : [32,13],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle-npc-0-2",
					"origin" : [30,14],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle-npc-0-3",
					"origin" : [32,13],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc4.img/toyCastle-npc-0-0",
					"origin" : [33,14],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc4.img/toyCastle-npc-0-1",
					"origin" : [32,13],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc4.img/toyCastle-npc-0-2",
					"origin" : [30,14],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc4.img/toyCastle-npc-0-3",
					"origin" : [32,13],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "acc4.img/toyCastle-npc-0-0",
					"origin" : [33,14],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "acc4.img/toyCastle-npc-0-1",
					"origin" : [32,13],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "acc4.img/toyCastle-npc-0-2",
					"origin" : [30,14],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "acc4.img/toyCastle-npc-0-3",
					"origin" : [32,13],
					"z" : 0,
					"delay" : 150,
				},
				"12" :  {
					"png_path": "acc4.img/toyCastle-npc-0-12",
					"origin" : [30,13],
					"z" : 0,
					"delay" : 150,
				},
				"13" :  {
					"png_path": "acc4.img/toyCastle-npc-0-13",
					"origin" : [32,23],
					"z" : 0,
					"delay" : 150,
				},
				"14" :  {
					"png_path": "acc4.img/toyCastle-npc-0-14",
					"origin" : [32,22],
					"z" : 0,
					"delay" : 150,
				},
				"15" :  {
					"png_path": "acc4.img/toyCastle-npc-0-15",
					"origin" : [33,17],
					"z" : 0,
					"delay" : 150,
				},
				"16" :  {
					"png_path": "acc4.img/toyCastle-npc-0-16",
					"origin" : [30,13],
					"z" : 0,
					"delay" : 150,
				},
				"17" :  {
					"png_path": "acc4.img/toyCastle-npc-0-17",
					"origin" : [32,13],
					"z" : 0,
					"delay" : 150,
				},
				"18" :  {
					"png_path": "acc4.img/toyCastle-npc-0-18",
					"origin" : [32,23],
					"z" : 0,
					"delay" : 150,
				},
				"19" :  {
					"png_path": "acc4.img/toyCastle-npc-0-19",
					"origin" : [32,22],
					"z" : 0,
					"delay" : 150,
				},
				"20" :  {
					"png_path": "acc4.img/toyCastle-npc-0-20",
					"origin" : [32,17],
					"z" : 0,
					"delay" : 150,
				},
				"21" :  {
					"png_path": "acc4.img/toyCastle-npc-0-21",
					"origin" : [32,13],
					"z" : 0,
					"delay" : 150,
				},
			},
		},
		"pet" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-0-0",
					"origin" : [28,22],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-1-0",
					"origin" : [28,22],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-2-0",
					"origin" : [22,17],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-3-0",
					"origin" : [22,17],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-4-0",
					"origin" : [154,45],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-5-0",
					"origin" : [83,44],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-6-0",
					"origin" : [60,68],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-7-0",
					"origin" : [141,60],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-8-0",
					"origin" : [101,30],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-9-0",
					"origin" : [44,111],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-10-0",
					"origin" : [154,97],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-11-0",
					"origin" : [27,42],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-12-0",
					"origin" : [23,19],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-13-0",
					"origin" : [23,19],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-14-0",
					"origin" : [12,19],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-15-0",
					"origin" : [27,42],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-16-0",
					"origin" : [23,19],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-17-0",
					"origin" : [23,19],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle-pet-18-0",
					"origin" : [12,18],
					"z" : 0,
				},
			},
		},
	},
	"toyCastle2" :  {
		"b1" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-0-0",
					"origin" : [33,22],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-1-0",
					"origin" : [33,22],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-2-0",
					"origin" : [33,22],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-3-0",
					"origin" : [33,22],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-4-0",
					"origin" : [33,22],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-5-0",
					"origin" : [33,22],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-6-0",
					"origin" : [33,22],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-7-0",
					"origin" : [33,22],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-8-0",
					"origin" : [33,22],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-9-0",
					"origin" : [33,22],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-10-0",
					"origin" : [33,22],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-11-0",
					"origin" : [72,3],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-12-0",
					"origin" : [41,35],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-13-0",
					"origin" : [42,35],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-14-0",
					"origin" : [42,35],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-15-0",
					"origin" : [41,35],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-16-0",
					"origin" : [41,35],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-17-0",
					"origin" : [41,35],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-18-0",
					"origin" : [42,35],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-19-0",
					"origin" : [41,35],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-20-0",
					"origin" : [41,35],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-21-0",
					"origin" : [42,35],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-22-0",
					"origin" : [42,35],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-23-0",
					"origin" : [42,35],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-24-0",
					"origin" : [41,35],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-25-0",
					"origin" : [42,35],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-26-0",
					"origin" : [42,35],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-27-0",
					"origin" : [41,35],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-28-0",
					"origin" : [94,221],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-29-0",
					"origin" : [128,194],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-30-0",
					"origin" : [36,110],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-31-0",
					"origin" : [31,110],
					"z" : 0,
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-32-0",
					"origin" : [265,60],
					"z" : 0,
				},
			},
			"33" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-33-0",
					"origin" : [128,35],
					"z" : 0,
				},
			},
			"34" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-34-0",
					"origin" : [114,31],
					"z" : 0,
				},
			},
			"35" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-35-0",
					"origin" : [16,14],
					"z" : 0,
				},
			},
			"36" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b1-36-0",
					"origin" : [46,15],
					"z" : 0,
				},
			},
		},
		"b2" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b2-0-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b2-1-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b2-2-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b2-3-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b2-4-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b2-5-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b2-6-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b2-7-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b2-8-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b2-9-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b2-10-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b2-11-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
		},
		"b3" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b3-0-0",
					"origin" : [72,44],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b3-1-0",
					"origin" : [72,23],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b3-2-0",
					"origin" : [71,19],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b3-3-0",
					"origin" : [59,38],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b3-4-0",
					"origin" : [43,32],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b3-5-0",
					"origin" : [58,30],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b3-6-0",
					"origin" : [17,17],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-0",
					"origin" : [29,73],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-1",
					"origin" : [26,73],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-2",
					"origin" : [21,73],
					"z" : 0,
					"delay" : 100,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-3",
					"origin" : [15,73],
					"z" : 0,
					"delay" : 100,
				},
				"4" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-4",
					"origin" : [10,73],
					"z" : 0,
					"delay" : 100,
				},
				"5" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-5",
					"origin" : [5,73],
					"z" : 0,
					"delay" : 100,
				},
				"6" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-6",
					"origin" : [0,73],
					"z" : 0,
					"delay" : 100,
				},
				"7" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-7",
					"origin" : [-6,73],
					"z" : 0,
					"delay" : 100,
				},
				"8" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-8",
					"origin" : [-11,74],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-7",
					"origin" : [-6,73],
					"z" : 0,
					"delay" : 100,
				},
				"10" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-6",
					"origin" : [0,73],
					"z" : 0,
					"delay" : 100,
				},
				"11" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-5",
					"origin" : [5,73],
					"z" : 0,
					"delay" : 100,
				},
				"12" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-4",
					"origin" : [10,73],
					"z" : 0,
					"delay" : 100,
				},
				"13" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-3",
					"origin" : [15,73],
					"z" : 0,
					"delay" : 100,
				},
				"14" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-2",
					"origin" : [21,73],
					"z" : 0,
					"delay" : 100,
				},
				"15" :  {
					"png_path": "acc4.img/toyCastle2-b3-7-1",
					"origin" : [26,73],
					"z" : 0,
					"delay" : 100,
				},
			},
		},
		"gate" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-gate-0-0",
					"origin" : [71,57],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-gate-1-0",
					"origin" : [71,51],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-gate-2-0",
					"origin" : [69,54],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-gate-3-0",
					"origin" : [33,15],
					"z" : 0,
					"delay" : 500,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle2-gate-3-1",
					"origin" : [33,15],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle2-gate-3-2",
					"origin" : [33,15],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle2-gate-3-3",
					"origin" : [33,15],
					"z" : 0,
					"delay" : 180,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-gate-4-0",
					"origin" : [33,13],
					"z" : 0,
					"delay" : 500,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle2-gate-4-1",
					"origin" : [33,13],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle2-gate-4-2",
					"origin" : [33,13],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle2-gate-4-3",
					"origin" : [33,13],
					"z" : 0,
					"delay" : 180,
				},
			},
		},
		"machine" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-0-0",
					"origin" : [165,156],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle2-machine-0-1",
					"origin" : [165,156],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle2-machine-0-2",
					"origin" : [165,156],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle2-machine-0-3",
					"origin" : [165,156],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc4.img/toyCastle2-machine-0-4",
					"origin" : [165,156],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc4.img/toyCastle2-machine-0-5",
					"origin" : [165,156],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc4.img/toyCastle2-machine-0-6",
					"origin" : [165,156],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc4.img/toyCastle2-machine-0-7",
					"origin" : [165,156],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "acc4.img/toyCastle2-machine-0-8",
					"origin" : [165,156],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "acc4.img/toyCastle2-machine-0-9",
					"origin" : [165,156],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "acc4.img/toyCastle2-machine-0-10",
					"origin" : [165,156],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "acc4.img/toyCastle2-machine-0-11",
					"origin" : [165,156],
					"z" : 0,
					"delay" : 150,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-1-0",
					"origin" : [94,105],
					"z" : 0,
					"delay" : 300,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle2-machine-1-1",
					"origin" : [94,105],
					"z" : 0,
					"delay" : 300,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle2-machine-1-2",
					"origin" : [94,105],
					"z" : 0,
					"delay" : 300,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle2-machine-1-3",
					"origin" : [94,105],
					"z" : 0,
					"delay" : 300,
				},
				"4" :  {
					"png_path": "acc4.img/toyCastle2-machine-1-4",
					"origin" : [94,105],
					"z" : 0,
					"delay" : 300,
				},
				"5" :  {
					"png_path": "acc4.img/toyCastle2-machine-1-5",
					"origin" : [94,105],
					"z" : 0,
					"delay" : 300,
				},
				"6" :  {
					"png_path": "acc4.img/toyCastle2-machine-1-6",
					"origin" : [94,105],
					"z" : 0,
					"delay" : 300,
				},
				"7" :  {
					"png_path": "acc4.img/toyCastle2-machine-1-7",
					"origin" : [94,105],
					"z" : 0,
					"delay" : 300,
				},
				"8" :  {
					"png_path": "acc4.img/toyCastle2-machine-1-8",
					"origin" : [94,105],
					"z" : 0,
					"delay" : 300,
				},
				"9" :  {
					"png_path": "acc4.img/toyCastle2-machine-1-9",
					"origin" : [94,105],
					"z" : 0,
					"delay" : 300,
				},
				"10" :  {
					"png_path": "acc4.img/toyCastle2-machine-1-10",
					"origin" : [94,105],
					"z" : 0,
					"delay" : 300,
				},
				"11" :  {
					"png_path": "acc4.img/toyCastle2-machine-1-11",
					"origin" : [94,105],
					"z" : 0,
					"delay" : 300,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-2-0",
					"origin" : [213,160],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle2-machine-2-1",
					"origin" : [213,160],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle2-machine-2-2",
					"origin" : [213,160],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle2-machine-2-3",
					"origin" : [213,160],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc4.img/toyCastle2-machine-2-4",
					"origin" : [213,160],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc4.img/toyCastle2-machine-2-5",
					"origin" : [213,160],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc4.img/toyCastle2-machine-2-6",
					"origin" : [213,160],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc4.img/toyCastle2-machine-2-7",
					"origin" : [213,160],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "acc4.img/toyCastle2-machine-2-8",
					"origin" : [213,160],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "acc4.img/toyCastle2-machine-2-9",
					"origin" : [213,160],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "acc4.img/toyCastle2-machine-2-10",
					"origin" : [213,160],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "acc4.img/toyCastle2-machine-2-11",
					"origin" : [213,160],
					"z" : 0,
					"delay" : 150,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-0",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-1",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-2",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-3",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-4",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-5",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-6",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-7",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-8",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-9",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-10",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-11",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"12" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-12",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"13" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-13",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"14" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-14",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
				"15" :  {
					"png_path": "acc4.img/toyCastle2-machine-3-15",
					"origin" : [161,109],
					"z" : 0,
					"delay" : 150,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-0",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-1",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-2",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-3",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-4",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-5",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-6",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-7",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-8",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-9",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-10",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-11",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"12" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-12",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"13" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-13",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"14" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-14",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
				"15" :  {
					"png_path": "acc4.img/toyCastle2-machine-4-15",
					"origin" : [194,109],
					"z" : 0,
					"delay" : 150,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-5-0",
					"origin" : [79,32],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-6-0",
					"origin" : [101,22],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-7-0",
					"origin" : [17,22],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-8-0",
					"origin" : [63,22],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-9-0",
					"origin" : [21,22],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-10-0",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 80,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle2-machine-10-1",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 80,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle2-machine-10-2",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 80,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle2-machine-10-3",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 80,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-11-0",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle2-machine-11-1",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 200,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle2-machine-11-2",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle2-machine-11-3",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 200,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-12-0",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 80,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle2-machine-12-1",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 80,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle2-machine-12-2",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 80,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle2-machine-12-3",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 80,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc4.img/toyCastle2-machine-13-0",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "acc4.img/toyCastle2-machine-13-1",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 200,
				},
				"2" :  {
					"png_path": "acc4.img/toyCastle2-machine-13-2",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "acc4.img/toyCastle2-machine-13-3",
					"origin" : [125,22],
					"z" : 0,
					"delay" : 200,
				},
			},
		},
	},
	"omegaSector" :  {
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-0-0",
					"origin" : [78,144],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-1-0",
					"origin" : [96,139],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-2-0",
					"origin" : [79,139],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-3-0",
					"origin" : [49,113],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-4-0",
					"origin" : [84,130],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-5-0",
					"origin" : [112,63],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-6-0",
					"origin" : [14,8],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-7-0",
					"origin" : [9,7],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-8-0",
					"origin" : [112,63],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-9-0",
					"origin" : [114,74],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-10-0",
					"origin" : [114,74],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-11-0",
					"origin" : [108,42],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-12-0",
					"origin" : [48,19],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-13-0",
					"origin" : [37,29],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-14-0",
					"origin" : [37,19],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-15-0",
					"origin" : [42,16],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-16-0",
					"origin" : [72,21],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-17-0",
					"origin" : [38,20],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-18-0",
					"origin" : [24,9],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-19-0",
					"origin" : [39,34],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-20-0",
					"origin" : [28,31],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-21-0",
					"origin" : [20,25],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-22-0",
					"origin" : [56,34],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-23-0",
					"origin" : [36,21],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-24-0",
					"origin" : [9,7],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-25-0",
					"origin" : [72,21],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-26-0",
					"origin" : [72,21],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-27-0",
					"origin" : [45,28],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-28-0",
					"origin" : [198,118],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-29-0",
					"origin" : [51,37],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-nature-30-0",
					"origin" : [46,32],
					"z" : 0,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-0-0",
					"origin" : [65,84],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-1-0",
					"origin" : [15,74],
					"z" : 0,
					"ladder" : [-4,70],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-2-0",
					"origin" : [65,84],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-3-0",
					"origin" : [53,30],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-4-0",
					"origin" : [53,30],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-5-0",
					"origin" : [53,30],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-6-0",
					"origin" : [32,208],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-7-0",
					"origin" : [26,73],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-8-0",
					"origin" : [32,208],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-9-0",
					"origin" : [26,74],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-10-0",
					"origin" : [15,187],
					"z" : 0,
					"ladder" : [5,184],
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-11-0",
					"origin" : [11,50],
					"z" : 0,
					"ladder" : [0,52],
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-12-0",
					"origin" : [177,146],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-13-0",
					"origin" : [82,70],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-14-0",
					"origin" : [179,147],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-15-0",
					"origin" : [258,163],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-16-0",
					"origin" : [168,7],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSector-artificiality-16-1",
					"origin" : [167,7],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc4.img/omegaSector-artificiality-16-2",
					"origin" : [167,7],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc4.img/omegaSector-artificiality-16-3",
					"origin" : [163,7],
					"z" : 0,
					"delay" : 150,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-17-0",
					"origin" : [64,69],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSector-artificiality-17-1",
					"origin" : [64,69],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc4.img/omegaSector-artificiality-17-2",
					"origin" : [64,69],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc4.img/omegaSector-artificiality-17-3",
					"origin" : [64,69],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc4.img/omegaSector-artificiality-17-4",
					"origin" : [64,69],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc4.img/omegaSector-artificiality-17-5",
					"origin" : [64,69],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc4.img/omegaSector-artificiality-17-6",
					"origin" : [64,69],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc4.img/omegaSector-artificiality-17-7",
					"origin" : [64,69],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-18-0",
					"origin" : [198,201],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-19-0",
					"origin" : [71,67],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 2500,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSector-artificiality-19-1",
					"origin" : [71,67],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 2500,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-20-0",
					"origin" : [82,70],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-21-0",
					"origin" : [74,35],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-22-0",
					"origin" : [156,80],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-23-0",
					"origin" : [74,35],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-artificiality-24-0",
					"origin" : [156,80],
					"z" : 0,
				},
			},
		},
		"gate" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-gate-0-0",
					"origin" : [249,216],
					"z" : 0,
					"delay" : 100,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSector-gate-0-1",
					"origin" : [249,218],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "acc4.img/omegaSector-gate-0-2",
					"origin" : [249,219],
					"z" : 0,
					"delay" : 100,
				},
				"3" :  {
					"png_path": "acc4.img/omegaSector-gate-0-3",
					"origin" : [249,219],
					"z" : 0,
					"delay" : 100,
				},
				"4" :  {
					"png_path": "acc4.img/omegaSector-gate-0-4",
					"origin" : [249,219],
					"z" : 0,
					"delay" : 100,
				},
				"5" :  {
					"png_path": "acc4.img/omegaSector-gate-0-5",
					"origin" : [249,219],
					"z" : 0,
					"delay" : 100,
				},
				"6" :  {
					"png_path": "acc4.img/omegaSector-gate-0-6",
					"origin" : [249,219],
					"z" : 0,
					"delay" : 100,
				},
				"7" :  {
					"png_path": "acc4.img/omegaSector-gate-0-7",
					"origin" : [249,217],
					"z" : 0,
					"delay" : 100,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-gate-1-0",
					"origin" : [124,216],
					"z" : 0,
					"delay" : 100,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSector-gate-1-1",
					"origin" : [124,218],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "acc4.img/omegaSector-gate-1-2",
					"origin" : [124,219],
					"z" : 0,
					"delay" : 100,
				},
				"3" :  {
					"png_path": "acc4.img/omegaSector-gate-1-3",
					"origin" : [124,219],
					"z" : 0,
					"delay" : 100,
				},
				"4" :  {
					"png_path": "acc4.img/omegaSector-gate-1-4",
					"origin" : [124,219],
					"z" : 0,
					"delay" : 100,
				},
				"5" :  {
					"png_path": "acc4.img/omegaSector-gate-1-5",
					"origin" : [124,219],
					"z" : 0,
					"delay" : 100,
				},
				"6" :  {
					"png_path": "acc4.img/omegaSector-gate-1-6",
					"origin" : [124,219],
					"z" : 0,
					"delay" : 100,
				},
				"7" :  {
					"png_path": "acc4.img/omegaSector-gate-1-7",
					"origin" : [124,217],
					"z" : 0,
					"delay" : 100,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-gate-2-0",
					"origin" : [124,214],
					"z" : 0,
					"delay" : 100,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSector-gate-2-1",
					"origin" : [124,216],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "acc4.img/omegaSector-gate-2-2",
					"origin" : [124,217],
					"z" : 0,
					"delay" : 100,
				},
				"3" :  {
					"png_path": "acc4.img/omegaSector-gate-2-3",
					"origin" : [124,217],
					"z" : 0,
					"delay" : 100,
				},
				"4" :  {
					"png_path": "acc4.img/omegaSector-gate-2-4",
					"origin" : [124,217],
					"z" : 0,
					"delay" : 100,
				},
				"5" :  {
					"png_path": "acc4.img/omegaSector-gate-2-5",
					"origin" : [124,217],
					"z" : 0,
					"delay" : 100,
				},
				"6" :  {
					"png_path": "acc4.img/omegaSector-gate-2-6",
					"origin" : [124,217],
					"z" : 0,
					"delay" : 100,
				},
				"7" :  {
					"png_path": "acc4.img/omegaSector-gate-2-7",
					"origin" : [124,216],
					"z" : 0,
					"delay" : 100,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-gate-3-0",
					"origin" : [97,107],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-gate-4-0",
					"origin" : [251,113],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-gate-5-0",
					"origin" : [90,107],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-gate-6-0",
					"origin" : [18,18],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSector-gate-6-1",
					"origin" : [18,18],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 1000,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-gate-7-0",
					"origin" : [147,119],
					"z" : 0,
				},
			},
		},
		"tile" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-tile-0-0",
					"origin" : [77,75],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-tile-1-0",
					"origin" : [106,109],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-tile-2-0",
					"origin" : [119,110],
					"z" : 0,
				},
			},
		},
		"npc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-npc-0-0",
					"origin" : [20,34],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-npc-1-0",
					"origin" : [24,33],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-npc-2-0",
					"origin" : [24,34],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-npc-3-0",
					"origin" : [0,0],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSector-npc-4-0",
					"origin" : [24,34],
					"z" : 0,
				},
			},
		},
	},
	"omegaSectorHangar" :  {
		"foot" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-foot-0-0",
					"origin" : [46,56],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-foot-1-0",
					"origin" : [39,56],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-foot-2-0",
					"origin" : [76,57],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-foot-3-0",
					"origin" : [122,45],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-foot-4-0",
					"origin" : [122,12],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-foot-5-0",
					"origin" : [114,56],
					"z" : 0,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-0-0",
					"origin" : [164,110],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-1-0",
					"origin" : [164,110],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-2-0",
					"origin" : [164,110],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-3-0",
					"origin" : [164,110],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-4-0",
					"origin" : [75,86],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-5-0",
					"origin" : [0,0],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-6-0",
					"origin" : [56,66],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-7-0",
					"origin" : [29,31],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-7-1",
					"origin" : [30,31],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-7-2",
					"origin" : [29,31],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-7-3",
					"origin" : [30,31],
					"z" : 0,
					"delay" : 150,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-8-0",
					"origin" : [38,41],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-9-0",
					"origin" : [62,45],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-10-0",
					"origin" : [33,26],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-10-1",
					"origin" : [33,26],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-10-2",
					"origin" : [33,26],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-10-3",
					"origin" : [33,26],
					"z" : 0,
					"delay" : 150,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-11-0",
					"origin" : [69,81],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-12-0",
					"origin" : [27,77],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-12-1",
					"origin" : [27,77],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-12-2",
					"origin" : [27,77],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-12-3",
					"origin" : [27,77],
					"z" : 0,
					"delay" : 150,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-13-0",
					"origin" : [116,84],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-14-0",
					"origin" : [116,84],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-15-0",
					"origin" : [88,23],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-16-0",
					"origin" : [63,58],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-17-0",
					"origin" : [107,36],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-18-0",
					"origin" : [77,52],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-19-0",
					"origin" : [141,110],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-20-0",
					"origin" : [48,19],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-21-0",
					"origin" : [28,19],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-22-0",
					"origin" : [0,0],
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-23-0",
					"origin" : [93,114],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-24-0",
					"origin" : [95,99],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-25-0",
					"origin" : [81,99],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-26-0",
					"origin" : [42,76],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-27-0",
					"origin" : [63,70],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-28-0",
					"origin" : [43,27],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-29-0",
					"origin" : [55,62],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-acc-30-0",
					"origin" : [92,78],
					"z" : 0,
				},
			},
		},
		"gate" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-0-0",
					"origin" : [60,72],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-1-0",
					"origin" : [23,18],
					"z" : 0,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-1-1",
					"origin" : [25,18],
					"z" : 0,
					"delay" : 80,
				},
				"2" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-1-2",
					"origin" : [23,18],
					"z" : 0,
					"delay" : 80,
				},
				"3" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-1-3",
					"origin" : [23,18],
					"z" : 0,
					"delay" : 80,
				},
				"4" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-1-4",
					"origin" : [23,20],
					"z" : 0,
					"delay" : 80,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-2-0",
					"origin" : [23,18],
					"z" : 0,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-2-1",
					"origin" : [25,18],
					"z" : 0,
					"delay" : 80,
				},
				"2" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-2-2",
					"origin" : [23,18],
					"z" : 0,
					"delay" : 80,
				},
				"3" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-2-3",
					"origin" : [23,18],
					"z" : 0,
					"delay" : 80,
				},
				"4" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-2-4",
					"origin" : [23,18],
					"z" : 0,
					"delay" : 80,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-3-0",
					"origin" : [23,18],
					"z" : 0,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-3-1",
					"origin" : [23,18],
					"z" : 0,
					"delay" : 80,
				},
				"2" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-3-2",
					"origin" : [23,18],
					"z" : 0,
					"delay" : 80,
				},
				"3" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-3-3",
					"origin" : [23,18],
					"z" : 0,
					"delay" : 80,
				},
				"4" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-3-4",
					"origin" : [25,18],
					"z" : 0,
					"delay" : 80,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-4-0",
					"origin" : [62,24],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSectorHangar-gate-4-1",
					"origin" : [62,24],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 1000,
				},
			},
		},
		"set1" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-set1-0-0",
					"origin" : [62,75],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-set1-1-0",
					"origin" : [92,46],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-set1-2-0",
					"origin" : [75,86],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-set1-3-0",
					"origin" : [62,24],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 1800,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSectorHangar-set1-3-1",
					"origin" : [62,24],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 1800,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-set1-4-0",
					"origin" : [31,71],
					"z" : 0,
					"a0" : 10,
					"a1" : 255,
					"delay" : 2500,
				},
				"1" :  {
					"png_path": "acc4.img/omegaSectorHangar-set1-4-1",
					"origin" : [31,71],
					"z" : 0,
					"a0" : 255,
					"a1" : 10,
					"delay" : 2500,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-set1-5-0",
					"origin" : [11,22],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc4.img/omegaSectorHangar-set1-6-0",
					"origin" : [27,60],
					"z" : 0,
				},
			},
		},
	},
};

