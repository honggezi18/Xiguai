var Objacc12 = Objacc12 || { }; 
Objacc12 =   {
	"id":"acc12",
	"aran" :  {
		"fire" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/aran-fire-0-0",
					"origin" : [38,286],
					"z" : 0,
					"delay" : 210,
				},
				"1" :  {
					"png_path": "acc12.img/aran-fire-0-1",
					"origin" : [53,286],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc12.img/aran-fire-0-2",
					"origin" : [58,273],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc12.img/aran-fire-0-3",
					"origin" : [68,258],
					"z" : 0,
					"delay" : 210,
				},
				"4" :  {
					"png_path": "acc12.img/aran-fire-0-4",
					"origin" : [67,268],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc12.img/aran-fire-0-5",
					"origin" : [54,317],
					"z" : 0,
					"delay" : 210,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/aran-fire-1-0",
					"origin" : [139,252],
					"z" : 0,
					"delay" : 210,
				},
				"1" :  {
					"png_path": "acc12.img/aran-fire-1-1",
					"origin" : [129,297],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc12.img/aran-fire-1-2",
					"origin" : [119,266],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc12.img/aran-fire-1-3",
					"origin" : [138,271],
					"z" : 0,
					"delay" : 210,
				},
				"4" :  {
					"png_path": "acc12.img/aran-fire-1-4",
					"origin" : [133,249],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc12.img/aran-fire-1-5",
					"origin" : [139,243],
					"z" : 0,
					"delay" : 210,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/aran-fire-2-0",
					"origin" : [40,204],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "acc12.img/aran-fire-2-1",
					"origin" : [40,214],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc12.img/aran-fire-2-2",
					"origin" : [46,206],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc12.img/aran-fire-2-3",
					"origin" : [67,202],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "acc12.img/aran-fire-2-4",
					"origin" : [61,210],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "acc12.img/aran-fire-2-5",
					"origin" : [48,233],
					"z" : 0,
					"delay" : 180,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/aran-fire-3-0",
					"origin" : [137,302],
					"z" : 0,
					"delay" : 240,
				},
				"1" :  {
					"png_path": "acc12.img/aran-fire-3-1",
					"origin" : [150,350],
					"z" : 0,
					"delay" : 240,
				},
				"2" :  {
					"png_path": "acc12.img/aran-fire-3-2",
					"origin" : [146,317],
					"z" : 0,
					"delay" : 240,
				},
				"3" :  {
					"png_path": "acc12.img/aran-fire-3-3",
					"origin" : [143,323],
					"z" : 0,
					"delay" : 240,
				},
				"4" :  {
					"png_path": "acc12.img/aran-fire-3-4",
					"origin" : [149,299],
					"z" : 0,
					"delay" : 240,
				},
				"5" :  {
					"png_path": "acc12.img/aran-fire-3-5",
					"origin" : [148,292],
					"z" : 0,
					"delay" : 240,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/aran-fire-4-0",
					"origin" : [125,226],
					"z" : 0,
					"delay" : 210,
				},
				"1" :  {
					"png_path": "acc12.img/aran-fire-4-1",
					"origin" : [124,269],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc12.img/aran-fire-4-2",
					"origin" : [114,223],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc12.img/aran-fire-4-3",
					"origin" : [126,245],
					"z" : 0,
					"delay" : 210,
				},
				"4" :  {
					"png_path": "acc12.img/aran-fire-4-4",
					"origin" : [123,223],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc12.img/aran-fire-4-5",
					"origin" : [121,217],
					"z" : 0,
					"delay" : 210,
				},
			},
		},
		"tree" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/aran-tree-0-0",
					"origin" : [152,73],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/aran-tree-1-0",
					"origin" : [13,314],
					"z" : 0,
					"delay" : 240,
				},
				"1" :  {
					"png_path": "acc12.img/aran-tree-1-1",
					"origin" : [13,320],
					"z" : 0,
					"delay" : 240,
				},
				"2" :  {
					"png_path": "acc12.img/aran-tree-1-2",
					"origin" : [13,302],
					"z" : 0,
					"delay" : 240,
				},
				"3" :  {
					"png_path": "acc12.img/aran-tree-1-3",
					"origin" : [13,325],
					"z" : 0,
					"delay" : 240,
				},
				"4" :  {
					"png_path": "acc12.img/aran-tree-1-4",
					"origin" : [13,299],
					"z" : 0,
					"delay" : 240,
				},
				"5" :  {
					"png_path": "acc12.img/aran-tree-1-5",
					"origin" : [13,286],
					"z" : 0,
					"delay" : 240,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/aran-tree-2-0",
					"origin" : [14,103],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/aran-tree-3-0",
					"origin" : [40,189],
					"z" : 0,
					"delay" : 210,
				},
				"1" :  {
					"png_path": "acc12.img/aran-tree-3-1",
					"origin" : [40,195],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc12.img/aran-tree-3-2",
					"origin" : [39,196],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc12.img/aran-tree-3-3",
					"origin" : [39,185],
					"z" : 0,
					"delay" : 210,
				},
				"4" :  {
					"png_path": "acc12.img/aran-tree-3-4",
					"origin" : [39,192],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc12.img/aran-tree-3-5",
					"origin" : [40,191],
					"z" : 0,
					"delay" : 210,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/aran-tree-4-0",
					"origin" : [139,97],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/aran-tree-5-0",
					"origin" : [59,194],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "acc12.img/aran-tree-5-1",
					"origin" : [68,203],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc12.img/aran-tree-5-2",
					"origin" : [89,205],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc12.img/aran-tree-5-3",
					"origin" : [74,169],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "acc12.img/aran-tree-5-4",
					"origin" : [78,170],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "acc12.img/aran-tree-5-5",
					"origin" : [86,196],
					"z" : 0,
					"delay" : 180,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/aran-tree-6-0",
					"origin" : [154,75],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc12.img/aran-tree-7-0",
					"origin" : [32,161],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "acc12.img/aran-tree-7-1",
					"origin" : [32,167],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc12.img/aran-tree-7-2",
					"origin" : [32,168],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc12.img/aran-tree-7-3",
					"origin" : [32,157],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "acc12.img/aran-tree-7-4",
					"origin" : [32,164],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "acc12.img/aran-tree-7-5",
					"origin" : [32,163],
					"z" : 0,
					"delay" : 180,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc12.img/aran-tree-8-0",
					"origin" : [122,155],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc12.img/aran-tree-9-0",
					"origin" : [48,165],
					"z" : 0,
					"delay" : 210,
				},
				"1" :  {
					"png_path": "acc12.img/aran-tree-9-1",
					"origin" : [57,167],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc12.img/aran-tree-9-2",
					"origin" : [80,169],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc12.img/aran-tree-9-3",
					"origin" : [72,135],
					"z" : 0,
					"delay" : 210,
				},
				"4" :  {
					"png_path": "acc12.img/aran-tree-9-4",
					"origin" : [74,136],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc12.img/aran-tree-9-5",
					"origin" : [76,167],
					"z" : 0,
					"delay" : 210,
				},
			},
		},
		"grass" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/aran-grass-0-0",
					"origin" : [126,185],
					"z" : 0,
					"delay" : 240,
				},
				"1" :  {
					"png_path": "acc12.img/aran-grass-0-1",
					"origin" : [126,191],
					"z" : 0,
					"delay" : 240,
				},
				"2" :  {
					"png_path": "acc12.img/aran-grass-0-2",
					"origin" : [126,192],
					"z" : 0,
					"delay" : 240,
				},
				"3" :  {
					"png_path": "acc12.img/aran-grass-0-3",
					"origin" : [126,181],
					"z" : 0,
					"delay" : 240,
				},
				"4" :  {
					"png_path": "acc12.img/aran-grass-0-4",
					"origin" : [126,188],
					"z" : 0,
					"delay" : 240,
				},
				"5" :  {
					"png_path": "acc12.img/aran-grass-0-5",
					"origin" : [126,187],
					"z" : 0,
					"delay" : 240,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/aran-grass-1-0",
					"origin" : [76,145],
					"z" : 0,
					"delay" : 210,
				},
				"1" :  {
					"png_path": "acc12.img/aran-grass-1-1",
					"origin" : [76,167],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc12.img/aran-grass-1-2",
					"origin" : [76,157],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc12.img/aran-grass-1-3",
					"origin" : [76,175],
					"z" : 0,
					"delay" : 210,
				},
				"4" :  {
					"png_path": "acc12.img/aran-grass-1-4",
					"origin" : [76,173],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc12.img/aran-grass-1-5",
					"origin" : [76,157],
					"z" : 0,
					"delay" : 210,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/aran-grass-2-0",
					"origin" : [122,212],
					"z" : 0,
					"delay" : 210,
				},
				"1" :  {
					"png_path": "acc12.img/aran-grass-2-1",
					"origin" : [122,212],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc12.img/aran-grass-2-2",
					"origin" : [122,194],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc12.img/aran-grass-2-3",
					"origin" : [122,192],
					"z" : 0,
					"delay" : 210,
				},
				"4" :  {
					"png_path": "acc12.img/aran-grass-2-4",
					"origin" : [122,199],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc12.img/aran-grass-2-5",
					"origin" : [122,234],
					"z" : 0,
					"delay" : 210,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/aran-grass-3-0",
					"origin" : [27,128],
					"z" : 0,
					"delay" : 210,
				},
				"1" :  {
					"png_path": "acc12.img/aran-grass-3-1",
					"origin" : [27,150],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc12.img/aran-grass-3-2",
					"origin" : [27,140],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc12.img/aran-grass-3-3",
					"origin" : [27,158],
					"z" : 0,
					"delay" : 210,
				},
				"4" :  {
					"png_path": "acc12.img/aran-grass-3-4",
					"origin" : [27,156],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc12.img/aran-grass-3-5",
					"origin" : [27,140],
					"z" : 0,
					"delay" : 210,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/aran-grass-4-0",
					"origin" : [28,129],
					"z" : 0,
					"delay" : 240,
				},
				"1" :  {
					"png_path": "acc12.img/aran-grass-4-1",
					"origin" : [28,151],
					"z" : 0,
					"delay" : 240,
				},
				"2" :  {
					"png_path": "acc12.img/aran-grass-4-2",
					"origin" : [28,141],
					"z" : 0,
					"delay" : 240,
				},
				"3" :  {
					"png_path": "acc12.img/aran-grass-4-3",
					"origin" : [28,159],
					"z" : 0,
					"delay" : 240,
				},
				"4" :  {
					"png_path": "acc12.img/aran-grass-4-4",
					"origin" : [28,157],
					"z" : 0,
					"delay" : 240,
				},
				"5" :  {
					"png_path": "acc12.img/aran-grass-4-5",
					"origin" : [28,141],
					"z" : 0,
					"delay" : 240,
				},
			},
		},
		"ship" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/aran-ship-0-0",
					"origin" : [484,385],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/aran-ship-1-0",
					"origin" : [141,81],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/aran-ship-2-0",
					"origin" : [27,70],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/aran-ship-2-1",
					"origin" : [31,70],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/aran-ship-2-2",
					"origin" : [28,70],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/aran-ship-2-3",
					"origin" : [27,70],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/aran-ship-3-0",
					"origin" : [311,37],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/aran-ship-4-0",
					"origin" : [160,106],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/aran-ship-5-0",
					"origin" : [357,493],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/aran-ship-5-1",
					"origin" : [357,494],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/aran-ship-5-2",
					"origin" : [357,495],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/aran-ship-5-3",
					"origin" : [357,496],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/aran-ship-5-4",
					"origin" : [357,495],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/aran-ship-5-5",
					"origin" : [357,494],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/aran-ship-6-0",
					"origin" : [151,27],
					"z" : 0,
					"delay" : 120,
				},
				"1" :  {
					"png_path": "acc12.img/aran-ship-6-1",
					"origin" : [173,76],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "acc12.img/aran-ship-6-2",
					"origin" : [188,60],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "acc12.img/aran-ship-6-3",
					"origin" : [200,53],
					"z" : 0,
					"delay" : 120,
				},
				"4" :  {
					"png_path": "acc12.img/aran-ship-6-4",
					"origin" : [209,51],
					"z" : 0,
					"delay" : 120,
				},
				"5" :  {
					"png_path": "acc12.img/aran-ship-6-5",
					"origin" : [220,55],
					"z" : 0,
					"delay" : 120,
				},
				"6" :  {
					"png_path": "acc12.img/aran-ship-6-6",
					"origin" : [232,-4],
					"z" : 0,
					"delay" : 120,
				},
				"7" :  {
					"png_path": "acc12.img/aran-ship-6-7",
					"origin" : [240,29],
					"z" : 0,
					"delay" : 120,
				},
				"8" :  {
					"png_path": "acc12.img/aran-ship-6-8",
					"origin" : [56,6],
					"z" : 0,
					"delay" : 120,
				},
				"9" :  {
					"png_path": "acc12.img/aran-ship-6-9",
					"origin" : [65,3],
					"z" : 0,
					"delay" : 120,
				},
				"10" :  {
					"png_path": "acc12.img/aran-ship-6-10",
					"origin" : [9,2],
					"z" : 0,
					"delay" : 120,
				},
			},
		},
		"house" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/aran-house-0-0",
					"origin" : [378,202],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/aran-house-1-0",
					"origin" : [800,299],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/aran-house-2-0",
					"origin" : [143,106],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/aran-house-3-0",
					"origin" : [397,40],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/aran-house-4-0",
					"origin" : [156,156],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/aran-house-5-0",
					"origin" : [181,137],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/aran-house-6-0",
					"origin" : [124,81],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc12.img/aran-house-7-0",
					"origin" : [57,297],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc12.img/aran-house-8-0",
					"origin" : [590,106],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc12.img/aran-house-9-0",
					"origin" : [152,297],
					"z" : 0,
				},
			},
		},
		"dragon" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/aran-dragon-0-0",
					"origin" : [411,85],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/aran-dragon-1-0",
					"origin" : [346,92],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/aran-dragon-2-0",
					"origin" : [197,127],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/aran-dragon-3-0",
					"origin" : [48,75],
					"z" : 0,
				},
			},
		},
	},
	"dragon" :  {
		"ship" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-ship-0-0",
					"origin" : [98,102],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/dragon-ship-0-1",
					"origin" : [98,101],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/dragon-ship-0-2",
					"origin" : [98,100],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/dragon-ship-0-3",
					"origin" : [98,99],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/dragon-ship-0-4",
					"origin" : [98,100],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/dragon-ship-0-5",
					"origin" : [98,101],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-ship-1-0",
					"origin" : [67,181],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/dragon-ship-1-1",
					"origin" : [67,180],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/dragon-ship-1-2",
					"origin" : [67,179],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/dragon-ship-1-3",
					"origin" : [67,178],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/dragon-ship-1-4",
					"origin" : [67,179],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/dragon-ship-1-5",
					"origin" : [67,180],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-ship-2-0",
					"origin" : [95,116],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-ship-3-0",
					"origin" : [102,36],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-ship-4-0",
					"origin" : [235,47],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/dragon-ship-4-1",
					"origin" : [259,51],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/dragon-ship-4-2",
					"origin" : [256,38],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/dragon-ship-4-3",
					"origin" : [235,47],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/dragon-ship-4-4",
					"origin" : [259,51],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/dragon-ship-4-5",
					"origin" : [229,38],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-ship-5-0",
					"origin" : [36,50],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-ship-6-0",
					"origin" : [48,101],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-ship-7-0",
					"origin" : [119,88],
					"z" : 0,
				},
			},
		},
		"port" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-port-0-0",
					"origin" : [105,122],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-port-1-0",
					"origin" : [63,64],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-port-2-0",
					"origin" : [116,98],
					"z" : 0,
				},
			},
		},
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-nature-0-0",
					"origin" : [265,103],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-nature-1-0",
					"origin" : [164,89],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-nature-2-0",
					"origin" : [113,57],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-nature-3-0",
					"origin" : [226,144],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-nature-4-0",
					"origin" : [121,80],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-nature-5-0",
					"origin" : [53,23],
					"z" : 0,
				},
			},
		},
		"door" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-door-0-0",
					"origin" : [435,163],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-door-1-0",
					"origin" : [264,134],
					"z" : 0,
				},
			},
		},
		"cave" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-cave-0-0",
					"origin" : [681,50],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-cave-1-0",
					"origin" : [146,95],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-cave-2-0",
					"origin" : [208,228],
					"z" : 0,
				},
			},
		},
		"dragon" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-dragon-0-0",
					"origin" : [358,63],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-dragon-1-0",
					"origin" : [301,94],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-dragon-2-0",
					"origin" : [172,112],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/dragon-dragon-3-0",
					"origin" : [36,66],
					"z" : 0,
				},
			},
		},
	},
	"mercedes" :  {
		"dragon" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/mercedes-dragon-0-0",
					"origin" : [447,71],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/mercedes-dragon-1-0",
					"origin" : [345,109],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/mercedes-dragon-2-0",
					"origin" : [148,52],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/mercedes-dragon-3-0",
					"origin" : [149,76],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/mercedes-dragon-4-0",
					"origin" : [48,77],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/mercedes-dragon-5-0",
					"origin" : [31,12],
					"z" : 0,
					"delay" : 240,
				},
				"1" :  {
					"png_path": "acc12.img/mercedes-dragon-5-1",
					"origin" : [31,12],
					"z" : 0,
					"delay" : 240,
				},
				"2" :  {
					"png_path": "acc12.img/mercedes-dragon-5-2",
					"origin" : [31,12],
					"z" : 0,
					"delay" : 240,
				},
				"3" :  {
					"png_path": "acc12.img/mercedes-dragon-5-3",
					"origin" : [31,12],
					"z" : 0,
					"delay" : 240,
				},
				"4" :  {
					"png_path": "acc12.img/mercedes-dragon-5-4",
					"origin" : [31,12],
					"z" : 0,
					"delay" : 240,
				},
				"5" :  {
					"png_path": "acc12.img/mercedes-dragon-5-5",
					"origin" : [0,0],
					"z" : 0,
					"delay" : 1500,
				},
			},
		},
	},
	"rienTW" :  {
		"polearm" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-polearm-0-0",
					"origin" : [517,195],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-polearm-1-0",
					"origin" : [136,125],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-polearm-2-0",
					"origin" : [115,50],
					"z" : 0,
				},
			},
		},
		"market" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-market-0-0",
					"origin" : [170,174],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-market-1-0",
					"origin" : [85,40],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-market-2-0",
					"origin" : [78,39],
					"z" : 0,
				},
			},
		},
		"ship" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-0-0",
					"origin" : [227,181],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-1-0",
					"origin" : [129,179],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-2-0",
					"origin" : [129,179],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-3-0",
					"origin" : [101,180],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-4-0",
					"origin" : [196,135],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-5-0",
					"origin" : [146,276],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-6-0",
					"origin" : [451,104],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-7-0",
					"origin" : [128,57],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-8-0",
					"origin" : [75,73],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-9-0",
					"origin" : [61,41],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-10-0",
					"origin" : [34,40],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-12-0",
					"origin" : [232,184],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienTW-ship-12-1",
					"origin" : [232,184],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienTW-ship-12-2",
					"origin" : [232,184],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienTW-ship-12-3",
					"origin" : [232,184],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/rienTW-ship-12-4",
					"origin" : [232,184],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/rienTW-ship-12-5",
					"origin" : [232,184],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc12.img/rienTW-ship-12-6",
					"origin" : [232,184],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc12.img/rienTW-ship-12-7",
					"origin" : [232,184],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-13-0",
					"origin" : [231,383],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienTW-ship-13-1",
					"origin" : [231,382],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienTW-ship-13-2",
					"origin" : [231,381],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienTW-ship-13-3",
					"origin" : [231,380],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/rienTW-ship-13-4",
					"origin" : [231,381],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/rienTW-ship-13-5",
					"origin" : [231,382],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc12.img/rienTW-ship-13-6",
					"origin" : [231,383],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc12.img/rienTW-ship-13-7",
					"origin" : [231,384],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-14-0",
					"origin" : [120,109],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-15-0",
					"origin" : [212,37],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-16-0",
					"origin" : [345,36],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienTW-ship-16-1",
					"origin" : [237,25],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienTW-ship-16-2",
					"origin" : [234,25],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienTW-ship-16-3",
					"origin" : [255,25],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/rienTW-ship-16-4",
					"origin" : [274,25],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/rienTW-ship-16-5",
					"origin" : [307,25],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc12.img/rienTW-ship-16-6",
					"origin" : [322,28],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc12.img/rienTW-ship-16-7",
					"origin" : [331,39],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-ship-17-0",
					"origin" : [43,16],
					"z" : 0,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-acc-0-0",
					"origin" : [92,36],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-acc-1-0",
					"origin" : [69,37],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-acc-2-0",
					"origin" : [11,20],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-acc-3-0",
					"origin" : [47,63],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienTW-acc-3-1",
					"origin" : [48,63],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienTW-acc-3-2",
					"origin" : [49,63],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienTW-acc-3-3",
					"origin" : [48,63],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/rienTW-acc-3-4",
					"origin" : [46,63],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/rienTW-acc-3-5",
					"origin" : [44,63],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc12.img/rienTW-acc-3-6",
					"origin" : [43,63],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-acc-4-0",
					"origin" : [16,18],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-acc-5-0",
					"origin" : [152,105],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-acc-6-0",
					"origin" : [208,70],
					"z" : 0,
				},
			},
		},
		"master" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-0-0",
					"origin" : [111,197],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-1-0",
					"origin" : [114,197],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-2-0",
					"origin" : [89,406],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-3-0",
					"origin" : [90,406],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-4-0",
					"origin" : [22,50],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-5-0",
					"origin" : [461,101],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-6-0",
					"origin" : [20,49],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-7-0",
					"origin" : [461,53],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-8-0",
					"origin" : [130,48],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-9-0",
					"origin" : [461,89],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-10-0",
					"origin" : [84,41],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-11-0",
					"origin" : [84,41],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-12-0",
					"origin" : [26,77],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-13-0",
					"origin" : [26,77],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-14-0",
					"origin" : [64,46],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-15-0",
					"origin" : [118,81],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc12.img/rienTW-master-16-0",
					"origin" : [221,38],
					"z" : 0,
				},
			},
		},
	},
	"rienFD" :  {
		"nature0" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-0-0",
					"origin" : [107,189],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-1-0",
					"origin" : [130,162],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-2-0",
					"origin" : [126,255],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-3-0",
					"origin" : [116,194],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-4-0",
					"origin" : [115,190],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-5-0",
					"origin" : [174,265],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-6-0",
					"origin" : [135,256],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-7-0",
					"origin" : [64,50],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-8-0",
					"origin" : [48,38],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-9-0",
					"origin" : [27,43],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-10-0",
					"origin" : [19,34],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-11-0",
					"origin" : [22,20],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-12-0",
					"origin" : [13,21],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-13-0",
					"origin" : [32,28],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-14-0",
					"origin" : [32,25],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-15-0",
					"origin" : [21,14],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-16-0",
					"origin" : [29,18],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-17-0",
					"origin" : [24,13],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-18-0",
					"origin" : [18,12],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-19-0",
					"origin" : [54,19],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-20-0",
					"origin" : [30,11],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-21-0",
					"origin" : [29,18],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-22-0",
					"origin" : [29,17],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-23-0",
					"origin" : [31,19],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-24-0",
					"origin" : [27,19],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-25-0",
					"origin" : [22,31],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature0-26-0",
					"origin" : [24,25],
					"z" : 0,
				},
			},
		},
		"nature1" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-0-0",
					"origin" : [234,111],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-1-0",
					"origin" : [310,167],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-2-0",
					"origin" : [187,321],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-3-0",
					"origin" : [107,188],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-4-0",
					"origin" : [130,160],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-5-0",
					"origin" : [126,257],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-6-0",
					"origin" : [116,196],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-7-0",
					"origin" : [115,192],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-8-0",
					"origin" : [174,265],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-9-0",
					"origin" : [136,256],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-10-0",
					"origin" : [66,49],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-11-0",
					"origin" : [50,38],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-12-0",
					"origin" : [27,42],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-13-0",
					"origin" : [19,36],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-14-0",
					"origin" : [22,20],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-15-0",
					"origin" : [13,21],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-16-0",
					"origin" : [104,43],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-17-0",
					"origin" : [61,46],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-18-0",
					"origin" : [41,39],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-19-0",
					"origin" : [30,23],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-nature1-20-0",
					"origin" : [32,20],
					"z" : 0,
				},
			},
		},
		"work" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-0-0",
					"origin" : [583,82],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-1-0",
					"origin" : [364,103],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-2-0",
					"origin" : [146,95],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-3-0",
					"origin" : [103,45],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-4-0",
					"origin" : [94,75],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-5-0",
					"origin" : [152,120],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-6-0",
					"origin" : [231,125],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-7-0",
					"origin" : [258,77],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-8-0",
					"origin" : [89,106],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-9-0",
					"origin" : [145,66],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-10-0",
					"origin" : [125,145],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-11-0",
					"origin" : [82,271],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-work-11-1",
					"origin" : [82,271],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-work-11-2",
					"origin" : [82,271],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-work-11-3",
					"origin" : [82,271],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/rienFD-work-11-4",
					"origin" : [82,271],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/rienFD-work-11-5",
					"origin" : [82,271],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc12.img/rienFD-work-11-6",
					"origin" : [82,271],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc12.img/rienFD-work-11-7",
					"origin" : [82,271],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc12.img/rienFD-work-11-8",
					"origin" : [82,271],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc12.img/rienFD-work-11-9",
					"origin" : [82,271],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc12.img/rienFD-work-11-10",
					"origin" : [82,271],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc12.img/rienFD-work-11-11",
					"origin" : [82,271],
					"z" : 0,
				},
				"12" :  {
					"png_path": "acc12.img/rienFD-work-11-12",
					"origin" : [82,271],
					"z" : 0,
				},
				"13" :  {
					"png_path": "acc12.img/rienFD-work-11-13",
					"origin" : [82,271],
					"z" : 0,
				},
				"14" :  {
					"png_path": "acc12.img/rienFD-work-11-14",
					"origin" : [82,271],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-work-12-0",
					"origin" : [70,351],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-work-12-1",
					"origin" : [70,351],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-work-12-2",
					"origin" : [70,351],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-work-12-3",
					"origin" : [70,351],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/rienFD-work-12-4",
					"origin" : [70,351],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/rienFD-work-12-5",
					"origin" : [70,351],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc12.img/rienFD-work-12-6",
					"origin" : [70,351],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc12.img/rienFD-work-12-7",
					"origin" : [70,351],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc12.img/rienFD-work-12-8",
					"origin" : [70,351],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc12.img/rienFD-work-12-9",
					"origin" : [70,351],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc12.img/rienFD-work-12-10",
					"origin" : [70,351],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc12.img/rienFD-work-12-11",
					"origin" : [70,351],
					"z" : 0,
				},
				"12" :  {
					"png_path": "acc12.img/rienFD-work-12-12",
					"origin" : [70,351],
					"z" : 0,
				},
				"13" :  {
					"png_path": "acc12.img/rienFD-work-12-13",
					"origin" : [70,351],
					"z" : 0,
				},
				"14" :  {
					"png_path": "acc12.img/rienFD-work-12-14",
					"origin" : [70,351],
					"z" : 0,
				},
			},
		},
		"ice" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-ice-0-0",
					"origin" : [193,56],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-ice-1-0",
					"origin" : [144,79],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-ice-2-0",
					"origin" : [91,44],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-ice-3-0",
					"origin" : [62,35],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-ice-4-0",
					"origin" : [44,27],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-ice-5-0",
					"origin" : [33,22],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-ice-6-0",
					"origin" : [52,43],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-ice-7-0",
					"origin" : [52,17],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-ice-8-0",
					"origin" : [24,38],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-ice-9-0",
					"origin" : [12,49],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-ice-10-0",
					"origin" : [33,8],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-ice-11-0",
					"origin" : [18,14],
					"z" : 0,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-0-0",
					"origin" : [120,59],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-1-0",
					"origin" : [122,59],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-2-0",
					"origin" : [88,168],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-3-0",
					"origin" : [72,157],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-4-0",
					"origin" : [77,90],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-5-0",
					"origin" : [87,178],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-6-0",
					"origin" : [168,137],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-7-0",
					"origin" : [177,95],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-8-0",
					"origin" : [102,65],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-9-0",
					"origin" : [78,43],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-10-0",
					"origin" : [75,55],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-11-0",
					"origin" : [63,38],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-12-0",
					"origin" : [64,37],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-13-0",
					"origin" : [57,35],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-14-0",
					"origin" : [57,39],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-15-0",
					"origin" : [66,12],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-16-0",
					"origin" : [43,42],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-17-0",
					"origin" : [73,34],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-18-0",
					"origin" : [22,26],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-19-0",
					"origin" : [27,34],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-20-0",
					"origin" : [99,32],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-acc-21-0",
					"origin" : [126,122],
					"z" : 0,
					"delay" : 240,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-acc-21-1",
					"origin" : [126,122],
					"z" : 0,
					"delay" : 240,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-acc-21-2",
					"origin" : [126,122],
					"z" : 0,
					"delay" : 240,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-acc-21-3",
					"origin" : [126,122],
					"z" : 0,
					"delay" : 240,
				},
				"4" :  {
					"png_path": "acc12.img/rienFD-acc-21-4",
					"origin" : [126,122],
					"z" : 0,
					"delay" : 240,
				},
				"5" :  {
					"png_path": "acc12.img/rienFD-acc-21-5",
					"origin" : [126,122],
					"z" : 0,
					"delay" : 240,
				},
			},
		},
		"pengiun" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-pengiun-0-0",
					"origin" : [28,57],
					"z" : 0,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-pengiun-0-1",
					"origin" : [28,57],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-pengiun-0-2",
					"origin" : [28,57],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-pengiun-0-3",
					"origin" : [28,57],
					"z" : 0,
					"delay" : 150,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-pengiun-1-0",
					"origin" : [17,66],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-pengiun-1-1",
					"origin" : [17,64],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-pengiun-1-2",
					"origin" : [20,64],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-pengiun-1-3",
					"origin" : [18,64],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-pengiun-2-0",
					"origin" : [37,63],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-pengiun-2-1",
					"origin" : [37,63],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-pengiun-2-2",
					"origin" : [46,63],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-pengiun-2-3",
					"origin" : [51,63],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-pengiun-3-0",
					"origin" : [23,65],
					"z" : 0,
					"delay" : 90,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-pengiun-3-1",
					"origin" : [23,67],
					"z" : 0,
					"delay" : 90,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-pengiun-3-2",
					"origin" : [23,65],
					"z" : 0,
					"delay" : 90,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-pengiun-3-3",
					"origin" : [23,67],
					"z" : 0,
					"delay" : 90,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-pengiun-4-0",
					"origin" : [25,64],
					"z" : 0,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-pengiun-4-1",
					"origin" : [25,63],
					"z" : 0,
					"delay" : 1200,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-pengiun-5-0",
					"origin" : [94,69],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-pengiun-5-1",
					"origin" : [94,68],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-pengiun-5-2",
					"origin" : [94,68],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-pengiun-5-3",
					"origin" : [94,67],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "acc12.img/rienFD-pengiun-5-4",
					"origin" : [94,67],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "acc12.img/rienFD-pengiun-5-5",
					"origin" : [94,69],
					"z" : 0,
					"delay" : 180,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-pengiun-6-0",
					"origin" : [31,65],
					"z" : 0,
					"delay" : 90,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-pengiun-6-1",
					"origin" : [31,65],
					"z" : 0,
					"delay" : 90,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-pengiun-6-2",
					"origin" : [31,65],
					"z" : 0,
					"delay" : 90,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-pengiun-6-3",
					"origin" : [31,65],
					"z" : 0,
					"delay" : 90,
				},
				"4" :  {
					"png_path": "acc12.img/rienFD-pengiun-6-4",
					"origin" : [31,65],
					"z" : 0,
					"delay" : 90,
				},
				"5" :  {
					"png_path": "acc12.img/rienFD-pengiun-6-5",
					"origin" : [31,65],
					"z" : 0,
					"delay" : 90,
				},
			},
		},
		"door" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-door-0-0",
					"origin" : [96,90],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-door-1-0",
					"origin" : [78,59],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-door-2-0",
					"origin" : [78,71],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-door-3-0",
					"origin" : [78,91],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-door-4-0",
					"origin" : [77,87],
					"z" : 0,
				},
			},
		},
		"cave0" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-cave0-0-0",
					"origin" : [500,50],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-cave0-1-0",
					"origin" : [73,14],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-cave0-2-0",
					"origin" : [30,33],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-cave0-3-0",
					"origin" : [86,42],
					"z" : 0,
				},
			},
		},
		"cave1" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-cave1-0-0",
					"origin" : [77,99],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-cave1-1-0",
					"origin" : [143,167],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-cave1-2-0",
					"origin" : [79,102],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-cave1-3-0",
					"origin" : [63,86],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-cave1-3-1",
					"origin" : [101,90],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-cave1-3-2",
					"origin" : [98,86],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-cave1-3-3",
					"origin" : [94,83],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/rienFD-cave1-3-4",
					"origin" : [86,83],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/rienFD-cave1-3-5",
					"origin" : [73,84],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc12.img/rienFD-cave1-3-6",
					"origin" : [62,85],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc12.img/rienFD-cave1-3-7",
					"origin" : [64,84],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc12.img/rienFD-cave1-3-8",
					"origin" : [64,83],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc12.img/rienFD-cave1-3-9",
					"origin" : [59,83],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc12.img/rienFD-cave1-3-10",
					"origin" : [59,81],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc12.img/rienFD-cave1-3-11",
					"origin" : [60,83],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-cave1-4-0",
					"origin" : [83,76],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-cave1-4-1",
					"origin" : [82,76],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-cave1-4-2",
					"origin" : [83,76],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-cave1-4-3",
					"origin" : [83,75],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/rienFD-cave1-4-4",
					"origin" : [83,76],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/rienFD-cave1-4-5",
					"origin" : [83,76],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-cave1-5-0",
					"origin" : [21,39],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-cave1-5-1",
					"origin" : [20,38],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-cave1-5-2",
					"origin" : [21,39],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-cave1-5-3",
					"origin" : [21,39],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/rienFD-cave1-5-4",
					"origin" : [21,39],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/rienFD-cave1-5-5",
					"origin" : [21,39],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-cave1-6-0",
					"origin" : [38,67],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-cave1-6-1",
					"origin" : [38,67],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-cave1-6-2",
					"origin" : [38,67],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-cave1-6-3",
					"origin" : [37,66],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/rienFD-cave1-6-4",
					"origin" : [38,67],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/rienFD-cave1-6-5",
					"origin" : [38,67],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-cave1-7-0",
					"origin" : [29,48],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc12.img/rienFD-cave1-7-1",
					"origin" : [30,49],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc12.img/rienFD-cave1-7-2",
					"origin" : [30,49],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc12.img/rienFD-cave1-7-3",
					"origin" : [30,49],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc12.img/rienFD-cave1-7-4",
					"origin" : [30,49],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc12.img/rienFD-cave1-7-5",
					"origin" : [30,49],
					"z" : 0,
				},
			},
		},
		"npc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienFD-npc-0-0",
					"origin" : [-17,45],
					"z" : 0,
				},
			},
		},
	},
	"rienTR" :  {
		"door" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-door-0-0",
					"origin" : [157,62],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-door-1-0",
					"origin" : [204,37],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-door-2-0",
					"origin" : [475,112],
					"z" : 0,
				},
			},
		},
		"wall" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-wall-0-0",
					"origin" : [27,129],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-wall-1-0",
					"origin" : [223,129],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-wall-2-0",
					"origin" : [223,129],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-wall-3-0",
					"origin" : [34,129],
					"z" : 0,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-0-0",
					"origin" : [209,130],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-1-0",
					"origin" : [105,95],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-2-0",
					"origin" : [178,139],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-3-0",
					"origin" : [68,82],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-4-0",
					"origin" : [56,190],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-5-0",
					"origin" : [36,66],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-6-0",
					"origin" : [120,67],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-7-0",
					"origin" : [30,62],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-8-0",
					"origin" : [106,108],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-9-0",
					"origin" : [113,71],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-10-0",
					"origin" : [150,57],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-11-0",
					"origin" : [39,55],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-12-0",
					"origin" : [98,58],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-13-0",
					"origin" : [48,60],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-14-0",
					"origin" : [82,43],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-15-0",
					"origin" : [61,25],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-16-0",
					"origin" : [79,54],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-17-0",
					"origin" : [66,52],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-18-0",
					"origin" : [46,29],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-19-0",
					"origin" : [36,27],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-20-0",
					"origin" : [33,40],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc12.img/rienTR-acc-21-0",
					"origin" : [32,30],
					"z" : 0,
				},
			},
		},
	},
};

