var Objacc1 = Objacc1 || { }; 
Objacc1 =   {
	"id":"acc1",
	"grassySoil" :  {
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-0-0",
					"origin" : [65,18],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-1-0",
					"origin" : [27,17],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-2-0",
					"origin" : [28,17],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-3-0",
					"origin" : [23,22],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-4-0",
					"origin" : [21,21],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-5-0",
					"origin" : [23,33],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-6-0",
					"origin" : [28,26],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-7-0",
					"origin" : [31,20],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-8-0",
					"origin" : [36,28],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-9-0",
					"origin" : [30,31],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-10-0",
					"origin" : [41,30],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-11-0",
					"origin" : [66,147],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-12-0",
					"origin" : [60,143],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-13-0",
					"origin" : [111,60],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-14-0",
					"origin" : [48,41],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-15-0",
					"origin" : [145,119],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-16-0",
					"origin" : [100,52],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-17-0",
					"origin" : [70,31],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-18-0",
					"origin" : [19,17],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-19-0",
					"origin" : [16,8],
					"z" : 0,
					"delay" : 130,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-nature-19-1",
					"origin" : [40,-7],
					"z" : 0,
					"delay" : 130,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-nature-19-2",
					"origin" : [53,4],
					"z" : 0,
					"delay" : 130,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil-nature-19-3",
					"origin" : [49,16],
					"z" : 0,
					"delay" : 130,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil-nature-19-4",
					"origin" : [22,42],
					"z" : 0,
					"delay" : 130,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil-nature-19-5",
					"origin" : [3,22],
					"z" : 0,
					"delay" : 130,
				},
				"6" :  {
					"png_path": "acc1.img/grassySoil-nature-19-6",
					"origin" : [-27,12],
					"z" : 0,
					"delay" : 130,
				},
				"7" :  {
					"png_path": "acc1.img/grassySoil-nature-19-7",
					"origin" : [-47,17],
					"z" : 0,
					"delay" : 130,
				},
				"8" :  {
					"png_path": "acc1.img/grassySoil-nature-19-8",
					"origin" : [-10,-8],
					"z" : 0,
					"delay" : 130,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-20-0",
					"origin" : [19,8],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-nature-20-1",
					"origin" : [14,12],
					"z" : 0,
					"delay" : 200,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-nature-20-2",
					"origin" : [8,17],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil-nature-20-3",
					"origin" : [2,19],
					"z" : 0,
					"delay" : 200,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil-nature-20-2",
					"origin" : [8,17],
					"z" : 0,
					"delay" : 200,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil-nature-20-1",
					"origin" : [14,12],
					"z" : 0,
					"delay" : 200,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-21-0",
					"origin" : [16,9],
					"z" : 0,
					"delay" : 130,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-nature-21-1",
					"origin" : [-18,-8],
					"z" : 0,
					"delay" : 130,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-nature-21-2",
					"origin" : [-50,-33],
					"z" : 0,
					"delay" : 130,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil-nature-21-3",
					"origin" : [-62,-14],
					"z" : 0,
					"delay" : 130,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil-nature-21-4",
					"origin" : [-56,5],
					"z" : 0,
					"delay" : 130,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil-nature-21-5",
					"origin" : [-74,7],
					"z" : 0,
					"delay" : 130,
				},
				"6" :  {
					"png_path": "acc1.img/grassySoil-nature-21-6",
					"origin" : [-74,-18],
					"z" : 0,
					"delay" : 130,
				},
				"7" :  {
					"png_path": "acc1.img/grassySoil-nature-21-7",
					"origin" : [-50,-33],
					"z" : 0,
					"delay" : 130,
				},
				"8" :  {
					"png_path": "acc1.img/grassySoil-nature-21-8",
					"origin" : [-9,-22],
					"z" : 0,
					"delay" : 130,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-22-0",
					"origin" : [20,33],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-23-0",
					"origin" : [31,44],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-24-0",
					"origin" : [25,38],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-25-0",
					"origin" : [66,91],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-nature-25-1",
					"origin" : [66,91],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 3000,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-26-0",
					"origin" : [60,78],
					"z" : 0,
					"delay" : 2100,
					"a0" : 0,
					"a1" : 255,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-nature-26-1",
					"origin" : [60,78],
					"z" : 0,
					"delay" : 2100,
					"a0" : 255,
					"a1" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-nature-27-0",
					"origin" : [168,13],
					"z" : 0,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-0-0",
					"origin" : [32,58],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-1-0",
					"origin" : [27,32],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-2-0",
					"origin" : [118,40],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-3-0",
					"origin" : [0,0],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-4-0",
					"origin" : [88,63],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-5-0",
					"origin" : [0,0],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-6-0",
					"origin" : [66,30],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-36,24],
					"1" : [31,24],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-7-0",
					"origin" : [60,30],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-8-0",
					"origin" : [54,38],
					"z" : 0,
					"delay" : 900,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-artificiality-8-1",
					"origin" : [54,38],
					"z" : 0,
					"delay" : 900,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-artificiality-8-0",
					"origin" : [54,38],
					"z" : 0,
					"delay" : 900,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil-artificiality-8-1",
					"origin" : [54,38],
					"z" : 0,
					"delay" : 900,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil-artificiality-8-0",
					"origin" : [54,38],
					"z" : 0,
					"delay" : 900,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil-artificiality-8-1",
					"origin" : [54,38],
					"z" : 0,
					"delay" : 900,
				},
				"6" :  {
					"png_path": "acc1.img/grassySoil-artificiality-8-6",
					"origin" : [54,38],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc1.img/grassySoil-artificiality-8-7",
					"origin" : [54,38],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "acc1.img/grassySoil-artificiality-8-6",
					"origin" : [54,38],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "acc1.img/grassySoil-artificiality-8-7",
					"origin" : [54,38],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "acc1.img/grassySoil-artificiality-8-10",
					"origin" : [54,38],
					"z" : 0,
					"delay" : 1500,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-9-0",
					"origin" : [76,44],
					"z" : 0,
					"delay" : 120,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-artificiality-9-1",
					"origin" : [76,44],
					"z" : 0,
					"delay" : 120,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-10-0",
					"origin" : [26,26],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-11-0",
					"origin" : [32,26],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-12-0",
					"origin" : [36,68],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-13-0",
					"origin" : [36,68],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-14-0",
					"origin" : [20,42],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-16-0",
					"origin" : [24,27],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-17-0",
					"origin" : [25,27],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-18-0",
					"origin" : [92,55],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-19-0",
					"origin" : [19,26],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-20-0",
					"origin" : [33,23],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-21-0",
					"origin" : [231,40],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-22-0",
					"origin" : [221,32],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-23-0",
					"origin" : [24,24],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-24-0",
					"origin" : [24,22],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-25-0",
					"origin" : [21,46],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-26-0",
					"origin" : [48,45],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-27-0",
					"origin" : [57,75],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-28-0",
					"origin" : [130,76],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-29-0",
					"origin" : [29,55],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-30-0",
					"origin" : [18,14],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-31-0",
					"origin" : [44,13],
					"z" : 0,
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-32-0",
					"origin" : [236,33],
					"z" : 0,
				},
			},
			"33" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-33-0",
					"origin" : [103,70],
					"z" : 0,
				},
			},
			"34" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-34-0",
					"origin" : [52,70],
					"z" : 0,
				},
			},
			"35" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-35-0",
					"origin" : [37,14],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-18,14],
					"1" : [5,14],
					"2" : [26,14],
				},
			},
			"36" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-36-0",
					"origin" : [0,0],
				},
			},
			"37" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-37-0",
					"origin" : [0,0],
				},
			},
			"38" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-38-0",
					"origin" : [0,0],
				},
			},
			"39" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-39-0",
					"origin" : [389,310],
					"z" : 0,
				},
			},
			"40" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-40-0",
					"origin" : [45,32],
					"z" : 0,
				},
			},
			"41" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-41-0",
					"origin" : [0,0],
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-15-0",
					"origin" : [21,44],
					"z" : 0,
				},
			},
			"42" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-42-0",
					"origin" : [236,120],
					"z" : 0,
				},
			},
			"43" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-artificiality-43-0",
					"origin" : [88,151],
					"z" : 0,
					"delay" : 120,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-artificiality-43-1",
					"origin" : [82,152],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-artificiality-43-2",
					"origin" : [74,151],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil-artificiality-43-3",
					"origin" : [74,151],
					"z" : 0,
					"delay" : 120,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil-artificiality-43-4",
					"origin" : [92,152],
					"z" : 0,
					"delay" : 120,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil-artificiality-43-5",
					"origin" : [89,151],
					"z" : 0,
					"delay" : 120,
				},
				"6" :  {
					"png_path": "acc1.img/grassySoil-artificiality-43-6",
					"origin" : [83,148],
					"z" : 0,
					"delay" : 120,
				},
				"7" :  {
					"png_path": "acc1.img/grassySoil-artificiality-43-7",
					"origin" : [93,143],
					"z" : 0,
					"delay" : 120,
				},
				"8" :  {
					"png_path": "acc1.img/grassySoil-artificiality-43-8",
					"origin" : [91,143],
					"z" : 0,
					"delay" : 120,
				},
			},
		},
		"market" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-0-0",
					"origin" : [107,75],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-1-0",
					"origin" : [107,75],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-2-0",
					"origin" : [107,75],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-3-0",
					"origin" : [73,14],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-4-0",
					"origin" : [92,92],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-5-0",
					"origin" : [92,92],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-6-0",
					"origin" : [92,92],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-7-0",
					"origin" : [12,92],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-8-0",
					"origin" : [117,75],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-9-0",
					"origin" : [118,75],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-10-0",
					"origin" : [105,75],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-11-0",
					"origin" : [138,75],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-12-0",
					"origin" : [134,69],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-13-0",
					"origin" : [131,45],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-14-0",
					"origin" : [89,54],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-15-0",
					"origin" : [123,90],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-16-0",
					"origin" : [98,92],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-17-0",
					"origin" : [75,43],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-18-0",
					"origin" : [29,21],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-19-0",
					"origin" : [57,53],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-20-0",
					"origin" : [70,57],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-21-0",
					"origin" : [22,45],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-22-0",
					"origin" : [43,48],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-23-0",
					"origin" : [43,33],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-24-0",
					"origin" : [88,37],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-25-0",
					"origin" : [25,20],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-26-0",
					"origin" : [88,37],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-27-0",
					"origin" : [43,34],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-28-0",
					"origin" : [131,92],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-29-0",
					"origin" : [28,15],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-30-0",
					"origin" : [13,25],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-31-0",
					"origin" : [14,14],
					"z" : 0,
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-32-0",
					"origin" : [22,30],
					"z" : 0,
				},
			},
			"35" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-35-0",
					"origin" : [25,28],
					"z" : 0,
				},
			},
			"36" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-36-0",
					"origin" : [27,19],
					"z" : 0,
				},
			},
			"38" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-38-0",
					"origin" : [36,22],
					"z" : 0,
				},
			},
			"43" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-43-0",
					"origin" : [21,33],
					"z" : 0,
				},
			},
			"45" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-45-0",
					"origin" : [27,12],
					"z" : 0,
				},
			},
			"47" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-47-0",
					"origin" : [11,18],
					"z" : 0,
				},
			},
			"48" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-48-0",
					"origin" : [27,22],
					"z" : 0,
				},
			},
			"49" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-49-0",
					"origin" : [28,17],
					"z" : 0,
				},
			},
			"50" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-50-0",
					"origin" : [28,17],
					"z" : 0,
				},
			},
			"51" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-51-0",
					"origin" : [216,182],
					"z" : 0,
				},
			},
			"52" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-52-0",
					"origin" : [159,78],
					"z" : 0,
				},
			},
			"53" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-53-0",
					"origin" : [18,19],
					"z" : 0,
					"delay" : 1100,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-market-53-1",
					"origin" : [18,19],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-market-53-2",
					"origin" : [18,19],
					"z" : 0,
					"delay" : 150,
				},
			},
			"54" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-54-0",
					"origin" : [14,16],
					"z" : 0,
					"delay" : 500,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-market-54-1",
					"origin" : [14,16],
					"z" : 0,
					"delay" : 800,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-market-54-2",
					"origin" : [14,16],
					"z" : 0,
					"delay" : 400,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil-market-54-3",
					"origin" : [14,16],
					"z" : 0,
					"delay" : 850,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil-market-54-4",
					"origin" : [14,16],
					"z" : 0,
					"delay" : 1000,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil-market-54-5",
					"origin" : [14,12],
					"z" : 0,
					"delay" : 100,
				},
				"6" :  {
					"png_path": "acc1.img/grassySoil-market-54-6",
					"origin" : [14,16],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc1.img/grassySoil-market-54-7",
					"origin" : [14,12],
					"z" : 0,
					"delay" : 100,
				},
				"8" :  {
					"png_path": "acc1.img/grassySoil-market-54-8",
					"origin" : [14,16],
					"z" : 0,
					"delay" : 1500,
				},
			},
			"55" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-55-0",
					"origin" : [224,157],
					"z" : 0,
				},
			},
			"56" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-56-0",
					"origin" : [128,70],
					"z" : 0,
				},
			},
			"57" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-57-0",
					"origin" : [119,76],
					"z" : 0,
				},
			},
			"58" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-58-0",
					"origin" : [29,68],
					"z" : 0,
				},
			},
			"59" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-59-0",
					"origin" : [30,66],
					"z" : 0,
				},
			},
			"60" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-60-0",
					"origin" : [144,-33],
					"z" : 0,
				},
			},
			"61" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-61-0",
					"origin" : [154,21],
					"z" : 0,
				},
			},
			"62" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-62-0",
					"origin" : [307,102],
					"z" : 0,
				},
			},
			"33" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-33-0",
					"origin" : [25,30],
					"z" : 0,
				},
			},
			"34" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-34-0",
					"origin" : [14,35],
					"z" : 0,
				},
			},
			"37" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-37-0",
					"origin" : [18,25],
					"z" : 0,
				},
			},
			"39" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-39-0",
					"origin" : [16,31],
					"z" : 0,
				},
			},
			"40" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-40-0",
					"origin" : [21,28],
					"z" : 0,
				},
			},
			"41" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-41-0",
					"origin" : [31,15],
					"z" : 0,
				},
			},
			"42" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-42-0",
					"origin" : [18,39],
					"z" : 0,
				},
			},
			"44" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-44-0",
					"origin" : [12,35],
					"z" : 0,
				},
			},
			"46" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-market-46-0",
					"origin" : [40,14],
					"z" : 0,
				},
			},
		},
		"space" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-0-0",
					"origin" : [0,0],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-1-0",
					"origin" : [0,0],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-2-0",
					"origin" : [0,0],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-3-0",
					"origin" : [80,9],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-4-0",
					"origin" : [80,9],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-5-0",
					"origin" : [27,58],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-6-0",
					"origin" : [80,69],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-7-0",
					"origin" : [30,46],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-8-0",
					"origin" : [83,51],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-9-0",
					"origin" : [98,122],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-10-0",
					"origin" : [32,77],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-11-0",
					"origin" : [32,77],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-12-0",
					"origin" : [41,19],
					"z" : 0,
					"delay" : 300,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-13-0",
					"origin" : [131,139],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-14-0",
					"origin" : [80,9],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-15-0",
					"origin" : [80,9],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-16-0",
					"origin" : [129,42],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-17-0",
					"origin" : [94,-24],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-space-17-1",
					"origin" : [94,-24],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-space-17-2",
					"origin" : [95,-24],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-18-0",
					"origin" : [45,19],
					"z" : 0,
					"delay" : 3000,
					"a0" : 0,
					"a1" : 170,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-space-18-1",
					"origin" : [45,19],
					"z" : 0,
					"delay" : 3000,
					"a0" : 170,
					"a1" : 0,
				},
				"blend" : 1,
			},
			"19" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-19-0",
					"origin" : [27,26],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-20-0",
					"origin" : [270,158],
					"z" : 0,
					"seat" :  {
						"0" : [-234,92],
						"1" : [-199,92],
						"2" : [163,91],
						"3" : [195,91],
					},
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-21-0",
					"origin" : [0,0],
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-22-0",
					"origin" : [0,0],
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-23-0",
					"origin" : [130,26],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-space-23-1",
					"origin" : [131,26],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-space-23-2",
					"origin" : [129,26],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-space-24-0",
					"origin" : [95,68],
					"z" : 0,
				},
			},
		},
		"pet" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-0-0",
					"origin" : [105,39],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-1-0",
					"origin" : [78,39],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-2-0",
					"origin" : [102,81],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-3-0",
					"origin" : [95,81],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-4-0",
					"origin" : [17,81],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-5-0",
					"origin" : [30,14],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-6-0",
					"origin" : [25,13],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-7-0",
					"origin" : [17,81],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-8-0",
					"origin" : [0,0],
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-9-0",
					"origin" : [34,20],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-10-0",
					"origin" : [21,21],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-11-0",
					"origin" : [52,43],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-12-0",
					"origin" : [10,43],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-13-0",
					"origin" : [37,37],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-14-0",
					"origin" : [28,28],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-15-0",
					"origin" : [0,0],
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-16-0",
					"origin" : [36,36],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-17-0",
					"origin" : [33,33],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-18-0",
					"origin" : [0,0],
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-19-0",
					"origin" : [23,84],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-20-0",
					"origin" : [23,84],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-21-0",
					"origin" : [0,0],
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-22-0",
					"origin" : [0,0],
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-23-0",
					"origin" : [23,84],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-24-0",
					"origin" : [23,84],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-25-0",
					"origin" : [0,0],
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-26-0",
					"origin" : [0,0],
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-27-0",
					"origin" : [56,87],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-28-0",
					"origin" : [56,87],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-29-0",
					"origin" : [23,32],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-30-0",
					"origin" : [23,32],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-31-0",
					"origin" : [23,32],
					"z" : 0,
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-32-0",
					"origin" : [33,13],
					"z" : 0,
				},
			},
			"33" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-33-0",
					"origin" : [39,18],
					"z" : 0,
				},
			},
			"34" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-34-0",
					"origin" : [36,24],
					"z" : 0,
				},
			},
			"35" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-35-0",
					"origin" : [46,22],
					"z" : 0,
				},
			},
			"36" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-36-0",
					"origin" : [38,11],
					"z" : 0,
				},
			},
			"37" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-37-0",
					"origin" : [89,39],
					"z" : 0,
				},
			},
			"38" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-38-0",
					"origin" : [40,55],
					"z" : 0,
					"delay" : 1200000,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-pet-38-1",
					"origin" : [40,55],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-pet-38-2",
					"origin" : [40,55],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil-pet-38-1",
					"origin" : [40,55],
					"z" : 0,
					"delay" : 100,
				},
			},
			"39" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-39-0",
					"origin" : [23,32],
					"z" : 0,
				},
			},
			"40" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-40-0",
					"origin" : [23,32],
					"z" : 0,
				},
			},
			"41" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-pet-41-0",
					"origin" : [23,32],
					"z" : 0,
				},
			},
		},
		"gamezone" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-gamezone-0-0",
					"origin" : [128,113],
					"z" : 0,
				},
			},
		},
		"event" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-event-0-0",
					"origin" : [52,139],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-event-1-0",
					"origin" : [42,139],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-event-2-0",
					"origin" : [77,73],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-event-3-0",
					"origin" : [76,78],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-event-4-0",
					"origin" : [233,51],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-event-5-0",
					"origin" : [60,144],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-event-5-1",
					"origin" : [59,144],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-event-5-2",
					"origin" : [59,146],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-event-6-0",
					"origin" : [58,124],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-event-6-1",
					"origin" : [66,127],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-event-6-2",
					"origin" : [66,127],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil-event-6-3",
					"origin" : [65,127],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil-event-6-4",
					"origin" : [64,126],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil-event-6-5",
					"origin" : [63,126],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/grassySoil-event-6-6",
					"origin" : [62,126],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/grassySoil-event-6-7",
					"origin" : [61,125],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/grassySoil-event-6-8",
					"origin" : [60,125],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/grassySoil-event-6-9",
					"origin" : [59,124],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-event-7-0",
					"origin" : [8,11],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-event-7-1",
					"origin" : [8,11],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-event-7-2",
					"origin" : [8,11],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil-event-7-3",
					"origin" : [8,11],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil-event-7-4",
					"origin" : [8,11],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil-event-7-5",
					"origin" : [8,11],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/grassySoil-event-7-6",
					"origin" : [8,11],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/grassySoil-event-7-7",
					"origin" : [8,11],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/grassySoil-event-7-8",
					"origin" : [8,11],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/grassySoil-event-7-9",
					"origin" : [8,11],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc1.img/grassySoil-event-7-10",
					"origin" : [8,11],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc1.img/grassySoil-event-7-11",
					"origin" : [8,11],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-event-8-0",
					"origin" : [26,32],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-event-8-1",
					"origin" : [23,30],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-event-8-2",
					"origin" : [20,29],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil-event-8-3",
					"origin" : [19,28],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil-event-8-4",
					"origin" : [14,27],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil-event-8-5",
					"origin" : [11,28],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/grassySoil-event-8-6",
					"origin" : [11,31],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/grassySoil-event-8-7",
					"origin" : [9,30],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/grassySoil-event-8-8",
					"origin" : [0,0],
					"delay" : 3000,
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-event-9-0",
					"origin" : [9,6],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-event-9-1",
					"origin" : [12,9],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil-event-9-2",
					"origin" : [13,9],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil-event-9-3",
					"origin" : [16,9],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil-event-9-4",
					"origin" : [13,9],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil-event-9-5",
					"origin" : [14,11],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/grassySoil-event-9-6",
					"origin" : [14,12],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/grassySoil-event-9-7",
					"origin" : [14,12],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/grassySoil-event-9-8",
					"origin" : [0,0],
					"delay" : 3000,
					"z" : 0,
				},
			},
		},
		"auction" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-auction-0-0",
					"origin" : [255,233],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-auction-1-0",
					"origin" : [-121,57],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-auction-2-0",
					"origin" : [102,181],
					"z" : 0,
					"delay" : 1200,
					"a0" : 255,
					"a1" : 130,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil-auction-2-1",
					"origin" : [102,181],
					"z" : 0,
					"delay" : 1200,
					"a0" : 130,
					"a1" : 255,
				},
			},
		},
		"golem" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-0-0",
					"origin" : [239,94],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-1-0",
					"origin" : [239,93],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-2-0",
					"origin" : [217,73],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-3-0",
					"origin" : [238,93],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-4-0",
					"origin" : [63,77],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-5-0",
					"origin" : [77,75],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-6-0",
					"origin" : [76,75],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-7-0",
					"origin" : [88,75],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-8-0",
					"origin" : [201,51],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-9-0",
					"origin" : [89,73],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-10-0",
					"origin" : [196,73],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-11-0",
					"origin" : [113,43],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-12-0",
					"origin" : [112,84],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-13-0",
					"origin" : [0,0],
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-14-0",
					"origin" : [165,93],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-15-0",
					"origin" : [143,52],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-16-0",
					"origin" : [135,37],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-17-0",
					"origin" : [112,76],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-18-0",
					"origin" : [245,51],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-19-0",
					"origin" : [168,51],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-20-0",
					"origin" : [118,121],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil-golem-21-0",
					"origin" : [600,300],
					"z" : 0,
				},
			},
		},
	},
	"grassySoil_new" :  {
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-nature-0-0",
					"origin" : [77,155],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-nature-1-0",
					"origin" : [160,157],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-nature-2-0",
					"origin" : [175,205],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-nature-3-0",
					"origin" : [207,196],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-nature-4-0",
					"origin" : [118,76],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-nature-5-0",
					"origin" : [128,34],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-nature-6-0",
					"origin" : [220,60],
					"z" : 0,
				},
			},
		},
		"house1" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-house1-0-0",
					"origin" : [167,239],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-house1-1-0",
					"origin" : [33,21],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil_new-house1-1-1",
					"origin" : [33,17],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil_new-house1-1-2",
					"origin" : [33,22],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil_new-house1-1-3",
					"origin" : [33,15],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil_new-house1-1-4",
					"origin" : [32,11],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil_new-house1-1-5",
					"origin" : [32,13],
					"z" : 0,
					"delay" : 180,
				},
				"6" :  {
					"png_path": "acc1.img/grassySoil_new-house1-1-6",
					"origin" : [33,22],
					"z" : 0,
					"delay" : 180,
				},
			},
		},
		"house2" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-house2-0-0",
					"origin" : [408,181],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-house2-1-0",
					"origin" : [14,28],
					"z" : 0,
					"delay" : 1500,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil_new-house2-1-1",
					"origin" : [14,28],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil_new-house2-1-2",
					"origin" : [14,28],
					"z" : 0,
					"delay" : 150,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-house2-2-0",
					"origin" : [113,126],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil_new-house2-2-1",
					"origin" : [111,127],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil_new-house2-2-2",
					"origin" : [106,123],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil_new-house2-2-3",
					"origin" : [98,118],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil_new-house2-2-4",
					"origin" : [105,102],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil_new-house2-2-5",
					"origin" : [112,117],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-house2-3-0",
					"origin" : [407,195],
					"z" : 0,
				},
			},
		},
		"house3" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-house3-0-0",
					"origin" : [302,142],
					"z" : 0,
				},
			},
		},
		"house4" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-house4-0-0",
					"origin" : [110,73],
					"z" : 0,
				},
			},
		},
		"house5" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-house5-0-0",
					"origin" : [346,279],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-house5-1-0",
					"origin" : [365,94],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-house5-2-0",
					"origin" : [389,169],
					"z" : 0,
				},
			},
		},
		"weaponShop" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-weaponShop-0-0",
					"origin" : [266,163],
					"z" : 0,
				},
			},
		},
		"potionShop" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-potionShop-0-0",
					"origin" : [218,175],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-potionShop-1-0",
					"origin" : [45,93],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/grassySoil_new-potionShop-1-1",
					"origin" : [45,85],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/grassySoil_new-potionShop-1-2",
					"origin" : [45,90],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/grassySoil_new-potionShop-1-3",
					"origin" : [45,90],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/grassySoil_new-potionShop-1-4",
					"origin" : [45,63],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/grassySoil_new-potionShop-1-5",
					"origin" : [45,83],
					"z" : 0,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-acc-0-0",
					"origin" : [111,54],
					"z" : 0,
				},
			},
		},
		"dock" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-dock-0-0",
					"origin" : [156,168],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/grassySoil_new-dock-1-0",
					"origin" : [63,76],
					"z" : 0,
				},
			},
		},
	},
	"dryRock" :  {
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-0-0",
					"origin" : [75,71],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-1-0",
					"origin" : [97,66],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-2-0",
					"origin" : [74,39],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-3-0",
					"origin" : [74,39],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-4-0",
					"origin" : [35,38],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-5-0",
					"origin" : [12,21],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-6-0",
					"origin" : [76,31],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-7-0",
					"origin" : [40,23],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-8-0",
					"origin" : [23,20],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-9-0",
					"origin" : [89,39],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-10-0",
					"origin" : [24,28],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-11-0",
					"origin" : [33,36],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-12-0",
					"origin" : [56,19],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-13-0",
					"origin" : [88,43],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-14-0",
					"origin" : [51,30],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-15-0",
					"origin" : [37,11],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-16-0",
					"origin" : [29,8],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-17-0",
					"origin" : [34,10],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-18-0",
					"origin" : [76,31],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-19-0",
					"origin" : [47,104],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-20-0",
					"origin" : [31,77],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-21-0",
					"origin" : [24,34],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-22-0",
					"origin" : [20,39],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-nature-23-0",
					"origin" : [145,118],
					"z" : 0,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-0-0",
					"origin" : [43,16],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-1-0",
					"origin" : [19,31],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-2-0",
					"origin" : [48,14],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-3-0",
					"origin" : [29,28],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-4-0",
					"origin" : [19,33],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-5-0",
					"origin" : [24,33],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-6-0",
					"origin" : [7,42],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-7-0",
					"origin" : [18,73],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-8-0",
					"origin" : [88,96],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-9-0",
					"origin" : [100,86],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-10-0",
					"origin" : [99,120],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-11-0",
					"origin" : [41,42],
					"z" : 0,
					"0" : [23,-35],
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-12-0",
					"origin" : [21,22],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-13-0",
					"origin" : [75,52],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-14-0",
					"origin" : [59,79],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-15-0",
					"origin" : [27,19],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-16-0",
					"origin" : [0,0],
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-17-0",
					"origin" : [90,121],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-18-0",
					"origin" : [41,45],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-19-0",
					"origin" : [41,51],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-20-0",
					"origin" : [66,77],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-21-0",
					"origin" : [58,98],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-22-0",
					"origin" : [17,18],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-23-0",
					"origin" : [42,94],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-24-0",
					"origin" : [46,83],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-25-0",
					"origin" : [37,86],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-26-0",
					"origin" : [25,85],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-27-0",
					"origin" : [37,75],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-28-0",
					"origin" : [45,29],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-29-0",
					"origin" : [61,28],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-30-0",
					"origin" : [0,0],
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-artificiality-31-0",
					"origin" : [40,14],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-22,14],
					"1" : [-5,14],
					"2" : [13,14],
				},
			},
		},
		"rock" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-rock-0-0",
					"origin" : [294,166],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-rock-1-0",
					"origin" : [276,165],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-rock-2-0",
					"origin" : [319,360],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-rock-3-0",
					"origin" : [392,350],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-rock-4-0",
					"origin" : [282,289],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-rock-5-0",
					"origin" : [292,293],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-rock-6-0",
					"origin" : [508,140],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-rock-7-0",
					"origin" : [235,57],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-rock-8-0",
					"origin" : [640,289],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-rock-9-0",
					"origin" : [392,350],
					"z" : 0,
				},
			},
		},
		"signpost" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-0-0",
					"origin" : [104,117],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-1-0",
					"origin" : [46,18],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-2-0",
					"origin" : [87,97],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-3-0",
					"origin" : [58,12],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-4-0",
					"origin" : [103,86],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-5-0",
					"origin" : [154,130],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-6-0",
					"origin" : [0,0],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-7-0",
					"origin" : [0,0],
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-8-0",
					"origin" : [0,0],
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-9-0",
					"origin" : [0,0],
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-10-0",
					"origin" : [0,0],
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-11-0",
					"origin" : [0,0],
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-12-0",
					"origin" : [0,0],
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-13-0",
					"origin" : [0,0],
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-signpost-14-0",
					"origin" : [0,0],
				},
			},
		},
		"castle" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-castle-0-0",
					"origin" : [288,72],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-castle-1-0",
					"origin" : [309,123],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-castle-2-0",
					"origin" : [201,117],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-castle-3-0",
					"origin" : [29,161],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-castle-4-0",
					"origin" : [108,164],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-castle-5-0",
					"origin" : [217,164],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-castle-6-0",
					"origin" : [61,164],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-castle-7-0",
					"origin" : [128,129],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-castle-8-0",
					"origin" : [98,129],
					"z" : 0,
				},
			},
		},
		"quest" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-quest-0-0",
					"origin" : [123,179],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-quest-1-0",
					"origin" : [123,212],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/dryRock-quest-2-0",
					"origin" : [123,219],
					"z" : 0,
				},
			},
		},
	},
	"darkWood" :  {
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-0-0",
					"origin" : [60,92],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-1-0",
					"origin" : [67,120],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-2-0",
					"origin" : [37,47],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-3-0",
					"origin" : [19,18],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-4-0",
					"origin" : [28,29],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-5-0",
					"origin" : [0,0],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-6-0",
					"origin" : [58,81],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-7-0",
					"origin" : [57,61],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-8-0",
					"origin" : [51,42],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-9-0",
					"origin" : [69,48],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-10-0",
					"origin" : [60,37],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-11-0",
					"origin" : [78,102],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-12-0",
					"origin" : [53,82],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-13-0",
					"origin" : [58,77],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-14-0",
					"origin" : [71,78],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-15-0",
					"origin" : [32,52],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-16-0",
					"origin" : [117,23],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-17-0",
					"origin" : [48,23],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-18-0",
					"origin" : [56,21],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-19-0",
					"origin" : [35,21],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-20-0",
					"origin" : [32,52],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-21-0",
					"origin" : [94,52],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-22-0",
					"origin" : [17,43],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-23-0",
					"origin" : [22,44],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-24-0",
					"origin" : [17,39],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-25-0",
					"origin" : [41,58],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-26-0",
					"origin" : [54,56],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-27-0",
					"origin" : [50,58],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "acc1.img/darkWood-nature-27-1",
					"origin" : [50,58],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 3000,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-28-0",
					"origin" : [114,75],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-29-0",
					"origin" : [38,44],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-30-0",
					"origin" : [23,82],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-nature-31-0",
					"origin" : [23,46],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "acc1.img/darkWood-nature-31-1",
					"origin" : [23,46],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 3000,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-0-0",
					"origin" : [107,73],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-1-0",
					"origin" : [83,53],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-2-0",
					"origin" : [108,107],
					"z" : 0,
					"moveType" : 2,
					"moveH" : 5,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-3-0",
					"origin" : [166,46],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-4-0",
					"origin" : [113,36],
					"z" : 0,
					"delay" : 2000,
					"a0" : 0,
					"a1" : 255,
				},
				"1" :  {
					"png_path": "acc1.img/darkWood-artificiality-4-1",
					"origin" : [113,36],
					"z" : 0,
					"delay" : 2000,
					"a0" : 255,
					"a1" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-5-0",
					"origin" : [169,136],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-6-0",
					"origin" : [197,322],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-7-0",
					"origin" : [197,322],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-8-0",
					"origin" : [143,115],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-9-0",
					"origin" : [228,255],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-10-0",
					"origin" : [109,244],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-11-0",
					"origin" : [121,117],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-12-0",
					"origin" : [65,114],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-13-0",
					"origin" : [95,139],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-14-0",
					"origin" : [0,0],
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-15-0",
					"origin" : [400,300],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/darkWood-artificiality-16-0",
					"origin" : [97,92],
					"z" : 0,
				},
			},
		},
	},
	"midForest" :  {
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-0-0",
					"origin" : [120,170],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-1-0",
					"origin" : [90,140],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-2-0",
					"origin" : [93,122],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-3-0",
					"origin" : [153,158],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-4-0",
					"origin" : [153,158],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-5-0",
					"origin" : [108,155],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-6-0",
					"origin" : [76,74],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-7-0",
					"origin" : [120,166],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-8-0",
					"origin" : [89,56],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-9-0",
					"origin" : [89,57],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-10-0",
					"origin" : [44,57],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-11-0",
					"origin" : [64,12],
					"z" : 0,
					"delay" : 1500,
				},
				"1" :  {
					"png_path": "acc1.img/midForest-nature-11-1",
					"origin" : [64,12],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc1.img/midForest-nature-11-2",
					"origin" : [64,17],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "acc1.img/midForest-nature-11-3",
					"origin" : [64,31],
					"z" : 0,
					"delay" : 1800,
				},
				"4" :  {
					"png_path": "acc1.img/midForest-nature-11-2",
					"origin" : [64,17],
					"z" : 0,
					"delay" : 120,
				},
				"5" :  {
					"png_path": "acc1.img/midForest-nature-11-1",
					"origin" : [64,12],
					"z" : 0,
					"delay" : 210,
				},
				"6" :  {
					"png_path": "acc1.img/midForest-nature-11-0",
					"origin" : [64,12],
					"z" : 0,
					"delay" : 1500,
				},
				"7" :  {
					"png_path": "acc1.img/midForest-nature-11-7",
					"origin" : [64,13],
					"z" : 0,
					"delay" : 1500,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-nature-12-0",
					"origin" : [141,40],
					"z" : 0,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-0-0",
					"origin" : [118,90],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-1-0",
					"origin" : [92,39],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-2-0",
					"origin" : [41,46],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-3-0",
					"origin" : [81,37],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-4-0",
					"origin" : [59,44],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-5-0",
					"origin" : [116,82],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-6-0",
					"origin" : [110,87],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-7-0",
					"origin" : [105,41],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-8-0",
					"origin" : [105,14],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-9-0",
					"origin" : [8,3],
					"z" : 0,
					"delay" : 3600,
				},
				"1" :  {
					"png_path": "acc1.img/midForest-artificiality-9-1",
					"origin" : [7,3],
					"z" : 0,
					"delay" : 1500,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-10-0",
					"origin" : [80,105],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-11-0",
					"origin" : [85,57],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-12-0",
					"origin" : [53,58],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-13-0",
					"origin" : [129,95],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/midForest-artificiality-14-0",
					"origin" : [99,80],
					"z" : 0,
				},
			},
		},
	},
	"portTown" :  {
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-0-0",
					"origin" : [46,34],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-1-0",
					"origin" : [0,0],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-2-0",
					"origin" : [26,55],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-3-0",
					"origin" : [37,36],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-4-0",
					"origin" : [17,18],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-6-0",
					"origin" : [175,95],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-7-0",
					"origin" : [0,0],
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-8-0",
					"origin" : [0,0],
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-9-0",
					"origin" : [91,53],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-10-0",
					"origin" : [29,18],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-11-0",
					"origin" : [20,19],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-12-0",
					"origin" : [12,13],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-13-0",
					"origin" : [19,12],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-14-0",
					"origin" : [56,35],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-15-0",
					"origin" : [49,102],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-16-0",
					"origin" : [44,96],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-17-0",
					"origin" : [0,0],
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-18-0",
					"origin" : [198,120],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-19-0",
					"origin" : [73,43],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-20-0",
					"origin" : [75,23],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-21-0",
					"origin" : [121,69],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-22-0",
					"origin" : [186,146],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-23-0",
					"origin" : [243,115],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-24-0",
					"origin" : [139,246],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/portTown-artificiality-5-0",
					"origin" : [176,114],
					"z" : 0,
				},
			},
		},
	},
	"woodMarble" :  {
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-nature-0-0",
					"origin" : [7,7],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-nature-1-0",
					"origin" : [9,5],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-nature-2-0",
					"origin" : [7,12],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-nature-3-0",
					"origin" : [7,7],
					"z" : 0,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-artificiality-0-0",
					"origin" : [33,23],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-artificiality-1-0",
					"origin" : [28,28],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-artificiality-2-0",
					"origin" : [14,47],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc1.img/woodMarble-artificiality-2-1",
					"origin" : [14,47],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc1.img/woodMarble-artificiality-2-2",
					"origin" : [14,47],
					"z" : 0,
					"delay" : 150,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-artificiality-3-0",
					"origin" : [26,24],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-artificiality-4-0",
					"origin" : [11,59],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc1.img/woodMarble-artificiality-4-1",
					"origin" : [9,59],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc1.img/woodMarble-artificiality-4-2",
					"origin" : [9,59],
					"z" : 0,
					"delay" : 150,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-artificiality-5-0",
					"origin" : [48,16],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-artificiality-6-0",
					"origin" : [48,16],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-artificiality-7-0",
					"origin" : [28,8],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/woodMarble-artificiality-8-0",
					"origin" : [22,1],
					"z" : 0,
				},
			},
		},
	},
	"quest" :  {
		"shadow" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/quest-shadow-0-0",
					"origin" : [180,90],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/quest-shadow-1-0",
					"origin" : [81,62],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/quest-shadow-2-0",
					"origin" : [45,56],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/quest-shadow-3-0",
					"origin" : [153,158],
					"z" : 0,
				},
			},
		},
		"helena" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/quest-helena-0-0",
					"origin" : [48,62],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/quest-helena-1-0",
					"origin" : [35,36],
					"z" : 0,
				},
			},
		},
		"puni" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/quest-puni-0-0",
					"origin" : [-17,45],
					"z" : 0,
				},
			},
		},
	},
	"lv200" :  {
		"warrior" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-warrior-0-0",
					"origin" : [400,300],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-warrior-1-0",
					"origin" : [400,250],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-warrior-2-0",
					"origin" : [400,73],
					"z" : 0,
				},
			},
		},
		"magician" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-magician-0-0",
					"origin" : [400,300],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-magician-1-0",
					"origin" : [400,300],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-magician-2-0",
					"origin" : [400,147],
					"z" : 0,
				},
			},
		},
		"archer" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-archer-0-0",
					"origin" : [400,300],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-archer-1-0",
					"origin" : [400,231],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-archer-2-0",
					"origin" : [400,75],
					"z" : 0,
				},
			},
		},
		"thief" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-thief-0-0",
					"origin" : [400,300],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-thief-1-0",
					"origin" : [400,188],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-thief-2-0",
					"origin" : [400,73],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-thief-3-0",
					"origin" : [362,54],
					"z" : 0,
				},
			},
		},
		"pirate" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-pirate-0-0",
					"origin" : [400,224],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-pirate-1-0",
					"origin" : [400,75],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-pirate-2-0",
					"origin" : [400,236],
					"z" : 0,
				},
			},
		},
		"evan" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-evan-0-0",
					"origin" : [245,74],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-evan-1-0",
					"origin" : [551,163],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-evan-2-0",
					"origin" : [372,57],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-evan-3-0",
					"origin" : [453,132],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-evan-4-0",
					"origin" : [123,208],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-evan-5-0",
					"origin" : [55,62],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-evan-6-0",
					"origin" : [121,208],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-evan-7-0",
					"origin" : [59,47],
					"z" : 0,
				},
			},
		},
		"light" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-light-0-0",
					"origin" : [217,300],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-light-1-0",
					"origin" : [60,163],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-light-2-0",
					"origin" : [158,162],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/lv200-light-3-0",
					"origin" : [173,193],
					"z" : 0,
				},
			},
		},
	},
	"heneFarmTW" :  {
		"room" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-room-0-0",
					"origin" : [369,300],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-room-1-0",
					"origin" : [172,171],
					"z" : 0,
					"a0" : 50,
					"a1" : 255,
					"delay" : 2000,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmTW-room-1-1",
					"origin" : [172,171],
					"z" : 0,
					"a0" : 255,
					"a1" : 50,
					"delay" : 2000,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-room-2-0",
					"origin" : [128,300],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-room-3-0",
					"origin" : [123,300],
					"z" : 0,
				},
			},
		},
		"Insinde" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-0-0",
					"origin" : [457,425],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-1-0",
					"origin" : [29,29],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-1-1",
					"origin" : [29,29],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-1-2",
					"origin" : [29,29],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-1-3",
					"origin" : [29,29],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-1-4",
					"origin" : [29,29],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-1-5",
					"origin" : [29,29],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-2-0",
					"origin" : [25,25],
					"z" : 0,
					"a0" : 50,
					"a1" : 255,
					"delay" : 1200,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-2-1",
					"origin" : [25,25],
					"z" : 0,
					"a0" : 255,
					"a1" : 50,
					"delay" : 1200,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-3-0",
					"origin" : [87,77],
					"z" : 0,
					"a0" : 50,
					"a1" : 255,
					"delay" : 2000,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-3-1",
					"origin" : [87,77],
					"z" : 0,
					"a0" : 255,
					"a1" : 50,
					"delay" : 2000,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-4-0",
					"origin" : [163,425],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Insinde-5-0",
					"origin" : [181,425],
					"z" : 0,
				},
			},
		},
		"Outside" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-0-0",
					"origin" : [657,127],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-1-0",
					"origin" : [657,532],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-2-0",
					"origin" : [406,492],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-3-0",
					"origin" : [172,629],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-4-0",
					"origin" : [945,373],
					"z" : 0,
					"delay" : 210,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-4-1",
					"origin" : [945,373],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-4-2",
					"origin" : [945,373],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-4-3",
					"origin" : [945,373],
					"z" : 0,
					"delay" : 210,
				},
				"4" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-4-4",
					"origin" : [945,373],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-4-5",
					"origin" : [945,373],
					"z" : 0,
					"delay" : 210,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-5-0",
					"origin" : [158,173],
					"z" : 0,
					"delay" : 240,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-5-1",
					"origin" : [152,168],
					"z" : 0,
					"delay" : 240,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-5-2",
					"origin" : [136,151],
					"z" : 0,
					"delay" : 240,
				},
				"3" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-5-3",
					"origin" : [136,151],
					"z" : 0,
					"delay" : 240,
				},
				"4" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-5-4",
					"origin" : [151,166],
					"z" : 0,
					"delay" : 240,
				},
				"5" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-5-5",
					"origin" : [156,171],
					"z" : 0,
					"delay" : 240,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-6-0",
					"origin" : [110,67],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-6-1",
					"origin" : [112,66],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-6-2",
					"origin" : [85,65],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-6-3",
					"origin" : [85,63],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-6-4",
					"origin" : [85,62],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-6-5",
					"origin" : [85,62],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-6-6",
					"origin" : [85,62],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-6-7",
					"origin" : [99,72],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-6-8",
					"origin" : [107,67],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-6-9",
					"origin" : [109,66],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-7-0",
					"origin" : [118,74],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-8-0",
					"origin" : [131,41],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmTW-Outside-9-0",
					"origin" : [91,50],
					"z" : 0,
				},
			},
		},
	},
	"heneFarmFD" :  {
		"fence" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-fence-0-0",
					"origin" : [28,40],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-fence-1-0",
					"origin" : [127,41],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-fence-2-0",
					"origin" : [100,36],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-fence-3-0",
					"origin" : [59,38],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-fence-4-0",
					"origin" : [118,38],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-fence-5-0",
					"origin" : [114,38],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-fence-6-0",
					"origin" : [25,39],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-fence-7-0",
					"origin" : [54,98],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-fence-8-0",
					"origin" : [123,91],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-fence-9-0",
					"origin" : [323,42],
					"z" : 0,
				},
			},
		},
		"npc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-npc-0-0",
					"origin" : [33,14],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-npc-1-0",
					"origin" : [73,56],
					"z" : 0,
				},
			},
		},
		"chair" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-chair-0-0",
					"origin" : [29,36],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-16,37],
					"1" : [7,37],
					"2" : [28,37],
				},
			},
		},
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-0-0",
					"origin" : [230,208],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-1-0",
					"origin" : [299,210],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-2-0",
					"origin" : [223,68],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-3-0",
					"origin" : [90,33],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-4-0",
					"origin" : [58,26],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-5-0",
					"origin" : [29,18],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-6-0",
					"origin" : [50,18],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-7-0",
					"origin" : [42,19],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-8-0",
					"origin" : [27,41],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-9-0",
					"origin" : [19,35],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-10-0",
					"origin" : [22,20],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-11-0",
					"origin" : [13,21],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-12-0",
					"origin" : [30,20],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-13-0",
					"origin" : [25,19],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-14-0",
					"origin" : [26,38],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-15-0",
					"origin" : [29,30],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-16-0",
					"origin" : [33,32],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-nature-17-0",
					"origin" : [28,33],
					"z" : 0,
				},
			},
		},
		"cow" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-cow-0-0",
					"origin" : [194,60],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-cow-1-0",
					"origin" : [161,66],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-cow-2-0",
					"origin" : [39,49],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-cow-3-0",
					"origin" : [78,48],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmFD-cow-3-1",
					"origin" : [78,47],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmFD-cow-3-2",
					"origin" : [78,46],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/heneFarmFD-cow-3-3",
					"origin" : [78,47],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-cow-4-0",
					"origin" : [70,44],
					"z" : 0,
					"delay" : 6000,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmFD-cow-4-1",
					"origin" : [70,43],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmFD-cow-4-2",
					"origin" : [79,42],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/heneFarmFD-cow-4-3",
					"origin" : [86,41],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/heneFarmFD-cow-4-4",
					"origin" : [90,41],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/heneFarmFD-cow-4-5",
					"origin" : [90,41],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/heneFarmFD-cow-4-6",
					"origin" : [91,42],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/heneFarmFD-cow-4-7",
					"origin" : [93,44],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/heneFarmFD-cow-4-8",
					"origin" : [70,44],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-cow-5-0",
					"origin" : [43,31],
					"z" : 0,
					"delay" : 1800,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmFD-cow-5-1",
					"origin" : [43,31],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmFD-cow-5-2",
					"origin" : [43,31],
					"z" : 0,
				},
			},
		},
		"tile" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-tile-0-0",
					"origin" : [65,61],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-tile-1-0",
					"origin" : [39,25],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-tile-2-0",
					"origin" : [98,44],
					"z" : 0,
				},
			},
		},
		"chicken" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-chicken-0-0",
					"origin" : [438,42],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-chicken-1-0",
					"origin" : [340,62],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-chicken-2-0",
					"origin" : [123,115],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-chicken-3-0",
					"origin" : [238,141],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-chicken-4-0",
					"origin" : [19,29],
					"z" : 0,
					"delay" : 1800,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmFD-chicken-4-1",
					"origin" : [19,29],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmFD-chicken-4-2",
					"origin" : [19,29],
					"z" : 0,
					"delay" : 90,
				},
				"3" :  {
					"png_path": "acc1.img/heneFarmFD-chicken-4-3",
					"origin" : [19,29],
					"z" : 0,
					"delay" : 120,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-chicken-5-0",
					"origin" : [18,22],
					"z" : 0,
					"delay" : 2400,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmFD-chicken-5-1",
					"origin" : [18,22],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmFD-chicken-5-2",
					"origin" : [18,22],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "acc1.img/heneFarmFD-chicken-5-3",
					"origin" : [18,22],
					"z" : 0,
					"delay" : 120,
				},
			},
		},
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-0-0",
					"origin" : [17,34],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-1-0",
					"origin" : [174,37],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-2-0",
					"origin" : [18,35],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-3-0",
					"origin" : [15,22],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-4-0",
					"origin" : [16,18],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-5-0",
					"origin" : [22,33],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-6-0",
					"origin" : [19,37],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-7-0",
					"origin" : [69,80],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-8-0",
					"origin" : [77,42],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-9-0",
					"origin" : [61,29],
					"z" : 0,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmFD-obj-9-1",
					"origin" : [61,29],
					"z" : 0,
					"delay" : 90,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmFD-obj-9-2",
					"origin" : [61,29],
					"z" : 0,
					"delay" : 90,
				},
				"3" :  {
					"png_path": "acc1.img/heneFarmFD-obj-9-3",
					"origin" : [61,29],
					"z" : 0,
					"delay" : 90,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-10-0",
					"origin" : [52,41],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-11-0",
					"origin" : [51,99],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-12-0",
					"origin" : [104,67],
					"z" : 0,
					"delay" : 2000,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmFD-obj-12-1",
					"origin" : [106,67],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmFD-obj-12-2",
					"origin" : [121,67],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "acc1.img/heneFarmFD-obj-12-3",
					"origin" : [133,67],
					"z" : 0,
					"delay" : 120,
				},
				"4" :  {
					"png_path": "acc1.img/heneFarmFD-obj-12-4",
					"origin" : [136,67],
					"z" : 0,
					"delay" : 120,
				},
				"5" :  {
					"png_path": "acc1.img/heneFarmFD-obj-12-5",
					"origin" : [138,67],
					"z" : 0,
					"delay" : 120,
				},
				"6" :  {
					"png_path": "acc1.img/heneFarmFD-obj-12-6",
					"origin" : [107,67],
					"z" : 0,
					"delay" : 120,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-13-0",
					"origin" : [44,85],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-14-0",
					"origin" : [104,54],
					"z" : 0,
					"delay" : 90,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmFD-obj-14-1",
					"origin" : [73,54],
					"z" : 0,
					"delay" : 90,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmFD-obj-14-2",
					"origin" : [70,54],
					"z" : 0,
					"delay" : 90,
				},
				"3" :  {
					"png_path": "acc1.img/heneFarmFD-obj-14-3",
					"origin" : [78,54],
					"z" : 0,
					"delay" : 90,
				},
				"4" :  {
					"png_path": "acc1.img/heneFarmFD-obj-14-4",
					"origin" : [87,54],
					"z" : 0,
					"delay" : 90,
				},
				"5" :  {
					"png_path": "acc1.img/heneFarmFD-obj-14-5",
					"origin" : [99,54],
					"z" : 0,
					"delay" : 90,
				},
				"6" :  {
					"png_path": "acc1.img/heneFarmFD-obj-14-6",
					"origin" : [102,54],
					"z" : 0,
					"delay" : 90,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-15-0",
					"origin" : [75,53],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-16-0",
					"origin" : [37,41],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-17-0",
					"origin" : [46,52],
					"z" : 0,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmFD-obj-17-1",
					"origin" : [46,52],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmFD-obj-17-2",
					"origin" : [46,52],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "acc1.img/heneFarmFD-obj-17-3",
					"origin" : [46,52],
					"z" : 0,
					"delay" : 120,
				},
				"4" :  {
					"png_path": "acc1.img/heneFarmFD-obj-17-4",
					"origin" : [46,52],
					"z" : 0,
					"delay" : 120,
				},
				"5" :  {
					"png_path": "acc1.img/heneFarmFD-obj-17-5",
					"origin" : [46,52],
					"z" : 0,
					"delay" : 120,
				},
				"6" :  {
					"png_path": "acc1.img/heneFarmFD-obj-17-6",
					"origin" : [46,52],
					"z" : 0,
					"delay" : 120,
				},
				"7" :  {
					"png_path": "acc1.img/heneFarmFD-obj-17-7",
					"origin" : [46,55],
					"z" : 0,
					"delay" : 120,
				},
				"8" :  {
					"png_path": "acc1.img/heneFarmFD-obj-17-8",
					"origin" : [46,52],
					"z" : 0,
					"delay" : 120,
				},
				"9" :  {
					"png_path": "acc1.img/heneFarmFD-obj-17-9",
					"origin" : [46,55],
					"z" : 0,
					"delay" : 120,
				},
				"10" :  {
					"png_path": "acc1.img/heneFarmFD-obj-17-10",
					"origin" : [46,52],
					"z" : 0,
					"delay" : 120,
				},
				"11" :  {
					"png_path": "acc1.img/heneFarmFD-obj-17-11",
					"origin" : [46,52],
					"z" : 0,
					"delay" : 120,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-18-0",
					"origin" : [123,92],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-19-0",
					"origin" : [164,42],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-20-0",
					"origin" : [46,89],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-21-0",
					"origin" : [10,14],
					"z" : 0,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmFD-obj-21-1",
					"origin" : [10,14],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmFD-obj-21-2",
					"origin" : [10,14],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-22-0",
					"origin" : [10,12],
					"z" : 0,
					"delay" : 1200,
				},
				"1" :  {
					"png_path": "acc1.img/heneFarmFD-obj-22-1",
					"origin" : [10,12],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/heneFarmFD-obj-22-2",
					"origin" : [10,12],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc1.img/heneFarmFD-obj-23-0",
					"origin" : [85,32],
					"z" : 0,
				},
			},
		},
	},
	"DragonDream" :  {
		"dragon" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-dragon-0-0",
					"origin" : [415,83],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-dragon-1-0",
					"origin" : [342,84],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-dragon-2-0",
					"origin" : [214,135],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-dragon-3-0",
					"origin" : [57,99],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-dragon-4-0",
					"origin" : [556,87],
					"z" : 0,
				},
			},
		},
		"stone" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-stone-0-0",
					"origin" : [150,117],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-stone-1-0",
					"origin" : [22,56],
					"z" : 0,
					"delay" : 240,
				},
				"1" :  {
					"png_path": "acc1.img/DragonDream-stone-1-1",
					"origin" : [22,67],
					"z" : 0,
					"delay" : 240,
				},
				"2" :  {
					"png_path": "acc1.img/DragonDream-stone-1-2",
					"origin" : [22,68],
					"z" : 0,
					"delay" : 240,
				},
				"3" :  {
					"png_path": "acc1.img/DragonDream-stone-1-3",
					"origin" : [22,68],
					"z" : 0,
					"delay" : 240,
				},
				"4" :  {
					"png_path": "acc1.img/DragonDream-stone-1-4",
					"origin" : [22,69],
					"z" : 0,
					"delay" : 240,
				},
				"5" :  {
					"png_path": "acc1.img/DragonDream-stone-1-5",
					"origin" : [22,69],
					"z" : 0,
					"delay" : 240,
				},
				"6" :  {
					"png_path": "acc1.img/DragonDream-stone-1-6",
					"origin" : [22,69],
					"z" : 0,
					"delay" : 240,
				},
				"7" :  {
					"png_path": "acc1.img/DragonDream-stone-1-7",
					"origin" : [22,69],
					"z" : 0,
					"delay" : 240,
				},
				"8" :  {
					"png_path": "acc1.img/DragonDream-stone-1-8",
					"origin" : [22,63],
					"z" : 0,
					"delay" : 240,
				},
				"9" :  {
					"png_path": "acc1.img/DragonDream-stone-1-9",
					"origin" : [22,55],
					"z" : 0,
					"delay" : 240,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-stone-2-0",
					"origin" : [93,95],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-stone-3-0",
					"origin" : [31,59],
					"z" : 0,
					"delay" : 240,
				},
				"1" :  {
					"png_path": "acc1.img/DragonDream-stone-3-1",
					"origin" : [31,70],
					"z" : 0,
					"delay" : 240,
				},
				"2" :  {
					"png_path": "acc1.img/DragonDream-stone-3-2",
					"origin" : [31,71],
					"z" : 0,
					"delay" : 240,
				},
				"3" :  {
					"png_path": "acc1.img/DragonDream-stone-3-3",
					"origin" : [31,71],
					"z" : 0,
					"delay" : 240,
				},
				"4" :  {
					"png_path": "acc1.img/DragonDream-stone-3-4",
					"origin" : [31,72],
					"z" : 0,
					"delay" : 240,
				},
				"5" :  {
					"png_path": "acc1.img/DragonDream-stone-3-5",
					"origin" : [31,72],
					"z" : 0,
					"delay" : 240,
				},
				"6" :  {
					"png_path": "acc1.img/DragonDream-stone-3-6",
					"origin" : [31,72],
					"z" : 0,
					"delay" : 240,
				},
				"7" :  {
					"png_path": "acc1.img/DragonDream-stone-3-7",
					"origin" : [31,72],
					"z" : 0,
					"delay" : 240,
				},
				"8" :  {
					"png_path": "acc1.img/DragonDream-stone-3-8",
					"origin" : [31,66],
					"z" : 0,
					"delay" : 240,
				},
				"9" :  {
					"png_path": "acc1.img/DragonDream-stone-3-9",
					"origin" : [31,58],
					"z" : 0,
					"delay" : 240,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-stone-4-0",
					"origin" : [46,41],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-stone-5-0",
					"origin" : [20,33],
					"z" : 0,
					"delay" : 240,
				},
				"1" :  {
					"png_path": "acc1.img/DragonDream-stone-5-1",
					"origin" : [20,33],
					"z" : 0,
					"delay" : 240,
				},
				"2" :  {
					"png_path": "acc1.img/DragonDream-stone-5-2",
					"origin" : [20,33],
					"z" : 0,
					"delay" : 240,
				},
				"3" :  {
					"png_path": "acc1.img/DragonDream-stone-5-3",
					"origin" : [20,33],
					"z" : 0,
					"delay" : 240,
				},
				"4" :  {
					"png_path": "acc1.img/DragonDream-stone-5-4",
					"origin" : [20,33],
					"z" : 0,
					"delay" : 240,
				},
				"5" :  {
					"png_path": "acc1.img/DragonDream-stone-5-5",
					"origin" : [20,30],
					"z" : 0,
					"delay" : 240,
				},
				"6" :  {
					"png_path": "acc1.img/DragonDream-stone-5-6",
					"origin" : [20,31],
					"z" : 0,
					"delay" : 240,
				},
				"7" :  {
					"png_path": "acc1.img/DragonDream-stone-5-7",
					"origin" : [20,32],
					"z" : 0,
					"delay" : 240,
				},
				"8" :  {
					"png_path": "acc1.img/DragonDream-stone-5-8",
					"origin" : [20,32],
					"z" : 0,
					"delay" : 240,
				},
				"9" :  {
					"png_path": "acc1.img/DragonDream-stone-5-9",
					"origin" : [20,32],
					"z" : 0,
					"delay" : 240,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-stone-6-0",
					"origin" : [90,67],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-stone-7-0",
					"origin" : [22,65],
					"z" : 0,
					"delay" : 240,
				},
				"1" :  {
					"png_path": "acc1.img/DragonDream-stone-7-1",
					"origin" : [22,66],
					"z" : 0,
					"delay" : 240,
				},
				"2" :  {
					"png_path": "acc1.img/DragonDream-stone-7-2",
					"origin" : [22,66],
					"z" : 0,
					"delay" : 240,
				},
				"3" :  {
					"png_path": "acc1.img/DragonDream-stone-7-3",
					"origin" : [22,66],
					"z" : 0,
					"delay" : 240,
				},
				"4" :  {
					"png_path": "acc1.img/DragonDream-stone-7-4",
					"origin" : [22,66],
					"z" : 0,
					"delay" : 240,
				},
				"5" :  {
					"png_path": "acc1.img/DragonDream-stone-7-5",
					"origin" : [22,66],
					"z" : 0,
					"delay" : 240,
				},
				"6" :  {
					"png_path": "acc1.img/DragonDream-stone-7-6",
					"origin" : [22,64],
					"z" : 0,
					"delay" : 240,
				},
				"7" :  {
					"png_path": "acc1.img/DragonDream-stone-7-7",
					"origin" : [22,65],
					"z" : 0,
					"delay" : 240,
				},
				"8" :  {
					"png_path": "acc1.img/DragonDream-stone-7-8",
					"origin" : [22,65],
					"z" : 0,
					"delay" : 240,
				},
				"9" :  {
					"png_path": "acc1.img/DragonDream-stone-7-9",
					"origin" : [22,65],
					"z" : 0,
					"delay" : 240,
				},
			},
		},
		"dragonEgg" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-0-0",
					"origin" : [212,86],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-1-0",
					"origin" : [73,69],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-2-0",
					"origin" : [83,88],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-2-1",
					"origin" : [82,87],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-2-2",
					"origin" : [82,87],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-2-3",
					"origin" : [82,87],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-2-4",
					"origin" : [82,87],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-2-5",
					"origin" : [82,87],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-2-6",
					"origin" : [82,87],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-2-7",
					"origin" : [82,87],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-2-8",
					"origin" : [82,87],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-2-9",
					"origin" : [82,87],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-3-0",
					"origin" : [80,149],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-4-0",
					"origin" : [54,84],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-4-1",
					"origin" : [53,85],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-4-2",
					"origin" : [53,85],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-4-3",
					"origin" : [53,85],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-4-4",
					"origin" : [53,85],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-4-5",
					"origin" : [53,85],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-4-6",
					"origin" : [53,83],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-4-7",
					"origin" : [53,84],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-4-8",
					"origin" : [53,84],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-4-9",
					"origin" : [53,84],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-5-0",
					"origin" : [125,40],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-dragonEgg-6-0",
					"origin" : [126,89],
					"z" : 0,
				},
			},
		},
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-0-0",
					"origin" : [125,44],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-1-0",
					"origin" : [76,32],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-2-0",
					"origin" : [75,26],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-3-0",
					"origin" : [106,25],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-4-0",
					"origin" : [49,51],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-5-0",
					"origin" : [58,43],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-6-0",
					"origin" : [104,75],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-7-0",
					"origin" : [86,32],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-8-0",
					"origin" : [78,44],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-9-0",
					"origin" : [42,19],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-10-0",
					"origin" : [50,18],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-11-0",
					"origin" : [29,18],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/DragonDream-nature-12-0",
					"origin" : [29,12],
					"z" : 0,
				},
			},
		},
	},
	"mapleIsland" :  {
		"maple" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-maple-0-0",
					"origin" : [523,439],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-maple-1-0",
					"origin" : [259,145],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-0",
					"origin" : [455,346],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-1",
					"origin" : [458,343],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-2",
					"origin" : [458,342],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-3",
					"origin" : [461,339],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-4",
					"origin" : [466,340],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-5",
					"origin" : [422,336],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-6",
					"origin" : [471,335],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-7",
					"origin" : [469,350],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-8",
					"origin" : [464,346],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-9",
					"origin" : [462,347],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-10",
					"origin" : [460,344],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-11",
					"origin" : [457,343],
					"z" : 0,
				},
				"12" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-12",
					"origin" : [453,349],
					"z" : 0,
				},
				"13" :  {
					"png_path": "acc1.img/mapleIsland-maple-2-13",
					"origin" : [453,345],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-maple-3-0",
					"origin" : [24,14],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-maple-4-0",
					"origin" : [29,13],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-maple-5-0",
					"origin" : [45,17],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-maple-6-0",
					"origin" : [107,27],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-maple-7-0",
					"origin" : [46,14],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-maple-8-0",
					"origin" : [19,10],
					"z" : 0,
				},
			},
		},
		"burundMapleIsland" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-0-0",
					"origin" : [307,163],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-1-0",
					"origin" : [270,132],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-2-0",
					"origin" : [220,59],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-3-0",
					"origin" : [128,33],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-4-0",
					"origin" : [79,310],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-4-1",
					"origin" : [79,310],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-4-2",
					"origin" : [79,310],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-4-3",
					"origin" : [79,310],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-4-4",
					"origin" : [79,310],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-4-5",
					"origin" : [79,310],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-4-6",
					"origin" : [79,310],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-4-7",
					"origin" : [79,310],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-4-8",
					"origin" : [79,310],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-4-9",
					"origin" : [79,310],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-4-10",
					"origin" : [79,310],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-4-11",
					"origin" : [79,310],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-5-0",
					"origin" : [172,315],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-5-1",
					"origin" : [160,315],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-5-2",
					"origin" : [160,315],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-5-3",
					"origin" : [160,315],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-5-4",
					"origin" : [160,315],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-5-5",
					"origin" : [160,315],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-5-6",
					"origin" : [172,315],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-5-7",
					"origin" : [160,315],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-5-8",
					"origin" : [160,315],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-5-9",
					"origin" : [160,315],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-5-10",
					"origin" : [160,315],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-5-11",
					"origin" : [160,315],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-6-0",
					"origin" : [176,417],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-6-1",
					"origin" : [176,435],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-6-2",
					"origin" : [176,433],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-6-3",
					"origin" : [176,417],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-6-4",
					"origin" : [176,412],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-6-5",
					"origin" : [201,427],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-6-6",
					"origin" : [176,417],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-6-7",
					"origin" : [176,435],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-6-8",
					"origin" : [176,433],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-6-9",
					"origin" : [176,417],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-6-10",
					"origin" : [176,412],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-6-11",
					"origin" : [201,427],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-7-0",
					"origin" : [176,395],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-7-1",
					"origin" : [176,395],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-7-2",
					"origin" : [176,395],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-7-3",
					"origin" : [176,395],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-7-4",
					"origin" : [176,395],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-7-5",
					"origin" : [176,395],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-7-6",
					"origin" : [176,395],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-7-7",
					"origin" : [176,395],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-7-8",
					"origin" : [176,395],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-7-9",
					"origin" : [176,395],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-7-10",
					"origin" : [176,395],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-7-11",
					"origin" : [176,395],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-8-0",
					"origin" : [123,173],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-8-1",
					"origin" : [123,176],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-8-2",
					"origin" : [123,177],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-8-3",
					"origin" : [123,171],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-8-4",
					"origin" : [123,175],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-8-5",
					"origin" : [123,174],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-8-6",
					"origin" : [123,173],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-8-7",
					"origin" : [123,176],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-8-8",
					"origin" : [123,177],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-8-9",
					"origin" : [123,171],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-8-10",
					"origin" : [123,175],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-8-11",
					"origin" : [123,174],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-9-0",
					"origin" : [132,245],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-9-1",
					"origin" : [132,216],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-9-2",
					"origin" : [132,265],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-9-3",
					"origin" : [132,247],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-9-4",
					"origin" : [132,222],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-9-5",
					"origin" : [132,231],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-9-6",
					"origin" : [132,245],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-9-7",
					"origin" : [132,216],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-9-8",
					"origin" : [132,265],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-9-9",
					"origin" : [132,247],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-9-10",
					"origin" : [132,222],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-9-11",
					"origin" : [132,231],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-10-0",
					"origin" : [83,82],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-10-1",
					"origin" : [83,82],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-10-2",
					"origin" : [83,82],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-10-3",
					"origin" : [83,82],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-10-4",
					"origin" : [83,82],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-10-5",
					"origin" : [83,82],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-10-6",
					"origin" : [83,82],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-10-7",
					"origin" : [83,82],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-10-8",
					"origin" : [83,82],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-10-9",
					"origin" : [83,82],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-10-10",
					"origin" : [83,82],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-10-11",
					"origin" : [83,82],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-11-0",
					"origin" : [29,24],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-12-0",
					"origin" : [29,229],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-12-1",
					"origin" : [44,229],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-12-2",
					"origin" : [49,216],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-12-3",
					"origin" : [59,201],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-12-4",
					"origin" : [58,211],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-12-5",
					"origin" : [45,260],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-13-0",
					"origin" : [174,197],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-13-1",
					"origin" : [126,242],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-13-2",
					"origin" : [116,211],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-13-3",
					"origin" : [135,216],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-13-4",
					"origin" : [130,194],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-13-5",
					"origin" : [136,188],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-14-0",
					"origin" : [47,150],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-14-1",
					"origin" : [47,160],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-14-2",
					"origin" : [53,152],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-14-3",
					"origin" : [74,148],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-14-4",
					"origin" : [68,156],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-14-5",
					"origin" : [55,179],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-15-0",
					"origin" : [161,247],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-15-1",
					"origin" : [174,295],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-15-2",
					"origin" : [170,262],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-15-3",
					"origin" : [167,268],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-15-4",
					"origin" : [173,244],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-15-5",
					"origin" : [172,237],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-16-0",
					"origin" : [164,158],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-16-1",
					"origin" : [163,201],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-16-2",
					"origin" : [153,155],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-16-3",
					"origin" : [165,177],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-16-4",
					"origin" : [162,155],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burundMapleIsland-16-5",
					"origin" : [160,149],
					"z" : 0,
				},
			},
		},
		"burningHouse1" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-0-0",
					"origin" : [248,415],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-1-0",
					"origin" : [107,210],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-1-1",
					"origin" : [111,178],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-1-2",
					"origin" : [112,177],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-1-3",
					"origin" : [113,190],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-1-4",
					"origin" : [114,194],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-1-5",
					"origin" : [110,184],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-2-0",
					"origin" : [2,150],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-2-1",
					"origin" : [1,172],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-2-2",
					"origin" : [1,162],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-2-3",
					"origin" : [5,180],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-2-4",
					"origin" : [2,178],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse1-2-5",
					"origin" : [2,162],
					"z" : 0,
				},
			},
		},
		"burningHouse2" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-0-0",
					"origin" : [358,443],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-1-0",
					"origin" : [6,114],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-1-1",
					"origin" : [10,132],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-1-2",
					"origin" : [7,130],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-1-3",
					"origin" : [7,114],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-1-4",
					"origin" : [7,102],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-1-5",
					"origin" : [6,124],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-2-0",
					"origin" : [-7,135],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-2-1",
					"origin" : [-8,157],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-2-2",
					"origin" : [-8,147],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-2-3",
					"origin" : [-4,165],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-2-4",
					"origin" : [-7,163],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-2-5",
					"origin" : [-7,147],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-3-0",
					"origin" : [42,340],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-3-1",
					"origin" : [29,396],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-3-2",
					"origin" : [24,345],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-3-3",
					"origin" : [33,328],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-3-4",
					"origin" : [38,324],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse2-3-5",
					"origin" : [46,322],
					"z" : 0,
				},
			},
		},
		"burningHouse3" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse3-0-0",
					"origin" : [151,293],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse3-1-0",
					"origin" : [-3,117],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse3-1-1",
					"origin" : [-4,139],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse3-1-2",
					"origin" : [-4,129],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse3-1-3",
					"origin" : [0,147],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse3-1-4",
					"origin" : [-3,145],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse3-1-5",
					"origin" : [-3,129],
					"z" : 0,
				},
			},
		},
		"burningHouse4" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-0-0",
					"origin" : [262,442],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-1-0",
					"origin" : [8,53],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-1-1",
					"origin" : [8,65],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-1-2",
					"origin" : [9,63],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-1-3",
					"origin" : [9,55],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-1-4",
					"origin" : [7,48],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-1-5",
					"origin" : [9,57],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-2-0",
					"origin" : [33,177],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-2-1",
					"origin" : [34,167],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-2-2",
					"origin" : [31,171],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-2-3",
					"origin" : [31,178],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-2-4",
					"origin" : [37,181],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-2-5",
					"origin" : [35,169],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-3-0",
					"origin" : [2,112],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-3-1",
					"origin" : [1,134],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-3-2",
					"origin" : [1,124],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-3-3",
					"origin" : [5,142],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-3-4",
					"origin" : [2,140],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-3-5",
					"origin" : [2,124],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-4-0",
					"origin" : [48,365],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-4-1",
					"origin" : [54,374],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-4-2",
					"origin" : [54,356],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-4-3",
					"origin" : [57,354],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-4-4",
					"origin" : [52,364],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-burningHouse4-4-5",
					"origin" : [55,419],
					"z" : 0,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-acc-0-0",
					"origin" : [209,189],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-acc-1-0",
					"origin" : [20,341],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-acc-1-1",
					"origin" : [24,350],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-acc-1-2",
					"origin" : [23,332],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-acc-1-3",
					"origin" : [26,330],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-acc-1-4",
					"origin" : [24,340],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-acc-1-5",
					"origin" : [28,395],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-acc-2-0",
					"origin" : [96,164],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-acc-3-0",
					"origin" : [79,178],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-acc-3-1",
					"origin" : [83,196],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-acc-3-2",
					"origin" : [80,194],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-acc-3-3",
					"origin" : [80,178],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-acc-3-4",
					"origin" : [80,166],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-acc-3-5",
					"origin" : [79,188],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-acc-4-0",
					"origin" : [-22,203],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-acc-4-1",
					"origin" : [-23,225],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-acc-4-2",
					"origin" : [-23,215],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-acc-4-3",
					"origin" : [-19,233],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-acc-4-4",
					"origin" : [-22,231],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-acc-4-5",
					"origin" : [-22,215],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-acc-5-0",
					"origin" : [149,155],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-acc-6-0",
					"origin" : [120,223],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-acc-6-1",
					"origin" : [119,245],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-acc-6-2",
					"origin" : [119,235],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-acc-6-3",
					"origin" : [123,253],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-acc-6-4",
					"origin" : [120,251],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-acc-6-5",
					"origin" : [120,235],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-acc-7-0",
					"origin" : [8,302],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-acc-7-1",
					"origin" : [-5,358],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-acc-7-2",
					"origin" : [-10,307],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-acc-7-3",
					"origin" : [-1,290],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-acc-7-4",
					"origin" : [4,286],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-acc-7-5",
					"origin" : [12,284],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-acc-8-0",
					"origin" : [83,172],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc1.img/mapleIsland-acc-9-0",
					"origin" : [52,279],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc1.img/mapleIsland-acc-9-1",
					"origin" : [56,297],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc1.img/mapleIsland-acc-9-2",
					"origin" : [53,295],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc1.img/mapleIsland-acc-9-3",
					"origin" : [53,279],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc1.img/mapleIsland-acc-9-4",
					"origin" : [53,267],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc1.img/mapleIsland-acc-9-5",
					"origin" : [52,289],
					"z" : 0,
				},
			},
		},
	},
};

