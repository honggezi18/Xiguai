var Objdungeon2 = Objdungeon2 || { }; 
Objdungeon2 =   {
	"id":"dungeon2",
	"snowyLightrock" :  {
		"foot" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-0-0",
					"origin" : [209,158],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-1-0",
					"origin" : [153,95],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-2-0",
					"origin" : [139,173],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-3-0",
					"origin" : [217,129],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-4-0",
					"origin" : [81,108],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-5-0",
					"origin" : [74,48],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-6-0",
					"origin" : [81,54],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-7-0",
					"origin" : [130,54],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-8-0",
					"origin" : [92,75],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-9-0",
					"origin" : [36,45],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-10-0",
					"origin" : [91,37],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-11-0",
					"origin" : [219,56],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-12-0",
					"origin" : [199,45],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-13-0",
					"origin" : [379,152],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-14-0",
					"origin" : [403,152],
					"z" : 1,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-15-0",
					"origin" : [273,165],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-16-0",
					"origin" : [187,223],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-17-0",
					"origin" : [192,55],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-18-0",
					"origin" : [143,78],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-19-0",
					"origin" : [91,43],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-20-0",
					"origin" : [62,34],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-21-0",
					"origin" : [43,26],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-22-0",
					"origin" : [32,21],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-23-0",
					"origin" : [379,152],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-24-0",
					"origin" : [616,99],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-25-0",
					"origin" : [312,99],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-26-0",
					"origin" : [57,99],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-27-0",
					"origin" : [-261,99],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-28-0",
					"origin" : [530,138],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-29-0",
					"origin" : [246,45],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-30-0",
					"origin" : [266,56],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-31-0",
					"origin" : [530,170],
					"z" : 0,
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-foot-32-0",
					"origin" : [530,170],
					"z" : 0,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-0-0",
					"origin" : [298,201],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-1-0",
					"origin" : [3,1],
					"z" : 0,
					"delay" : 50,
					"a0" : 0,
				},
				"1" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-1-1",
					"origin" : [3,1],
					"z" : 0,
					"delay" : 50,
					"a0" : 255,
				},
				"2" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-1-2",
					"origin" : [3,1],
					"z" : 0,
					"delay" : 50,
				},
				"3" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-1-3",
					"origin" : [3,2],
					"z" : 0,
					"delay" : 80,
				},
				"4" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-1-2",
					"origin" : [3,1],
					"z" : 0,
					"delay" : 50,
				},
				"5" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-1-1",
					"origin" : [3,1],
					"z" : 0,
					"delay" : 50,
					"a0" : 255,
				},
				"6" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-1-0",
					"origin" : [3,1],
					"z" : 0,
					"delay" : 50,
					"a0" : 0,
				},
				"7" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-1-1",
					"origin" : [3,1],
					"z" : 0,
					"delay" : 50,
					"a0" : 255,
				},
				"8" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-1-2",
					"origin" : [3,1],
					"z" : 0,
					"delay" : 50,
				},
				"9" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-1-3",
					"origin" : [3,2],
					"z" : 0,
					"delay" : 80,
				},
				"10" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-1-10",
					"origin" : [3,1],
					"z" : 0,
					"delay" : 2500,
					"a0" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-2-0",
					"origin" : [8,1],
					"z" : 0,
					"delay" : 50,
					"a0" : 0,
				},
				"1" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-2-1",
					"origin" : [8,1],
					"z" : 0,
					"delay" : 50,
					"a0" : 255,
				},
				"2" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-2-2",
					"origin" : [9,2],
					"z" : 0,
					"delay" : 50,
				},
				"3" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-2-3",
					"origin" : [9,4],
					"z" : 0,
					"delay" : 80,
				},
				"4" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-2-2",
					"origin" : [9,2],
					"z" : 0,
					"delay" : 50,
				},
				"5" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-2-1",
					"origin" : [8,1],
					"z" : 0,
					"delay" : 50,
					"a0" : 255,
				},
				"6" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-2-0",
					"origin" : [8,1],
					"z" : 0,
					"delay" : 50,
					"a0" : 0,
				},
				"7" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-2-1",
					"origin" : [8,1],
					"z" : 0,
					"delay" : 50,
					"a0" : 255,
				},
				"8" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-2-2",
					"origin" : [9,2],
					"z" : 0,
					"delay" : 50,
				},
				"9" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-2-3",
					"origin" : [9,4],
					"z" : 0,
					"delay" : 80,
				},
				"10" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-2-10",
					"origin" : [8,1],
					"z" : 0,
					"delay" : 3000,
					"a0" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-3-0",
					"origin" : [12,0],
					"z" : 0,
					"delay" : 50,
					"a0" : 0,
				},
				"1" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-3-1",
					"origin" : [12,0],
					"z" : 0,
					"delay" : 50,
					"a0" : 255,
				},
				"2" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-3-2",
					"origin" : [13,1],
					"z" : 0,
					"delay" : 50,
				},
				"3" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-3-3",
					"origin" : [13,6],
					"z" : 0,
					"delay" : 80,
				},
				"4" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-3-2",
					"origin" : [13,1],
					"z" : 0,
					"delay" : 50,
				},
				"5" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-3-1",
					"origin" : [12,0],
					"z" : 0,
					"delay" : 50,
					"a0" : 255,
				},
				"6" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-3-0",
					"origin" : [12,0],
					"z" : 0,
					"delay" : 50,
					"a0" : 0,
				},
				"7" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-3-1",
					"origin" : [12,0],
					"z" : 0,
					"delay" : 50,
					"a0" : 255,
				},
				"8" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-3-2",
					"origin" : [13,1],
					"z" : 0,
					"delay" : 50,
				},
				"9" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-3-3",
					"origin" : [13,6],
					"z" : 0,
					"delay" : 80,
				},
				"10" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-3-10",
					"origin" : [12,0],
					"z" : 0,
					"delay" : 3100,
					"a0" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-4-0",
					"origin" : [129,170],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-5-0",
					"origin" : [100,94],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-6-0",
					"origin" : [43,70],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-7-0",
					"origin" : [54,78],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-8-0",
					"origin" : [45,58],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-9-0",
					"origin" : [62,95],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-10-0",
					"origin" : [38,68],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-11-0",
					"origin" : [66,90],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-12-0",
					"origin" : [65,73],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-13-0",
					"origin" : [39,49],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-14-0",
					"origin" : [70,22],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-15-0",
					"origin" : [70,25],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-16-0",
					"origin" : [40,60],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-17-0",
					"origin" : [52,58],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-18-0",
					"origin" : [62,17],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-19-0",
					"origin" : [68,16],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-20-0",
					"origin" : [0,0],
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-21-0",
					"origin" : [0,0],
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-22-0",
					"origin" : [0,0],
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-23-0",
					"origin" : [53,9],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-24-0",
					"origin" : [83,52],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-25-0",
					"origin" : [168,88],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-26-0",
					"origin" : [178,90],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-27-0",
					"origin" : [94,44],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-28-0",
					"origin" : [34,33],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-29-0",
					"origin" : [302,164],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-30-0",
					"origin" : [168,78],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-30-1",
					"origin" : [168,79],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-30-2",
					"origin" : [168,80],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-30-3",
					"origin" : [168,81],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-30-4",
					"origin" : [168,82],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-30-5",
					"origin" : [168,81],
					"z" : 0,
					"delay" : 180,
				},
				"6" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-30-6",
					"origin" : [168,80],
					"z" : 0,
					"delay" : 180,
				},
				"7" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-30-7",
					"origin" : [168,79],
					"z" : 0,
					"delay" : 180,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-31-0",
					"origin" : [116,87],
					"z" : 0,
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-32-0",
					"origin" : [100,74],
					"z" : 0,
				},
			},
			"33" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-33-0",
					"origin" : [140,84],
					"z" : 0,
				},
			},
			"34" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-34-0",
					"origin" : [53,98],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-34-1",
					"origin" : [53,101],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-34-2",
					"origin" : [53,104],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-34-3",
					"origin" : [54,105],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-34-4",
					"origin" : [53,104],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "dungeon2.img/snowyLightrock-artificiality-34-5",
					"origin" : [53,101],
					"z" : 0,
					"delay" : 180,
				},
			},
		},
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-0-0",
					"origin" : [160,91],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-1-0",
					"origin" : [123,65],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-2-0",
					"origin" : [109,64],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-3-0",
					"origin" : [69,43],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-4-0",
					"origin" : [62,46],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-5-0",
					"origin" : [68,54],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-6-0",
					"origin" : [120,142],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-7-0",
					"origin" : [82,77],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-8-0",
					"origin" : [108,108],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-9-0",
					"origin" : [130,61],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-10-0",
					"origin" : [51,82],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-11-0",
					"origin" : [69,51],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-12-0",
					"origin" : [23,45],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-13-0",
					"origin" : [14,36],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-14-0",
					"origin" : [17,28],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-15-0",
					"origin" : [107,188],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-16-0",
					"origin" : [130,161],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-17-0",
					"origin" : [116,197],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-18-0",
					"origin" : [113,192],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-19-0",
					"origin" : [173,266],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-20-0",
					"origin" : [144,252],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-21-0",
					"origin" : [71,46],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-22-0",
					"origin" : [53,80],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-23-0",
					"origin" : [130,106],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-24-0",
					"origin" : [82,74],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-25-0",
					"origin" : [120,139],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-26-0",
					"origin" : [181,43],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-27-0",
					"origin" : [38,99],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-27-1",
					"origin" : [33,97],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-27-2",
					"origin" : [38,101],
					"z" : 0,
					"delay" : 180,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-nature-28-0",
					"origin" : [41,51],
					"z" : 0,
				},
			},
		},
		"snowball" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-snowball-0-0",
					"origin" : [60,59],
					"z" : 0,
				},
			},
		},
		"bridge" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-bridge-0-0",
					"origin" : [308,185],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-bridge-1-0",
					"origin" : [308,185],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-bridge-2-0",
					"origin" : [0,0],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-bridge-3-0",
					"origin" : [0,0],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-bridge-4-0",
					"origin" : [308,185],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/snowyLightrock-bridge-5-0",
					"origin" : [290,152],
					"z" : 0,
				},
			},
		},
	},
	"deepMine" :  {
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-0-0",
					"origin" : [47,61],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-1-0",
					"origin" : [63,71],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-2-0",
					"origin" : [37,45],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-3-0",
					"origin" : [62,22],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-4-0",
					"origin" : [58,20],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-5-0",
					"origin" : [28,58],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-6-0",
					"origin" : [48,55],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-7-0",
					"origin" : [63,16],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-8-0",
					"origin" : [76,28],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-9-0",
					"origin" : [48,24],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-10-0",
					"origin" : [42,20],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-11-0",
					"origin" : [141,84],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-12-0",
					"origin" : [137,85],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-13-0",
					"origin" : [2,56],
					"z" : 0,
					"rope" : [0,74],
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-14-0",
					"origin" : [63,59],
					"z" : 0,
					"rope" : [4,-15],
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-15-0",
					"origin" : [42,55],
					"z" : 0,
					"rope" : [-2,-15],
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-16-0",
					"origin" : [14,48],
					"z" : 0,
					"rope" : [0,-5],
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-17-0",
					"origin" : [12,53],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-18-0",
					"origin" : [33,33],
					"z" : 0,
					"a0" : 0,
					"a1" : 210,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-18-1",
					"origin" : [33,33],
					"z" : 0,
					"a0" : 210,
					"a1" : 0,
					"delay" : 3000,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-19-0",
					"origin" : [11,49],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-20-0",
					"origin" : [33,33],
					"z" : 0,
					"a0" : 0,
					"a1" : 220,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-20-1",
					"origin" : [33,33],
					"z" : 0,
					"a0" : 220,
					"a1" : 0,
					"delay" : 3000,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-21-0",
					"origin" : [111,77],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-22-0",
					"origin" : [14,34],
					"z" : 0,
					"rope" : [-7,45],
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-23-0",
					"origin" : [28,43],
					"z" : 0,
					"rope" : [1,-12],
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-24-0",
					"origin" : [103,77],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-25-0",
					"origin" : [64,62],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-26-0",
					"origin" : [64,60],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-27-0",
					"origin" : [85,68],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-28-0",
					"origin" : [85,45],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-29-0",
					"origin" : [69,100],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-30-0",
					"origin" : [40,57],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-31-0",
					"origin" : [70,41],
					"z" : 0,
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-32-0",
					"origin" : [25,29],
					"z" : 0,
				},
			},
			"33" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-33-0",
					"origin" : [25,41],
					"z" : 0,
				},
			},
			"34" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-34-0",
					"origin" : [25,29],
					"z" : 0,
				},
			},
			"35" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-35-0",
					"origin" : [36,41],
					"z" : 0,
				},
			},
			"36" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-36-0",
					"origin" : [68,52],
					"z" : 0,
				},
			},
			"37" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-37-0",
					"origin" : [65,41],
					"z" : 0,
				},
			},
			"38" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-38-0",
					"origin" : [55,30],
					"z" : 0,
				},
			},
			"39" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepMine-artificiality-39-0",
					"origin" : [50,29],
					"z" : 0,
				},
			},
		},
	},
	"moltenRock" :  {
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-0-0",
					"origin" : [60,30],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-1-0",
					"origin" : [57,34],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-2-0",
					"origin" : [58,35],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-3-0",
					"origin" : [30,15],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-4-0",
					"origin" : [24,13],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-5-0",
					"origin" : [29,14],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-6-0",
					"origin" : [70,21],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-7-0",
					"origin" : [76,31],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-8-0",
					"origin" : [89,21],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-9-0",
					"origin" : [79,45],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-10-0",
					"origin" : [58,25],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-11-0",
					"origin" : [63,16],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-12-0",
					"origin" : [68,23],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-13-0",
					"origin" : [41,20],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-14-0",
					"origin" : [32,25],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-15-0",
					"origin" : [35,29],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-16-0",
					"origin" : [32,28],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-17-0",
					"origin" : [146,137],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-18-0",
					"origin" : [0,0],
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-19-0",
					"origin" : [115,71],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-20-0",
					"origin" : [170,56],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-21-0",
					"origin" : [226,29],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-22-0",
					"origin" : [86,3],
					"z" : 0,
				},
				"1" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-22-1",
					"origin" : [86,3],
					"z" : 0,
				},
				"2" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-22-2",
					"origin" : [86,3],
					"z" : 0,
				},
				"3" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-22-3",
					"origin" : [86,3],
					"z" : 0,
				},
				"4" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-22-4",
					"origin" : [86,3],
					"z" : 0,
				},
				"5" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-22-5",
					"origin" : [86,3],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-23-0",
					"origin" : [27,23],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-artificiality-24-0",
					"origin" : [124,110],
					"z" : 0,
				},
			},
		},
		"foot" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-foot-0-0",
					"origin" : [127,25],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/moltenRock-foot-1-0",
					"origin" : [74,24],
					"z" : 0,
				},
			},
		},
	},
	"darkDeepMine" :  {
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/darkDeepMine-artificiality-0-0",
					"origin" : [185,153],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/darkDeepMine-artificiality-1-0",
					"origin" : [194,172],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/darkDeepMine-artificiality-2-0",
					"origin" : [182,149],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/darkDeepMine-artificiality-3-0",
					"origin" : [191,167],
					"z" : 0,
				},
			},
		},
	},
	"toyCastle1" :  {
		"foot" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle1-foot-0-0",
					"origin" : [212,15],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle1-foot-1-0",
					"origin" : [212,15],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle1-foot-2-0",
					"origin" : [212,16],
					"z" : 0,
				},
			},
		},
		"gate" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle1-gate-0-0",
					"origin" : [184,164],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle1-gate-0-1",
					"origin" : [184,164],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle1-gate-0-2",
					"origin" : [184,164],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "dungeon2.img/toyCastle1-gate-0-3",
					"origin" : [184,164],
					"z" : 0,
					"delay" : 150,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle1-gate-1-0",
					"origin" : [162,165],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle1-gate-1-1",
					"origin" : [162,165],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle1-gate-1-2",
					"origin" : [162,165],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "dungeon2.img/toyCastle1-gate-1-3",
					"origin" : [162,165],
					"z" : 0,
					"delay" : 150,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle1-gate-2-0",
					"origin" : [32,74],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle1-gate-3-0",
					"origin" : [71,75],
					"z" : 0,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle1-acc-0-0",
					"origin" : [82,95],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle1-acc-1-0",
					"origin" : [31,34],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle1-acc-2-0",
					"origin" : [21,23],
					"z" : 0,
				},
			},
		},
	},
	"toyCastle2" :  {
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-0-0",
					"origin" : [93,62],
					"z" : 0,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-0-1",
					"origin" : [90,59],
					"z" : 0,
					"delay" : 1000,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-0-2",
					"origin" : [91,61],
					"z" : 0,
					"delay" : 1000,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-1-0",
					"origin" : [74,78],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-1-1",
					"origin" : [74,78],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-1-2",
					"origin" : [74,78],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-1-3",
					"origin" : [74,78],
					"z" : 0,
					"delay" : 150,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-2-0",
					"origin" : [71,64],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-3-0",
					"origin" : [70,50],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-4-0",
					"origin" : [31,13],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-5-0",
					"origin" : [76,13],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-6-0",
					"origin" : [66,105],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-7-0",
					"origin" : [45,45],
					"z" : 0,
					"a0" : 20,
					"a1" : 255,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-7-1",
					"origin" : [45,45],
					"z" : 0,
					"a0" : 255,
					"a1" : 20,
					"delay" : 3000,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-8-0",
					"origin" : [25,46],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-9-0",
					"origin" : [24,46],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-10-0",
					"origin" : [24,46],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-11-0",
					"origin" : [24,46],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-12-0",
					"origin" : [45,45],
					"z" : 0,
					"a0" : 20,
					"a1" : 255,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-12-1",
					"origin" : [45,45],
					"z" : 0,
					"a0" : 255,
					"a1" : 20,
					"delay" : 3000,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-13-0",
					"origin" : [45,45],
					"z" : 0,
					"a0" : 0,
					"a1" : 140,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-13-1",
					"origin" : [45,45],
					"z" : 0,
					"a0" : 140,
					"a1" : 0,
					"delay" : 3000,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-14-0",
					"origin" : [115,113],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-14-1",
					"origin" : [114,113],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-14-2",
					"origin" : [114,113],
					"z" : 0,
					"delay" : 150,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-15-0",
					"origin" : [92,90],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-15-1",
					"origin" : [92,90],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-15-2",
					"origin" : [92,90],
					"z" : 0,
					"delay" : 150,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-16-0",
					"origin" : [52,57],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-16-1",
					"origin" : [52,57],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-16-2",
					"origin" : [52,57],
					"z" : 0,
					"delay" : 150,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-17-0",
					"origin" : [120,69],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-18-0",
					"origin" : [110,47],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc-19-0",
					"origin" : [94,38],
					"z" : 0,
				},
			},
		},
		"crane" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-0-0",
					"origin" : [55,62],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-1-0",
					"origin" : [40,20],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-2-0",
					"origin" : [58,47],
					"z" : 0,
					"ladder" : [-10,56],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-3-0",
					"origin" : [30,37],
					"z" : 0,
					"ladder" : [0,45],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-4-0",
					"origin" : [30,19],
					"z" : 0,
					"ladder" : [0,37],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-5-0",
					"origin" : [68,75],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-6-0",
					"origin" : [40,20],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-7-0",
					"origin" : [63,49],
					"z" : 0,
					"ladder" : [5,60],
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-8-0",
					"origin" : [30,37],
					"z" : 0,
					"ladder" : [1,46],
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-9-0",
					"origin" : [30,19],
					"z" : 0,
					"ladder" : [1,28],
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-10-0",
					"origin" : [52,105],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-11-0",
					"origin" : [53,94],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-12-0",
					"origin" : [51,51],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-13-0",
					"origin" : [30,21],
					"z" : 0,
					"ladder" : [0,28],
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-14-0",
					"origin" : [0,0],
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-15-0",
					"origin" : [30,19],
					"z" : 0,
					"ladder" : [0,28],
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-16-0",
					"origin" : [51,51],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-17-0",
					"origin" : [30,19],
					"z" : 0,
					"ladder" : [1,28],
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-18-0",
					"origin" : [30,50],
					"z" : 0,
					"ladder" : [1,60],
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-crane-19-0",
					"origin" : [30,19],
					"z" : 0,
					"ladder" : [1,28],
				},
			},
		},
		"foot" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-0-0",
					"origin" : [19,40],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-1-0",
					"origin" : [208,40],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-2-0",
					"origin" : [22,40],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-3-0",
					"origin" : [57,26],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-4-0",
					"origin" : [19,25],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-5-0",
					"origin" : [64,26],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-6-0",
					"origin" : [22,25],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-7-0",
					"origin" : [52,32],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-8-0",
					"origin" : [88,32],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-9-0",
					"origin" : [91,65],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-10-0",
					"origin" : [77,63],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-11-0",
					"origin" : [88,32],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-12-0",
					"origin" : [54,32],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-13-0",
					"origin" : [0,0],
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-14-0",
					"origin" : [0,0],
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-15-0",
					"origin" : [0,0],
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-16-0",
					"origin" : [28,26],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-17-0",
					"origin" : [52,26],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-18-0",
					"origin" : [19,46],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-19-0",
					"origin" : [44,54],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-20-0",
					"origin" : [53,26],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-21-0",
					"origin" : [45,26],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-22-0",
					"origin" : [27,26],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-23-0",
					"origin" : [51,26],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-24-0",
					"origin" : [19,46],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-25-0",
					"origin" : [45,54],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-26-0",
					"origin" : [53,26],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-27-0",
					"origin" : [45,26],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-28-0",
					"origin" : [27,26],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-29-0",
					"origin" : [53,26],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-30-0",
					"origin" : [19,46],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-31-0",
					"origin" : [44,54],
					"z" : 0,
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-32-0",
					"origin" : [51,26],
					"z" : 0,
				},
			},
			"33" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-33-0",
					"origin" : [45,26],
					"z" : 0,
				},
			},
			"34" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-34-0",
					"origin" : [144,27],
					"z" : 0,
				},
			},
			"35" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-35-0",
					"origin" : [98,25],
					"z" : 0,
				},
			},
			"36" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-36-0",
					"origin" : [45,21],
					"z" : 0,
				},
			},
			"37" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-37-0",
					"origin" : [43,18],
					"z" : 0,
				},
			},
			"38" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-38-0",
					"origin" : [43,17],
					"z" : 0,
				},
			},
			"39" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot-39-0",
					"origin" : [29,19],
					"z" : 0,
				},
			},
		},
		"foot1" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-0-0",
					"origin" : [20,40],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-1-0",
					"origin" : [208,40],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-2-0",
					"origin" : [22,40],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-3-0",
					"origin" : [58,26],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-4-0",
					"origin" : [19,25],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-5-0",
					"origin" : [64,26],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-6-0",
					"origin" : [22,25],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-7-0",
					"origin" : [52,32],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-8-0",
					"origin" : [88,32],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-9-0",
					"origin" : [91,65],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-10-0",
					"origin" : [77,63],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-11-0",
					"origin" : [88,32],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-12-0",
					"origin" : [54,32],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-13-0",
					"origin" : [0,0],
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-14-0",
					"origin" : [0,0],
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot1-15-0",
					"origin" : [0,0],
				},
			},
		},
		"foot2" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot2-0-0",
					"origin" : [20,40],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot2-1-0",
					"origin" : [208,41],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-foot2-2-0",
					"origin" : [22,41],
					"z" : 0,
				},
			},
		},
		"gate" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-0-0",
					"origin" : [92,102],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-1-0",
					"origin" : [90,103],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-2-0",
					"origin" : [98,105],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-3-0",
					"origin" : [98,104],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-4-0",
					"origin" : [149,144],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-5-0",
					"origin" : [150,144],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-6-0",
					"origin" : [53,65],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-6-1",
					"origin" : [53,65],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-6-2",
					"origin" : [53,65],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-6-3",
					"origin" : [53,65],
					"z" : 0,
					"delay" : 150,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-7-0",
					"origin" : [34,34],
					"z" : 0,
					"a0" : 150,
					"a1" : 255,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-7-1",
					"origin" : [34,34],
					"z" : 0,
					"a0" : 255,
					"a1" : 150,
					"delay" : 3000,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-8-0",
					"origin" : [34,34],
					"z" : 0,
					"a0" : 100,
					"a1" : 200,
					"delay" : 3000,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-8-1",
					"origin" : [34,34],
					"z" : 0,
					"a0" : 200,
					"a1" : 100,
					"delay" : 3000,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-gate-9-0",
					"origin" : [155,139],
					"z" : 0,
				},
			},
		},
		"acc2" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc2-0-0",
					"origin" : [34,77],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc2-1-0",
					"origin" : [59,78],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc2-2-0",
					"origin" : [46,71],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc2-3-0",
					"origin" : [75,76],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc2-4-0",
					"origin" : [31,41],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc2-5-0",
					"origin" : [78,55],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc2-6-0",
					"origin" : [91,93],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-acc2-6-1",
					"origin" : [91,96],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle2-acc2-6-2",
					"origin" : [92,98],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "dungeon2.img/toyCastle2-acc2-6-3",
					"origin" : [92,98],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "dungeon2.img/toyCastle2-acc2-6-4",
					"origin" : [92,95],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "dungeon2.img/toyCastle2-acc2-6-5",
					"origin" : [92,91],
					"z" : 0,
					"delay" : 150,
				},
			},
		},
		"acc3" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc3-0-0",
					"origin" : [32,77],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc3-1-0",
					"origin" : [76,77],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc3-2-0",
					"origin" : [63,120],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc3-3-0",
					"origin" : [107,87],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc3-4-0",
					"origin" : [48,73],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc3-5-0",
					"origin" : [67,92],
					"z" : 0,
					"delay" : 300,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-acc3-5-1",
					"origin" : [67,90],
					"z" : 0,
					"delay" : 300,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle2-acc3-5-2",
					"origin" : [67,89],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "dungeon2.img/toyCastle2-acc3-5-3",
					"origin" : [67,90],
					"z" : 0,
					"delay" : 250,
				},
				"4" :  {
					"png_path": "dungeon2.img/toyCastle2-acc3-5-4",
					"origin" : [67,92],
					"z" : 0,
					"delay" : 250,
				},
				"5" :  {
					"png_path": "dungeon2.img/toyCastle2-acc3-5-5",
					"origin" : [67,93],
					"z" : 0,
					"delay" : 250,
				},
			},
		},
		"acc4" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-0-0",
					"origin" : [42,98],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-1-0",
					"origin" : [83,98],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-2-0",
					"origin" : [77,79],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-3-0",
					"origin" : [109,63],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-4-0",
					"origin" : [46,42],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-5-0",
					"origin" : [62,55],
					"z" : 0,
					"delay" : 100,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-5-1",
					"origin" : [62,55],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-5-2",
					"origin" : [62,55],
					"z" : 0,
					"delay" : 100,
				},
				"3" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-5-3",
					"origin" : [62,55],
					"z" : 0,
					"delay" : 100,
				},
				"4" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-5-4",
					"origin" : [62,55],
					"z" : 0,
					"delay" : 100,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-6-0",
					"origin" : [97,83],
					"z" : 0,
					"delay" : 120,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-6-1",
					"origin" : [97,83],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-6-2",
					"origin" : [97,83],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "dungeon2.img/toyCastle2-acc4-6-3",
					"origin" : [97,83],
					"z" : 0,
					"delay" : 120,
				},
			},
		},
		"ghost" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-0-0",
					"origin" : [73,70],
					"z" : 0,
					"a0" : 50,
					"a1" : 100,
					"delay" : 250,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-0-1",
					"origin" : [73,70],
					"z" : 0,
					"a0" : 100,
					"a1" : 165,
					"delay" : 250,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-0-2",
					"origin" : [72,71],
					"z" : 0,
					"a0" : 165,
					"a1" : 215,
					"delay" : 250,
				},
				"3" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-0-3",
					"origin" : [75,73],
					"z" : 0,
					"a0" : 215,
					"a1" : 255,
					"delay" : 250,
				},
				"4" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-0-4",
					"origin" : [73,70],
					"z" : 0,
					"a0" : 255,
					"a1" : 215,
					"delay" : 250,
				},
				"5" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-0-5",
					"origin" : [73,70],
					"z" : 0,
					"a0" : 215,
					"a1" : 165,
					"delay" : 250,
				},
				"6" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-0-6",
					"origin" : [72,71],
					"z" : 0,
					"a0" : 165,
					"a1" : 100,
					"delay" : 250,
				},
				"7" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-0-7",
					"origin" : [75,73],
					"z" : 0,
					"a0" : 100,
					"a1" : 50,
					"delay" : 250,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-1-0",
					"origin" : [40,50],
					"z" : 0,
					"a0" : 50,
					"a1" : 100,
					"delay" : 280,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-1-1",
					"origin" : [42,44],
					"z" : 0,
					"a0" : 100,
					"a1" : 165,
					"delay" : 280,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-1-2",
					"origin" : [42,37],
					"z" : 0,
					"a0" : 165,
					"a1" : 215,
					"delay" : 280,
				},
				"3" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-1-3",
					"origin" : [39,44],
					"z" : 0,
					"a0" : 215,
					"a1" : 255,
					"delay" : 280,
				},
				"4" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-1-4",
					"origin" : [40,50],
					"z" : 0,
					"a0" : 255,
					"a1" : 215,
					"delay" : 280,
				},
				"5" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-1-5",
					"origin" : [42,44],
					"z" : 0,
					"a0" : 215,
					"a1" : 165,
					"delay" : 280,
				},
				"6" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-1-6",
					"origin" : [42,37],
					"z" : 0,
					"a0" : 165,
					"a1" : 100,
					"delay" : 280,
				},
				"7" :  {
					"png_path": "dungeon2.img/toyCastle2-ghost-1-7",
					"origin" : [39,44],
					"z" : 0,
					"a0" : 100,
					"a1" : 50,
					"delay" : 280,
				},
			},
		},
		"acc5" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-0-0",
					"origin" : [28,47],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-1-0",
					"origin" : [32,26],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-2-0",
					"origin" : [22,39],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-3-0",
					"origin" : [20,24],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-4-0",
					"origin" : [34,24],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-5-0",
					"origin" : [49,15],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-6-0",
					"origin" : [31,70],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-7-0",
					"origin" : [31,49],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-8-0",
					"origin" : [23,33],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-9-0",
					"origin" : [22,26],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-10-0",
					"origin" : [67,48],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-11-0",
					"origin" : [34,18],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-12-0",
					"origin" : [50,52],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-13-0",
					"origin" : [31,42],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-14-0",
					"origin" : [31,32],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-15-0",
					"origin" : [48,29],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-16-0",
					"origin" : [48,26],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-17-0",
					"origin" : [22,12],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-18-0",
					"origin" : [42,27],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-19-0",
					"origin" : [37,37],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-20-0",
					"origin" : [43,16],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-21-0",
					"origin" : [32,12],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-22-0",
					"origin" : [68,42],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-23-0",
					"origin" : [67,60],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-24-0",
					"origin" : [94,61],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-25-0",
					"origin" : [70,73],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-26-0",
					"origin" : [39,43],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-27-0",
					"origin" : [59,67],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-28-0",
					"origin" : [73,61],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-29-0",
					"origin" : [50,21],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-30-0",
					"origin" : [67,25],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-31-0",
					"origin" : [56,42],
					"z" : 0,
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-32-0",
					"origin" : [50,48],
					"z" : 0,
				},
			},
			"33" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc5-33-0",
					"origin" : [61,34],
					"z" : 0,
				},
			},
		},
		"acc6" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc6-0-0",
					"origin" : [86,111],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc6-1-0",
					"origin" : [85,112],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc6-2-0",
					"origin" : [90,113],
					"z" : 0,
				},
			},
		},
		"acc7" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-0-0",
					"origin" : [104,125],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-1-0",
					"origin" : [105,126],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-2-0",
					"origin" : [105,126],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-3-0",
					"origin" : [45,54],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-4-0",
					"origin" : [45,54],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-5-0",
					"origin" : [45,54],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-6-0",
					"origin" : [22,13],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-7-0",
					"origin" : [28,11],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-8-0",
					"origin" : [17,8],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-9-0",
					"origin" : [77,49],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-10-0",
					"origin" : [28,37],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-11-0",
					"origin" : [28,52],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-12-0",
					"origin" : [0,0],
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-13-0",
					"origin" : [36,65],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-14-0",
					"origin" : [19,26],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-15-0",
					"origin" : [0,0],
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-16-0",
					"origin" : [29,68],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-17-0",
					"origin" : [0,0],
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-18-0",
					"origin" : [18,47],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-19-0",
					"origin" : [23,51],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-20-0",
					"origin" : [20,39],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-21-0",
					"origin" : [31,36],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc7-22-0",
					"origin" : [77,49],
					"z" : 0,
				},
			},
		},
		"acc8" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc8-0-0",
					"origin" : [55,124],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc8-1-0",
					"origin" : [55,124],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc8-2-0",
					"origin" : [0,0],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc8-3-0",
					"origin" : [0,0],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc8-4-0",
					"origin" : [409,37],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc8-5-0",
					"origin" : [382,36],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc8-6-0",
					"origin" : [350,35],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc8-7-0",
					"origin" : [138,43],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc8-8-0",
					"origin" : [87,36],
					"z" : -1,
				},
				"seat" :  {
					"0" : [-12,32],
					"1" : [17,32],
					"2" : [46,32],
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastle2-acc8-9-0",
					"origin" : [88,36],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-48,28],
					"1" : [-18,28],
					"2" : [11,28],
				},
			},
		},
	},
	"toyCastleBoss" :  {
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-0-0",
					"origin" : [88,54],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-1-0",
					"origin" : [135,45],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-2-0",
					"origin" : [54,60],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-3-0",
					"origin" : [55,16],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-4-0",
					"origin" : [55,57],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-5-0",
					"origin" : [56,56],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-6-0",
					"origin" : [43,104],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-7-0",
					"origin" : [27,124],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-8-0",
					"origin" : [148,245],
					"z" : 0,
					"delay" : 120,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-8-1",
					"origin" : [148,245],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-8-2",
					"origin" : [148,245],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-8-3",
					"origin" : [148,245],
					"z" : 0,
					"delay" : 120,
				},
				"4" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-8-4",
					"origin" : [148,245],
					"z" : 0,
					"delay" : 120,
				},
				"5" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-8-5",
					"origin" : [148,245],
					"z" : 0,
					"delay" : 120,
				},
				"6" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-8-6",
					"origin" : [148,245],
					"z" : 0,
					"delay" : 120,
				},
				"7" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-8-7",
					"origin" : [148,245],
					"z" : 0,
					"delay" : 120,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-9-0",
					"origin" : [89,89],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 3500,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-9-1",
					"origin" : [89,89],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 3500,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-10-0",
					"origin" : [52,56],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 2500,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-10-1",
					"origin" : [52,56],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 2500,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-11-0",
					"origin" : [52,56],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 2500,
				},
				"1" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-11-1",
					"origin" : [52,56],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 2500,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-12-0",
					"origin" : [64,228],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-13-0",
					"origin" : [62,229],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-14-0",
					"origin" : [52,56],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-acc-15-0",
					"origin" : [62,33],
					"z" : 0,
				},
			},
		},
		"back" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-back-0-0",
					"origin" : [77,218],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-back-1-0",
					"origin" : [77,218],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-back-2-0",
					"origin" : [108,219],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-back-3-0",
					"origin" : [77,218],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-back-4-0",
					"origin" : [77,218],
					"z" : 0,
				},
			},
		},
		"foot" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-foot-0-0",
					"origin" : [15,26],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-foot-1-0",
					"origin" : [21,27],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-foot-2-0",
					"origin" : [15,27],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-foot-3-0",
					"origin" : [25,63],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-foot-4-0",
					"origin" : [127,64],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/toyCastleBoss-foot-5-0",
					"origin" : [23,63],
					"z" : 0,
				},
			},
		},
	},
	"deepSee" :  {
		"foot" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-0-0",
					"origin" : [259,122],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-1-0",
					"origin" : [210,142],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-2-0",
					"origin" : [227,139],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-3-0",
					"origin" : [258,85],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-4-0",
					"origin" : [150,56],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-5-0",
					"origin" : [191,52],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-6-0",
					"origin" : [120,38],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-7-0",
					"origin" : [135,46],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-8-0",
					"origin" : [127,48],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-9-0",
					"origin" : [125,43],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-10-0",
					"origin" : [127,42],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-11-0",
					"origin" : [106,50],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-12-0",
					"origin" : [67,49],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-13-0",
					"origin" : [52,20],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-14-0",
					"origin" : [53,23],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-15-0",
					"origin" : [385,57],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-16-0",
					"origin" : [98,73],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-17-0",
					"origin" : [26,73],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-foot-18-0",
					"origin" : [32,73],
					"z" : 0,
				},
			},
		},
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-0-0",
					"origin" : [37,118],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-1-0",
					"origin" : [69,49],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-2-0",
					"origin" : [66,42],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-3-0",
					"origin" : [42,38],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-4-0",
					"origin" : [145,118],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-5-0",
					"origin" : [56,103],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-6-0",
					"origin" : [49,91],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-7-0",
					"origin" : [42,36],
					"z" : 0,
					"delay" : 120,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-nature-7-1",
					"origin" : [41,35],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "dungeon2.img/deepSee-nature-7-2",
					"origin" : [42,34],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "dungeon2.img/deepSee-nature-7-3",
					"origin" : [43,33],
					"z" : 0,
					"delay" : 120,
				},
				"4" :  {
					"png_path": "dungeon2.img/deepSee-nature-7-4",
					"origin" : [42,34],
					"z" : 0,
					"delay" : 120,
				},
				"5" :  {
					"png_path": "dungeon2.img/deepSee-nature-7-5",
					"origin" : [41,35],
					"z" : 0,
					"delay" : 120,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-8-0",
					"origin" : [99,46],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-9-0",
					"origin" : [99,46],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-10-0",
					"origin" : [99,46],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-11-0",
					"origin" : [45,21],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-12-0",
					"origin" : [35,16],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-13-0",
					"origin" : [45,21],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-14-0",
					"origin" : [35,16],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-15-0",
					"origin" : [132,56],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-16-0",
					"origin" : [104,49],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-17-0",
					"origin" : [135,92],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-18-0",
					"origin" : [162,142],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-19-0",
					"origin" : [97,133],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-20-0",
					"origin" : [172,122],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-21-0",
					"origin" : [12,12],
					"z" : 0,
					"a0" : 20,
					"a1" : 255,
					"delay" : 2000,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-nature-21-1",
					"origin" : [12,12],
					"z" : 0,
					"a0" : 255,
					"a1" : 10,
					"delay" : 2000,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-nature-22-0",
					"origin" : [184,57],
					"z" : 0,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-0-0",
					"origin" : [51,65],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-1-0",
					"origin" : [82,75],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-2-0",
					"origin" : [0,0],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-3-0",
					"origin" : [105,51],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-4-0",
					"origin" : [117,46],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-5-0",
					"origin" : [114,44],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-6-0",
					"origin" : [72,29],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-7-0",
					"origin" : [73,27],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-8-0",
					"origin" : [158,40],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-9-0",
					"origin" : [45,25],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-10-0",
					"origin" : [91,53],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-11-0",
					"origin" : [91,36],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-12-0",
					"origin" : [94,38],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-13-0",
					"origin" : [82,15],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-14-0",
					"origin" : [56,35],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-15-0",
					"origin" : [37,37],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-16-0",
					"origin" : [38,37],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-17-0",
					"origin" : [129,124],
					"z" : 0,
					"delay" : 130,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-acc-17-1",
					"origin" : [129,124],
					"z" : 0,
					"delay" : 130,
				},
				"2" :  {
					"png_path": "dungeon2.img/deepSee-acc-17-2",
					"origin" : [129,133],
					"z" : 0,
					"delay" : 130,
				},
				"3" :  {
					"png_path": "dungeon2.img/deepSee-acc-17-3",
					"origin" : [129,135],
					"z" : 0,
					"delay" : 130,
				},
				"4" :  {
					"png_path": "dungeon2.img/deepSee-acc-17-4",
					"origin" : [129,137],
					"z" : 0,
					"delay" : 130,
				},
				"5" :  {
					"png_path": "dungeon2.img/deepSee-acc-17-5",
					"origin" : [129,139],
					"z" : 0,
					"delay" : 130,
				},
				"6" :  {
					"png_path": "dungeon2.img/deepSee-acc-17-6",
					"origin" : [129,141],
					"z" : 0,
					"delay" : 130,
				},
				"7" :  {
					"png_path": "dungeon2.img/deepSee-acc-17-7",
					"origin" : [129,143],
					"z" : 0,
					"delay" : 130,
				},
				"8" :  {
					"png_path": "dungeon2.img/deepSee-acc-17-8",
					"origin" : [129,146],
					"z" : 0,
					"delay" : 130,
				},
				"9" :  {
					"png_path": "dungeon2.img/deepSee-acc-17-9",
					"origin" : [129,149],
					"z" : 0,
					"delay" : 130,
				},
				"10" :  {
					"png_path": "dungeon2.img/deepSee-acc-17-10",
					"origin" : [129,144],
					"z" : 0,
					"delay" : 130,
				},
				"11" :  {
					"png_path": "dungeon2.img/deepSee-acc-17-11",
					"origin" : [129,134],
					"z" : 0,
					"delay" : 130,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-acc-18-0",
					"origin" : [17,2],
					"z" : 0,
				},
			},
		},
		"ship" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-0-0",
					"origin" : [379,256],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-1-0",
					"origin" : [99,134],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-2-0",
					"origin" : [82,80],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-3-0",
					"origin" : [215,155],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-4-0",
					"origin" : [83,68],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-5-0",
					"origin" : [148,124],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-6-0",
					"origin" : [96,60],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-7-0",
					"origin" : [70,19],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-8-0",
					"origin" : [127,85],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-9-0",
					"origin" : [126,85],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-10-0",
					"origin" : [126,85],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-11-0",
					"origin" : [29,26],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-ship-12-0",
					"origin" : [28,30],
					"z" : 0,
					"a0" : 80,
					"a1" : 255,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-ship-12-1",
					"origin" : [28,30],
					"z" : 0,
					"a0" : 255,
					"a1" : 80,
					"delay" : 1000,
				},
			},
		},
		"gate" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-gate-0-0",
					"origin" : [156,158],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-gate-1-0",
					"origin" : [132,155],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-gate-2-0",
					"origin" : [122,136],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-gate-3-0",
					"origin" : [60,43],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-gate-4-0",
					"origin" : [80,59],
					"z" : 0,
					"delay" : 100,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-gate-4-1",
					"origin" : [80,59],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "dungeon2.img/deepSee-gate-4-2",
					"origin" : [80,59],
					"z" : 0,
					"delay" : 100,
				},
				"3" :  {
					"png_path": "dungeon2.img/deepSee-gate-4-3",
					"origin" : [80,59],
					"z" : 0,
					"delay" : 100,
				},
				"4" :  {
					"png_path": "dungeon2.img/deepSee-gate-4-4",
					"origin" : [80,59],
					"z" : 0,
					"delay" : 100,
				},
				"5" :  {
					"png_path": "dungeon2.img/deepSee-gate-4-5",
					"origin" : [80,59],
					"z" : 0,
					"delay" : 100,
				},
				"6" :  {
					"png_path": "dungeon2.img/deepSee-gate-4-6",
					"origin" : [80,59],
					"z" : 0,
					"delay" : 100,
				},
				"7" :  {
					"png_path": "dungeon2.img/deepSee-gate-4-7",
					"origin" : [80,59],
					"z" : 0,
					"delay" : 100,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-gate-5-0",
					"origin" : [105,46],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-gate-6-0",
					"origin" : [36,45],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-gate-6-1",
					"origin" : [36,45],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "dungeon2.img/deepSee-gate-6-2",
					"origin" : [34,45],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "dungeon2.img/deepSee-gate-6-3",
					"origin" : [34,44],
					"z" : 0,
					"delay" : 180,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-gate-7-0",
					"origin" : [40,37],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-gate-8-0",
					"origin" : [29,38],
					"z" : 0,
					"a0" : 20,
					"a1" : 255,
					"delay" : 1500,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-gate-8-1",
					"origin" : [29,38],
					"z" : 0,
					"a0" : 255,
					"a1" : 20,
					"delay" : 1500,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-gate-9-0",
					"origin" : [11,4],
					"z" : 0,
					"delay" : 300,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-gate-9-1",
					"origin" : [10,2],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "dungeon2.img/deepSee-gate-9-2",
					"origin" : [10,1],
					"z" : 0,
					"delay" : 350,
				},
				"3" :  {
					"png_path": "dungeon2.img/deepSee-gate-9-1",
					"origin" : [10,2],
					"z" : 0,
					"delay" : 100,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-gate-10-0",
					"origin" : [7,3],
					"z" : 0,
					"delay" : 250,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-gate-10-1",
					"origin" : [7,2],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "dungeon2.img/deepSee-gate-10-2",
					"origin" : [6,1],
					"z" : 0,
					"delay" : 300,
				},
				"3" :  {
					"png_path": "dungeon2.img/deepSee-gate-10-1",
					"origin" : [7,2],
					"z" : 0,
					"delay" : 120,
				},
			},
		},
		"rock1" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-rock1-0-0",
					"origin" : [64,13],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-rock1-1-0",
					"origin" : [64,69],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-rock1-2-0",
					"origin" : [64,102],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-rock1-3-0",
					"origin" : [68,77],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-rock1-3-1",
					"origin" : [68,77],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "dungeon2.img/deepSee-rock1-3-2",
					"origin" : [68,77],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "dungeon2.img/deepSee-rock1-3-3",
					"origin" : [68,76],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "dungeon2.img/deepSee-rock1-3-4",
					"origin" : [68,76],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "dungeon2.img/deepSee-rock1-3-5",
					"origin" : [67,76],
					"z" : 0,
					"delay" : 180,
				},
				"6" :  {
					"png_path": "dungeon2.img/deepSee-rock1-3-6",
					"origin" : [68,76],
					"z" : 0,
					"delay" : 180,
				},
				"7" :  {
					"png_path": "dungeon2.img/deepSee-rock1-3-7",
					"origin" : [68,76],
					"z" : 0,
					"delay" : 180,
				},
				"8" :  {
					"png_path": "dungeon2.img/deepSee-rock1-3-8",
					"origin" : [68,77],
					"z" : 0,
					"delay" : 180,
				},
				"9" :  {
					"png_path": "dungeon2.img/deepSee-rock1-3-9",
					"origin" : [68,77],
					"z" : 0,
					"delay" : 180,
				},
			},
		},
		"rock2" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-rock2-0-0",
					"origin" : [55,3],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-rock2-1-0",
					"origin" : [56,29],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-rock2-2-0",
					"origin" : [64,101],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-rock2-3-0",
					"origin" : [57,104],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-rock2-3-1",
					"origin" : [57,104],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "dungeon2.img/deepSee-rock2-3-2",
					"origin" : [57,104],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "dungeon2.img/deepSee-rock2-3-3",
					"origin" : [57,103],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "dungeon2.img/deepSee-rock2-3-4",
					"origin" : [57,103],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "dungeon2.img/deepSee-rock2-3-5",
					"origin" : [56,103],
					"z" : 0,
					"delay" : 180,
				},
				"6" :  {
					"png_path": "dungeon2.img/deepSee-rock2-3-6",
					"origin" : [57,103],
					"z" : 0,
					"delay" : 180,
				},
				"7" :  {
					"png_path": "dungeon2.img/deepSee-rock2-3-7",
					"origin" : [57,103],
					"z" : 0,
					"delay" : 180,
				},
				"8" :  {
					"png_path": "dungeon2.img/deepSee-rock2-3-8",
					"origin" : [57,104],
					"z" : 0,
					"delay" : 180,
				},
				"9" :  {
					"png_path": "dungeon2.img/deepSee-rock2-3-9",
					"origin" : [57,104],
					"z" : 0,
					"delay" : 180,
				},
			},
		},
		"rock3" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-rock3-0-0",
					"origin" : [51,40],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-rock3-1-0",
					"origin" : [54,75],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-rock3-2-0",
					"origin" : [54,106],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-rock3-3-0",
					"origin" : [58,110],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-rock3-3-1",
					"origin" : [58,110],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "dungeon2.img/deepSee-rock3-3-2",
					"origin" : [58,110],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "dungeon2.img/deepSee-rock3-3-3",
					"origin" : [58,110],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "dungeon2.img/deepSee-rock3-3-4",
					"origin" : [58,109],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "dungeon2.img/deepSee-rock3-3-5",
					"origin" : [57,109],
					"z" : 0,
					"delay" : 180,
				},
				"6" :  {
					"png_path": "dungeon2.img/deepSee-rock3-3-6",
					"origin" : [58,109],
					"z" : 0,
					"delay" : 180,
				},
				"7" :  {
					"png_path": "dungeon2.img/deepSee-rock3-3-7",
					"origin" : [58,110],
					"z" : 0,
					"delay" : 180,
				},
				"8" :  {
					"png_path": "dungeon2.img/deepSee-rock3-3-8",
					"origin" : [58,110],
					"z" : 0,
					"delay" : 180,
				},
				"9" :  {
					"png_path": "dungeon2.img/deepSee-rock3-3-9",
					"origin" : [58,110],
					"z" : 0,
					"delay" : 180,
				},
			},
		},
		"caveInside" :  {
			"0" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-0-0",
					"origin" : [122,136],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-1-0",
					"origin" : [75,85],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-2-0",
					"origin" : [85,77],
					"z" : 0,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-2-1",
					"origin" : [85,77],
					"z" : 0,
				},
				"2" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-2-2",
					"origin" : [85,77],
					"z" : 0,
				},
				"3" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-2-3",
					"origin" : [85,77],
					"z" : 0,
				},
				"4" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-2-4",
					"origin" : [85,77],
					"z" : 0,
				},
				"5" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-2-5",
					"origin" : [85,77],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-3-0",
					"origin" : [-1,33],
					"z" : 0,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-3-1",
					"origin" : [-1,33],
					"z" : 0,
				},
				"2" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-3-2",
					"origin" : [-1,34],
					"z" : 0,
				},
				"3" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-3-3",
					"origin" : [-1,34],
					"z" : 0,
				},
				"4" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-3-4",
					"origin" : [-1,34],
					"z" : 0,
				},
				"5" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-3-5",
					"origin" : [-1,34],
					"z" : 0,
				},
				"6" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-3-6",
					"origin" : [-1,33],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-4-0",
					"origin" : [150,290],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-5-0",
					"origin" : [150,290],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-6-0",
					"origin" : [71,40],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-7-0",
					"origin" : [89,43],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-8-0",
					"origin" : [86,44],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-9-0",
					"origin" : [60,33],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-10-0",
					"origin" : [99,37],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-11-0",
					"origin" : [99,52],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-12-0",
					"origin" : [53,14],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-13-0",
					"origin" : [124,39],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-14-0",
					"origin" : [91,36],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-15-0",
					"origin" : [91,53],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-16-0",
					"origin" : [101,38],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-17-0",
					"origin" : [78,15],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-18-0",
					"origin" : [27,71],
					"z" : 0,
					"delay" : 120,
				},
				"1" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-18-1",
					"origin" : [27,72],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-18-2",
					"origin" : [27,71],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "dungeon2.img/deepSee-caveInside-18-3",
					"origin" : [27,69],
					"z" : 0,
					"delay" : 120,
				},
			},
		},
	},
};

