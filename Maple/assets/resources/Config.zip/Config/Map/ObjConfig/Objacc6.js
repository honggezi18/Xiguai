var Objacc6 = Objacc6 || { }; 
Objacc6 =   {
	"id":"acc6",
	"folkvillige" :  {
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-0-0",
					"origin" : [109,131],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-1-0",
					"origin" : [121,148],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-2-0",
					"origin" : [95,139],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-3-0",
					"origin" : [76,114],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-4-0",
					"origin" : [145,160],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-5-0",
					"origin" : [94,128],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-6-0",
					"origin" : [276,286],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-7-0",
					"origin" : [84,31],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-8-0",
					"origin" : [72,22],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-9-0",
					"origin" : [35,13],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-10-0",
					"origin" : [80,59],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-11-0",
					"origin" : [60,45],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-12-0",
					"origin" : [70,38],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-13-0",
					"origin" : [39,24],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-14-0",
					"origin" : [39,26],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-15-0",
					"origin" : [25,19],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-16-0",
					"origin" : [37,24],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-17-0",
					"origin" : [24,23],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-18-0",
					"origin" : [43,31],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-19-0",
					"origin" : [29,25],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-20-0",
					"origin" : [53,12],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-21-0",
					"origin" : [41,12],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-22-0",
					"origin" : [30,11],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-23-0",
					"origin" : [16,14],
					"z" : 0,
					"a0" : 10,
					"a1" : 255,
					"delay" : 1500,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-nature-23-1",
					"origin" : [16,14],
					"z" : 0,
					"a0" : 255,
					"a1" : 10,
					"delay" : 1500,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-24-0",
					"origin" : [12,12],
					"z" : 0,
					"a0" : 10,
					"a1" : 255,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-nature-24-1",
					"origin" : [12,12],
					"z" : 0,
					"a0" : 255,
					"a1" : 10,
					"delay" : 1000,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-25-0",
					"origin" : [196,217],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-26-0",
					"origin" : [63,29],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-27-0",
					"origin" : [0,0],
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-nature-28-0",
					"origin" : [179,177],
					"z" : 0,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-0-0",
					"origin" : [123,52],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-1-0",
					"origin" : [62,60],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-2-0",
					"origin" : [0,0],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-3-0",
					"origin" : [19,21],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-4-0",
					"origin" : [19,21],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-5-0",
					"origin" : [90,105],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-6-0",
					"origin" : [0,0],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-7-0",
					"origin" : [42,27],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-8-0",
					"origin" : [13,24],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-9-0",
					"origin" : [14,32],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-10-0",
					"origin" : [14,42],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-11-0",
					"origin" : [86,103],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-12-0",
					"origin" : [43,81],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-13-0",
					"origin" : [55,58],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-artificiality-14-0",
					"origin" : [35,51],
					"z" : 0,
				},
			},
		},
		"bridge" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-bridge-0-0",
					"origin" : [183,64],
					"z" : 0,
				},
			},
		},
		"well" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-well-0-0",
					"origin" : [93,42],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-well-1-0",
					"origin" : [88,85],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-well-2-0",
					"origin" : [93,42],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-well-3-0",
					"origin" : [34,43],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-well-4-0",
					"origin" : [34,85],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-well-5-0",
					"origin" : [35,42],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-well-6-0",
					"origin" : [32,43],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-well-7-0",
					"origin" : [31,85],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-well-8-0",
					"origin" : [32,42],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-well-9-0",
					"origin" : [88,20],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-well-10-0",
					"origin" : [0,0],
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-well-11-0",
					"origin" : [0,0],
				},
			},
		},
		"event" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-0-0",
					"origin" : [328,105],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-1-0",
					"origin" : [84,63],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-2-0",
					"origin" : [146,63],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-3-0",
					"origin" : [227,66],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-4-0",
					"origin" : [102,138],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-5-0",
					"origin" : [30,85],
					"z" : 0,
					"ladder" : [0,94],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-6-0",
					"origin" : [28,19],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-7-0",
					"origin" : [31,28],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-8-0",
					"origin" : [26,23],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-9-0",
					"origin" : [44,46],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-10-0",
					"origin" : [78,37],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-11-0",
					"origin" : [82,36],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-12-0",
					"origin" : [44,28],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-event-13-0",
					"origin" : [64,19],
					"z" : 0,
				},
			},
		},
		"market" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-market-0-0",
					"origin" : [144,172],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-market-1-0",
					"origin" : [32,13],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-market-2-0",
					"origin" : [32,13],
					"z" : 0,
				},
			},
		},
		"jump" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-0-0",
					"origin" : [163,62],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-jump-0-1",
					"origin" : [168,67],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-jump-0-2",
					"origin" : [175,66],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-jump-0-3",
					"origin" : [177,65],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-jump-0-4",
					"origin" : [182,68],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-jump-0-5",
					"origin" : [184,70],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-1-0",
					"origin" : [35,171],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-2-0",
					"origin" : [139,155],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-3-0",
					"origin" : [60,169],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-4-0",
					"origin" : [129,142],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-5-0",
					"origin" : [73,109],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-6-0",
					"origin" : [68,128],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-7-0",
					"origin" : [92,137],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-8-0",
					"origin" : [-93,45],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-9-0",
					"origin" : [140,91],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-10-0",
					"origin" : [-141,201],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-11-0",
					"origin" : [70,162],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-jump-11-1",
					"origin" : [70,165],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-jump-11-2",
					"origin" : [70,166],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-jump-11-3",
					"origin" : [70,166],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-jump-11-4",
					"origin" : [70,162],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-jump-11-5",
					"origin" : [70,165],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc6.img/folkvillige-jump-11-6",
					"origin" : [70,165],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc6.img/folkvillige-jump-11-7",
					"origin" : [70,165],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc6.img/folkvillige-jump-11-8",
					"origin" : [70,162],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc6.img/folkvillige-jump-11-9",
					"origin" : [70,166],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc6.img/folkvillige-jump-11-10",
					"origin" : [70,166],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc6.img/folkvillige-jump-11-11",
					"origin" : [70,166],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-12-0",
					"origin" : [53,101],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-jump-12-1",
					"origin" : [46,121],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-jump-12-2",
					"origin" : [55,126],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-jump-12-3",
					"origin" : [50,120],
					"z" : 0,
					"delay" : 180,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-13-0",
					"origin" : [24,102],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-jump-13-1",
					"origin" : [23,122],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-jump-13-2",
					"origin" : [22,127],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-jump-13-3",
					"origin" : [24,121],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-14-0",
					"origin" : [20,68],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-jump-14-1",
					"origin" : [20,68],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-jump-14-2",
					"origin" : [19,68],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-jump-14-3",
					"origin" : [19,68],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-jump-14-4",
					"origin" : [19,68],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-jump-14-5",
					"origin" : [20,71],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc6.img/folkvillige-jump-14-6",
					"origin" : [20,73],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc6.img/folkvillige-jump-14-7",
					"origin" : [21,76],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc6.img/folkvillige-jump-14-8",
					"origin" : [22,78],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc6.img/folkvillige-jump-14-9",
					"origin" : [22,68],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc6.img/folkvillige-jump-14-10",
					"origin" : [22,68],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc6.img/folkvillige-jump-14-11",
					"origin" : [22,68],
					"z" : 0,
					"delay" : 900,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-15-0",
					"origin" : [24,16],
					"z" : 0,
					"delay" : 1800,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-jump-15-1",
					"origin" : [0,0],
					"delay" : 3600,
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-jump-15-2",
					"origin" : [48,16],
					"z" : 0,
					"delay" : 2100,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-jump-15-3",
					"origin" : [0,0],
					"delay" : 3600,
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-16-0",
					"origin" : [0,0],
					"delay" : 5000,
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-jump-16-1",
					"origin" : [48,23],
					"z" : 0,
					"delay" : 2100,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-jump-16-2",
					"origin" : [0,0],
					"delay" : 4200,
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-jump-16-3",
					"origin" : [36,16],
					"z" : 0,
					"delay" : 1800,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-17-0",
					"origin" : [48,30],
					"z" : 0,
					"delay" : 1800,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-jump-17-1",
					"origin" : [0,0],
					"delay" : 900,
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-18-0",
					"origin" : [159,162],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-jump-19-0",
					"origin" : [36,95],
					"z" : 0,
					"delay" : 100,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-jump-19-1",
					"origin" : [36,95],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-jump-19-2",
					"origin" : [36,95],
					"z" : 0,
					"delay" : 100,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-jump-19-3",
					"origin" : [37,92],
					"z" : 0,
					"delay" : 100,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-jump-19-4",
					"origin" : [37,95],
					"z" : 0,
					"delay" : 100,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-jump-19-5",
					"origin" : [36,95],
					"z" : 0,
					"delay" : 100,
				},
			},
		},
		"moon1" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-0-0",
					"origin" : [135,139],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-1-0",
					"origin" : [-135,163],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-2-0",
					"origin" : [-403,180],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-3-0",
					"origin" : [-712,149],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-4-0",
					"origin" : [151,83],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-5-0",
					"origin" : [164,61],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-6-0",
					"origin" : [224,32],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-7-0",
					"origin" : [109,32],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-0",
					"origin" : [5,80],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-1",
					"origin" : [5,80],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-2",
					"origin" : [5,80],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-3",
					"origin" : [5,80],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-4",
					"origin" : [5,80],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-5",
					"origin" : [5,80],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-6",
					"origin" : [5,80],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-7",
					"origin" : [5,80],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-8",
					"origin" : [5,80],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-9",
					"origin" : [5,80],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-10",
					"origin" : [5,80],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-11",
					"origin" : [5,80],
					"z" : 0,
				},
				"12" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-12",
					"origin" : [5,80],
					"z" : 0,
				},
				"13" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-13",
					"origin" : [5,80],
					"z" : 0,
				},
				"14" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-14",
					"origin" : [17,77],
					"z" : 0,
				},
				"15" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-15",
					"origin" : [48,79],
					"z" : 0,
				},
				"16" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-16",
					"origin" : [53,80],
					"z" : 0,
				},
				"17" :  {
					"png_path": "acc6.img/folkvillige-moon1-8-17",
					"origin" : [69,80],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-9-0",
					"origin" : [-10,67],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon1-9-1",
					"origin" : [-10,64],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon1-9-2",
					"origin" : [1,68],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon1-9-3",
					"origin" : [12,60],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon1-9-4",
					"origin" : [19,41],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon1-9-5",
					"origin" : [34,27],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc6.img/folkvillige-moon1-9-6",
					"origin" : [51,21],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc6.img/folkvillige-moon1-9-7",
					"origin" : [56,4],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc6.img/folkvillige-moon1-9-8",
					"origin" : [68,9],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc6.img/folkvillige-moon1-9-9",
					"origin" : [80,-4],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc6.img/folkvillige-moon1-9-10",
					"origin" : [80,-19],
					"z" : 0,
					"delay" : 1200,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-10-0",
					"origin" : [39,75],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon1-10-1",
					"origin" : [36,78],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon1-10-2",
					"origin" : [35,79],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon1-10-3",
					"origin" : [34,80],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon1-10-4",
					"origin" : [42,77],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon1-10-5",
					"origin" : [41,78],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-11-0",
					"origin" : [146,102],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-12-0",
					"origin" : [98,32],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-13-0",
					"origin" : [53,134],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-14-0",
					"origin" : [-53,132],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-15-0",
					"origin" : [-194,122],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-0",
					"origin" : [38,77],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-1",
					"origin" : [38,77],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-2",
					"origin" : [38,77],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-3",
					"origin" : [38,77],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-4",
					"origin" : [38,77],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-5",
					"origin" : [38,77],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-6",
					"origin" : [38,77],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-7",
					"origin" : [38,77],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-8",
					"origin" : [38,77],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-9",
					"origin" : [38,77],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-10",
					"origin" : [38,77],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-11",
					"origin" : [38,77],
					"z" : 0,
				},
				"12" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-12",
					"origin" : [38,77],
					"z" : 0,
				},
				"13" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-13",
					"origin" : [38,77],
					"z" : 0,
				},
				"14" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-14",
					"origin" : [38,77],
					"z" : 0,
				},
				"15" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-15",
					"origin" : [38,77],
					"z" : 0,
				},
				"16" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-16",
					"origin" : [38,77],
					"z" : 0,
				},
				"17" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-17",
					"origin" : [38,77],
					"z" : 0,
				},
				"18" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-18",
					"origin" : [38,77],
					"z" : 0,
				},
				"19" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-19",
					"origin" : [38,77],
					"z" : 0,
				},
				"20" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-20",
					"origin" : [38,77],
					"z" : 0,
				},
				"21" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-21",
					"origin" : [38,77],
					"z" : 0,
				},
				"22" :  {
					"png_path": "acc6.img/folkvillige-moon1-16-22",
					"origin" : [38,77],
					"z" : 0,
					"delay" : 600,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-17-0",
					"origin" : [71,71],
					"z" : 0,
					"a0" : 255,
					"a1" : 120,
					"delay" : 600,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon1-17-1",
					"origin" : [71,71],
					"z" : 0,
					"a0" : 120,
					"a1" : 255,
					"delay" : 600,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-18-0",
					"origin" : [184,176],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-19-0",
					"origin" : [135,144],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-20-0",
					"origin" : [210,165],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-21-0",
					"origin" : [27,29],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-22-0",
					"origin" : [25,19],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-23-0",
					"origin" : [23,22],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-24-0",
					"origin" : [28,19],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-25-0",
					"origin" : [25,24],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-26-0",
					"origin" : [27,30],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-27-0",
					"origin" : [39,22],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-28-0",
					"origin" : [140,65],
					"z" : 0,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon1-29-0",
					"origin" : [48,23],
					"z" : 0,
					"delay" : 1800,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon1-29-1",
					"origin" : [0,0],
					"delay" : 3300,
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon1-29-2",
					"origin" : [48,16],
					"z" : 0,
					"delay" : 2100,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon1-29-3",
					"origin" : [0,0],
					"delay" : 4800,
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon1-29-4",
					"origin" : [48,30],
					"z" : 0,
					"delay" : 1800,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon1-29-5",
					"origin" : [0,0],
					"delay" : 5700,
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc6.img/folkvillige-moon1-29-6",
					"origin" : [48,23],
					"z" : 0,
					"delay" : 1800,
				},
				"7" :  {
					"png_path": "acc6.img/folkvillige-moon1-29-7",
					"origin" : [0,0],
					"delay" : 5700,
					"z" : 0,
				},
			},
		},
		"moon2" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon2-0-0",
					"origin" : [125,251],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon2-1-0",
					"origin" : [125,249],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon2-2-0",
					"origin" : [119,251],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon2-3-0",
					"origin" : [119,249],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon2-4-0",
					"origin" : [215,250],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon2-5-0",
					"origin" : [215,-250],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-0",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-1",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-2",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-3",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-4",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-5",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"6" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-6",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"7" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-7",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"8" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-8",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"9" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-9",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"10" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-10",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"11" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-11",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"12" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-12",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"13" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-13",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"14" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-14",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"15" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-15",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"16" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-16",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"17" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-17",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 180,
				},
				"18" :  {
					"png_path": "acc6.img/folkvillige-moon2-6-18",
					"origin" : [73,178],
					"z" : 0,
					"delay" : 6000,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon2-7-0",
					"origin" : [81,166],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon2-7-1",
					"origin" : [81,166],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon2-7-2",
					"origin" : [81,166],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon2-7-3",
					"origin" : [81,166],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon2-7-4",
					"origin" : [81,166],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon2-7-5",
					"origin" : [81,166],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc6.img/folkvillige-moon2-7-6",
					"origin" : [81,166],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc6.img/folkvillige-moon2-7-7",
					"origin" : [81,166],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "acc6.img/folkvillige-moon2-7-8",
					"origin" : [81,166],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "acc6.img/folkvillige-moon2-7-9",
					"origin" : [81,166],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "acc6.img/folkvillige-moon2-7-10",
					"origin" : [81,166],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "acc6.img/folkvillige-moon2-7-11",
					"origin" : [81,166],
					"z" : 0,
					"delay" : 3300,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-0",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-1",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-2",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-3",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-4",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-5",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-6",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-7",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-8",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-9",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-10",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-11",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 150,
				},
				"12" :  {
					"png_path": "acc6.img/folkvillige-moon2-8-12",
					"origin" : [79,164],
					"z" : 0,
					"delay" : 4200,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon2-9-0",
					"origin" : [56,138],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon2-9-1",
					"origin" : [56,138],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon2-9-2",
					"origin" : [56,138],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon2-9-3",
					"origin" : [56,138],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon2-9-4",
					"origin" : [56,138],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon2-9-5",
					"origin" : [56,138],
					"z" : 0,
					"delay" : 5200,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon2-10-0",
					"origin" : [71,158],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon2-10-1",
					"origin" : [71,158],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon2-10-2",
					"origin" : [71,158],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon2-10-3",
					"origin" : [71,158],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon2-10-4",
					"origin" : [71,158],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon2-10-5",
					"origin" : [71,158],
					"z" : 0,
					"delay" : 6600,
				},
			},
		},
		"moon3" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-0-0",
					"origin" : [189,146],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-1-0",
					"origin" : [199,160],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-2-0",
					"origin" : [212,148],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-3-0",
					"origin" : [156,191],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-4-0",
					"origin" : [86,102],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-5-0",
					"origin" : [73,88],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-6-0",
					"origin" : [123,141],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-7-0",
					"origin" : [178,43],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-8-0",
					"origin" : [158,33],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-9-0",
					"origin" : [234,88],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-10-0",
					"origin" : [138,61],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-11-0",
					"origin" : [60,21],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-0",
					"origin" : [58,133],
					"z" : 0,
					"delay" : 210,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-1",
					"origin" : [58,132],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-2",
					"origin" : [58,131],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-3",
					"origin" : [58,132],
					"z" : 0,
					"delay" : 210,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-4",
					"origin" : [58,133],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-5",
					"origin" : [58,134],
					"z" : 0,
					"delay" : 210,
				},
				"6" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-6",
					"origin" : [58,135],
					"z" : 0,
					"delay" : 210,
				},
				"7" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-7",
					"origin" : [58,134],
					"z" : 0,
					"delay" : 210,
				},
				"8" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-8",
					"origin" : [58,133],
					"z" : 0,
					"delay" : 210,
				},
				"9" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-9",
					"origin" : [58,132],
					"z" : 0,
					"delay" : 210,
				},
				"10" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-10",
					"origin" : [58,131],
					"z" : 0,
					"delay" : 210,
				},
				"11" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-11",
					"origin" : [58,132],
					"z" : 0,
					"delay" : 210,
				},
				"12" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-12",
					"origin" : [58,133],
					"z" : 0,
					"delay" : 210,
				},
				"13" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-13",
					"origin" : [58,134],
					"z" : 0,
					"delay" : 210,
				},
				"14" :  {
					"png_path": "acc6.img/folkvillige-moon3-12-14",
					"origin" : [58,135],
					"z" : 0,
					"delay" : 210,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-0",
					"origin" : [39,93],
					"z" : 0,
					"delay" : 240,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-1",
					"origin" : [40,93],
					"z" : 0,
					"delay" : 240,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-2",
					"origin" : [41,93],
					"z" : 0,
					"delay" : 240,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-3",
					"origin" : [42,93],
					"z" : 0,
					"delay" : 240,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-4",
					"origin" : [42,93],
					"z" : 0,
					"delay" : 240,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-5",
					"origin" : [41,93],
					"z" : 0,
					"delay" : 240,
				},
				"6" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-6",
					"origin" : [39,93],
					"z" : 0,
					"delay" : 240,
				},
				"7" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-7",
					"origin" : [39,93],
					"z" : 0,
					"delay" : 240,
				},
				"8" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-8",
					"origin" : [40,93],
					"z" : 0,
					"delay" : 240,
				},
				"9" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-9",
					"origin" : [41,93],
					"z" : 0,
					"delay" : 240,
				},
				"10" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-10",
					"origin" : [41,93],
					"z" : 0,
					"delay" : 240,
				},
				"11" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-11",
					"origin" : [42,93],
					"z" : 0,
					"delay" : 240,
				},
				"12" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-12",
					"origin" : [42,93],
					"z" : 0,
					"delay" : 240,
				},
				"13" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-13",
					"origin" : [41,93],
					"z" : 0,
					"delay" : 240,
				},
				"14" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-14",
					"origin" : [39,93],
					"z" : 0,
					"delay" : 240,
				},
				"15" :  {
					"png_path": "acc6.img/folkvillige-moon3-13-15",
					"origin" : [38,93],
					"z" : 0,
					"delay" : 240,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-0",
					"origin" : [32,40],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-1",
					"origin" : [32,40],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-2",
					"origin" : [32,40],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-3",
					"origin" : [32,40],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-4",
					"origin" : [32,42],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-5",
					"origin" : [32,40],
					"z" : 0,
					"delay" : 180,
				},
				"6" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-6",
					"origin" : [32,38],
					"z" : 0,
					"delay" : 180,
				},
				"7" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-7",
					"origin" : [31,41],
					"z" : 0,
					"delay" : 180,
				},
				"8" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-8",
					"origin" : [32,40],
					"z" : 0,
					"delay" : 180,
				},
				"9" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-9",
					"origin" : [41,40],
					"z" : 0,
					"delay" : 180,
				},
				"10" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-10",
					"origin" : [41,40],
					"z" : 0,
					"delay" : 180,
				},
				"11" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-11",
					"origin" : [42,40],
					"z" : 0,
					"delay" : 180,
				},
				"12" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-12",
					"origin" : [32,42],
					"z" : 0,
					"delay" : 180,
				},
				"13" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-13",
					"origin" : [32,40],
					"z" : 0,
					"delay" : 180,
				},
				"14" :  {
					"png_path": "acc6.img/folkvillige-moon3-14-14",
					"origin" : [32,38],
					"z" : 0,
					"delay" : 180,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon3-15-0",
					"origin" : [137,55],
					"z" : 0,
				},
			},
		},
		"moon4" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-0-0",
					"origin" : [452,160],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-1-0",
					"origin" : [31,88],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon4-1-1",
					"origin" : [31,84],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon4-1-2",
					"origin" : [31,85],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon4-1-3",
					"origin" : [31,91],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon4-1-4",
					"origin" : [31,93],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-2-0",
					"origin" : [31,88],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon4-2-1",
					"origin" : [31,84],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon4-2-2",
					"origin" : [31,85],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon4-2-3",
					"origin" : [31,91],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon4-2-4",
					"origin" : [31,93],
					"z" : 0,
					"delay" : 180,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-3-0",
					"origin" : [31,88],
					"z" : 0,
					"delay" : 210,
				},
				"1" :  {
					"png_path": "acc6.img/folkvillige-moon4-3-1",
					"origin" : [31,84],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc6.img/folkvillige-moon4-3-2",
					"origin" : [31,85],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc6.img/folkvillige-moon4-3-3",
					"origin" : [31,91],
					"z" : 0,
					"delay" : 210,
				},
				"4" :  {
					"png_path": "acc6.img/folkvillige-moon4-3-4",
					"origin" : [31,93],
					"z" : 0,
					"delay" : 210,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-4-0",
					"origin" : [228,180],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-5-0",
					"origin" : [125,167],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-6-0",
					"origin" : [62,120],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-7-0",
					"origin" : [13,28],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-8-0",
					"origin" : [17,28],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-9-0",
					"origin" : [-18,28],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-10-0",
					"origin" : [-18,28],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-11-0",
					"origin" : [-18,29],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-12-0",
					"origin" : [-108,28],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-13-0",
					"origin" : [-108,28],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-14-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-15-0",
					"origin" : [15,0],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/folkvillige-moon4-16-0",
					"origin" : [0,0],
					"delay" : 5700,
					"z" : 0,
				},
			},
		},
	},
	"darkmountain" :  {
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-0-0",
					"origin" : [145,160],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-1-0",
					"origin" : [94,128],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-2-0",
					"origin" : [121,138],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-3-0",
					"origin" : [76,110],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-4-0",
					"origin" : [95,130],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-5-0",
					"origin" : [80,59],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-6-0",
					"origin" : [60,45],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-7-0",
					"origin" : [70,39],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-8-0",
					"origin" : [39,24],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-9-0",
					"origin" : [85,31],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-10-0",
					"origin" : [74,39],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-11-0",
					"origin" : [35,13],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-12-0",
					"origin" : [40,26],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-13-0",
					"origin" : [25,19],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-14-0",
					"origin" : [39,24],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-15-0",
					"origin" : [90,92],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-16-0",
					"origin" : [126,118],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-17-0",
					"origin" : [81,66],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-18-0",
					"origin" : [90,92],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-19-0",
					"origin" : [119,45],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-20-0",
					"origin" : [36,73],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-21-0",
					"origin" : [60,44],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-22-0",
					"origin" : [81,66],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-nature-23-0",
					"origin" : [196,217],
					"z" : 0,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-acc-0-0",
					"origin" : [24,22],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-acc-1-0",
					"origin" : [19,40],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-acc-2-0",
					"origin" : [27,41],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-acc-3-0",
					"origin" : [23,11],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-acc-4-0",
					"origin" : [0,0],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-acc-5-0",
					"origin" : [22,10],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-acc-6-0",
					"origin" : [10,10],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain-acc-6-1",
					"origin" : [10,10],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 1000,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-acc-7-0",
					"origin" : [6,6],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 600,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain-acc-7-1",
					"origin" : [6,6],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 600,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-0-0",
					"origin" : [30,19],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-1-0",
					"origin" : [24,22],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-2-0",
					"origin" : [42,29],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-3-0",
					"origin" : [44,47],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-4-0",
					"origin" : [0,0],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-5-0",
					"origin" : [179,177],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-6-0",
					"origin" : [270,167],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain-artificiality-6-1",
					"origin" : [270,167],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc6.img/darkmountain-artificiality-6-2",
					"origin" : [270,167],
					"z" : 0,
					"delay" : 150,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-7-0",
					"origin" : [176,54],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-8-0",
					"origin" : [224,66],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-9-0",
					"origin" : [280,69],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-10-0",
					"origin" : [93,50],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-11-0",
					"origin" : [109,97],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-12-0",
					"origin" : [132,41],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-13-0",
					"origin" : [169,73],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-14-0",
					"origin" : [15,2],
					"z" : 0,
					"delay" : 400,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain-artificiality-14-1",
					"origin" : [14,1],
					"z" : 0,
					"delay" : 300,
				},
				"2" :  {
					"png_path": "acc6.img/darkmountain-artificiality-14-2",
					"origin" : [14,0],
					"z" : 0,
					"delay" : 300,
				},
				"3" :  {
					"png_path": "acc6.img/darkmountain-artificiality-14-3",
					"origin" : [0,0],
					"delay" : 800,
				},
				"4" :  {
					"png_path": "acc6.img/darkmountain-artificiality-14-2",
					"origin" : [14,0],
					"z" : 0,
					"delay" : 300,
				},
				"5" :  {
					"png_path": "acc6.img/darkmountain-artificiality-14-1",
					"origin" : [14,1],
					"z" : 0,
					"delay" : 300,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-15-0",
					"origin" : [9,2],
					"z" : 0,
					"delay" : 250,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain-artificiality-15-1",
					"origin" : [9,1],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc6.img/darkmountain-artificiality-15-2",
					"origin" : [8,0],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc6.img/darkmountain-artificiality-15-3",
					"origin" : [0,0],
					"delay" : 750,
				},
				"4" :  {
					"png_path": "acc6.img/darkmountain-artificiality-15-2",
					"origin" : [8,0],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc6.img/darkmountain-artificiality-15-1",
					"origin" : [9,1],
					"z" : 0,
					"delay" : 210,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-16-0",
					"origin" : [4,1],
					"z" : 0,
					"delay" : 450,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain-artificiality-16-1",
					"origin" : [4,0],
					"z" : 0,
					"delay" : 300,
				},
				"2" :  {
					"png_path": "acc6.img/darkmountain-artificiality-16-2",
					"origin" : [4,0],
					"z" : 0,
					"delay" : 300,
				},
				"3" :  {
					"png_path": "acc6.img/darkmountain-artificiality-16-3",
					"origin" : [0,0],
					"delay" : 600,
				},
				"4" :  {
					"png_path": "acc6.img/darkmountain-artificiality-16-2",
					"origin" : [4,0],
					"z" : 0,
					"delay" : 300,
				},
				"5" :  {
					"png_path": "acc6.img/darkmountain-artificiality-16-1",
					"origin" : [4,0],
					"z" : 0,
					"delay" : 300,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-17-0",
					"origin" : [52,139],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-18-0",
					"origin" : [60,91],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-artificiality-19-0",
					"origin" : [186,71],
					"z" : 0,
				},
			},
		},
		"cloud" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-cloud-0-0",
					"origin" : [123,44],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-cloud-1-0",
					"origin" : [123,43],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain-cloud-2-0",
					"origin" : [230,47],
					"z" : 0,
				},
			},
		},
	},
	"minar" :  {
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-0-0",
					"origin" : [81,152],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-1-0",
					"origin" : [29,67],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-2-0",
					"origin" : [59,82],
					"z" : 0,
					"delay" : 60,
				},
				"1" :  {
					"png_path": "acc6.img/minar-acc-2-1",
					"origin" : [61,81],
					"z" : 0,
					"delay" : 60,
				},
				"2" :  {
					"png_path": "acc6.img/minar-acc-2-2",
					"origin" : [61,84],
					"z" : 0,
					"delay" : 60,
				},
				"3" :  {
					"png_path": "acc6.img/minar-acc-2-3",
					"origin" : [59,82],
					"z" : 0,
					"delay" : 60,
				},
				"4" :  {
					"png_path": "acc6.img/minar-acc-2-4",
					"origin" : [61,81],
					"z" : 0,
					"delay" : 60,
				},
				"5" :  {
					"png_path": "acc6.img/minar-acc-2-5",
					"origin" : [61,84],
					"z" : 0,
					"delay" : 60,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-3-0",
					"origin" : [29,22],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-4-0",
					"origin" : [71,72],
					"z" : 0,
					"a0" : 40,
					"a1" : 255,
					"delay" : 2000,
				},
				"1" :  {
					"png_path": "acc6.img/minar-acc-4-1",
					"origin" : [71,72],
					"z" : 0,
					"a0" : 255,
					"a1" : 40,
					"delay" : 2000,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-5-0",
					"origin" : [92,210],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-6-0",
					"origin" : [57,136],
					"z" : 0,
					"a0" : 40,
					"a1" : 255,
					"delay" : 2500,
				},
				"1" :  {
					"png_path": "acc6.img/minar-acc-6-1",
					"origin" : [57,136],
					"z" : 0,
					"a0" : 255,
					"a1" : 40,
					"delay" : 2500,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-7-0",
					"origin" : [71,72],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-8-0",
					"origin" : [66,92],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-9-0",
					"origin" : [66,94],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-10-0",
					"origin" : [75,17],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-11-0",
					"origin" : [186,160],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-12-0",
					"origin" : [0,0],
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-13-0",
					"origin" : [91,97],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-14-0",
					"origin" : [67,65],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-15-0",
					"origin" : [442,102],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-16-0",
					"origin" : [428,139],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-17-0",
					"origin" : [341,212],
					"z" : 0,
					"ladder" :  {
						"0" : [226,-32],
						"1" : [166,11],
						"2" : [106,11],
						"3" : [46,-25],
					},
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-18-0",
					"origin" : [136,39],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-19-0",
					"origin" : [153,71],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-20-0",
					"origin" : [141,109],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc6.img/minar-acc-20-1",
					"origin" : [142,109],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc6.img/minar-acc-20-2",
					"origin" : [145,109],
					"z" : 0,
					"delay" : 150,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-21-0",
					"origin" : [41,71],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-22-0",
					"origin" : [62,80],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-23-0",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "acc6.img/minar-acc-23-1",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "acc6.img/minar-acc-23-2",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"3" :  {
					"png_path": "acc6.img/minar-acc-23-1",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"4" :  {
					"png_path": "acc6.img/minar-acc-23-4",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"5" :  {
					"png_path": "acc6.img/minar-acc-23-1",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"6" :  {
					"png_path": "acc6.img/minar-acc-23-6",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 1000,
				},
				"7" :  {
					"png_path": "acc6.img/minar-acc-23-1",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"8" :  {
					"png_path": "acc6.img/minar-acc-23-4",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"9" :  {
					"png_path": "acc6.img/minar-acc-23-1",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"10" :  {
					"png_path": "acc6.img/minar-acc-23-2",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"11" :  {
					"png_path": "acc6.img/minar-acc-23-1",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-24-0",
					"origin" : [62,78],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-25-0",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "acc6.img/minar-acc-25-1",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "acc6.img/minar-acc-25-2",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"3" :  {
					"png_path": "acc6.img/minar-acc-25-1",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"4" :  {
					"png_path": "acc6.img/minar-acc-25-4",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"5" :  {
					"png_path": "acc6.img/minar-acc-25-1",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"6" :  {
					"png_path": "acc6.img/minar-acc-25-6",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 1000,
				},
				"7" :  {
					"png_path": "acc6.img/minar-acc-25-1",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"8" :  {
					"png_path": "acc6.img/minar-acc-25-4",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"9" :  {
					"png_path": "acc6.img/minar-acc-25-1",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"10" :  {
					"png_path": "acc6.img/minar-acc-25-2",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
				"11" :  {
					"png_path": "acc6.img/minar-acc-25-1",
					"origin" : [13,3],
					"z" : 0,
					"delay" : 100,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-26-0",
					"origin" : [57,40],
					"z" : 0,
					"delay" : 130,
				},
				"1" :  {
					"png_path": "acc6.img/minar-acc-26-1",
					"origin" : [57,40],
					"z" : 0,
					"delay" : 130,
				},
				"2" :  {
					"png_path": "acc6.img/minar-acc-26-2",
					"origin" : [57,40],
					"z" : 0,
					"delay" : 130,
				},
				"3" :  {
					"png_path": "acc6.img/minar-acc-26-3",
					"origin" : [57,40],
					"z" : 0,
					"delay" : 130,
				},
				"4" :  {
					"png_path": "acc6.img/minar-acc-26-4",
					"origin" : [57,40],
					"z" : 0,
					"delay" : 130,
				},
				"5" :  {
					"png_path": "acc6.img/minar-acc-26-5",
					"origin" : [57,40],
					"z" : 0,
					"delay" : 130,
				},
				"6" :  {
					"png_path": "acc6.img/minar-acc-26-6",
					"origin" : [57,40],
					"z" : 0,
					"delay" : 130,
				},
				"7" :  {
					"png_path": "acc6.img/minar-acc-26-7",
					"origin" : [57,40],
					"z" : 0,
					"delay" : 500,
				},
				"8" :  {
					"png_path": "acc6.img/minar-acc-26-8",
					"origin" : [57,40],
					"z" : 0,
					"delay" : 500,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-27-0",
					"origin" : [55,40],
					"z" : 0,
					"delay" : 130,
				},
				"1" :  {
					"png_path": "acc6.img/minar-acc-27-1",
					"origin" : [55,40],
					"z" : 0,
					"delay" : 130,
				},
				"2" :  {
					"png_path": "acc6.img/minar-acc-27-2",
					"origin" : [55,40],
					"z" : 0,
					"delay" : 130,
				},
				"3" :  {
					"png_path": "acc6.img/minar-acc-27-3",
					"origin" : [55,40],
					"z" : 0,
					"delay" : 130,
				},
				"4" :  {
					"png_path": "acc6.img/minar-acc-27-4",
					"origin" : [55,40],
					"z" : 0,
					"delay" : 130,
				},
				"5" :  {
					"png_path": "acc6.img/minar-acc-27-5",
					"origin" : [55,40],
					"z" : 0,
					"delay" : 130,
				},
				"6" :  {
					"png_path": "acc6.img/minar-acc-27-6",
					"origin" : [55,40],
					"z" : 0,
					"delay" : 130,
				},
				"7" :  {
					"png_path": "acc6.img/minar-acc-27-7",
					"origin" : [55,40],
					"z" : 0,
					"delay" : 500,
				},
				"8" :  {
					"png_path": "acc6.img/minar-acc-27-8",
					"origin" : [55,40],
					"z" : 0,
					"delay" : 500,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-28-0",
					"origin" : [50,44],
					"z" : 0,
					"delay" : "100",
				},
				"1" :  {
					"png_path": "acc6.img/minar-acc-28-1",
					"origin" : [50,44],
					"z" : 0,
					"delay" : "100",
				},
				"2" :  {
					"png_path": "acc6.img/minar-acc-28-2",
					"origin" : [50,44],
					"z" : 0,
					"delay" : "100",
				},
				"3" :  {
					"png_path": "acc6.img/minar-acc-28-3",
					"origin" : [50,44],
					"z" : 0,
					"delay" : "100",
				},
				"4" :  {
					"png_path": "acc6.img/minar-acc-28-4",
					"origin" : [50,44],
					"z" : 0,
					"delay" : "100",
				},
				"5" :  {
					"png_path": "acc6.img/minar-acc-28-5",
					"origin" : [50,44],
					"z" : 0,
					"delay" : "100",
				},
				"6" :  {
					"png_path": "acc6.img/minar-acc-28-6",
					"origin" : [50,44],
					"z" : 0,
					"delay" : "100",
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-29-0",
					"origin" : [50,44],
					"z" : 0,
					"delay" : 7000,
				},
				"1" :  {
					"png_path": "acc6.img/minar-acc-29-1",
					"origin" : [50,44],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "acc6.img/minar-acc-29-2",
					"origin" : [49,44],
					"z" : 0,
					"delay" : 100,
				},
				"3" :  {
					"png_path": "acc6.img/minar-acc-29-3",
					"origin" : [49,44],
					"z" : 0,
					"delay" : 100,
				},
				"4" :  {
					"png_path": "acc6.img/minar-acc-29-4",
					"origin" : [49,44],
					"z" : 0,
					"delay" : 100,
				},
				"5" :  {
					"png_path": "acc6.img/minar-acc-29-5",
					"origin" : [49,44],
					"z" : 0,
					"delay" : 900,
				},
				"6" :  {
					"png_path": "acc6.img/minar-acc-29-6",
					"origin" : [49,44],
					"z" : 0,
					"delay" : 100,
				},
				"7" :  {
					"png_path": "acc6.img/minar-acc-29-7",
					"origin" : [49,44],
					"z" : 0,
					"delay" : 100,
				},
				"8" :  {
					"png_path": "acc6.img/minar-acc-29-8",
					"origin" : [49,44],
					"z" : 0,
					"delay" : 100,
				},
				"9" :  {
					"png_path": "acc6.img/minar-acc-29-9",
					"origin" : [50,44],
					"z" : 0,
					"delay" : 100,
				},
				"10" :  {
					"png_path": "acc6.img/minar-acc-29-10",
					"origin" : [50,44],
					"z" : 0,
					"delay" : 100,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-30-0",
					"origin" : [126,67],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-31-0",
					"origin" : [121,67],
					"z" : 0,
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-32-0",
					"origin" : [56,40],
					"z" : 0,
				},
			},
			"33" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-33-0",
					"origin" : [116,58],
					"z" : 0,
				},
			},
			"34" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-34-0",
					"origin" : [95,48],
					"z" : 0,
				},
			},
			"35" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-35-0",
					"origin" : [0,0],
				},
			},
			"36" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-36-0",
					"origin" : [42,65],
					"z" : 0,
				},
			},
			"37" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-37-0",
					"origin" : [48,75],
					"z" : 0,
				},
			},
			"38" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-38-0",
					"origin" : [0,0],
				},
			},
			"39" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-39-0",
					"origin" : [313,56],
					"z" : 0,
				},
			},
			"40" :  {
				"0" :  {
					"png_path": "acc6.img/minar-acc-40-0",
					"origin" : [186,195],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "acc6.img/minar-acc-40-1",
					"origin" : [186,195],
					"z" : 0,
					"delay" : 200,
				},
				"2" :  {
					"png_path": "acc6.img/minar-acc-40-2",
					"origin" : [186,195],
					"z" : 0,
					"delay" : 250,
				},
				"3" :  {
					"png_path": "acc6.img/minar-acc-40-3",
					"origin" : [186,195],
					"z" : 0,
					"delay" : 250,
				},
			},
		},
		"nature1" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-0-0",
					"origin" : [415,144],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc6.img/minar-nature1-0-1",
					"origin" : [415,144],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc6.img/minar-nature1-0-2",
					"origin" : [415,144],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "acc6.img/minar-nature1-0-3",
					"origin" : [415,144],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "acc6.img/minar-nature1-0-4",
					"origin" : [415,144],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "acc6.img/minar-nature1-0-5",
					"origin" : [415,144],
					"z" : 0,
					"delay" : 150,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-1-0",
					"origin" : [119,86],
					"z" : 0,
					"delay" : 110,
				},
				"1" :  {
					"png_path": "acc6.img/minar-nature1-1-1",
					"origin" : [119,84],
					"z" : 0,
					"delay" : 110,
				},
				"2" :  {
					"png_path": "acc6.img/minar-nature1-1-2",
					"origin" : [119,83],
					"z" : 0,
					"delay" : 110,
				},
				"3" :  {
					"png_path": "acc6.img/minar-nature1-1-3",
					"origin" : [119,86],
					"z" : 0,
					"delay" : 110,
				},
				"4" :  {
					"png_path": "acc6.img/minar-nature1-1-4",
					"origin" : [119,84],
					"z" : 0,
					"delay" : 110,
				},
				"5" :  {
					"png_path": "acc6.img/minar-nature1-1-5",
					"origin" : [119,83],
					"z" : 0,
					"delay" : 110,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-2-0",
					"origin" : [88,122],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-3-0",
					"origin" : [79,92],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-4-0",
					"origin" : [0,0],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-5-0",
					"origin" : [19,19],
					"z" : 0,
					"a0" : 20,
					"a1" : 200,
					"delay" : 1800,
				},
				"1" :  {
					"png_path": "acc6.img/minar-nature1-5-1",
					"origin" : [19,19],
					"z" : 0,
					"a0" : 200,
					"a1" : 20,
					"delay" : 1800,
				},
			},
			"6" :  {
				"1" :  {
					"png_path": "acc6.img/minar-nature1-5-0",
					"origin" : [19,19],
					"z" : 0,
					"a0" : 20,
					"a1" : 200,
					"delay" : 1800,
				},
				"0" :  {
					"png_path": "acc6.img/minar-nature1-6-0",
					"origin" : [0,0],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-7-0",
					"origin" : [144,85],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-9-0",
					"origin" : [84,65],
					"z" : 0,
					"delay" : 180,
				},
				"1" :  {
					"png_path": "acc6.img/minar-nature1-9-1",
					"origin" : [84,65],
					"z" : 0,
					"delay" : 180,
				},
				"2" :  {
					"png_path": "acc6.img/minar-nature1-9-2",
					"origin" : [84,65],
					"z" : 0,
					"delay" : 180,
				},
				"3" :  {
					"png_path": "acc6.img/minar-nature1-9-3",
					"origin" : [84,65],
					"z" : 0,
					"delay" : 180,
				},
				"4" :  {
					"png_path": "acc6.img/minar-nature1-9-4",
					"origin" : [84,65],
					"z" : 0,
					"delay" : 180,
				},
				"5" :  {
					"png_path": "acc6.img/minar-nature1-9-5",
					"origin" : [84,65],
					"z" : 0,
					"delay" : 180,
				},
				"6" :  {
					"png_path": "acc6.img/minar-nature1-9-6",
					"origin" : [84,65],
					"z" : 0,
					"delay" : 180,
				},
				"7" :  {
					"png_path": "acc6.img/minar-nature1-9-7",
					"origin" : [84,65],
					"z" : 0,
					"delay" : 180,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-10-0",
					"origin" : [121,36],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-11-0",
					"origin" : [229,287],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-12-0",
					"origin" : [89,204],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-13-0",
					"origin" : [136,170],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-14-0",
					"origin" : [40,27],
					"z" : 0,
					"delay" : 15000,
				},
				"1" :  {
					"png_path": "acc6.img/minar-nature1-14-1",
					"origin" : [40,27],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "acc6.img/minar-nature1-14-2",
					"origin" : [40,27],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "acc6.img/minar-nature1-14-3",
					"origin" : [40,27],
					"z" : 0,
					"delay" : 120,
				},
				"4" :  {
					"png_path": "acc6.img/minar-nature1-14-1",
					"origin" : [40,27],
					"z" : 0,
					"delay" : 120,
				},
				"5" :  {
					"png_path": "acc6.img/minar-nature1-14-2",
					"origin" : [40,27],
					"z" : 0,
					"delay" : 120,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-15-0",
					"origin" : [139,119],
					"z" : 0,
					"a0" : 40,
					"a1" : 255,
					"delay" : 2500,
				},
				"1" :  {
					"png_path": "acc6.img/minar-nature1-15-1",
					"origin" : [139,119],
					"z" : 0,
					"a0" : 255,
					"a1" : 40,
					"delay" : 2500,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-16-0",
					"origin" : [91,113],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-17-0",
					"origin" : [106,152],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-18-0",
					"origin" : [71,57],
					"z" : 0,
					"a0" : 40,
					"a1" : 255,
					"delay" : 2500,
				},
				"1" :  {
					"png_path": "acc6.img/minar-nature1-18-1",
					"origin" : [71,57],
					"z" : 0,
					"a0" : 255,
					"a1" : 40,
					"delay" : 2500,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-19-0",
					"origin" : [62,94],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-20-0",
					"origin" : [112,117],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-21-0",
					"origin" : [42,97],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-22-0",
					"origin" : [109,234],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-23-0",
					"origin" : [98,127],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-24-0",
					"origin" : [61,105],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-25-0",
					"origin" : [114,154],
					"z" : 0,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-26-0",
					"origin" : [68,86],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-27-0",
					"origin" : [144,152],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-28-0",
					"origin" : [61,92],
					"z" : 0,
					"delay" : 120,
				},
				"1" :  {
					"png_path": "acc6.img/minar-nature1-28-1",
					"origin" : [66,97],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "acc6.img/minar-nature1-28-2",
					"origin" : [68,99],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "acc6.img/minar-nature1-28-3",
					"origin" : [70,101],
					"z" : 0,
					"delay" : 120,
				},
				"4" :  {
					"png_path": "acc6.img/minar-nature1-28-4",
					"origin" : [71,102],
					"z" : 0,
					"delay" : 120,
				},
				"5" :  {
					"png_path": "acc6.img/minar-nature1-28-5",
					"origin" : [70,101],
					"z" : 0,
					"delay" : 120,
				},
				"6" :  {
					"png_path": "acc6.img/minar-nature1-28-6",
					"origin" : [68,99],
					"z" : 0,
					"delay" : 120,
				},
				"7" :  {
					"png_path": "acc6.img/minar-nature1-28-7",
					"origin" : [66,97],
					"z" : 0,
					"delay" : 120,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-29-0",
					"origin" : [80,126],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-30-0",
					"origin" : [127,135],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature1-8-0",
					"origin" : [0,0],
				},
			},
		},
		"nature2" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-0-0",
					"origin" : [56,35],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-1-0",
					"origin" : [49,31],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-2-0",
					"origin" : [188,70],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-3-0",
					"origin" : [150,86],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-4-0",
					"origin" : [144,145],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-5-0",
					"origin" : [121,80],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-6-0",
					"origin" : [79,48],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-7-0",
					"origin" : [69,50],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-8-0",
					"origin" : [65,53],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-9-0",
					"origin" : [49,30],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-10-0",
					"origin" : [39,55],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-11-0",
					"origin" : [143,62],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-12-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-13-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-14-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-15-0",
					"origin" : [0,0],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-16-0",
					"origin" : [30,18],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-17-0",
					"origin" : [48,18],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-18-0",
					"origin" : [34,31],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-19-0",
					"origin" : [40,32],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-20-0",
					"origin" : [54,66],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-21-0",
					"origin" : [46,73],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-22-0",
					"origin" : [72,22],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-23-0",
					"origin" : [84,31],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-24-0",
					"origin" : [191,58],
					"z" : 0,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-25-0",
					"origin" : [80,68],
					"z" : 0,
					"delay" : 1500,
				},
				"1" :  {
					"png_path": "acc6.img/minar-nature2-25-1",
					"origin" : [80,68],
					"z" : 0,
					"delay" : 80,
				},
				"2" :  {
					"png_path": "acc6.img/minar-nature2-25-2",
					"origin" : [80,68],
					"z" : 0,
					"delay" : 80,
				},
				"3" :  {
					"png_path": "acc6.img/minar-nature2-25-3",
					"origin" : [80,68],
					"z" : 0,
					"delay" : 80,
				},
				"4" :  {
					"png_path": "acc6.img/minar-nature2-25-4",
					"origin" : [80,68],
					"z" : 0,
					"delay" : 80,
				},
				"5" :  {
					"png_path": "acc6.img/minar-nature2-25-5",
					"origin" : [80,68],
					"z" : 0,
					"delay" : 80,
				},
				"6" :  {
					"png_path": "acc6.img/minar-nature2-25-6",
					"origin" : [80,68],
					"z" : 0,
					"delay" : 80,
				},
				"7" :  {
					"png_path": "acc6.img/minar-nature2-25-7",
					"origin" : [80,68],
					"z" : 0,
					"delay" : 80,
				},
				"8" :  {
					"png_path": "acc6.img/minar-nature2-25-8",
					"origin" : [80,68],
					"z" : 0,
					"delay" : 80,
				},
				"9" :  {
					"png_path": "acc6.img/minar-nature2-25-9",
					"origin" : [80,68],
					"z" : 0,
					"delay" : 80,
				},
				"10" :  {
					"png_path": "acc6.img/minar-nature2-25-10",
					"origin" : [80,68],
					"z" : 0,
					"delay" : 80,
				},
				"11" :  {
					"png_path": "acc6.img/minar-nature2-25-11",
					"origin" : [85,68],
					"z" : 0,
					"delay" : 80,
				},
				"12" :  {
					"png_path": "acc6.img/minar-nature2-25-12",
					"origin" : [80,68],
					"z" : 0,
					"delay" : 80,
				},
				"13" :  {
					"png_path": "acc6.img/minar-nature2-25-13",
					"origin" : [87,68],
					"z" : 0,
					"delay" : 80,
				},
			},
			"26" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-26-0",
					"origin" : [84,45],
					"z" : 0,
				},
			},
			"27" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-27-0",
					"origin" : [66,86],
					"z" : 0,
				},
			},
			"28" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-28-0",
					"origin" : [68,65],
					"z" : 0,
					"a0" : 40,
					"a1" : 255,
					"delay" : 2500,
				},
				"1" :  {
					"png_path": "acc6.img/minar-nature2-28-1",
					"origin" : [68,65],
					"z" : 0,
					"a0" : 255,
					"a1" : 40,
					"delay" : 2500,
				},
			},
			"29" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-29-0",
					"origin" : [83,57],
					"z" : 0,
				},
			},
			"30" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-30-0",
					"origin" : [34,36],
					"z" : 0,
				},
			},
			"31" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-31-0",
					"origin" : [34,31],
					"z" : 0,
				},
			},
			"32" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-32-0",
					"origin" : [63,63],
					"z" : 0,
				},
			},
			"33" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-33-0",
					"origin" : [44,42],
					"z" : 0,
				},
			},
			"34" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-34-0",
					"origin" : [33,21],
					"z" : 0,
				},
			},
			"35" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-35-0",
					"origin" : [62,29],
					"z" : 0,
				},
			},
			"36" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-36-0",
					"origin" : [56,18],
					"z" : 0,
				},
			},
			"37" :  {
				"0" :  {
					"png_path": "acc6.img/minar-nature2-37-0",
					"origin" : [208,31],
					"z" : 0,
				},
			},
		},
		"ground" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/minar-ground-0-0",
					"origin" : [293,111],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/minar-ground-1-0",
					"origin" : [0,0],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/minar-ground-2-0",
					"origin" : [81,63],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/minar-ground-3-0",
					"origin" : [113,71],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/minar-ground-4-0",
					"origin" : [133,120],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/minar-ground-5-0",
					"origin" : [119,74],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/minar-ground-6-0",
					"origin" : [132,70],
					"z" : 0,
				},
			},
		},
		"station" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-0-0",
					"origin" : [342,98],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-1-0",
					"origin" : [213,66],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-2-0",
					"origin" : [262,122],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-3-0",
					"origin" : [315,101],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-4-0",
					"origin" : [303,100],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-5-0",
					"origin" : [125,111],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-6-0",
					"origin" : [107,43],
					"z" : 0,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "acc6.img/minar-station-6-1",
					"origin" : [107,43],
					"z" : 0,
					"delay" : 100,
				},
				"2" :  {
					"png_path": "acc6.img/minar-station-6-2",
					"origin" : [107,43],
					"z" : 0,
					"delay" : 100,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-7-0",
					"origin" : [107,41],
					"z" : 0,
					"delay" : 1500,
				},
				"1" :  {
					"png_path": "acc6.img/minar-station-7-1",
					"origin" : [107,41],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "acc6.img/minar-station-7-2",
					"origin" : [107,41],
					"z" : 0,
					"delay" : 120,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-8-0",
					"origin" : [116,41],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-9-0",
					"origin" : [127,139],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-10-0",
					"origin" : [0,0],
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-11-0",
					"origin" : [75,43],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-12-0",
					"origin" : [0,0],
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-13-0",
					"origin" : [95,38],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-14-0",
					"origin" : [0,0],
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-15-0",
					"origin" : [0,0],
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-16-0",
					"origin" : [141,91],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-17-0",
					"origin" : [77,91],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/minar-station-18-0",
					"origin" : [83,94],
					"z" : 0,
				},
			},
		},
		"market" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/minar-market-0-0",
					"origin" : [238,136],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/minar-market-1-0",
					"origin" : [54,54],
					"z" : 0,
					"a0" : 20,
					"a1" : 255,
					"delay" : 2000,
				},
				"1" :  {
					"png_path": "acc6.img/minar-market-1-1",
					"origin" : [54,54],
					"z" : 0,
					"a0" : 255,
					"a1" : 20,
					"delay" : 2000,
				},
			},
		},
		"npc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/minar-npc-0-0",
					"origin" : [16,74],
					"z" : 0,
					"rope" :  {
						"0" : [12,79],
						"1" : [-12,79],
					},
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/minar-npc-1-0",
					"origin" : [37,23],
					"z" : 0,
				},
			},
		},
		"stone" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/minar-stone-0-0",
					"origin" : [152,141],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/minar-stone-1-0",
					"origin" : [147,113],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/minar-stone-2-0",
					"origin" : [125,61],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/minar-stone-3-0",
					"origin" : [95,78],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/minar-stone-4-0",
					"origin" : [100,58],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/minar-stone-5-0",
					"origin" : [74,37],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/minar-stone-6-0",
					"origin" : [35,30],
					"z" : 0,
				},
			},
		},
		"gate" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/minar-gate-0-0",
					"origin" : [186,161],
					"z" : 0,
					"delay" : 130,
				},
				"1" :  {
					"png_path": "acc6.img/minar-gate-0-1",
					"origin" : [186,161],
					"z" : 0,
					"delay" : 130,
				},
				"2" :  {
					"png_path": "acc6.img/minar-gate-0-2",
					"origin" : [186,161],
					"z" : 0,
					"delay" : 130,
				},
				"3" :  {
					"png_path": "acc6.img/minar-gate-0-3",
					"origin" : [186,161],
					"z" : 0,
					"delay" : 130,
				},
				"4" :  {
					"png_path": "acc6.img/minar-gate-0-4",
					"origin" : [186,161],
					"z" : 0,
					"delay" : 130,
				},
				"5" :  {
					"png_path": "acc6.img/minar-gate-0-5",
					"origin" : [186,161],
					"z" : 0,
					"delay" : 130,
				},
				"6" :  {
					"png_path": "acc6.img/minar-gate-0-6",
					"origin" : [186,161],
					"z" : 0,
					"delay" : 130,
				},
				"7" :  {
					"png_path": "acc6.img/minar-gate-0-7",
					"origin" : [186,161],
					"z" : 0,
					"delay" : 130,
				},
				"8" :  {
					"png_path": "acc6.img/minar-gate-0-8",
					"origin" : [186,161],
					"z" : 0,
					"delay" : 130,
				},
				"9" :  {
					"png_path": "acc6.img/minar-gate-0-9",
					"origin" : [186,161],
					"z" : 0,
					"delay" : 130,
				},
				"10" :  {
					"png_path": "acc6.img/minar-gate-0-10",
					"origin" : [186,161],
					"z" : 0,
					"delay" : 130,
				},
				"11" :  {
					"png_path": "acc6.img/minar-gate-0-11",
					"origin" : [186,161],
					"z" : 0,
					"delay" : 130,
				},
			},
		},
		"quest" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/minar-quest-0-0",
					"origin" : [253,173],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/minar-quest-1-0",
					"origin" : [315,94],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/minar-quest-2-0",
					"origin" : [45,38],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/minar-quest-3-0",
					"origin" : [600,50],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/minar-quest-4-0",
					"origin" : [182,120],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/minar-quest-5-0",
					"origin" : [121,49],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/minar-quest-6-0",
					"origin" : [137,98],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/minar-quest-7-0",
					"origin" : [124,15],
					"z" : 0,
					"delay" : 3000,
					"a0" : 255,
					"a1" : 120,
				},
				"1" :  {
					"png_path": "acc6.img/minar-quest-7-1",
					"origin" : [124,15],
					"z" : 0,
					"delay" : 3000,
					"a0" : 120,
					"a1" : 255,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/minar-quest-8-0",
					"origin" : [154,146],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/minar-quest-9-0",
					"origin" : [146,151],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/minar-quest-10-0",
					"origin" : [184,177],
					"z" : 0,
				},
			},
		},
	},
	"darkmountain3" :  {
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-0-0",
					"origin" : [145,160],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-1-0",
					"origin" : [94,128],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-2-0",
					"origin" : [121,138],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-3-0",
					"origin" : [76,110],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-4-0",
					"origin" : [95,130],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-5-0",
					"origin" : [80,59],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-6-0",
					"origin" : [60,45],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-7-0",
					"origin" : [70,39],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-8-0",
					"origin" : [39,24],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-9-0",
					"origin" : [85,31],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-10-0",
					"origin" : [74,39],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-11-0",
					"origin" : [35,13],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-12-0",
					"origin" : [40,26],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-13-0",
					"origin" : [25,19],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-14-0",
					"origin" : [39,24],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-15-0",
					"origin" : [90,92],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-16-0",
					"origin" : [126,118],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-17-0",
					"origin" : [81,66],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-18-0",
					"origin" : [90,92],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-19-0",
					"origin" : [119,45],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-20-0",
					"origin" : [36,73],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-21-0",
					"origin" : [60,44],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-22-0",
					"origin" : [81,66],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-nature-23-0",
					"origin" : [196,217],
					"z" : 0,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-acc-0-0",
					"origin" : [24,22],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-acc-1-0",
					"origin" : [19,40],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-acc-2-0",
					"origin" : [27,41],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-acc-3-0",
					"origin" : [23,11],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-acc-4-0",
					"origin" : [0,0],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-acc-5-0",
					"origin" : [22,10],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-acc-6-0",
					"origin" : [10,10],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain3-acc-6-1",
					"origin" : [10,10],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 1000,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-acc-7-0",
					"origin" : [6,6],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 600,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain3-acc-7-1",
					"origin" : [6,6],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 600,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-0-0",
					"origin" : [30,19],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-1-0",
					"origin" : [24,22],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-2-0",
					"origin" : [42,29],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-3-0",
					"origin" : [44,47],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-4-0",
					"origin" : [0,0],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-5-0",
					"origin" : [179,177],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-6-0",
					"origin" : [270,167],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-6-1",
					"origin" : [270,167],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-6-2",
					"origin" : [270,167],
					"z" : 0,
					"delay" : 150,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-7-0",
					"origin" : [176,54],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-8-0",
					"origin" : [224,66],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-9-0",
					"origin" : [280,69],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-10-0",
					"origin" : [93,50],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-11-0",
					"origin" : [109,97],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-12-0",
					"origin" : [132,41],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-13-0",
					"origin" : [169,73],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-14-0",
					"origin" : [15,2],
					"z" : 0,
					"delay" : 400,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-14-1",
					"origin" : [14,1],
					"z" : 0,
					"delay" : 300,
				},
				"2" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-14-2",
					"origin" : [14,0],
					"z" : 0,
					"delay" : 300,
				},
				"3" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-14-3",
					"origin" : [0,0],
					"delay" : 800,
				},
				"4" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-14-2",
					"origin" : [14,0],
					"z" : 0,
					"delay" : 300,
				},
				"5" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-14-1",
					"origin" : [14,1],
					"z" : 0,
					"delay" : 300,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-15-0",
					"origin" : [9,2],
					"z" : 0,
					"delay" : 250,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-15-1",
					"origin" : [9,1],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-15-2",
					"origin" : [8,0],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-15-3",
					"origin" : [0,0],
					"delay" : 750,
				},
				"4" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-15-2",
					"origin" : [8,0],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-15-1",
					"origin" : [9,1],
					"z" : 0,
					"delay" : 210,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-16-0",
					"origin" : [4,1],
					"z" : 0,
					"delay" : 450,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-16-1",
					"origin" : [4,0],
					"z" : 0,
					"delay" : 300,
				},
				"2" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-16-2",
					"origin" : [4,0],
					"z" : 0,
					"delay" : 300,
				},
				"3" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-16-3",
					"origin" : [0,0],
					"delay" : 600,
				},
				"4" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-16-2",
					"origin" : [4,0],
					"z" : 0,
					"delay" : 300,
				},
				"5" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-16-1",
					"origin" : [4,0],
					"z" : 0,
					"delay" : 300,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-17-0",
					"origin" : [52,139],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-18-0",
					"origin" : [60,91],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-artificiality-19-0",
					"origin" : [186,71],
					"z" : 0,
				},
			},
		},
		"cloud" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-cloud-0-0",
					"origin" : [123,44],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-cloud-1-0",
					"origin" : [123,43],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain3-cloud-2-0",
					"origin" : [230,47],
					"z" : 0,
				},
			},
		},
	},
	"darkmountain2" :  {
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-0-0",
					"origin" : [145,160],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-1-0",
					"origin" : [94,128],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-2-0",
					"origin" : [121,138],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-3-0",
					"origin" : [76,110],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-4-0",
					"origin" : [95,130],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-5-0",
					"origin" : [80,59],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-6-0",
					"origin" : [60,45],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-7-0",
					"origin" : [70,39],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-8-0",
					"origin" : [39,24],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-9-0",
					"origin" : [85,31],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-10-0",
					"origin" : [74,39],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-11-0",
					"origin" : [35,13],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-12-0",
					"origin" : [40,26],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-13-0",
					"origin" : [25,19],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-14-0",
					"origin" : [39,24],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-15-0",
					"origin" : [90,92],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-16-0",
					"origin" : [126,118],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-17-0",
					"origin" : [81,66],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-18-0",
					"origin" : [90,92],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-19-0",
					"origin" : [119,45],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-20-0",
					"origin" : [36,73],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-21-0",
					"origin" : [60,44],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-22-0",
					"origin" : [81,66],
					"z" : 0,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-nature-23-0",
					"origin" : [196,217],
					"z" : 0,
				},
			},
		},
		"acc" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-acc-0-0",
					"origin" : [24,22],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-acc-1-0",
					"origin" : [19,40],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-acc-2-0",
					"origin" : [27,41],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-acc-3-0",
					"origin" : [23,11],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-acc-4-0",
					"origin" : [0,0],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-acc-5-0",
					"origin" : [22,10],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-acc-6-0",
					"origin" : [10,10],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 1000,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain2-acc-6-1",
					"origin" : [10,10],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 1000,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-acc-7-0",
					"origin" : [6,6],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 600,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain2-acc-7-1",
					"origin" : [6,6],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 600,
				},
			},
		},
		"artificiality" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-0-0",
					"origin" : [30,19],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-1-0",
					"origin" : [24,22],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-2-0",
					"origin" : [42,29],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-3-0",
					"origin" : [44,47],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-4-0",
					"origin" : [0,0],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-5-0",
					"origin" : [179,177],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-6-0",
					"origin" : [270,167],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-6-1",
					"origin" : [270,167],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-6-2",
					"origin" : [270,167],
					"z" : 0,
					"delay" : 150,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-7-0",
					"origin" : [176,54],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-8-0",
					"origin" : [224,66],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-9-0",
					"origin" : [280,69],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-10-0",
					"origin" : [93,50],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-11-0",
					"origin" : [109,97],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-12-0",
					"origin" : [132,41],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-13-0",
					"origin" : [169,73],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-14-0",
					"origin" : [15,2],
					"z" : 0,
					"delay" : 400,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-14-1",
					"origin" : [14,1],
					"z" : 0,
					"delay" : 300,
				},
				"2" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-14-2",
					"origin" : [14,0],
					"z" : 0,
					"delay" : 300,
				},
				"3" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-14-3",
					"origin" : [0,0],
					"delay" : 800,
				},
				"4" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-14-2",
					"origin" : [14,0],
					"z" : 0,
					"delay" : 300,
				},
				"5" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-14-1",
					"origin" : [14,1],
					"z" : 0,
					"delay" : 300,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-15-0",
					"origin" : [9,2],
					"z" : 0,
					"delay" : 250,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-15-1",
					"origin" : [9,1],
					"z" : 0,
					"delay" : 210,
				},
				"2" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-15-2",
					"origin" : [8,0],
					"z" : 0,
					"delay" : 210,
				},
				"3" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-15-3",
					"origin" : [0,0],
					"delay" : 750,
				},
				"4" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-15-2",
					"origin" : [8,0],
					"z" : 0,
					"delay" : 210,
				},
				"5" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-15-1",
					"origin" : [9,1],
					"z" : 0,
					"delay" : 210,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-16-0",
					"origin" : [4,1],
					"z" : 0,
					"delay" : 450,
				},
				"1" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-16-1",
					"origin" : [4,0],
					"z" : 0,
					"delay" : 300,
				},
				"2" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-16-2",
					"origin" : [4,0],
					"z" : 0,
					"delay" : 300,
				},
				"3" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-16-3",
					"origin" : [0,0],
					"delay" : 600,
				},
				"4" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-16-2",
					"origin" : [4,0],
					"z" : 0,
					"delay" : 300,
				},
				"5" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-16-1",
					"origin" : [4,0],
					"z" : 0,
					"delay" : 300,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-17-0",
					"origin" : [52,139],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-18-0",
					"origin" : [60,91],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-artificiality-19-0",
					"origin" : [192,71],
					"z" : 0,
				},
			},
		},
		"cloud" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-cloud-0-0",
					"origin" : [123,44],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-cloud-1-0",
					"origin" : [123,43],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/darkmountain2-cloud-2-0",
					"origin" : [230,47],
					"z" : 0,
				},
			},
		},
	},
	"cokeTown" :  {
		"acc1" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-0-0",
					"origin" : [172,119],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-1-0",
					"origin" : [107,162],
					"z" : 0,
					"delay" : 120,
				},
				"1" :  {
					"png_path": "acc6.img/cokeTown-acc1-1-1",
					"origin" : [107,162],
					"z" : 0,
					"delay" : 120,
				},
				"2" :  {
					"png_path": "acc6.img/cokeTown-acc1-1-2",
					"origin" : [107,162],
					"z" : 0,
					"delay" : 120,
				},
				"3" :  {
					"png_path": "acc6.img/cokeTown-acc1-1-3",
					"origin" : [107,162],
					"z" : 0,
					"delay" : 120,
				},
				"4" :  {
					"png_path": "acc6.img/cokeTown-acc1-1-4",
					"origin" : [107,162],
					"z" : 0,
					"delay" : 120,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-2-0",
					"origin" : [140,158],
					"z" : 0,
					"delay" : 110,
				},
				"1" :  {
					"png_path": "acc6.img/cokeTown-acc1-2-1",
					"origin" : [140,158],
					"z" : 0,
					"delay" : 110,
				},
				"2" :  {
					"png_path": "acc6.img/cokeTown-acc1-2-2",
					"origin" : [140,158],
					"z" : 0,
					"delay" : 110,
				},
				"3" :  {
					"png_path": "acc6.img/cokeTown-acc1-2-3",
					"origin" : [140,158],
					"z" : 0,
					"delay" : 110,
				},
				"4" :  {
					"png_path": "acc6.img/cokeTown-acc1-2-4",
					"origin" : [140,158],
					"z" : 0,
					"delay" : 110,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-3-0",
					"origin" : [167,57],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-4-0",
					"origin" : [0,0],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-5-0",
					"origin" : [129,131],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-6-0",
					"origin" : [89,55],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-7-0",
					"origin" : [92,61],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 2200,
				},
				"1" :  {
					"png_path": "acc6.img/cokeTown-acc1-7-1",
					"origin" : [92,61],
					"z" : 0,
					"a0" : 255,
					"a1" : 255,
					"delay" : 2500,
				},
				"2" :  {
					"png_path": "acc6.img/cokeTown-acc1-7-2",
					"origin" : [92,61],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 2200,
				},
				"3" :  {
					"png_path": "acc6.img/cokeTown-acc1-7-3",
					"origin" : [92,61],
					"z" : 0,
					"a0" : 0,
					"a1" : 0,
					"delay" : 2500,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-8-0",
					"origin" : [92,61],
					"z" : 0,
					"a0" : 255,
					"a1" : 0,
					"delay" : 2200,
				},
				"1" :  {
					"png_path": "acc6.img/cokeTown-acc1-8-1",
					"origin" : [92,61],
					"z" : 0,
					"a0" : 0,
					"a1" : 0,
					"delay" : 2500,
				},
				"2" :  {
					"png_path": "acc6.img/cokeTown-acc1-8-2",
					"origin" : [92,61],
					"z" : 0,
					"a0" : 0,
					"a1" : 255,
					"delay" : 2200,
				},
				"3" :  {
					"png_path": "acc6.img/cokeTown-acc1-8-3",
					"origin" : [92,61],
					"z" : 0,
					"a0" : 255,
					"a1" : 255,
					"delay" : 2500,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-9-0",
					"origin" : [159,74],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-10-0",
					"origin" : [141,124],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-11-0",
					"origin" : [126,81],
					"z" : 0,
				},
				"1" :  {
					"png_path": "acc6.img/cokeTown-acc1-11-1",
					"origin" : [126,81],
					"z" : 0,
				},
				"2" :  {
					"png_path": "acc6.img/cokeTown-acc1-11-2",
					"origin" : [126,80],
					"z" : 0,
				},
				"3" :  {
					"png_path": "acc6.img/cokeTown-acc1-11-3",
					"origin" : [126,80],
					"z" : 0,
				},
				"4" :  {
					"png_path": "acc6.img/cokeTown-acc1-11-4",
					"origin" : [126,77],
					"z" : 0,
				},
				"5" :  {
					"png_path": "acc6.img/cokeTown-acc1-11-5",
					"origin" : [125,75],
					"z" : 0,
				},
				"6" :  {
					"png_path": "acc6.img/cokeTown-acc1-11-6",
					"origin" : [123,75],
					"z" : 0,
				},
				"7" :  {
					"png_path": "acc6.img/cokeTown-acc1-11-7",
					"origin" : [123,75],
					"z" : 0,
				},
				"8" :  {
					"png_path": "acc6.img/cokeTown-acc1-11-8",
					"origin" : [121,80],
					"z" : 0,
				},
				"9" :  {
					"png_path": "acc6.img/cokeTown-acc1-11-9",
					"origin" : [123,80],
					"z" : 0,
				},
				"10" :  {
					"png_path": "acc6.img/cokeTown-acc1-11-10",
					"origin" : [123,80],
					"z" : 0,
				},
				"11" :  {
					"png_path": "acc6.img/cokeTown-acc1-11-11",
					"origin" : [125,81],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-12-0",
					"origin" : [62,132],
					"z" : 0,
					"rope" : [-4,29],
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-13-0",
					"origin" : [182,141],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-14-0",
					"origin" : [83,85],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-15-0",
					"origin" : [264,168],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-16-0",
					"origin" : [131,136],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-acc1-17-0",
					"origin" : [196,155],
					"z" : 0,
				},
			},
		},
		"foot" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-0-0",
					"origin" : [188,94],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-1-0",
					"origin" : [167,93],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-2-0",
					"origin" : [77,44],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-3-0",
					"origin" : [77,89],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-4-0",
					"origin" : [161,63],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-5-0",
					"origin" : [161,59],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-6-0",
					"origin" : [132,110],
					"z" : 0,
				},
				"seat" :  {
					"0" : [-33,109],
					"1" : [-12,109],
					"2" : [8,109],
					"4" : [26,109],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-7-0",
					"origin" : [21,32],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-8-0",
					"origin" : [90,19],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-9-0",
					"origin" : [90,24],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-10-0",
					"origin" : [54,19],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-11-0",
					"origin" : [71,14],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-12-0",
					"origin" : [147,132],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-13-0",
					"origin" : [127,80],
					"z" : 0,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-14-0",
					"origin" : [90,24],
					"z" : 0,
				},
			},
			"15" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-15-0",
					"origin" : [90,18],
					"z" : 0,
				},
			},
			"16" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-16-0",
					"origin" : [54,18],
					"z" : 0,
				},
			},
			"17" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-17-0",
					"origin" : [71,14],
					"z" : 0,
				},
			},
			"18" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-18-0",
					"origin" : [138,131],
					"z" : 0,
				},
			},
			"19" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-19-0",
					"origin" : [127,80],
					"z" : 0,
				},
			},
			"20" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-20-0",
					"origin" : [24,42],
					"z" : 0,
				},
			},
			"21" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-21-0",
					"origin" : [20,31],
					"z" : 0,
				},
			},
			"22" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-22-0",
					"origin" : [44,39],
					"z" : 0,
					"a0" : 40,
					"a1" : 255,
					"delay" : 2200,
				},
				"1" :  {
					"png_path": "acc6.img/cokeTown-foot-22-1",
					"origin" : [44,39],
					"z" : 0,
					"a0" : 255,
					"a1" : 80,
					"delay" : 2200,
				},
			},
			"23" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-23-0",
					"origin" : [30,17],
					"z" : 0,
				},
			},
			"24" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-24-0",
					"origin" : [61,62],
					"z" : 0,
					"a0" : 40,
					"a1" : 255,
					"delay" : 1500,
				},
				"1" :  {
					"png_path": "acc6.img/cokeTown-foot-24-1",
					"origin" : [61,62],
					"z" : 0,
					"a0" : 255,
					"a1" : 220,
					"delay" : 300,
				},
				"2" :  {
					"png_path": "acc6.img/cokeTown-foot-24-2",
					"origin" : [61,62],
					"z" : 0,
					"a0" : 220,
					"a1" : 255,
					"delay" : 300,
				},
				"3" :  {
					"png_path": "acc6.img/cokeTown-foot-24-1",
					"origin" : [61,62],
					"z" : 0,
					"a0" : 255,
					"a1" : 220,
					"delay" : 300,
				},
				"4" :  {
					"png_path": "acc6.img/cokeTown-foot-24-2",
					"origin" : [61,62],
					"z" : 0,
					"a0" : 220,
					"a1" : 255,
					"delay" : 300,
				},
				"5" :  {
					"png_path": "acc6.img/cokeTown-foot-24-1",
					"origin" : [61,62],
					"z" : 0,
					"a0" : 255,
					"a1" : 220,
					"delay" : 300,
				},
				"6" :  {
					"png_path": "acc6.img/cokeTown-foot-24-2",
					"origin" : [61,62],
					"z" : 0,
					"a0" : 220,
					"a1" : 255,
					"delay" : 300,
				},
				"7" :  {
					"png_path": "acc6.img/cokeTown-foot-24-7",
					"origin" : [61,62],
					"z" : 0,
					"a0" : 255,
					"a1" : 40,
					"delay" : 1200,
				},
			},
			"25" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-foot-25-0",
					"origin" : [30,51],
					"z" : 0,
					"a0" : 80,
					"a1" : 255,
					"delay" : 1500,
				},
				"1" :  {
					"png_path": "acc6.img/cokeTown-foot-25-1",
					"origin" : [30,51],
					"z" : 0,
					"a0" : 255,
					"a1" : 40,
					"delay" : 1200,
				},
				"2" :  {
					"png_path": "acc6.img/cokeTown-foot-25-2",
					"origin" : [29,46],
					"z" : 0,
					"a0" : 80,
					"a1" : 255,
					"delay" : 1500,
				},
				"3" :  {
					"png_path": "acc6.img/cokeTown-foot-25-3",
					"origin" : [29,46],
					"z" : 0,
					"a0" : 255,
					"a1" : 40,
					"delay" : 1200,
				},
				"4" :  {
					"png_path": "acc6.img/cokeTown-foot-25-4",
					"origin" : [28,48],
					"z" : 0,
					"a0" : 80,
					"a1" : 255,
					"delay" : 1500,
				},
				"5" :  {
					"png_path": "acc6.img/cokeTown-foot-25-5",
					"origin" : [28,48],
					"z" : 0,
					"a0" : 255,
					"a1" : 40,
					"delay" : 1200,
				},
			},
		},
		"nature" :  {
			"0" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-0-0",
					"origin" : [171,78],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-1-0",
					"origin" : [100,43],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-2-0",
					"origin" : [74,37],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-3-0",
					"origin" : [35,26],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-4-0",
					"origin" : [38,22],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-5-0",
					"origin" : [78,129],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-6-0",
					"origin" : [72,116],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-7-0",
					"origin" : [107,36],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-8-0",
					"origin" : [107,43],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-9-0",
					"origin" : [151,48],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-10-0",
					"origin" : [114,76],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-11-0",
					"origin" : [148,94],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-12-0",
					"origin" : [21,23],
					"z" : 0,
					"a0" : 40,
					"a1" : 255,
					"delay" : 700,
				},
				"1" :  {
					"png_path": "acc6.img/cokeTown-nature-12-1",
					"origin" : [21,23],
					"z" : 0,
					"a0" : 255,
					"a1" : 40,
					"delay" : 700,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-13-0",
					"origin" : [12,13],
					"z" : 0,
					"a0" : 255,
					"a1" : 40,
					"delay" : 700,
				},
				"1" :  {
					"png_path": "acc6.img/cokeTown-nature-13-1",
					"origin" : [12,13],
					"z" : 0,
					"a0" : 40,
					"a1" : 255,
					"delay" : 700,
				},
			},
			"14" :  {
				"0" :  {
					"png_path": "acc6.img/cokeTown-nature-14-0",
					"origin" : [6,6],
					"z" : 0,
					"a0" : 40,
					"a1" : 255,
					"delay" : 700,
				},
				"1" :  {
					"png_path": "acc6.img/cokeTown-nature-14-1",
					"origin" : [6,6],
					"z" : 0,
					"a0" : 255,
					"a1" : 40,
					"delay" : 700,
				},
			},
		},
	},
};

