var Objconnect = Objconnect || { }; 
Objconnect =   {
	"id":"connect",
	"ladder" :  {
		"0" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-0-0-0",
					"origin" : [24,9],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-0-1-0",
					"origin" : [25,24],
					"z" : 0,
					"ladder" : [0,26],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-0-2-0",
					"origin" : [26,28],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-0-3-0",
					"origin" : [22,7],
					"z" : 0,
					"ladder" : [0,9],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-0-4-0",
					"origin" : [27,127],
					"z" : 0,
					"ladder" : [0,131],
				},
			},
		},
		"1" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-1-0-0",
					"origin" : [34,103],
					"z" : 0,
					"ladder" : [0,103],
				},
			},
		},
		"2" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-2-0-0",
					"origin" : [25,18],
					"z" : 0,
					"ladder" : [0,26],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-2-1-0",
					"origin" : [26,21],
					"z" : 0,
					"ladder" : [0,26],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-2-2-0",
					"origin" : [26,15],
					"z" : 0,
					"ladder" : [0,15],
				},
			},
		},
		"3" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-3-0-0",
					"origin" : [32,11],
					"z" : 0,
					"ladder" : [0,22],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-3-1-0",
					"origin" : [28,24],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-3-2-0",
					"origin" : [28,24],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-3-3-0",
					"origin" : [28,24],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-3-4-0",
					"origin" : [28,5],
					"z" : 0,
					"ladder" : [0,9],
				},
			},
		},
		"4" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-4-0-0",
					"origin" : [23,11],
					"z" : 0,
					"ladder" : [0,14],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-4-1-0",
					"origin" : [18,8],
					"z" : 0,
					"ladder" : [0,12],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-4-2-0",
					"origin" : [18,9],
					"z" : 0,
					"ladder" : [0,14],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-4-3-0",
					"origin" : [18,25],
					"z" : 0,
					"ladder" : [0,29],
				},
			},
		},
		"5" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-5-0-0",
					"origin" : [21,12],
					"z" : 0,
					"ladder" : [0,18],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-5-1-0",
					"origin" : [19,9],
					"z" : 0,
					"ladder" : [0,12],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-5-2-0",
					"origin" : [19,10],
					"z" : 0,
					"ladder" : [0,13],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-5-3-0",
					"origin" : [19,27],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
		},
		"6" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-6-0-0",
					"origin" : [0,0],
					"ladder" : [0,50],
				},
			},
		},
		"7" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-7-0-0",
					"origin" : [42,10],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-7-1-0",
					"origin" : [33,48],
					"z" : 0,
					"ladder" : [0,55],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-7-2-0",
					"origin" : [39,48],
					"z" : 0,
					"ladder" : [0,55],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-7-3-0",
					"origin" : [30,14],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
		},
		"8" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-8-0-0",
					"origin" : [31,10],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-8-1-0",
					"origin" : [27,15],
					"z" : 0,
					"ladder" : [0,19],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-8-2-0",
					"origin" : [24,15],
					"z" : 0,
					"ladder" : [0,6],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-8-3-0",
					"origin" : [24,15],
					"z" : 0,
					"ladder" : [0,14],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-8-4-0",
					"origin" : [24,27],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
		},
		"9" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-9-0-0",
					"origin" : [36,10],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-9-1-0",
					"origin" : [27,15],
					"z" : 0,
					"ladder" : [0,19],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-9-2-0",
					"origin" : [24,15],
					"z" : 0,
					"ladder" : [0,16],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-9-3-0",
					"origin" : [26,15],
					"z" : 0,
					"ladder" : [0,15],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-9-4-0",
					"origin" : [24,27],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
		},
		"10" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-10-0-0",
					"origin" : [0,0],
				},
			},
		},
		"11" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-11-0-0",
					"origin" : [35,8],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-11-1-0",
					"origin" : [27,9],
					"z" : 0,
					"ladder" : [0,23],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-11-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [0,19],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-11-3-0",
					"origin" : [26,9],
					"z" : 0,
					"ladder" : [0,20],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-11-4-0",
					"origin" : [24,27],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
		},
		"12" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-12-0-0",
					"origin" : [16,9],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-12-1-0",
					"origin" : [16,16],
					"z" : 0,
					"ladder" : [3,20],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-12-2-0",
					"origin" : [16,16],
					"z" : 0,
					"ladder" : [3,20],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-12-3-0",
					"origin" : [16,8],
					"z" : 0,
					"ladder" : [3,9],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-12-4-0",
					"origin" : [16,49],
					"z" : 0,
					"ladder" : [3,53],
				},
			},
		},
		"13" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-13-0-0",
					"origin" : [28,17],
					"z" : 0,
					"ladder" : [0,37],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-13-1-0",
					"origin" : [26,40],
					"z" : 0,
					"ladder" : [0,42],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-13-2-0",
					"origin" : [27,19],
					"z" : 0,
					"ladder" : [0,34],
				},
			},
		},
		"14" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-14-0-0",
					"origin" : [0,0],
				},
			},
		},
		"15" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-15-0-0",
					"origin" : [24,11],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-15-1-0",
					"origin" : [25,24],
					"z" : 0,
					"ladder" : [0,26],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-15-2-0",
					"origin" : [26,28],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-15-3-0",
					"origin" : [22,7],
					"z" : 0,
					"ladder" : [0,9],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-15-4-0",
					"origin" : [26,58],
					"z" : 0,
					"ladder" : [0,54],
				},
			},
		},
		"16" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-16-0-0",
					"origin" : [17,12],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-16-1-0",
					"origin" : [16,16],
					"z" : 0,
					"ladder" : [3,20],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-16-2-0",
					"origin" : [16,16],
					"z" : 0,
					"ladder" : [3,20],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-16-3-0",
					"origin" : [16,8],
					"z" : 0,
					"ladder" : [3,9],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-16-4-0",
					"origin" : [16,49],
					"z" : 0,
					"ladder" : [3,53],
				},
			},
		},
		"17" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-17-0-0",
					"origin" : [17,12],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-17-1-0",
					"origin" : [16,16],
					"z" : 0,
					"ladder" : [3,20],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-17-2-0",
					"origin" : [16,16],
					"z" : 0,
					"ladder" : [3,20],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-17-3-0",
					"origin" : [16,8],
					"z" : 0,
					"ladder" : [3,9],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-17-4-0",
					"origin" : [16,49],
					"z" : 0,
					"ladder" : [3,53],
				},
			},
		},
		"18" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-18-0-0",
					"origin" : [20,11],
					"z" : 0,
					"ladder" : [0,20],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-18-1-0",
					"origin" : [21,19],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-18-2-0",
					"origin" : [21,38],
					"z" : 0,
					"ladder" : [0,44],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-18-3-0",
					"origin" : [21,18],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
		},
		"19" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-19-0-0",
					"origin" : [20,11],
					"z" : 0,
					"ladder" : [0,20],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-19-1-0",
					"origin" : [21,19],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-19-2-0",
					"origin" : [21,38],
					"z" : 0,
					"ladder" : [0,44],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-19-3-0",
					"origin" : [21,18],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-19-4-0",
					"origin" : [21,76],
					"z" : 0,
					"ladder" : [0,81],
				},
			},
		},
		"20" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-20-0-0",
					"origin" : [20,11],
					"z" : 0,
					"ladder" : [0,20],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-20-1-0",
					"origin" : [21,19],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-20-2-0",
					"origin" : [21,38],
					"z" : 0,
					"ladder" : [0,44],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-20-3-0",
					"origin" : [21,18],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
		},
		"21" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-21-0-0",
					"origin" : [20,11],
					"z" : 0,
					"ladder" : [0,20],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-21-1-0",
					"origin" : [21,19],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-21-2-0",
					"origin" : [21,38],
					"z" : 0,
					"ladder" : [0,44],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-21-3-0",
					"origin" : [21,18],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
		},
		"22" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-22-0-0",
					"origin" : [27,11],
					"z" : 0,
					"ladder" : [0,20],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-22-1-0",
					"origin" : [21,19],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-22-2-0",
					"origin" : [21,38],
					"z" : 0,
					"ladder" : [0,44],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-22-3-0",
					"origin" : [21,18],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-22-4-0",
					"origin" : [21,19],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-22-5-0",
					"origin" : [21,38],
					"z" : 0,
					"ladder" : [0,44],
				},
			},
		},
		"23" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-23-0-0",
					"origin" : [27,11],
					"z" : 0,
					"ladder" : [0,20],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-23-1-0",
					"origin" : [21,19],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-23-2-0",
					"origin" : [21,38],
					"z" : 0,
					"ladder" : [0,44],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-23-3-0",
					"origin" : [21,18],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-23-4-0",
					"origin" : [21,19],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-23-5-0",
					"origin" : [21,38],
					"z" : 0,
					"ladder" : [0,44],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/ladder-23-6-0",
					"origin" : [21,18],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "connect.img/ladder-23-7-0",
					"origin" : [27,11],
					"z" : 0,
					"ladder" : [0,20],
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "connect.img/ladder-23-8-0",
					"origin" : [21,19],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "connect.img/ladder-23-9-0",
					"origin" : [21,38],
					"z" : 0,
					"ladder" : [0,44],
				},
			},
		},
		"24" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-24-0-0",
					"origin" : [27,11],
					"z" : 0,
					"ladder" : [0,20],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-24-1-0",
					"origin" : [21,19],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-24-2-0",
					"origin" : [21,38],
					"z" : 0,
					"ladder" : [0,44],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-24-3-0",
					"origin" : [21,18],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
		},
		"25" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-25-0-0",
					"origin" : [0,0],
				},
			},
		},
		"26" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-26-0-0",
					"origin" : [26,12],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-26-1-0",
					"origin" : [24,40],
					"z" : 0,
					"ladder" : [0,67],
				},
			},
		},
		"27" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-27-0-0",
					"origin" : [26,12],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-27-1-0",
					"origin" : [24,40],
					"z" : 0,
					"ladder" : [0,67],
				},
			},
		},
		"28" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-28-0-0",
					"origin" : [26,12],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-28-1-0",
					"origin" : [0,0],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-28-2-0",
					"origin" : [24,100],
					"z" : 0,
					"ladder" : [0,105],
				},
			},
		},
		"29" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-29-0-0",
					"origin" : [5,6],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-29-1-0",
					"origin" : [18,33],
					"z" : 0,
					"ladder" : [0,38],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-29-2-0",
					"origin" : [18,33],
					"z" : 0,
					"ladder" : [0,38],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-29-3-0",
					"origin" : [18,33],
					"z" : 0,
					"ladder" : [0,38],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-29-4-0",
					"origin" : [18,19],
					"z" : 0,
					"ladder" : [0,27],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-29-5-0",
					"origin" : [18,66],
					"z" : 0,
					"ladder" : [0,76],
				},
			},
		},
		"30" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-30-0-0",
					"origin" : [0,0],
				},
			},
		},
		"31" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-31-0-0",
					"origin" : [0,0],
				},
			},
		},
		"32" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-32-0-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [0,28],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-32-1-0",
					"origin" : [22,26],
					"z" : 0,
					"ladder" : [0,39],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-32-2-0",
					"origin" : [22,52],
					"z" : 0,
					"ladder" : [0,67],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-32-3-0",
					"origin" : [22,26],
					"z" : 0,
					"ladder" : [0,39],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-32-4-0",
					"origin" : [18,13],
					"z" : 0,
					"ladder" : [0,28],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-32-5-0",
					"origin" : [23,12],
					"z" : 0,
					"ladder" : [0,23],
				},
			},
		},
		"33" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-33-0-0",
					"origin" : [26,17],
					"z" : 0,
					"ladder" : [0,21],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-33-1-0",
					"origin" : [22,26],
					"z" : 0,
					"ladder" : [0,34],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-33-2-0",
					"origin" : [22,26],
					"z" : 0,
					"ladder" : [0,34],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-33-3-0",
					"origin" : [22,52],
					"z" : 0,
					"ladder" : [0,59],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-33-4-0",
					"origin" : [18,13],
					"z" : 0,
					"ladder" : [0,21],
				},
			},
		},
		"34" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-34-0-0",
					"origin" : [23,17],
					"z" : 0,
					"ladder" : [0,23],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-34-1-0",
					"origin" : [22,33],
					"z" : 0,
					"ladder" : [0,34],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-34-2-0",
					"origin" : [22,30],
					"z" : 0,
					"ladder" : [0,36],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-34-3-0",
					"origin" : [22,27],
					"z" : 0,
					"ladder" : [0,38],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-34-4-0",
					"origin" : [18,14],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
		},
		"35" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-35-0-0",
					"origin" : [36,17],
					"z" : 0,
					"ladder" : [3,28],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-35-1-0",
					"origin" : [25,24],
					"z" : 0,
					"ladder" : [3,33],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-35-2-0",
					"origin" : [25,48],
					"z" : 0,
					"ladder" : [3,57],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-35-3-0",
					"origin" : [25,12],
					"z" : 0,
					"ladder" : [3,16],
				},
			},
		},
		"36" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-36-0-0",
					"origin" : [26,17],
					"z" : 0,
					"ladder" : [-1,22],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-36-1-0",
					"origin" : [25,26],
					"z" : 0,
					"ladder" : [-1,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-36-2-0",
					"origin" : [25,52],
					"z" : 0,
					"ladder" : [-1,56],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-36-3-0",
					"origin" : [38,12],
					"z" : 0,
					"ladder" : [-1,16],
				},
			},
		},
		"37" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-37-0-0",
					"origin" : [26,13],
					"z" : 0,
					"ladder" : [-4,22],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-37-1-0",
					"origin" : [26,17],
					"z" : 0,
					"ladder" : [-4,22],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-37-2-0",
					"origin" : [26,11],
					"z" : 0,
					"ladder" : [-4,13],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-37-3-0",
					"origin" : [26,51],
					"z" : 0,
					"ladder" : [-4,55],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-37-4-0",
					"origin" : [30,13],
					"z" : 0,
					"ladder" : [4,22],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-37-5-0",
					"origin" : [26,17],
					"z" : 0,
					"ladder" : [4,22],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/ladder-37-6-0",
					"origin" : [26,11],
					"z" : 0,
					"ladder" : [4,13],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "connect.img/ladder-37-7-0",
					"origin" : [26,51],
					"z" : 0,
					"ladder" : [4,55],
				},
			},
		},
		"38" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-38-0-0",
					"origin" : [27,17],
					"z" : 0,
					"ladder" : [1,22],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-38-1-0",
					"origin" : [25,19],
					"z" : 0,
					"ladder" : [1,24],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-38-2-0",
					"origin" : [26,9],
					"z" : 0,
					"ladder" : [1,13],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-38-3-0",
					"origin" : [25,57],
					"z" : 0,
					"ladder" : [1,61],
				},
			},
		},
		"39" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-39-0-0",
					"origin" : [24,15],
					"z" : 0,
					"ladder" : [-2,22],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-39-1-0",
					"origin" : [24,17],
					"z" : 0,
					"ladder" : [-2,22],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-39-2-0",
					"origin" : [24,13],
					"z" : 0,
					"ladder" : [-2,13],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-39-3-0",
					"origin" : [24,51],
					"z" : 0,
					"ladder" : [-2,55],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-39-4-0",
					"origin" : [32,15],
					"z" : 0,
					"ladder" : [2,22],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-39-5-0",
					"origin" : [24,17],
					"z" : 0,
					"ladder" : [2,22],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/ladder-39-6-0",
					"origin" : [24,13],
					"z" : 0,
					"ladder" : [2,13],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "connect.img/ladder-39-7-0",
					"origin" : [24,51],
					"z" : 0,
					"ladder" : [2,55],
				},
			},
		},
		"40" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-40-0-0",
					"origin" : [26,9],
					"z" : 0,
					"ladder" : [1,22],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-40-1-0",
					"origin" : [25,18],
					"z" : 0,
					"ladder" : [1,24],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-40-2-0",
					"origin" : [26,9],
					"z" : 0,
					"ladder" : [1,13],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-40-3-0",
					"origin" : [25,54],
					"z" : 0,
					"ladder" : [1,61],
				},
			},
		},
		"41" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-41-0-0",
					"origin" : [24,15],
					"z" : 0,
					"ladder" : [-2,22],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-41-1-0",
					"origin" : [24,17],
					"z" : 0,
					"ladder" : [-2,22],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-41-2-0",
					"origin" : [24,13],
					"z" : 0,
					"ladder" : [-2,13],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-41-3-0",
					"origin" : [24,51],
					"z" : 0,
					"ladder" : [-2,55],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-41-4-0",
					"origin" : [32,15],
					"z" : 0,
					"ladder" : [2,22],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-41-5-0",
					"origin" : [24,17],
					"z" : 0,
					"ladder" : [2,22],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/ladder-41-6-0",
					"origin" : [24,13],
					"z" : 0,
					"ladder" : [2,13],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "connect.img/ladder-41-7-0",
					"origin" : [24,51],
					"z" : 0,
					"ladder" : [2,55],
				},
			},
		},
		"42" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-42-0-0",
					"origin" : [26,9],
					"z" : 0,
					"ladder" : [1,22],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-42-1-0",
					"origin" : [25,18],
					"z" : 0,
					"ladder" : [1,24],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-42-2-0",
					"origin" : [26,9],
					"z" : 0,
					"ladder" : [1,13],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-42-3-0",
					"origin" : [25,54],
					"z" : 0,
					"ladder" : [1,61],
				},
			},
		},
		"43" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-43-0-0",
					"origin" : [37,26],
					"z" : 0,
					"ladder" : [0,33],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-43-1-0",
					"origin" : [25,15],
					"z" : 0,
					"ladder" : [0,24],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-43-2-0",
					"origin" : [26,21],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-43-3-0",
					"origin" : [26,46],
					"z" : 0,
					"ladder" : [0,52],
				},
			},
		},
		"44" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-44-0-0",
					"origin" : [36,22],
					"z" : 0,
					"ladder" : [0,43],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-44-1-0",
					"origin" : [31,36],
					"z" : 0,
					"ladder" : [0,42],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-44-2-0",
					"origin" : [37,20],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-44-3-0",
					"origin" : [31,108],
					"z" : 0,
					"ladder" : [0,113],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-44-4-0",
					"origin" : [36,22],
					"z" : 0,
					"ladder" : [0,43],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-44-5-0",
					"origin" : [31,36],
					"z" : 0,
					"ladder" : [0,42],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/ladder-44-6-0",
					"origin" : [37,20],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "connect.img/ladder-44-7-0",
					"origin" : [31,108],
					"z" : 0,
					"ladder" : [0,113],
				},
			},
		},
		"45" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-45-0-0",
					"origin" : [36,22],
					"z" : 0,
					"ladder" : [0,43],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-45-1-0",
					"origin" : [31,36],
					"z" : 0,
					"ladder" : [0,42],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-45-2-0",
					"origin" : [37,20],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-45-3-0",
					"origin" : [31,108],
					"z" : 0,
					"ladder" : [0,113],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-45-4-0",
					"origin" : [36,22],
					"z" : 0,
					"ladder" : [0,43],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-45-5-0",
					"origin" : [31,36],
					"z" : 0,
					"ladder" : [0,42],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/ladder-45-6-0",
					"origin" : [37,20],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "connect.img/ladder-45-7-0",
					"origin" : [31,108],
					"z" : 0,
					"ladder" : [0,113],
				},
			},
		},
		"46" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-46-0-0",
					"origin" : [36,22],
					"z" : 0,
					"ladder" : [0,43],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-46-1-0",
					"origin" : [31,36],
					"z" : 0,
					"ladder" : [0,42],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-46-2-0",
					"origin" : [37,20],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-46-3-0",
					"origin" : [31,108],
					"z" : 0,
					"ladder" : [0,113],
				},
			},
		},
		"47" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-47-0-0",
					"origin" : [24,12],
					"z" : 0,
					"ladder" : [0,21],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-47-1-0",
					"origin" : [22,26],
					"z" : 0,
					"ladder" : [0,34],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-47-2-0",
					"origin" : [16,13],
					"z" : 0,
					"ladder" : [0,17],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-47-3-0",
					"origin" : [22,78],
					"z" : 0,
					"ladder" : [0,83],
				},
			},
		},
		"48" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-48-0-0",
					"origin" : [28,13],
					"z" : 0,
					"ladder" : [-4,33],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-48-1-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-48-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [0,25],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-48-3-0",
					"origin" : [24,32],
					"z" : 0,
					"ladder" : [0,43],
				},
			},
		},
		"49" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-49-0-0",
					"origin" : [22,12],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-49-1-0",
					"origin" : [22,25],
					"z" : 0,
					"ladder" : [0,38],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-49-2-0",
					"origin" : [22,25],
					"z" : 0,
					"ladder" : [0,37],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-49-3-0",
					"origin" : [22,26],
					"z" : 0,
					"ladder" : [0,40],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-49-4-0",
					"origin" : [18,14],
					"z" : 0,
					"ladder" : [-2,24],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-49-5-0",
					"origin" : [22,77],
					"z" : 0,
					"ladder" : [0,89],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/ladder-49-6-0",
					"origin" : [22,12],
					"z" : 0,
					"ladder" : [0,35],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "connect.img/ladder-49-7-0",
					"origin" : [22,25],
					"z" : 0,
					"ladder" : [0,37],
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "connect.img/ladder-49-8-0",
					"origin" : [22,25],
					"z" : 0,
					"ladder" : [0,39],
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "connect.img/ladder-49-9-0",
					"origin" : [22,26],
					"z" : 0,
					"ladder" : [0,38],
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "connect.img/ladder-49-10-0",
					"origin" : [18,14],
					"z" : 0,
					"ladder" : [2,23],
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "connect.img/ladder-49-11-0",
					"origin" : [22,77],
					"z" : 0,
					"ladder" : [0,89],
				},
			},
		},
		"50" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-50-0-0",
					"origin" : [24,12],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-50-1-0",
					"origin" : [23,25],
					"z" : 0,
					"ladder" : [0,38],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-50-2-0",
					"origin" : [23,25],
					"z" : 0,
					"ladder" : [0,37],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-50-3-0",
					"origin" : [23,26],
					"z" : 0,
					"ladder" : [0,40],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-50-4-0",
					"origin" : [19,14],
					"z" : 0,
					"ladder" : [-2,24],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-50-5-0",
					"origin" : [23,77],
					"z" : 0,
					"ladder" : [0,89],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/ladder-50-6-0",
					"origin" : [24,12],
					"z" : 0,
					"ladder" : [0,35],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "connect.img/ladder-50-7-0",
					"origin" : [23,25],
					"z" : 0,
					"ladder" : [0,37],
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "connect.img/ladder-50-8-0",
					"origin" : [23,25],
					"z" : 0,
					"ladder" : [0,39],
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "connect.img/ladder-50-9-0",
					"origin" : [23,26],
					"z" : 0,
					"ladder" : [0,38],
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "connect.img/ladder-50-10-0",
					"origin" : [19,14],
					"z" : 0,
					"ladder" : [2,23],
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "connect.img/ladder-50-11-0",
					"origin" : [23,77],
					"z" : 0,
					"ladder" : [0,89],
				},
			},
		},
		"51" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-51-0-0",
					"origin" : [22,12],
					"z" : 0,
					"ladder" : [0,18],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-51-1-0",
					"origin" : [21,25],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-51-2-0",
					"origin" : [21,25],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-51-3-0",
					"origin" : [15,14],
					"z" : 0,
					"ladder" : [0,19],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-51-4-0",
					"origin" : [21,78],
					"z" : 0,
					"ladder" : [0,81],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-51-5-0",
					"origin" : [22,12],
					"z" : 0,
					"ladder" : [0,18],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/ladder-51-6-0",
					"origin" : [22,25],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "connect.img/ladder-51-7-0",
					"origin" : [22,25],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "connect.img/ladder-51-8-0",
					"origin" : [20,15],
					"z" : 0,
					"ladder" : [0,19],
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "connect.img/ladder-51-9-0",
					"origin" : [22,78],
					"z" : 0,
					"ladder" : [0,81],
				},
			},
		},
		"52" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-52-0-0",
					"origin" : [24,18],
					"z" : 0,
					"ladder" : [0,21],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-52-1-0",
					"origin" : [24,25],
					"z" : 0,
					"ladder" : [0,28],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-52-2-0",
					"origin" : [24,5],
					"z" : 0,
					"ladder" : [0,5],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-52-3-0",
					"origin" : [24,76],
					"z" : 0,
					"ladder" : [0,78],
				},
			},
		},
		"53" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-53-0-0",
					"origin" : [29,3],
					"z" : 0,
					"laddeer" : [-1,6],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-53-1-0",
					"origin" : [29,12],
					"z" : 0,
					"ladder" : [-1,14],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-53-2-0",
					"origin" : [29,6],
					"z" : 0,
					"ladder" : [-1,8],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-53-3-0",
					"origin" : [29,48],
					"z" : 0,
					"ladder" : [-1,50],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-53-4-0",
					"origin" : [34,3],
					"z" : 0,
					"ladder" : [-1,6],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/ladder-53-5-0",
					"origin" : [30,12],
					"z" : 0,
					"ladder" : [-1,14],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/ladder-53-6-0",
					"origin" : [30,6],
					"z" : 0,
					"ladder" : [-1,8],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "connect.img/ladder-53-7-0",
					"origin" : [30,48],
					"z" : 0,
					"ladder" : [-1,50],
				},
			},
		},
		"54" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-54-0-0",
					"origin" : [27,13],
					"z" : 0,
					"ladder" : [2,16],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-54-1-0",
					"origin" : [21,17],
					"z" : 0,
					"ladder" : [2,19],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-54-2-0",
					"origin" : [21,51],
					"z" : 0,
					"ladder" : [2,53],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-54-3-0",
					"origin" : [21,11],
					"z" : 0,
					"ladder" : [2,14],
				},
			},
		},
		"55" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-55-0-0",
					"origin" : [27,62],
					"z" : 1,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-55-1-0",
					"origin" : [25,28],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-55-2-0",
					"origin" : [26,9],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-55-3-0",
					"origin" : [25,67],
					"z" : 0,
					"ladder" : [0,69],
				},
			},
		},
		"56" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-56-0-0",
					"origin" : [22,13],
					"z" : 1,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-56-1-0",
					"origin" : [20,30],
					"z" : 0,
					"ladder" : [0,33],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-56-2-0",
					"origin" : [21,15],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-56-3-0",
					"origin" : [20,60],
					"z" : 0,
					"ladder" : [0,63],
				},
			},
		},
		"57" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-57-0-0",
					"origin" : [22,13],
					"z" : 1,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-57-1-0",
					"origin" : [20,30],
					"z" : 0,
					"ladder" : [0,33],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-57-2-0",
					"origin" : [21,15],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-57-3-0",
					"origin" : [20,60],
					"z" : 0,
					"ladder" : [0,63],
				},
			},
		},
		"58" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-58-0-0",
					"origin" : [28,13],
					"z" : 0,
					"ladder" : [-4,33],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-58-1-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-58-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [0,25],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-58-3-0",
					"origin" : [24,48],
					"z" : 0,
					"ladder" : [0,55],
				},
			},
		},
		"59" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-59-0-0",
					"origin" : [32,7],
					"z" : 0,
					"ladder" : [0,38],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-59-1-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-59-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [0,25],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-59-3-0",
					"origin" : [24,48],
					"z" : 0,
					"ladder" : [0,57],
				},
			},
		},
		"60" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-60-0-0",
					"origin" : [28,13],
					"z" : 0,
					"ladder" : [-4,33],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-60-1-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-60-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [0,25],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-60-3-0",
					"origin" : [24,48],
					"z" : 0,
					"ladder" : [0,57],
				},
			},
		},
		"61" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-61-0-0",
					"origin" : [32,7],
					"z" : 0,
					"ladder" : [0,38],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-61-1-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-61-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [0,25],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-61-3-0",
					"origin" : [24,48],
					"z" : 0,
					"ladder" : [0,61],
				},
			},
		},
		"62" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-62-0-0",
					"origin" : [28,13],
					"z" : 0,
					"ladder" : [-4,33],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-62-1-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-62-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [0,25],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-62-3-0",
					"origin" : [24,48],
					"z" : 0,
					"ladder" : [0,61],
				},
			},
		},
		"63" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-63-0-0",
					"origin" : [32,10],
					"z" : 0,
					"ladder" : [0,33],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-63-1-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-63-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [0,25],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-63-3-0",
					"origin" : [24,48],
					"z" : 0,
					"ladder" : [0,61],
				},
			},
		},
		"64" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-64-0-0",
					"origin" : [28,13],
					"z" : 0,
					"ladder" : [-4,33],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-64-1-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-64-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [0,25],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-64-3-0",
					"origin" : [24,48],
					"z" : 0,
					"ladder" : [0,61],
				},
			},
		},
		"65" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-65-0-0",
					"origin" : [32,10],
					"z" : 0,
					"ladder" : [0,33],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-65-1-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-65-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [0,25],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-65-3-0",
					"origin" : [24,48],
					"z" : 0,
					"ladder" : [0,61],
				},
			},
		},
		"66" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-66-0-0",
					"origin" : [28,12],
					"z" : 0,
					"ladder" : [-6,17],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-66-1-0",
					"origin" : [28,16],
					"z" : 0,
					"ladder" : [-6,20],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-66-2-0",
					"origin" : [28,15],
					"z" : 0,
					"ladder" : [-6,4],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-66-3-0",
					"origin" : [28,32],
					"z" : 0,
					"ladder" : [-6,33],
				},
			},
		},
		"67" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-67-0-0",
					"origin" : [27,13],
					"z" : 0,
					"ladder" : [-3,18],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-67-1-0",
					"origin" : [24,17],
					"z" : 0,
					"ladder" : [0,19],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-67-2-0",
					"origin" : [24,11],
					"z" : 0,
					"ladder" : [0,14],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-67-3-0",
					"origin" : [24,51],
					"z" : 0,
					"ladder" : [0,52],
				},
			},
		},
		"68" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-68-0-0",
					"origin" : [30,53],
					"z" : 0,
					"ladder" : [0,116],
				},
			},
		},
		"69" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-69-0-0",
					"origin" : [30,53],
					"z" : 0,
					"ladder" : [-1,51],
				},
			},
		},
		"70" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-70-0-0",
					"origin" : [23,78],
					"z" : 0,
					"ladder" : [1,90],
				},
			},
		},
		"71" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-71-0-0",
					"origin" : [23,18],
					"z" : 0,
					"ladder" : [1,13],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-71-1-0",
					"origin" : [23,8],
					"z" : 0,
					"ladder" : [1,13],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-71-2-0",
					"origin" : [23,9],
					"z" : 0,
					"ladder" : [1,12],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-71-3-0",
					"origin" : [27,133],
					"z" : 0,
					"ladder" : [-2,146],
				},
			},
		},
		"72" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-72-0-0",
					"origin" : [24,9],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-72-1-0",
					"origin" : [25,24],
					"z" : 0,
					"ladder" : [0,26],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-72-2-0",
					"origin" : [26,28],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-72-3-0",
					"origin" : [22,7],
					"z" : 0,
					"ladder" : [0,9],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-72-4-0",
					"origin" : [27,127],
					"z" : 0,
					"ladder" : [0,131],
				},
			},
		},
		"73" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-73-0-0",
					"origin" : [26,18],
					"z" : 0,
					"ladder" : [2,17],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-73-1-0",
					"origin" : [26,21],
					"z" : 0,
					"ladder" : [2,26],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-73-2-0",
					"origin" : [26,15],
					"z" : 0,
					"ladder" : [2,15],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-73-3-0",
					"origin" : [29,148],
					"z" : 0,
					"ladder" : [0,149],
				},
			},
		},
		"74" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-74-0-0",
					"origin" : [23,9],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-74-1-0",
					"origin" : [25,24],
					"z" : 0,
					"ladder" : [0,26],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-74-2-0",
					"origin" : [24,26],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-74-3-0",
					"origin" : [23,8],
					"z" : 0,
					"ladder" : [0,9],
				},
			},
		},
		"75" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-75-0-0",
					"origin" : [-62,267],
					"z" : 0,
					"ladder" : [86,-46],
				},
			},
		},
		"76" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-76-0-0",
					"origin" : [28,71],
					"z" : 0,
					"ladder" : [0,72],
				},
			},
		},
		"77" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-77-0-0",
					"origin" : [11,161],
					"z" : 0,
					"ladder" : [0,165],
				},
			},
		},
		"78" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-78-0-0",
					"origin" : [28,12],
					"z" : 0,
					"ladder" : [-4,33],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-78-1-0",
					"origin" : [24,12],
					"z" : 0,
					"ladder" : [0,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-78-2-0",
					"origin" : [24,7],
					"z" : 0,
					"ladder" : [0,25],
				},
			},
		},
		"79" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-79-0-0",
					"origin" : [23,16],
					"z" : 0,
					"ladder" : [1,12],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-79-1-0",
					"origin" : [23,16],
					"z" : 0,
					"ladder" : [1,20],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-79-2-0",
					"origin" : [23,16],
					"z" : 0,
					"ladder" : [1,11],
				},
			},
		},
		"80" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-80-0-0",
					"origin" : [38,281],
					"z" : 0,
					"ladder" : [1,287],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-80-1-0",
					"origin" : [23,25],
					"z" : 0,
					"ladder" : [1,27],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-80-2-0",
					"origin" : [29,25],
					"z" : 0,
					"ladder" : [1,27],
				},
			},
		},
		"81" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-81-0-0",
					"origin" : [26,12],
					"z" : 0,
					"ladder" : [-3,18],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-81-1-0",
					"origin" : [22,17],
					"z" : 0,
					"ladder" : [0,19],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-81-2-0",
					"origin" : [22,11],
					"z" : 0,
					"ladder" : [0,14],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-81-3-0",
					"origin" : [22,66],
					"z" : 0,
					"ladder" : [0,72],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/ladder-81-4-0",
					"origin" : [26,12],
					"z" : 0,
					"ladder" : [-4,18],
				},
			},
		},
		"82" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-82-0-0",
					"origin" : [27,12],
					"z" : 0,
					"ladder" : [-3,19],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-82-1-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [0,19],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-82-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [0,14],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-82-3-0",
					"origin" : [24,64],
					"z" : 0,
					"ladder" : [0,72],
				},
			},
		},
		"83" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-83-0-0",
					"origin" : [27,12],
					"z" : 0,
					"ladder" : [-3,19],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-83-1-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [0,19],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-83-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [0,14],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-83-3-0",
					"origin" : [24,64],
					"z" : 0,
					"ladder" : [0,72],
				},
			},
		},
		"84" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-84-0-0",
					"origin" : [27,13],
					"z" : 0,
					"ladder" : [2,19],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-84-1-0",
					"origin" : [24,16],
					"z" : 0,
					"ladder" : [2,19],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-84-2-0",
					"origin" : [24,9],
					"z" : 0,
					"ladder" : [2,14],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/ladder-84-3-0",
					"origin" : [24,64],
					"z" : 0,
					"ladder" : [2,72],
				},
			},
		},
		"85" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-85-0-0",
					"origin" : [33,16],
					"z" : 0,
					"ladder" : [0,17],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-85-1-0",
					"origin" : [33,16],
					"z" : 0,
					"ladder" : [0,18],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-85-2-0",
					"origin" : [33,7],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
		},
		"86" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-86-0-0",
					"origin" : [28,9],
					"z" : 0,
					"ladder" : [0,18],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-86-1-0",
					"origin" : [28,16],
					"z" : 0,
					"ladder" : [0,20],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-86-2-0",
					"origin" : [28,2],
					"z" : 0,
					"ladder" : [0,31],
				},
			},
		},
		"87" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/ladder-87-0-0",
					"origin" : [34,16],
					"z" : 0,
					"ladder" : [-5,18],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/ladder-87-1-0",
					"origin" : [30,18],
					"z" : 0,
					"ladder" : [-1,20],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/ladder-87-2-0",
					"origin" : [30,12],
					"z" : 0,
					"ladder" : [-1,21],
				},
			},
		},
	},
	"rope" :  {
		"0" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-0-0-0",
					"origin" : [5,24],
					"z" : 0,
					"rope" : [0,27],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-0-1-0",
					"origin" : [2,15],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-0-2-0",
					"origin" : [4,15],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-0-3-0",
					"origin" : [2,60],
					"z" : 0,
					"rope" : [0,62],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-0-4-0",
					"origin" : [5,24],
					"z" : 0,
				},
			},
		},
		"1" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-1-0-0",
					"origin" : [32,92],
					"z" : 0,
					"rope" : [30,69],
				},
			},
		},
		"2" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-2-0-0",
					"origin" : [5,24],
					"z" : 0,
					"rope" : [6,17],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-2-1-0",
					"origin" : [2,15],
					"z" : 0,
					"rope" : [3,43],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-2-2-0",
					"origin" : [4,15],
					"z" : 0,
					"rope" : [2,46],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-2-3-0",
					"origin" : [2,60],
					"z" : 0,
					"rope" : [9,-27],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-2-4-0",
					"origin" : [6,15],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-2-5-0",
					"origin" : [6,57],
					"z" : 0,
					"rope" : [0,62],
				},
			},
		},
		"3" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-3-0-0",
					"origin" : [0,32],
					"z" : 0,
					"rope" : [11,12],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-3-1-0",
					"origin" : [0,32],
					"z" : 0,
					"rope" : [10,1],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-3-2-0",
					"origin" : [0,32],
					"z" : 0,
					"rope" : [10,10],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-3-3-0",
					"origin" : [0,32],
					"z" : 0,
					"rope" : [13,90],
				},
			},
		},
		"4" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-4-0-0",
					"origin" : [0,0],
					"rope" : [0,50],
				},
			},
		},
		"5" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-5-0-0",
					"origin" : [12,16],
					"z" : 0,
					"rope" : [-7,16],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-5-1-0",
					"origin" : [14,-10],
					"z" : 0,
					"rope" : [-7,93],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-5-2-0",
					"origin" : [13,14],
					"z" : 0,
					"rope" : [-7,25],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-5-3-0",
					"origin" : [13,-8],
					"z" : 0,
					"rope" : [-7,47],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-5-4-0",
					"origin" : [14,13],
					"z" : 0,
					"rope" : [-7,148],
				},
			},
		},
		"6" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-6-0-0",
					"origin" : [18,50],
					"z" : 0,
					"rope" : [0,49],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-6-1-0",
					"origin" : [21,90],
					"z" : 0,
					"rope" : [1,87],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-6-2-0",
					"origin" : [23,128],
					"z" : 0,
					"rope" : [-1,125],
				},
			},
		},
		"7" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-7-0-0",
					"origin" : [10,13],
					"z" : 0,
					"rope" : [0,49],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-7-1-0",
					"origin" : [11,41],
					"z" : 0,
					"rope" : [0,43],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-7-2-0",
					"origin" : [11,32],
					"z" : 0,
					"rope" : [0,35],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-7-3-0",
					"origin" : [13,15],
					"z" : 0,
					"rope" : [0,24],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-7-4-0",
					"origin" : [14,114],
					"z" : 0,
					"rope" : [-3,120],
				},
			},
		},
		"8" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-8-0-0",
					"origin" : [13,20],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-8-1-0",
					"origin" : [0,24],
					"z" : 0,
					"rope" : [2,28],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-8-2-0",
					"origin" : [2,9],
					"z" : 0,
					"rope" : [2,20],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-8-3-0",
					"origin" : [11,10],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-8-4-0",
					"origin" : [0,51],
					"z" : 0,
					"rope" : [2,55],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-8-5-0",
					"origin" : [14,22],
					"z" : 0,
					"rope" : [2,28],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/rope-8-6-0",
					"origin" : [4,9],
					"z" : 0,
					"rope" : [2,22],
				},
			},
		},
		"9" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-9-0-0",
					"origin" : [4,10],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-9-1-0",
					"origin" : [0,24],
					"z" : 0,
					"rope" : [2,28],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-9-2-0",
					"origin" : [2,9],
					"z" : 0,
					"rope" : [2,20],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-9-3-0",
					"origin" : [13,22],
					"z" : 0,
					"rope" : [2,29],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-9-4-0",
					"origin" : [4,9],
					"z" : 0,
					"rope" : [2,23],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-9-5-0",
					"origin" : [0,63],
					"z" : 0,
					"rope" : [2,68],
				},
			},
		},
		"10" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-10-0-0",
					"origin" : [23,35],
					"z" : 0,
					"rope" : [2,49],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-10-1-0",
					"origin" : [20,28],
					"z" : 0,
					"rope" : [2,34],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-10-2-0",
					"origin" : [13,21],
					"z" : 0,
					"rope" : [2,28],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-10-3-0",
					"origin" : [0,26],
					"z" : 0,
					"rope" : [2,28],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-10-4-0",
					"origin" : [0,78],
					"z" : 0,
					"rope" : [2,83],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-10-5-0",
					"origin" : [2,6],
					"z" : 0,
					"rope" : [2,23],
				},
			},
		},
		"11" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-11-0-0",
					"origin" : [15,12],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-11-1-0",
					"origin" : [4,19],
					"z" : 0,
					"rope" : [2,13],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-11-2-0",
					"origin" : [3,11],
					"z" : 0,
					"rope" : [2,16],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-11-3-0",
					"origin" : [4,40],
					"z" : 0,
					"rope" : [2,49],
				},
			},
		},
		"12" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-12-0-0",
					"origin" : [6,17],
					"z" : 0,
					"rope" : [0,22],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-12-1-0",
					"origin" : [4,57],
					"z" : 0,
					"rope" : [0,62],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-12-2-0",
					"origin" : [4,6],
					"z" : 0,
					"rope" : [0,29],
				},
			},
		},
		"13" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-13-0-0",
					"origin" : [6,38],
					"z" : 0,
					"rope" : [0,42],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-13-1-0",
					"origin" : [4,24],
					"z" : 0,
					"rope" : [0,36],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-13-2-0",
					"origin" : [4,54],
					"z" : 0,
					"rope" : [0,62],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-13-3-0",
					"origin" : [6,30],
					"z" : 0,
					"rope" : [0,42],
				},
			},
		},
		"14" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-14-0-0",
					"origin" : [5,24],
					"z" : 0,
					"rope" : [0,27],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-14-1-0",
					"origin" : [2,15],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-14-2-0",
					"origin" : [4,15],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-14-3-0",
					"origin" : [2,60],
					"z" : 0,
					"rope" : [0,62],
				},
			},
		},
		"15" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-15-0-0",
					"origin" : [15,13],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-15-1-0",
					"origin" : [4,19],
					"z" : 0,
					"rope" : [2,13],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-15-2-0",
					"origin" : [4,11],
					"z" : 0,
					"rope" : [2,16],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-15-3-0",
					"origin" : [4,40],
					"z" : 0,
					"rope" : [2,49],
				},
			},
		},
		"16" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-16-0-0",
					"origin" : [15,13],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-16-1-0",
					"origin" : [4,19],
					"z" : 0,
					"rope" : [2,13],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-16-2-0",
					"origin" : [4,11],
					"z" : 0,
					"rope" : [2,16],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-16-3-0",
					"origin" : [4,40],
					"z" : 0,
					"rope" : [2,49],
				},
			},
		},
		"17" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-17-0-0",
					"origin" : [17,37],
					"z" : 0,
					"rope" : [0,47],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-17-1-0",
					"origin" : [6,44],
					"z" : 0,
					"rope" : [0,52],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-17-2-0",
					"origin" : [6,88],
					"z" : 0,
					"rope" : [0,99],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-17-3-0",
					"origin" : [6,176],
					"z" : 0,
					"rope" : [0,179],
				},
			},
		},
		"18" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-18-0-0",
					"origin" : [6,12],
					"z" : 0,
					"rope" : [0,22],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-18-1-0",
					"origin" : [3,36],
					"z" : 0,
					"rope" : [0,52],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-18-2-0",
					"origin" : [6,18],
					"z" : 0,
					"rope" : [0,27],
				},
			},
		},
		"19" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-19-0-0",
					"origin" : [6,17],
					"z" : 0,
					"rope" : [0,23],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-19-1-0",
					"origin" : [4,19],
					"z" : 0,
					"rope" : [0,25],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-19-2-0",
					"origin" : [4,9],
					"z" : 0,
					"rope" : [0,15],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-19-3-0",
					"origin" : [4,57],
					"z" : 0,
					"rope" : [0,63],
				},
			},
		},
		"20" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-20-0-0",
					"origin" : [8,17],
					"z" : 0,
					"rope" : [0,25],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-20-1-0",
					"origin" : [2,18],
					"z" : 0,
					"rope" : [0,25],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-20-2-0",
					"origin" : [5,12],
					"z" : 0,
					"rope" : [0,16],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-20-3-0",
					"origin" : [2,54],
					"z" : 0,
					"rope" : [0,60],
				},
			},
		},
		"21" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-21-0-0",
					"origin" : [11,22],
					"z" : 0,
					"rope" : [0,25],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-21-1-0",
					"origin" : [9,36],
					"z" : 0,
					"rope" : [0,39],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-21-2-0",
					"origin" : [7,36],
					"z" : 0,
					"rope" : [0,39],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-21-3-0",
					"origin" : [15,20],
					"z" : 0,
					"rope" : [0,31],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-21-4-0",
					"origin" : [6,20],
					"z" : 0,
					"rope" : [0,31],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-21-5-0",
					"origin" : [9,108],
					"z" : 0,
					"rope" : [0,114],
				},
			},
		},
		"22" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-22-0-0",
					"origin" : [11,22],
					"z" : 0,
					"rope" : [0,25],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-22-1-0",
					"origin" : [9,36],
					"z" : 0,
					"rope" : [0,39],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-22-2-0",
					"origin" : [7,36],
					"z" : 0,
					"rope" : [0,39],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-22-3-0",
					"origin" : [15,20],
					"z" : 0,
					"rope" : [0,26],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-22-4-0",
					"origin" : [6,20],
					"z" : 0,
					"rope" : [0,26],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-22-5-0",
					"origin" : [9,108],
					"z" : 0,
					"rope" : [0,114],
				},
			},
		},
		"23" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-23-0-0",
					"origin" : [11,22],
					"z" : 0,
					"rope" : [0,25],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-23-1-0",
					"origin" : [9,36],
					"z" : 0,
					"rope" : [0,39],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-23-2-0",
					"origin" : [7,36],
					"z" : 0,
					"rope" : [0,39],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-23-3-0",
					"origin" : [6,20],
					"z" : 0,
					"rope" : [0,26],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-23-4-0",
					"origin" : [9,108],
					"z" : 0,
					"rope" : [0,114],
				},
			},
		},
		"24" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-24-0-0",
					"origin" : [5,25],
					"z" : 0,
					"rope" : [1,37],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-24-1-0",
					"origin" : [3,15],
					"z" : 0,
					"rope" : [1,25],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-24-2-0",
					"origin" : [3,15],
					"z" : 0,
					"rope" : [1,27],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-24-3-0",
					"origin" : [3,60],
					"z" : 0,
					"rope" : [1,72],
				},
			},
		},
		"25" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-25-0-0",
					"origin" : [18,23],
					"z" : 0,
					"rope" : [0,50],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-25-1-0",
					"origin" : [3,24],
					"z" : 0,
					"rope" : [0,42],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-25-2-0",
					"origin" : [9,24],
					"z" : 0,
					"rope" : [-2,43],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-25-3-0",
					"origin" : [3,72],
					"z" : 0,
					"rope" : [0,88],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-25-4-0",
					"origin" : [13,22],
					"z" : 0,
					"rope" : [0,50],
				},
			},
		},
		"26" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-26-0-0",
					"origin" : [7,10],
					"z" : 0,
					"rope" : [0,37],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-26-1-0",
					"origin" : [4,18],
					"z" : 0,
					"rope" : [0,36],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-26-2-0",
					"origin" : [6,15],
					"z" : 0,
					"rope" : [0,33],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-26-3-0",
					"origin" : [4,72],
					"z" : 0,
					"rope" : [0,89],
				},
			},
		},
		"27" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-27-0-0",
					"origin" : [9,12],
					"z" : 0,
					"rope" : [0,18],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-27-1-0",
					"origin" : [3,21],
					"z" : 0,
					"rope" : [0,26],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-27-2-0",
					"origin" : [7,13],
					"z" : 0,
					"rope" : [-1,18],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-27-3-0",
					"origin" : [3,84],
					"z" : 0,
					"rope" : [0,89],
				},
			},
		},
		"28" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-28-0-0",
					"origin" : [2,9],
					"z" : 0,
					"rope" : [1,11],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-28-1-0",
					"origin" : [5,10],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-28-2-0",
					"origin" : [15,30],
					"z" : 0,
					"rope" : [-2,21],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-28-3-0",
					"origin" : [25,73],
					"z" : 0,
					"rope" : [-4,-35],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-28-4-0",
					"origin" : [2,31],
					"z" : 0,
					"rope" : [1,34],
				},
			},
		},
		"29" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-29-0-0",
					"origin" : [2,9],
					"z" : 0,
					"rope" : [0,11],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-29-1-0",
					"origin" : [11,12],
					"z" : 0,
					"rope" : [9,9],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-29-2-0",
					"origin" : [2,27],
					"z" : 0,
					"rope" : [0,29],
				},
			},
		},
		"30" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-30-0-0",
					"origin" : [6,17],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-30-1-0",
					"origin" : [4,9],
					"z" : 0,
					"rope" : [1,12],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-30-2-0",
					"origin" : [4,9],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-30-3-0",
					"origin" : [4,28],
					"z" : 0,
					"rope" : [1,31],
				},
			},
		},
		"31" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-31-0-0",
					"origin" : [8,10],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-31-1-0",
					"origin" : [2,18],
					"z" : 0,
					"rope" : [0,20],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-31-2-0",
					"origin" : [2,72],
					"z" : 0,
					"rope" : [0,75],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-31-3-0",
					"origin" : [4,9],
					"z" : 0,
					"rope" : [0,11],
				},
			},
		},
		"32" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-32-0-0",
					"origin" : [20,24],
					"z" : 0,
					"rope" : [-10,27],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-32-1-0",
					"origin" : [3,28],
					"z" : 0,
					"rope" : [0,30],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-32-2-0",
					"origin" : [3,15],
					"z" : 0,
					"rope" : [0,18],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-32-3-0",
					"origin" : [3,112],
					"z" : 0,
					"rope" : [0,114],
				},
			},
		},
		"33" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-33-0-0",
					"origin" : [13,16],
					"z" : 0,
					"rope" : [5,19],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-33-1-0",
					"origin" : [4,22],
					"z" : 0,
					"rope" : [0,25],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-33-2-0",
					"origin" : [4,11],
					"z" : 0,
					"rope" : [0,13],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-33-3-0",
					"origin" : [4,90],
					"z" : 0,
					"rope" : [0,92],
				},
			},
		},
		"34" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-34-0-0",
					"origin" : [13,62],
					"z" : 0,
					"rope" : [0,61],
				},
			},
		},
		"35" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-35-0-0",
					"origin" : [15,80],
					"z" : 0,
					"rope" : [0,-24],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-35-1-0",
					"origin" : [9,36],
					"z" : 0,
					"rope" : [0,56],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-35-2-0",
					"origin" : [10,-36],
					"z" : 0,
					"rope" : [0,113],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-35-3-0",
					"origin" : [16,-104],
					"z" : 0,
					"rope" : [0,154],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-35-4-0",
					"origin" : [10,36],
					"z" : 0,
					"rope" : [0,125],
				},
			},
		},
		"36" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-36-0-0",
					"origin" : [11,22],
					"z" : 0,
					"rope" : [0,34],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-36-1-0",
					"origin" : [9,36],
					"z" : 0,
					"rope" : [0,51],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-36-2-0",
					"origin" : [7,36],
					"z" : 0,
					"rope" : [0,47],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-36-3-0",
					"origin" : [6,20],
					"z" : 0,
					"rope" : [0,26],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-36-4-0",
					"origin" : [9,108],
					"z" : 0,
					"rope" : [0,53],
				},
			},
		},
		"37" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-37-0-0",
					"origin" : [11,125],
					"z" : 0,
					"rope" : [2,-71],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-37-1-0",
					"origin" : [5,81],
					"z" : 0,
					"rope" : [2,4],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-37-2-0",
					"origin" : [6,9],
					"z" : 0,
					"rope" : [2,74],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-37-3-0",
					"origin" : [12,-63],
					"z" : 0,
					"rope" : [2,102],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-37-4-0",
					"origin" : [6,81],
					"z" : 0,
					"rope" : [2,82],
				},
			},
		},
		"38" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-38-0-0",
					"origin" : [11,22],
					"z" : 0,
					"rope" : [0,32],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-38-1-0",
					"origin" : [9,36],
					"z" : 0,
					"rope" : [0,45],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-38-2-0",
					"origin" : [7,36],
					"z" : 0,
					"rope" : [0,45],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-38-3-0",
					"origin" : [6,20],
					"z" : 0,
					"rope" : [0,26],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-38-4-0",
					"origin" : [9,108],
					"z" : 0,
					"rope" : [0,48],
				},
			},
		},
		"39" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-39-0-0",
					"origin" : [9,26],
					"z" : 0,
					"rope" : [3,37],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-39-1-0",
					"origin" : [2,-27],
					"z" : 0,
					"rope" : [3,60],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-39-2-0",
					"origin" : [2,-47],
					"z" : 0,
					"rope" : [3,80],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-39-3-0",
					"origin" : [9,26],
					"z" : 0,
					"rope" : [-3,37],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-39-4-0",
					"origin" : [9,-27],
					"z" : 0,
					"rope" : [-3,60],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-39-5-0",
					"origin" : [9,-47],
					"z" : 0,
					"rope" : [-3,79],
				},
			},
		},
		"40" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-40-0-0",
					"origin" : [0,0],
				},
			},
		},
		"41" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-41-0-0",
					"origin" : [0,0],
				},
			},
		},
		"42" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-42-0-0",
					"origin" : [0,0],
				},
			},
		},
		"43" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-43-0-0",
					"origin" : [9,13],
					"z" : 0,
					"rope" : [-2,16],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-43-1-0",
					"origin" : [6,18],
					"z" : 0,
					"rope" : [-2,25],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-43-2-0",
					"origin" : [8,15],
					"z" : 0,
					"rope" : [-2,24],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-43-3-0",
					"origin" : [6,72],
					"z" : 0,
					"rope" : [-2,79],
				},
			},
		},
		"44" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-44-0-0",
					"origin" : [13,22],
					"z" : 0,
					"rope" : [0,27],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-44-1-0",
					"origin" : [13,22],
					"z" : 0,
					"rope" : [0,27],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-44-2-0",
					"origin" : [4,22],
					"z" : 0,
					"rope" : [0,28],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-44-3-0",
					"origin" : [4,3],
					"z" : 0,
					"rope" : [0,14],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-44-4-0",
					"origin" : [4,75],
					"z" : 0,
					"rope" : [0,81],
				},
			},
		},
		"45" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-45-0-0",
					"origin" : [4,13],
					"z" : 0,
					"rope" : [0,27],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-45-1-0",
					"origin" : [3,18],
					"z" : 0,
					"rope" : [0,28],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-45-2-0",
					"origin" : [6,15],
					"z" : 0,
					"rope" : [0,25],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-45-3-0",
					"origin" : [3,72],
					"z" : 0,
					"rope" : [0,81],
				},
			},
		},
		"46" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-46-0-0",
					"origin" : [13,22],
					"z" : 0,
					"rope" : [0,27],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-46-1-0",
					"origin" : [4,22],
					"z" : 0,
					"rope" : [0,4],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-46-2-0",
					"origin" : [4,3],
					"z" : 0,
					"rope" : [0,25],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-46-3-0",
					"origin" : [4,75],
					"z" : 0,
					"rope" : [0,63],
				},
			},
		},
		"47" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-47-0-0",
					"origin" : [15,20],
					"z" : 0,
					"rope" : [4,40],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-47-1-0",
					"origin" : [1,-20],
					"z" : 0,
					"rope" : [4,46],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-47-2-0",
					"origin" : [1,108],
					"z" : 0,
					"rope" : [4,153],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-47-3-0",
					"origin" : [5,-37],
					"z" : 0,
					"rope" : [4,84],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-47-4-0",
					"origin" : [15,20],
					"z" : 0,
					"rope" : [4,25],
				},
			},
		},
		"48" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-48-0-0",
					"origin" : [6,24],
					"z" : 0,
					"rope" : [0,27],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-48-1-0",
					"origin" : [2,15],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-48-2-0",
					"origin" : [4,15],
					"z" : 0,
					"rope" : [0,18],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-48-3-0",
					"origin" : [2,60],
					"z" : 0,
					"rope" : [0,62],
				},
			},
		},
		"49" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-49-0-0",
					"origin" : [10,11],
					"z" : 0,
					"rope" : [0,24],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-49-1-0",
					"origin" : [2,8],
					"z" : 0,
					"rope" : [0,13],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-49-2-0",
					"origin" : [5,9],
					"z" : 0,
					"rope" : [0,18],
				},
			},
		},
		"50" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-50-0-0",
					"origin" : [11,22],
					"z" : 0,
					"rope" : [0,31],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-50-1-0",
					"origin" : [6,-21],
					"z" : 0,
					"rope" : [0,66],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-50-2-0",
					"origin" : [9,-22],
					"z" : 0,
					"rope" : [0,70],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-50-3-0",
					"origin" : [7,-22],
					"z" : 0,
					"rope" : [0,69],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-50-4-0",
					"origin" : [6,-22],
					"z" : 0,
					"rope" : [0,71],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-50-5-0",
					"origin" : [6,-22],
					"z" : 0,
					"rope" : [0,64],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/rope-50-6-0",
					"origin" : [13,114],
					"z" : 0,
					"rope" : [-2,114],
				},
			},
		},
		"51" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-51-0-0",
					"origin" : [11,22],
					"z" : 0,
					"rope" : [2,111],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-51-1-0",
					"origin" : [5,-22],
					"z" : 0,
					"rope" : [2,70],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-51-2-0",
					"origin" : [3,-22],
					"z" : 0,
					"rope" : [2,71],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-51-3-0",
					"origin" : [4,-22],
					"z" : 0,
					"rope" : [2,66],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-51-4-0",
					"origin" : [6,-22],
					"z" : 0,
					"rope" : [2,70],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-51-5-0",
					"origin" : [12,-22],
					"z" : 0,
					"rope" : [2,73],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/rope-51-6-0",
					"origin" : [13,114],
					"z" : 0,
					"rope" : [1,114],
				},
			},
		},
		"52" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-52-0-0",
					"origin" : [9,17],
					"z" : 0,
					"rope" : [-4,26],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-52-1-0",
					"origin" : [9,-17],
					"z" : 0,
					"rope" : [-4,40],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-52-2-0",
					"origin" : [12,-17],
					"z" : 0,
					"rope" : [-4,64],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-52-3-0",
					"origin" : [11,95],
					"z" : 0,
					"rope" : [-2,105],
				},
			},
		},
		"53" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-53-0-0",
					"origin" : [10,13],
					"z" : 0,
					"rope" : [-5,26],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-53-1-0",
					"origin" : [9,-17],
					"z" : 0,
					"rope" : [-4,40],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-53-2-0",
					"origin" : [12,-17],
					"z" : 0,
					"rope" : [-1,71],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-53-3-0",
					"origin" : [5,56],
					"z" : 0,
					"rope" : [0,64],
				},
			},
		},
		"54" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-54-0-0",
					"origin" : [13,23],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-54-1-0",
					"origin" : [6,14],
					"z" : 0,
					"rope" : [1,17],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-54-2-0",
					"origin" : [7,-15],
					"z" : 0,
					"rope" : [1,45],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-54-3-0",
					"origin" : [6,40],
					"z" : 0,
					"rope" : [1,49],
				},
			},
		},
		"55" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-55-0-0",
					"origin" : [12,22],
					"z" : 0,
					"rope" : [3,36],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-55-1-0",
					"origin" : [5,-22],
					"z" : 0,
					"rope" : [1,70],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-55-2-0",
					"origin" : [4,-22],
					"z" : 0,
					"rope" : [3,71],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-55-3-0",
					"origin" : [7,-22],
					"z" : 0,
					"rope" : [2,66],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-55-4-0",
					"origin" : [12,-19],
					"z" : 0,
					"rope" : [2,89],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-55-5-0",
					"origin" : [12,-22],
					"z" : 0,
					"rope" : [-3,145],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/rope-55-6-0",
					"origin" : [13,114],
					"z" : 0,
					"rope" : [2,141],
				},
			},
		},
		"56" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-56-0-0",
					"origin" : [11,21],
					"z" : 0,
					"rope" : [-6,22],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-56-1-0",
					"origin" : [5,-22],
					"z" : 0,
					"rope" : [0,44],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-56-2-0",
					"origin" : [3,-22],
					"z" : 0,
					"rope" : [8,89],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-56-3-0",
					"origin" : [4,-22],
					"z" : 0,
					"rope" : [1,101],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-56-4-0",
					"origin" : [13,114],
					"z" : 0,
					"rope" : [-2,119],
				},
			},
		},
		"57" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-57-0-0",
					"origin" : [6,25],
					"z" : 0,
					"rope" : [0,27],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-57-1-0",
					"origin" : [3,15],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-57-2-0",
					"origin" : [6,15],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-57-3-0",
					"origin" : [4,60],
					"z" : 0,
					"rope" : [0,62],
				},
			},
		},
		"58" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-58-0-0",
					"origin" : [13,22],
					"z" : 0,
					"rope" : [0,27],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-58-1-0",
					"origin" : [4,15],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-58-2-0",
					"origin" : [4,11],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-58-3-0",
					"origin" : [4,45],
					"z" : 0,
					"rope" : [0,48],
				},
			},
		},
		"59" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-59-0-0",
					"origin" : [10,20],
					"z" : 0,
					"rope" : [0,27],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-59-1-0",
					"origin" : [9,15],
					"z" : 0,
					"rope" : [0,20],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-59-2-0",
					"origin" : [9,19],
					"z" : 0,
					"rope" : [0,22],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-59-3-0",
					"origin" : [12,60],
					"z" : 0,
					"rope" : [0,70],
				},
			},
		},
		"60" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-60-0-0",
					"origin" : [6,13],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-60-1-0",
					"origin" : [5,26],
					"z" : 0,
					"rope" : [0,28],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-60-2-0",
					"origin" : [5,13],
					"z" : 0,
					"rope" : [0,14],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-60-3-0",
					"origin" : [7,13],
					"z" : 0,
					"rope" : [0,14],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-60-4-0",
					"origin" : [11,13],
					"z" : 0,
					"rope" : [0,25],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-60-5-0",
					"origin" : [6,14],
					"z" : 0,
					"rope" : [0,17],
				},
			},
		},
		"61" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-61-0-0",
					"origin" : [9,17],
					"z" : 0,
					"rope" : [-5,23],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-61-1-0",
					"origin" : [4,7],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-61-2-0",
					"origin" : [4,10],
					"z" : 0,
					"rope" : [0,17],
				},
			},
		},
		"62" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-62-0-0",
					"origin" : [11,22],
					"z" : 0,
					"rope" : [0,23],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-62-1-0",
					"origin" : [5,18],
					"z" : 0,
					"rope" : [0,28],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-62-2-0",
					"origin" : [4,19],
					"z" : 0,
					"rope" : [0,22],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-62-3-0",
					"origin" : [4,20],
					"z" : 0,
					"rope" : [0,20],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-62-4-0",
					"origin" : [6,17],
					"z" : 0,
					"rope" : [0,25],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-62-5-0",
					"origin" : [2,18],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/rope-62-6-0",
					"origin" : [6,69],
					"z" : 0,
					"rope" : [0,74],
				},
			},
		},
		"63" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-63-0-0",
					"origin" : [10,16],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-63-1-0",
					"origin" : [2,10],
					"z" : 0,
					"rope" : [0,14],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-63-2-0",
					"origin" : [5,9],
					"z" : 0,
					"rope" : [0,14],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-63-3-0",
					"origin" : [2,49],
					"z" : 0,
					"rope" : [0,48],
				},
			},
		},
		"64" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-64-0-0",
					"origin" : [9,17],
					"z" : 0,
					"rope" : [-5,23],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-64-1-0",
					"origin" : [9,1],
					"z" : 0,
					"rope" : [-5,23],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-64-2-0",
					"origin" : [13,14],
					"z" : 0,
					"rope" : [-5,17],
				},
			},
		},
		"65" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-65-0-0",
					"origin" : [11,22],
					"z" : 0,
					"rope" : [3,27],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-65-1-0",
					"origin" : [5,18],
					"z" : 0,
					"rope" : [0,22],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-65-2-0",
					"origin" : [6,18],
					"z" : 0,
					"rope" : [0,21],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-65-3-0",
					"origin" : [8,18],
					"z" : 0,
					"rope" : [0,22],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-65-4-0",
					"origin" : [13,14],
					"z" : 0,
					"rope" : [0,15],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-65-5-0",
					"origin" : [13,109],
					"z" : 0,
					"rope" : [0,108],
				},
			},
		},
		"66" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-66-0-0",
					"origin" : [9,24],
					"z" : 0,
					"rope" : [0,25],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-66-1-0",
					"origin" : [2,60],
					"z" : 0,
					"rope" : [0,62],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-66-2-0",
					"origin" : [2,15],
					"z" : 0,
					"rope" : [0,16],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-66-3-0",
					"origin" : [5,15],
					"z" : 0,
					"rope" : [0,16],
				},
			},
		},
		"67" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-67-0-0",
					"origin" : [9,14],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-67-1-0",
					"origin" : [4,9],
					"z" : 0,
					"rope" : [0,19],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-67-2-0",
					"origin" : [6,15],
					"z" : 0,
					"rope" : [0,14],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-67-3-0",
					"origin" : [4,27],
					"z" : 0,
					"rope" : [0,37],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-67-4-0",
					"origin" : [4,80],
					"z" : 0,
					"rope" : [0,90],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-67-5-0",
					"origin" : [9,92],
					"z" : 0,
					"rope" : [0,91],
				},
			},
		},
		"68" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-68-0-0",
					"origin" : [9,14],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-68-1-0",
					"origin" : [4,9],
					"z" : 0,
					"rope" : [0,19],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-68-2-0",
					"origin" : [6,15],
					"z" : 0,
					"rope" : [0,14],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-68-3-0",
					"origin" : [4,27],
					"z" : 0,
					"rope" : [0,37],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-68-4-0",
					"origin" : [4,80],
					"z" : 0,
					"rope" : [0,90],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-68-5-0",
					"origin" : [9,92],
					"z" : 0,
					"rope" : [0,91],
				},
			},
		},
		"69" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-69-0-0",
					"origin" : [13,27],
					"z" : 0,
					"rope" : [0,31],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-69-1-0",
					"origin" : [10,15],
					"z" : 0,
					"rope" : [0,18],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-69-2-0",
					"origin" : [13,15],
					"z" : 0,
					"rope" : [0,18],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-69-3-0",
					"origin" : [11,19],
					"z" : 0,
					"rope" : [0,22],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-69-4-0",
					"origin" : [13,30],
					"z" : 0,
					"rope" : [0,33],
				},
			},
		},
		"70" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-70-0-0",
					"origin" : [13,23],
					"z" : 0,
					"rope" : [0,27],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-70-1-0",
					"origin" : [4,15],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-70-2-0",
					"origin" : [4,11],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-70-3-0",
					"origin" : [4,45],
					"z" : 0,
					"rope" : [0,48],
				},
			},
		},
		"71" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-71-0-0",
					"origin" : [14,25],
					"z" : 0,
					"rope" : [-1,23],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-71-1-0",
					"origin" : [7,19],
					"z" : 0,
					"rope" : [-1,18],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-71-2-0",
					"origin" : [10,17],
					"z" : 0,
					"rope" : [-1,21],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-71-3-0",
					"origin" : [8,18],
					"z" : 0,
					"rope" : [-1,20],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-71-4-0",
					"origin" : [7,16],
					"z" : 0,
					"rope" : [-1,22],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-71-5-0",
					"origin" : [7,18],
					"z" : 0,
					"rope" : [-1,15],
				},
			},
		},
		"72" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-72-0-0",
					"origin" : [15,23],
					"z" : 0,
					"rope" : [-1,28],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-72-1-0",
					"origin" : [4,7],
					"z" : 0,
					"rope" : [1,9],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-72-2-0",
					"origin" : [4,37],
					"z" : 0,
					"rope" : [1,39],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-72-3-0",
					"origin" : [4,75],
					"z" : 0,
					"rope" : [1,76],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-72-4-0",
					"origin" : [4,3],
					"z" : 0,
					"rope" : [1,2],
				},
			},
		},
		"73" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-73-0-0",
					"origin" : [11,25],
					"z" : 0,
					"rope" : [-1,23],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-73-1-0",
					"origin" : [6,17],
					"z" : 0,
					"rope" : [-1,18],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-73-2-0",
					"origin" : [9,17],
					"z" : 0,
					"rope" : [-1,21],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-73-3-0",
					"origin" : [7,17],
					"z" : 0,
					"rope" : [-1,20],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-73-4-0",
					"origin" : [6,17],
					"z" : 0,
					"rope" : [-1,22],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-73-5-0",
					"origin" : [6,8],
					"z" : 0,
					"rope" : [-1,15],
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "connect.img/rope-73-6-0",
					"origin" : [11,25],
					"z" : 0,
					"rope" : [-1,23],
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "connect.img/rope-73-7-0",
					"origin" : [8,17],
					"z" : 0,
					"rope" : [-1,18],
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "connect.img/rope-73-8-0",
					"origin" : [6,17],
					"z" : 0,
					"rope" : [-1,21],
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "connect.img/rope-73-9-0",
					"origin" : [7,17],
					"z" : 0,
					"rope" : [-1,20],
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "connect.img/rope-73-10-0",
					"origin" : [9,17],
					"z" : 0,
					"rope" : [-1,22],
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "connect.img/rope-73-11-0",
					"origin" : [15,17],
					"z" : 0,
					"rope" : [-1,15],
				},
			},
		},
		"74" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-74-0-0",
					"origin" : [11,34],
					"z" : 0,
					"rope" : [1,33],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-74-1-0",
					"origin" : [3,34],
					"z" : 0,
					"rope" : [1,32],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-74-2-0",
					"origin" : [3,71],
					"z" : 0,
					"rope" : [1,71],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-74-3-0",
					"origin" : [5,23],
					"z" : 0,
					"rope" : [1,17],
				},
			},
		},
		"75" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-75-0-0",
					"origin" : [11,24],
					"z" : 0,
					"rope" : [4,25],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-75-1-0",
					"origin" : [6,7],
					"z" : 0,
					"rope" : [1,8],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-75-2-0",
					"origin" : [6,4],
					"z" : 0,
					"rope" : [1,4],
				},
			},
		},
		"76" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-76-0-0",
					"origin" : [9,17],
					"z" : 0,
					"rope" : [-4,17],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-76-1-0",
					"origin" : [4,7],
					"z" : 0,
					"rope" : [1,8],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-76-2-0",
					"origin" : [7,18],
					"z" : 0,
					"rope" : [1,18],
				},
			},
		},
		"77" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-77-0-0",
					"origin" : [21,57],
					"z" : 0,
					"rope" : [0,1],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-77-1-0",
					"origin" : [13,13],
					"z" : 0,
					"rope" : [0,14],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-77-2-0",
					"origin" : [18,6],
					"z" : 0,
					"rope" : [0,45],
				},
			},
		},
		"78" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-78-0-0",
					"origin" : [10,14],
					"z" : 0,
					"rope" : [0,17],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-78-1-0",
					"origin" : [8,13],
					"z" : 0,
					"rope" : [0,18],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-78-2-0",
					"origin" : [12,8],
					"z" : 0,
					"rope" : [0,11],
				},
			},
		},
		"79" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-79-0-0",
					"origin" : [9,23],
					"z" : 0,
					"rope" : [4,30],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-79-1-0",
					"origin" : [0,0],
					"z" : 0,
					"rope" : [4,21],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-79-2-0",
					"origin" : [0,0],
					"z" : 0,
					"rope" : [4,13],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-79-3-0",
					"origin" : [0,0],
					"z" : 0,
					"rope" : [4,80],
				},
			},
		},
		"80" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-80-0-0",
					"origin" : [11,20],
					"z" : 0,
					"rope" : [3,30],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-80-1-0",
					"origin" : [11,20],
					"z" : 0,
					"rope" : [4,20],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-80-2-0",
					"origin" : [7,20],
					"z" : 0,
					"rope" : [2,20],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-80-3-0",
					"origin" : [10,20],
					"z" : 0,
					"rope" : [4,20],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-80-4-0",
					"origin" : [11,60],
					"z" : 0,
					"rope" : [4,60],
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "connect.img/rope-80-5-0",
					"origin" : [8,21],
					"z" : 0,
					"rope" : [3,26],
				},
			},
		},
		"81" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-81-0-0",
					"origin" : [8,121],
					"z" : 0,
					"rope" : [2,-71],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-81-1-0",
					"origin" : [13,81],
					"z" : 0,
					"rope" : [2,4],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-81-2-0",
					"origin" : [16,9],
					"z" : 0,
					"rope" : [2,74],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-81-3-0",
					"origin" : [10,-58],
					"z" : 0,
					"rope" : [2,102],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-81-4-0",
					"origin" : [16,81],
					"z" : 0,
					"rope" : [2,82],
				},
			},
		},
		"82" :  {
			"0" :  {
				"0" :  {
					"png_path": "connect.img/rope-82-0-0",
					"origin" : [8,121],
					"z" : 0,
					"rope" : [2,-71],
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "connect.img/rope-82-1-0",
					"origin" : [13,81],
					"z" : 0,
					"rope" : [2,4],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "connect.img/rope-82-2-0",
					"origin" : [16,9],
					"z" : 0,
					"rope" : [2,74],
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "connect.img/rope-82-3-0",
					"origin" : [10,-58],
					"z" : 0,
					"rope" : [2,102],
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "connect.img/rope-82-4-0",
					"origin" : [16,81],
					"z" : 0,
					"rope" : [2,82],
				},
			},
		},
	},
};

