var Objguide = Objguide || { }; 
Objguide =   {
	"id":"guide",
	"dryRock" :  {
		"bone" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/dryRock-bone-0-0",
					"origin" : [63,103],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/dryRock-bone-1-0",
					"origin" : [40,40],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/dryRock-bone-2-0",
					"origin" : [40,40],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/dryRock-bone-3-0",
					"origin" : [57,17],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/dryRock-bone-4-0",
					"origin" : [57,17],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/dryRock-bone-5-0",
					"origin" : [40,40],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/dryRock-bone-6-0",
					"origin" : [40,40],
					"z" : 0,
				},
			},
		},
	},
	"midForest" :  {
		"danger" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/midForest-danger-0-0",
					"origin" : [33,38],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/midForest-danger-1-0",
					"origin" : [33,40],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/midForest-danger-2-0",
					"origin" : [33,38],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/midForest-danger-3-0",
					"origin" : [39,45],
					"z" : 0,
				},
			},
		},
		"wood" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/midForest-wood-0-0",
					"origin" : [42,72],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/midForest-wood-1-0",
					"origin" : [27,19],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/midForest-wood-2-0",
					"origin" : [26,18],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/midForest-wood-3-0",
					"origin" : [23,10],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/midForest-wood-4-0",
					"origin" : [25,9],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/midForest-wood-5-0",
					"origin" : [27,19],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/midForest-wood-6-0",
					"origin" : [26,18],
					"z" : 0,
				},
			},
		},
	},
	"common" :  {
		"sign" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/common-sign-0-0",
					"origin" : [26,60],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/common-sign-1-0",
					"origin" : [21,55],
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/common-sign-2-0",
					"origin" : [37,67],
					"z" : 0,
				},
			},
		},
		"post" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/common-post-0-0",
					"origin" : [91,55],
					"z" : 0,
				},
			},
		},
		"tour" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/common-tour-0-0",
					"origin" : [106,97],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/common-tour-1-0",
					"origin" : [0,0],
				},
			},
		},
	},
	"darkWood" :  {
		"number" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/darkWood-number-0-0",
					"origin" : [5,9],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/darkWood-number-1-0",
					"origin" : [7,9],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/darkWood-number-2-0",
					"origin" : [7,9],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/darkWood-number-3-0",
					"origin" : [8,9],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/darkWood-number-4-0",
					"origin" : [7,9],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/darkWood-number-5-0",
					"origin" : [7,9],
					"z" : 0,
				},
			},
		},
	},
	"grassySoil" :  {
		"number" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/grassySoil-number-0-0",
					"origin" : [29,22],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/grassySoil-number-1-0",
					"origin" : [29,22],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/grassySoil-number-2-0",
					"origin" : [29,22],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/grassySoil-number-3-0",
					"origin" : [29,22],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/grassySoil-number-4-0",
					"origin" : [29,22],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/grassySoil-number-5-0",
					"origin" : [29,22],
					"z" : 0,
				},
			},
		},
	},
	"maple" :  {
		"suryun" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/maple-suryun-0-0",
					"origin" : [144,127],
					"z" : 0,
				},
			},
		},
		"board" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/maple-board-0-0",
					"origin" : [71,82],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/maple-board-1-0",
					"origin" : [38,21],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/maple-board-1-1",
					"origin" : [37,21],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/maple-board-1-2",
					"origin" : [36,21],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/maple-board-1-3",
					"origin" : [37,21],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/maple-board-1-4",
					"origin" : [38,21],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/maple-board-1-5",
					"origin" : [38,21],
					"z" : 0,
				},
				"6" :  {
					"png_path": "guide.img/maple-board-1-6",
					"origin" : [39,21],
					"z" : 0,
				},
			},
		},
		"startPoint" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/maple-startPoint-0-0",
					"origin" : [163,161],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/maple-startPoint-1-0",
					"origin" : [62,90],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/maple-startPoint-1-1",
					"origin" : [60,88],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/maple-startPoint-1-2",
					"origin" : [58,88],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/maple-startPoint-1-3",
					"origin" : [60,88],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/maple-startPoint-1-4",
					"origin" : [71,88],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/maple-startPoint-1-5",
					"origin" : [71,88],
					"z" : 0,
				},
				"6" :  {
					"png_path": "guide.img/maple-startPoint-1-6",
					"origin" : [70,88],
					"z" : 0,
				},
				"7" :  {
					"png_path": "guide.img/maple-startPoint-1-7",
					"origin" : [67,89],
					"z" : 0,
				},
				"8" :  {
					"png_path": "guide.img/maple-startPoint-1-8",
					"origin" : [66,90],
					"z" : 0,
				},
				"9" :  {
					"png_path": "guide.img/maple-startPoint-1-9",
					"origin" : [62,91],
					"z" : 0,
				},
				"10" :  {
					"png_path": "guide.img/maple-startPoint-1-10",
					"origin" : [60,91],
					"z" : 0,
				},
				"11" :  {
					"png_path": "guide.img/maple-startPoint-1-11",
					"origin" : [58,91],
					"z" : 0,
				},
				"12" :  {
					"png_path": "guide.img/maple-startPoint-1-12",
					"origin" : [60,91],
					"z" : 0,
				},
				"13" :  {
					"png_path": "guide.img/maple-startPoint-1-13",
					"origin" : [71,91],
					"z" : 0,
				},
				"14" :  {
					"png_path": "guide.img/maple-startPoint-1-14",
					"origin" : [71,91],
					"z" : 0,
				},
				"15" :  {
					"png_path": "guide.img/maple-startPoint-1-15",
					"origin" : [70,90],
					"z" : 0,
				},
				"16" :  {
					"png_path": "guide.img/maple-startPoint-1-16",
					"origin" : [67,90],
					"z" : 0,
				},
				"17" :  {
					"png_path": "guide.img/maple-startPoint-1-17",
					"origin" : [66,90],
					"z" : 0,
				},
			},
		},
		"key" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/maple-key-0-0",
					"origin" : [20,19],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/maple-key-1-0",
					"origin" : [20,19],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/maple-key-2-0",
					"origin" : [20,19],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/maple-key-3-0",
					"origin" : [20,19],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/maple-key-4-0",
					"origin" : [25,19],
					"z" : 0,
				},
			},
		},
	},
	"milepost" :  {
		"common" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-common-0-0",
					"origin" : [14,11],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-common-1-0",
					"origin" : [10,30],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-common-2-0",
					"origin" : [13,21],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-common-3-0",
					"origin" : [23,22],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-common-4-0",
					"origin" : [24,20],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-common-5-0",
					"origin" : [26,18],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-common-6-0",
					"origin" : [26,19],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-common-7-0",
					"origin" : [24,24],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "guide.img/milepost-common-8-0",
					"origin" : [24,19],
					"z" : 0,
				},
			},
		},
		"digital" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-digital-0-0",
					"origin" : [24,30],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-digital-1-0",
					"origin" : [26,15],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-digital-2-0",
					"origin" : [34,28],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-digital-5-0",
					"origin" : [34,28],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-digital-6-0",
					"origin" : [34,28],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-digital-3-0",
					"origin" : [34,28],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-digital-4-0",
					"origin" : [34,28],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-digital-7-0",
					"origin" : [34,28],
					"z" : 0,
				},
			},
		},
		"orbis" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-orbis-0-0",
					"origin" : [18,13],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-orbis-1-0",
					"origin" : [7,30],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-orbis-2-0",
					"origin" : [34,34],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-orbis-3-0",
					"origin" : [33,27],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-orbis-4-0",
					"origin" : [34,23],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-orbis-5-0",
					"origin" : [36,13],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-orbis-6-0",
					"origin" : [36,14],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-orbis-7-0",
					"origin" : [33,23],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "guide.img/milepost-orbis-8-0",
					"origin" : [32,26],
					"z" : 0,
				},
			},
		},
		"edelrock" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelrock-0-0",
					"origin" : [58,47],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelrock-1-0",
					"origin" : [28,31],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelrock-2-0",
					"origin" : [29,31],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelrock-3-0",
					"origin" : [29,31],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelrock-4-0",
					"origin" : [29,31],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelrock-5-0",
					"origin" : [29,31],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelrock-6-0",
					"origin" : [29,31],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelrock-7-0",
					"origin" : [29,31],
					"z" : 0,
				},
			},
		},
		"edelpark" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelpark-0-0",
					"origin" : [25,24],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelpark-1-0",
					"origin" : [6,15],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelpark-2-0",
					"origin" : [34,34],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelpark-3-0",
					"origin" : [33,31],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-edelpark-4-0",
					"origin" : [34,31],
					"z" : 0,
				},
			},
		},
		"lioncastle" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-lioncastle-0-0",
					"origin" : [54,30],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-lioncastle-1-0",
					"origin" : [11,36],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-lioncastle-2-0",
					"origin" : [34,38],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-lioncastle-3-0",
					"origin" : [34,38],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-lioncastle-4-0",
					"origin" : [34,38],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-lioncastle-5-0",
					"origin" : [34,38],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-lioncastle-6-0",
					"origin" : [34,38],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-lioncastle-7-0",
					"origin" : [34,38],
					"z" : 0,
				},
			},
		},
		"krease" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-krease-0-0",
					"origin" : [70,56],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-krease-1-0",
					"origin" : [12,30],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-krease-2-0",
					"origin" : [42,37],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-krease-3-0",
					"origin" : [69,42],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-krease-4-0",
					"origin" : [75,37],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-krease-5-0",
					"origin" : [69,43],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-krease-6-0",
					"origin" : [70,43],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-krease-7-0",
					"origin" : [75,37],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "guide.img/milepost-krease-8-0",
					"origin" : [70,44],
					"z" : 0,
				},
			},
		},
		"eurel" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-eurel-0-0",
					"origin" : [42,69],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-eurel-1-0",
					"origin" : [34,33],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-eurel-2-0",
					"origin" : [67,29],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-eurel-3-0",
					"origin" : [63,33],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-eurel-4-0",
					"origin" : [67,29],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-eurel-5-0",
					"origin" : [63,32],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-eurel-6-0",
					"origin" : [63,32],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-eurel-7-0",
					"origin" : [63,32],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "guide.img/milepost-eurel-8-0",
					"origin" : [66,29],
					"z" : 0,
				},
			},
		},
		"henesis" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-henesis-0-0",
					"origin" : [31,18],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-henesis-1-0",
					"origin" : [5,1],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-henesis-2-0",
					"origin" : [29,26],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-henesis-3-0",
					"origin" : [29,23],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-henesis-4-0",
					"origin" : [28,23],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-henesis-5-0",
					"origin" : [30,23],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-henesis-6-0",
					"origin" : [31,23],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-henesis-7-0",
					"origin" : [30,23],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "guide.img/milepost-henesis-8-0",
					"origin" : [28,23],
					"z" : 0,
				},
			},
		},
		"snow" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-snow-0-0",
					"origin" : [28,11],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-snow-1-0",
					"origin" : [13,23],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-snow-2-0",
					"origin" : [23,22],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-snow-3-0",
					"origin" : [24,21],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-snow-4-0",
					"origin" : [26,19],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-snow-5-0",
					"origin" : [26,19],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-snow-6-0",
					"origin" : [24,22],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-snow-7-0",
					"origin" : [24,19],
					"z" : 0,
				},
			},
		},
		"ludi" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ludi-0-0",
					"origin" : [30,14],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ludi-1-0",
					"origin" : [13,27],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ludi-2-0",
					"origin" : [34,37],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ludi-3-0",
					"origin" : [23,25],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ludi-4-0",
					"origin" : [23,20],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ludi-5-0",
					"origin" : [25,20],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ludi-6-0",
					"origin" : [25,20],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ludi-7-0",
					"origin" : [24,21],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ludi-8-0",
					"origin" : [23,20],
					"z" : 0,
				},
			},
		},
		"elnas" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elnas-0-0",
					"origin" : [53,59],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elnas-1-0",
					"origin" : [49,28],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elnas-2-0",
					"origin" : [49,28],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elnas-3-0",
					"origin" : [49,26],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elnas-4-0",
					"origin" : [49,26],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elnas-5-0",
					"origin" : [49,24],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elnas-6-0",
					"origin" : [49,24],
					"z" : 0,
				},
			},
		},
		"aqua" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-aqua-0-0",
					"origin" : [49,32],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-aqua-1-0",
					"origin" : [58,63],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/milepost-aqua-1-1",
					"origin" : [60,63],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-aqua-2-0",
					"origin" : [63,63],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/milepost-aqua-2-1",
					"origin" : [63,63],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-aqua-3-0",
					"origin" : [62,86],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "guide.img/milepost-aqua-3-1",
					"origin" : [61,86],
					"z" : 0,
					"delay" : 150,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-aqua-4-0",
					"origin" : [64,83],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "guide.img/milepost-aqua-4-1",
					"origin" : [66,83],
					"z" : 0,
					"delay" : 150,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-aqua-5-0",
					"origin" : [58,63],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/milepost-aqua-5-1",
					"origin" : [60,63],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-aqua-6-0",
					"origin" : [59,63],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/milepost-aqua-6-1",
					"origin" : [59,63],
					"z" : 0,
				},
			},
		},
		"mureung" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-mureung-0-0",
					"origin" : [64,121],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-mureung-1-0",
					"origin" : [64,89],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-mureung-2-0",
					"origin" : [9,17],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-mureung-3-0",
					"origin" : [30,15],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-mureung-4-0",
					"origin" : [31,29],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-mureung-5-0",
					"origin" : [31,30],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-mureung-6-0",
					"origin" : [29,29],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-mureung-7-0",
					"origin" : [30,29],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "guide.img/milepost-mureung-8-0",
					"origin" : [30,32],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "guide.img/milepost-mureung-9-0",
					"origin" : [31,32],
					"z" : 0,
				},
			},
		},
		"backcho" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-backcho-0-0",
					"origin" : [37,95],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-backcho-1-0",
					"origin" : [31,26],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-backcho-2-0",
					"origin" : [31,20],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-backcho-3-0",
					"origin" : [30,25],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-backcho-4-0",
					"origin" : [31,25],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-backcho-5-0",
					"origin" : [32,20],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-backcho-6-0",
					"origin" : [31,25],
					"z" : 0,
				},
			},
		},
		"elin" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elin-0-0",
					"origin" : [67,97],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elin-1-0",
					"origin" : [45,36],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elin-2-0",
					"origin" : [47,31],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elin-3-0",
					"origin" : [45,41],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elin-4-0",
					"origin" : [46,35],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elin-5-0",
					"origin" : [47,31],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-elin-6-0",
					"origin" : [45,41],
					"z" : 0,
				},
			},
		},
		"poisonforest" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-poisonforest-0-0",
					"origin" : [69,97],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-poisonforest-1-0",
					"origin" : [45,36],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-poisonforest-2-0",
					"origin" : [47,31],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-poisonforest-3-0",
					"origin" : [45,41],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-poisonforest-4-0",
					"origin" : [46,35],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-poisonforest-5-0",
					"origin" : [47,31],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-poisonforest-6-0",
					"origin" : [45,41],
					"z" : 0,
				},
			},
		},
		"timetemple" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-timetemple-0-0",
					"origin" : [16,38],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-timetemple-1-0",
					"origin" : [56,52],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-timetemple-2-0",
					"origin" : [42,52],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-timetemple-3-0",
					"origin" : [42,52],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-timetemple-4-0",
					"origin" : [42,52],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-timetemple-5-0",
					"origin" : [41,52],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-timetemple-6-0",
					"origin" : [57,52],
					"z" : 0,
				},
			},
		},
		"ereb" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ereb-0-0",
					"origin" : [61,40],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ereb-1-0",
					"origin" : [4,18],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ereb-2-0",
					"origin" : [28,23],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ereb-3-0",
					"origin" : [47,32],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ereb-4-0",
					"origin" : [50,31],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ereb-5-0",
					"origin" : [46,31],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ereb-6-0",
					"origin" : [49,31],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ereb-7-0",
					"origin" : [45,32],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "guide.img/milepost-ereb-8-0",
					"origin" : [45,32],
					"z" : 0,
				},
			},
		},
		"rien" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-rien-0-0",
					"origin" : [31,39],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-rien-1-0",
					"origin" : [7,19],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-rien-2-0",
					"origin" : [37,39],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-rien-3-0",
					"origin" : [45,35],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-rien-4-0",
					"origin" : [45,35],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-rien-5-0",
					"origin" : [47,28],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-rien-6-0",
					"origin" : [46,34],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-rien-7-0",
					"origin" : [46,36],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "guide.img/milepost-rien-8-0",
					"origin" : [47,28],
					"z" : 0,
				},
			},
		},
		"farm" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/milepost-farm-0-0",
					"origin" : [32,125],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/milepost-farm-1-0",
					"origin" : [8,12],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/milepost-farm-2-0",
					"origin" : [42,38],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/milepost-farm-3-0",
					"origin" : [43,34],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/milepost-farm-4-0",
					"origin" : [43,34],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/milepost-farm-5-0",
					"origin" : [41,33],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/milepost-farm-6-0",
					"origin" : [43,34],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/milepost-farm-7-0",
					"origin" : [43,39],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "guide.img/milepost-farm-8-0",
					"origin" : [7,12],
					"z" : 0,
				},
			},
		},
	},
	"miniD" :  {
		"portalEff" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/miniD-portalEff-0-0",
					"origin" : [63,95],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "guide.img/miniD-portalEff-0-1",
					"origin" : [63,93],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "guide.img/miniD-portalEff-0-2",
					"origin" : [62,93],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "guide.img/miniD-portalEff-0-3",
					"origin" : [58,93],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "guide.img/miniD-portalEff-0-4",
					"origin" : [57,90],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "guide.img/miniD-portalEff-0-5",
					"origin" : [62,92],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "guide.img/miniD-portalEff-0-6",
					"origin" : [62,94],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "guide.img/miniD-portalEff-0-7",
					"origin" : [63,95],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "guide.img/miniD-portalEff-0-8",
					"origin" : [63,93],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "guide.img/miniD-portalEff-0-9",
					"origin" : [62,93],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "guide.img/miniD-portalEff-0-10",
					"origin" : [58,93],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "guide.img/miniD-portalEff-0-11",
					"origin" : [57,90],
					"z" : 0,
					"delay" : 150,
				},
				"12" :  {
					"png_path": "guide.img/miniD-portalEff-0-12",
					"origin" : [62,92],
					"z" : 0,
					"delay" : 150,
				},
				"13" :  {
					"png_path": "guide.img/miniD-portalEff-0-13",
					"origin" : [62,94],
					"z" : 0,
					"delay" : 150,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/miniD-portalEff-1-0",
					"origin" : [55,82],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "guide.img/miniD-portalEff-1-1",
					"origin" : [55,80],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "guide.img/miniD-portalEff-1-2",
					"origin" : [54,79],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "guide.img/miniD-portalEff-1-3",
					"origin" : [51,80],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "guide.img/miniD-portalEff-1-4",
					"origin" : [50,78],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "guide.img/miniD-portalEff-1-5",
					"origin" : [54,79],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "guide.img/miniD-portalEff-1-6",
					"origin" : [54,80],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "guide.img/miniD-portalEff-1-7",
					"origin" : [55,82],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "guide.img/miniD-portalEff-1-8",
					"origin" : [55,80],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "guide.img/miniD-portalEff-1-9",
					"origin" : [54,79],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "guide.img/miniD-portalEff-1-10",
					"origin" : [51,80],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "guide.img/miniD-portalEff-1-11",
					"origin" : [50,78],
					"z" : 0,
					"delay" : 150,
				},
				"12" :  {
					"png_path": "guide.img/miniD-portalEff-1-12",
					"origin" : [54,79],
					"z" : 0,
					"delay" : 150,
				},
				"13" :  {
					"png_path": "guide.img/miniD-portalEff-1-13",
					"origin" : [54,80],
					"z" : 0,
					"delay" : 150,
				},
			},
		},
	},
	"tutorial" :  {
		"key" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-0-0",
					"origin" : [25,50],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-0-1",
					"origin" : [24,49],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/tutorial-key-0-2",
					"origin" : [23,48],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/tutorial-key-0-3",
					"origin" : [26,49],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/tutorial-key-0-4",
					"origin" : [25,48],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/tutorial-key-0-5",
					"origin" : [26,50],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-1-0",
					"origin" : [26,61],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-1-1",
					"origin" : [25,60],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/tutorial-key-1-2",
					"origin" : [24,59],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/tutorial-key-1-3",
					"origin" : [26,62],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/tutorial-key-1-4",
					"origin" : [26,62],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/tutorial-key-1-5",
					"origin" : [27,62],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-2-0",
					"origin" : [55,60],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-2-1",
					"origin" : [54,59],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/tutorial-key-2-2",
					"origin" : [53,58],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/tutorial-key-2-3",
					"origin" : [55,60],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/tutorial-key-2-4",
					"origin" : [55,60],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/tutorial-key-2-5",
					"origin" : [56,61],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-3-0",
					"origin" : [25,54],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-3-1",
					"origin" : [24,53],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/tutorial-key-3-2",
					"origin" : [23,52],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/tutorial-key-3-3",
					"origin" : [26,53],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/tutorial-key-3-4",
					"origin" : [25,52],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/tutorial-key-3-5",
					"origin" : [26,55],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-4-0",
					"origin" : [26,82],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-4-1",
					"origin" : [25,81],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/tutorial-key-4-2",
					"origin" : [23,80],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/tutorial-key-4-3",
					"origin" : [27,81],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/tutorial-key-4-4",
					"origin" : [27,81],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/tutorial-key-4-5",
					"origin" : [26,83],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-5-0",
					"origin" : [29,38],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-5-1",
					"origin" : [28,37],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/tutorial-key-5-2",
					"origin" : [27,36],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/tutorial-key-5-3",
					"origin" : [30,39],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/tutorial-key-5-4",
					"origin" : [30,39],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/tutorial-key-5-5",
					"origin" : [30,39],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-6-0",
					"origin" : [18,34],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-6-1",
					"origin" : [17,33],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/tutorial-key-6-2",
					"origin" : [16,32],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/tutorial-key-6-3",
					"origin" : [19,33],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/tutorial-key-6-4",
					"origin" : [18,32],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/tutorial-key-6-5",
					"origin" : [19,34],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-7-0",
					"origin" : [29,17],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-7-1",
					"origin" : [28,16],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/tutorial-key-7-2",
					"origin" : [28,16],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/tutorial-key-7-3",
					"origin" : [31,19],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/tutorial-key-7-4",
					"origin" : [31,19],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/tutorial-key-7-5",
					"origin" : [29,17],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-8-0",
					"origin" : [44,15],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-8-1",
					"origin" : [44,14],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/tutorial-key-8-2",
					"origin" : [43,14],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/tutorial-key-8-3",
					"origin" : [47,17],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/tutorial-key-8-4",
					"origin" : [46,17],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/tutorial-key-8-5",
					"origin" : [44,15],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-9-0",
					"origin" : [27,25],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-9-1",
					"origin" : [26,24],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/tutorial-key-9-2",
					"origin" : [25,23],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/tutorial-key-9-3",
					"origin" : [28,24],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/tutorial-key-9-4",
					"origin" : [27,23],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/tutorial-key-9-5",
					"origin" : [28,25],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-10-0",
					"origin" : [25,50],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-10-1",
					"origin" : [24,49],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/tutorial-key-10-2",
					"origin" : [23,48],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/tutorial-key-10-3",
					"origin" : [26,49],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/tutorial-key-10-4",
					"origin" : [25,48],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/tutorial-key-10-5",
					"origin" : [26,50],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-11-0",
					"origin" : [92,19],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-11-1",
					"origin" : [94,18],
					"z" : 0,
					"delay" : 150,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-key-12-0",
					"origin" : [92,19],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "guide.img/tutorial-key-12-1",
					"origin" : [95,20],
					"z" : 0,
					"delay" : 150,
				},
			},
		},
		"suryun" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-suryun-0-0",
					"origin" : [105,98],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-suryun-1-0",
					"origin" : [108,93],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-suryun-2-0",
					"origin" : [120,110],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-suryun-3-0",
					"origin" : [105,105],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "guide.img/tutorial-suryun-4-0",
					"origin" : [158,102],
					"z" : 0,
				},
			},
		},
	},
	"2013detectives" :  {
		"point" :  {
			"0" :  {
				"0" :  {
					"png_path": "guide.img/2013detectives-point-0-0",
					"origin" : [29,30],
					"z" : 0,
				},
				"1" :  {
					"png_path": "guide.img/2013detectives-point-0-1",
					"origin" : [26,29],
					"z" : 0,
				},
				"2" :  {
					"png_path": "guide.img/2013detectives-point-0-2",
					"origin" : [23,26],
					"z" : 0,
				},
				"3" :  {
					"png_path": "guide.img/2013detectives-point-0-3",
					"origin" : [23,24],
					"z" : 0,
				},
				"4" :  {
					"png_path": "guide.img/2013detectives-point-0-4",
					"origin" : [26,21],
					"z" : 0,
				},
				"5" :  {
					"png_path": "guide.img/2013detectives-point-0-5",
					"origin" : [29,21],
					"z" : 0,
				},
				"6" :  {
					"png_path": "guide.img/2013detectives-point-0-6",
					"origin" : [32,24],
					"z" : 0,
				},
				"7" :  {
					"png_path": "guide.img/2013detectives-point-0-7",
					"origin" : [32,27],
					"z" : 0,
				},
			},
		},
	},
};

