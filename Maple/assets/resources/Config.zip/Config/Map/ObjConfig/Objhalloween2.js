var Objhalloween2 = Objhalloween2 || { }; 
Objhalloween2 =   {
	"id":"halloween2",
	"commonObj" :  {
		"roof_purple" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/commonObj-roof_purple-0-0",
					"origin" : [683,126],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/commonObj-roof_purple-1-0",
					"origin" : [121,186],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/commonObj-roof_purple-2-0",
					"origin" : [111,186],
					"z" : 0,
				},
			},
		},
		"floor" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/commonObj-floor-0-0",
					"origin" : [683,77],
					"z" : 0,
				},
			},
		},
		"chandelier" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/commonObj-chandelier-0-0",
					"origin" : [60,61],
					"z" : 0,
				},
			},
		},
		"chandelier_ani" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/commonObj-chandelier_ani-0-0",
					"origin" : [78,-12],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 900,
				},
				"1" :  {
					"png_path": "halloween2.img/commonObj-chandelier_ani-0-1",
					"origin" : [78,-12],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 900,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/commonObj-chandelier_ani-1-0",
					"origin" : [48,24],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 900,
				},
				"1" :  {
					"png_path": "halloween2.img/commonObj-chandelier_ani-1-1",
					"origin" : [48,24],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 900,
				},
			},
		},
	},
	"mainHall" :  {
		"stairs" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-stairs-0-0",
					"origin" : [374,187],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-stairs-1-0",
					"origin" : [229,186],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-stairs-2-0",
					"origin" : [229,186],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-stairs-3-0",
					"origin" : [49,137],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-stairs-4-0",
					"origin" : [49,137],
					"z" : 0,
				},
			},
		},
		"door" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-door-0-0",
					"origin" : [138,137],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-door-1-0",
					"origin" : [140,137],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-door-2-0",
					"origin" : [140,137],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-door-3-0",
					"origin" : [140,137],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-door-4-0",
					"origin" : [140,137],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-door-5-0",
					"origin" : [140,137],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-door-6-0",
					"origin" : [140,137],
					"z" : 0,
					"delay" : 210,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-door-7-0",
					"origin" : [140,137],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-door-8-0",
					"origin" : [197,126],
					"z" : 0,
				},
			},
		},
		"ani" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-ani-0-0",
					"origin" : [48,-13],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween2.img/mainHall-ani-0-1",
					"origin" : [47,-14],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween2.img/mainHall-ani-0-2",
					"origin" : [46,-14],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-ani-1-0",
					"origin" : [78,-12],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 900,
				},
				"1" :  {
					"png_path": "halloween2.img/mainHall-ani-1-1",
					"origin" : [78,-12],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 900,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-ani-2-0",
					"origin" : [108,24],
					"z" : 0,
					"a0" : 100,
					"a1" : 255,
					"delay" : 900,
				},
				"1" :  {
					"png_path": "halloween2.img/mainHall-ani-2-1",
					"origin" : [107,23],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 900,
				},
				"2" :  {
					"png_path": "halloween2.img/mainHall-ani-2-2",
					"origin" : [106,23],
					"z" : 0,
					"a0" : 255,
					"a1" : 100,
					"delay" : 900,
				},
			},
		},
		"foot" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-foot-0-0",
					"origin" : [125,77],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-foot-1-0",
					"origin" : [125,76],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-foot-2-0",
					"origin" : [125,77],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-foot-3-0",
					"origin" : [125,47],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-foot-4-0",
					"origin" : [125,46],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-foot-5-0",
					"origin" : [125,46],
					"z" : 0,
				},
			},
		},
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-obj-0-0",
					"origin" : [99,36],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-obj-1-0",
					"origin" : [57,76],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-obj-2-0",
					"origin" : [47,79],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-obj-3-0",
					"origin" : [47,75],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-obj-4-0",
					"origin" : [99,71],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-obj-5-0",
					"origin" : [104,85],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-obj-6-0",
					"origin" : [38,49],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-obj-7-0",
					"origin" : [47,59],
					"z" : 0,
					"delay" : 210,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-obj-8-0",
					"origin" : [33,34],
					"z" : 0,
				},
			},
		},
		"candle" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-candle-0-0",
					"origin" : [47,38],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-candle-1-0",
					"origin" : [60,61],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/mainHall-candle-2-0",
					"origin" : [120,126],
					"z" : 0,
				},
			},
		},
	},
	"loft" :  {
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/loft-obj-0-0",
					"origin" : [81,40],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/loft-obj-1-0",
					"origin" : [52,39],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/loft-obj-2-0",
					"origin" : [81,40],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/loft-obj-3-0",
					"origin" : [81,40],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/loft-obj-4-0",
					"origin" : [178,126],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween2.img/loft-obj-5-0",
					"origin" : [178,126],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween2.img/loft-obj-6-0",
					"origin" : [146,277],
					"z" : 0,
					"delay" : 210,
				},
			},
		},
		"door" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/loft-door-0-0",
					"origin" : [71,93],
					"z" : 0,
				},
			},
		},
		"roof" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/loft-roof-0-0",
					"origin" : [125,60],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/loft-roof-1-0",
					"origin" : [125,60],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/loft-roof-2-0",
					"origin" : [125,60],
					"z" : 0,
				},
			},
		},
	},
	"hallWay" :  {
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-obj-0-0",
					"origin" : [81,40],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-obj-1-0",
					"origin" : [52,39],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-obj-2-0",
					"origin" : [81,40],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-obj-3-0",
					"origin" : [81,40],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-obj-4-0",
					"origin" : [178,126],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-obj-5-0",
					"origin" : [178,126],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-obj-6-0",
					"origin" : [146,277],
					"z" : 0,
					"delay" : 210,
				},
			},
		},
		"door" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-door-0-0",
					"origin" : [147,140],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-door-1-0",
					"origin" : [147,140],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-door-2-0",
					"origin" : [147,140],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-door-3-0",
					"origin" : [147,140],
					"z" : 0,
				},
			},
		},
		"roof" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-roof-0-0",
					"origin" : [125,35],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-roof-1-0",
					"origin" : [125,35],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/hallWay-roof-2-0",
					"origin" : [125,35],
					"z" : 0,
				},
			},
		},
	},
	"shopiliaRoom" :  {
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/shopiliaRoom-obj-0-0",
					"origin" : [261,155],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/shopiliaRoom-obj-1-0",
					"origin" : [135,71],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/shopiliaRoom-obj-2-0",
					"origin" : [125,76],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/shopiliaRoom-obj-3-0",
					"origin" : [227,246],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/shopiliaRoom-obj-4-0",
					"origin" : [167,246],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween2.img/shopiliaRoom-obj-5-0",
					"origin" : [215,246],
					"z" : 0,
				},
			},
		},
	},
	"object" :  {
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/object-obj-0-0",
					"origin" : [59,69],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/object-obj-1-0",
					"origin" : [44,32],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/object-obj-2-0",
					"origin" : [91,28],
					"z" : 0,
				},
			},
		},
		"obj_ani" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/object-obj_ani-0-0",
					"origin" : [52,35],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween2.img/object-obj_ani-0-1",
					"origin" : [52,35],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween2.img/object-obj_ani-0-2",
					"origin" : [53,36],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween2.img/object-obj_ani-0-3",
					"origin" : [53,36],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween2.img/object-obj_ani-0-4",
					"origin" : [53,36],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween2.img/object-obj_ani-0-3",
					"origin" : [53,36],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "halloween2.img/object-obj_ani-0-2",
					"origin" : [53,36],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "halloween2.img/object-obj_ani-0-1",
					"origin" : [52,35],
					"z" : 0,
					"delay" : 150,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/object-obj_ani-1-0",
					"origin" : [40,72],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween2.img/object-obj_ani-1-1",
					"origin" : [41,72],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween2.img/object-obj_ani-1-2",
					"origin" : [41,72],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween2.img/object-obj_ani-1-3",
					"origin" : [41,72],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween2.img/object-obj_ani-1-4",
					"origin" : [42,72],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween2.img/object-obj_ani-1-3",
					"origin" : [41,72],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "halloween2.img/object-obj_ani-1-2",
					"origin" : [41,72],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "halloween2.img/object-obj_ani-1-1",
					"origin" : [41,72],
					"z" : 0,
					"delay" : 150,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/object-obj_ani-2-0",
					"origin" : [19,34],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween2.img/object-obj_ani-2-1",
					"origin" : [19,34],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween2.img/object-obj_ani-2-2",
					"origin" : [18,34],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween2.img/object-obj_ani-2-3",
					"origin" : [18,33],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween2.img/object-obj_ani-2-4",
					"origin" : [18,33],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween2.img/object-obj_ani-2-5",
					"origin" : [17,33],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "halloween2.img/object-obj_ani-2-6",
					"origin" : [17,32],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "halloween2.img/object-obj_ani-2-5",
					"origin" : [17,33],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "halloween2.img/object-obj_ani-2-4",
					"origin" : [18,33],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "halloween2.img/object-obj_ani-2-3",
					"origin" : [18,33],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "halloween2.img/object-obj_ani-2-2",
					"origin" : [18,34],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "halloween2.img/object-obj_ani-2-1",
					"origin" : [19,34],
					"z" : 0,
					"delay" : 150,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/object-obj_ani-3-0",
					"origin" : [3,17],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween2.img/object-obj_ani-3-1",
					"origin" : [4,18],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween2.img/object-obj_ani-3-2",
					"origin" : [5,19],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween2.img/object-obj_ani-3-3",
					"origin" : [7,21],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween2.img/object-obj_ani-3-4",
					"origin" : [15,29],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween2.img/object-obj_ani-3-5",
					"origin" : [18,32],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "halloween2.img/object-obj_ani-3-6",
					"origin" : [19,33],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "halloween2.img/object-obj_ani-3-7",
					"origin" : [18,32],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "halloween2.img/object-obj_ani-3-8",
					"origin" : [13,27],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "halloween2.img/object-obj_ani-3-9",
					"origin" : [9,23],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "halloween2.img/object-obj_ani-3-10",
					"origin" : [7,21],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "halloween2.img/object-obj_ani-3-11",
					"origin" : [4,18],
					"z" : 0,
					"delay" : 150,
				},
			},
		},
	},
	"dollFactory" :  {
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/dollFactory-obj-0-0",
					"origin" : [186,284],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/dollFactory-obj-1-0",
					"origin" : [239,284],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/dollFactory-obj-2-0",
					"origin" : [181,284],
					"z" : 0,
				},
			},
		},
		"candle" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/dollFactory-candle-0-0",
					"origin" : [34,33],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/dollFactory-candle-1-0",
					"origin" : [34,33],
					"z" : 0,
				},
			},
		},
		"candle_ani" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/dollFactory-candle_ani-0-0",
					"origin" : [29,24],
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween2.img/dollFactory-candle_ani-0-1",
					"origin" : [28,23],
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween2.img/dollFactory-candle_ani-0-2",
					"origin" : [27,23],
					"delay" : 150,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/dollFactory-candle_ani-1-0",
					"origin" : [33,31],
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween2.img/dollFactory-candle_ani-1-1",
					"origin" : [32,30],
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween2.img/dollFactory-candle_ani-1-2",
					"origin" : [31,30],
					"delay" : 150,
				},
			},
		},
		"sewingMachine" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/dollFactory-sewingMachine-0-0",
					"origin" : [155,209],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween2.img/dollFactory-sewingMachine-0-1",
					"origin" : [155,210],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween2.img/dollFactory-sewingMachine-0-2",
					"origin" : [155,209],
					"z" : 0,
				},
				"3" :  {
					"png_path": "halloween2.img/dollFactory-sewingMachine-0-3",
					"origin" : [155,210],
					"z" : 0,
				},
				"4" :  {
					"png_path": "halloween2.img/dollFactory-sewingMachine-0-4",
					"origin" : [155,209],
					"z" : 0,
				},
				"5" :  {
					"png_path": "halloween2.img/dollFactory-sewingMachine-0-5",
					"origin" : [155,210],
					"z" : 0,
				},
				"6" :  {
					"png_path": "halloween2.img/dollFactory-sewingMachine-0-6",
					"origin" : [155,209],
					"z" : 0,
				},
				"7" :  {
					"png_path": "halloween2.img/dollFactory-sewingMachine-0-7",
					"origin" : [155,210],
					"z" : 0,
				},
				"8" :  {
					"png_path": "halloween2.img/dollFactory-sewingMachine-0-8",
					"origin" : [155,209],
					"z" : 0,
				},
				"9" :  {
					"png_path": "halloween2.img/dollFactory-sewingMachine-0-9",
					"origin" : [155,210],
					"z" : 0,
				},
				"10" :  {
					"png_path": "halloween2.img/dollFactory-sewingMachine-0-10",
					"origin" : [155,209],
					"z" : 0,
				},
				"11" :  {
					"png_path": "halloween2.img/dollFactory-sewingMachine-0-11",
					"origin" : [155,210],
					"z" : 0,
				},
			},
		},
	},
	"maskRoom" :  {
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/maskRoom-obj-0-0",
					"origin" : [191,75],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/maskRoom-obj-1-0",
					"origin" : [65,51],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/maskRoom-obj-2-0",
					"origin" : [174,283],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/maskRoom-obj-3-0",
					"origin" : [257,283],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/maskRoom-obj-4-0",
					"origin" : [170,283],
					"z" : 0,
				},
			},
		},
	},
	"library" :  {
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/library-obj-0-0",
					"origin" : [53,63],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/library-obj-1-0",
					"origin" : [47,39],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/library-obj-2-0",
					"origin" : [76,40],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/library-obj-3-0",
					"origin" : [271,308],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/library-obj-4-0",
					"origin" : [170,308],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween2.img/library-obj-5-0",
					"origin" : [294,308],
					"z" : 0,
				},
			},
		},
		"candle_ani" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/library-candle_ani-0-0",
					"origin" : [40,56],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween2.img/library-candle_ani-0-1",
					"origin" : [40,55],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween2.img/library-candle_ani-0-2",
					"origin" : [40,55],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/library-candle_ani-1-0",
					"origin" : [38,56],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween2.img/library-candle_ani-1-1",
					"origin" : [38,55],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween2.img/library-candle_ani-1-2",
					"origin" : [38,55],
					"z" : 0,
				},
			},
		},
	},
	"frameRoom" :  {
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/frameRoom-obj-0-0",
					"origin" : [120,36],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/frameRoom-obj-1-0",
					"origin" : [137,60],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/frameRoom-obj-2-0",
					"origin" : [283,308],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/frameRoom-obj-3-0",
					"origin" : [200,308],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/frameRoom-obj-4-0",
					"origin" : [251,308],
					"z" : 0,
				},
			},
		},
		"frame" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/frameRoom-frame-0-0",
					"origin" : [39,43],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/frameRoom-frame-1-0",
					"origin" : [39,43],
					"z" : 0,
				},
			},
		},
		"candle_ani" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/frameRoom-candle_ani-0-0",
					"origin" : [40,56],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween2.img/frameRoom-candle_ani-0-1",
					"origin" : [40,55],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween2.img/frameRoom-candle_ani-0-2",
					"origin" : [40,55],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/frameRoom-candle_ani-1-0",
					"origin" : [38,56],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween2.img/frameRoom-candle_ani-1-1",
					"origin" : [38,55],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween2.img/frameRoom-candle_ani-1-2",
					"origin" : [38,55],
					"z" : 0,
				},
			},
		},
	},
	"jonasRoom" :  {
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/jonasRoom-obj-0-0",
					"origin" : [47,39],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/jonasRoom-obj-1-0",
					"origin" : [76,40],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/jonasRoom-obj-2-0",
					"origin" : [267,308],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/jonasRoom-obj-3-0",
					"origin" : [220,308],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/jonasRoom-obj-4-0",
					"origin" : [241,308],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween2.img/jonasRoom-obj-5-0",
					"origin" : [220,308],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween2.img/jonasRoom-obj-6-0",
					"origin" : [151,308],
					"z" : 0,
				},
			},
		},
		"candle" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/jonasRoom-candle-0-0",
					"origin" : [47,38],
					"z" : 0,
				},
			},
		},
		"candle_ani" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/jonasRoom-candle_ani-0-0",
					"origin" : [50,17],
					"z" : 0,
				},
				"1" :  {
					"png_path": "halloween2.img/jonasRoom-candle_ani-0-1",
					"origin" : [49,16],
					"z" : 0,
				},
				"2" :  {
					"png_path": "halloween2.img/jonasRoom-candle_ani-0-2",
					"origin" : [48,16],
					"z" : 0,
				},
			},
		},
		"firePlace" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/jonasRoom-firePlace-0-0",
					"origin" : [98,196],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween2.img/jonasRoom-firePlace-0-1",
					"origin" : [98,196],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween2.img/jonasRoom-firePlace-0-2",
					"origin" : [98,195],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween2.img/jonasRoom-firePlace-0-3",
					"origin" : [98,196],
					"z" : 0,
					"delay" : 150,
				},
			},
		},
	},
	"joyRoom" :  {
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/joyRoom-obj-0-0",
					"origin" : [235,207],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/joyRoom-obj-1-0",
					"origin" : [232,212],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/joyRoom-obj-2-0",
					"origin" : [211,249],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/joyRoom-obj-3-0",
					"origin" : [224,249],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/joyRoom-obj-4-0",
					"origin" : [174,249],
					"z" : 0,
				},
			},
		},
	},
	"guest" :  {
		"fire_ani" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-fire_ani-0-0",
					"origin" : [22,58],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween2.img/guest-fire_ani-0-1",
					"origin" : [22,52],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween2.img/guest-fire_ani-0-2",
					"origin" : [22,55],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween2.img/guest-fire_ani-0-3",
					"origin" : [22,54],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween2.img/guest-fire_ani-0-4",
					"origin" : [22,54],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween2.img/guest-fire_ani-0-5",
					"origin" : [21,57],
					"z" : 0,
					"delay" : 150,
				},
			},
		},
		"one" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-one-0-0",
					"origin" : [156,66],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-one-1-0",
					"origin" : [221,291],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-one-2-0",
					"origin" : [212,291],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-one-3-0",
					"origin" : [176,291],
					"z" : 0,
				},
			},
		},
		"two" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-two-0-0",
					"origin" : [226,68],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-two-1-0",
					"origin" : [53,63],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-two-2-0",
					"origin" : [119,90],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-two-3-0",
					"origin" : [52,74],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-two-4-0",
					"origin" : [213,246],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-two-5-0",
					"origin" : [262,246],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-two-6-0",
					"origin" : [132,276],
					"z" : 0,
				},
			},
		},
		"three" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-three-0-0",
					"origin" : [222,69],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-three-1-0",
					"origin" : [91,63],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-three-2-0",
					"origin" : [198,250],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-three-3-0",
					"origin" : [234,254],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-three-4-0",
					"origin" : [176,250],
					"z" : 0,
				},
			},
		},
		"four" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-four-0-0",
					"origin" : [182,250],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-four-1-0",
					"origin" : [252,254],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/guest-four-2-0",
					"origin" : [176,250],
					"z" : 0,
				},
			},
		},
	},
	"outside" :  {
		"obj" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/outside-obj-0-0",
					"origin" : [178,173],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/outside-obj-1-0",
					"origin" : [177,150],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/outside-obj-2-0",
					"origin" : [178,173],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "halloween2.img/outside-obj-3-0",
					"origin" : [189,188],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "halloween2.img/outside-obj-4-0",
					"origin" : [177,150],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "halloween2.img/outside-obj-5-0",
					"origin" : [13,70],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "halloween2.img/outside-obj-6-0",
					"origin" : [72,70],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "halloween2.img/outside-obj-7-0",
					"origin" : [73,72],
					"z" : 0,
				},
			},
		},
		"obj_ani" :  {
			"0" :  {
				"0" :  {
					"png_path": "halloween2.img/outside-obj_ani-0-0",
					"origin" : [105,172],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween2.img/outside-obj_ani-0-1",
					"origin" : [105,172],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween2.img/outside-obj_ani-0-2",
					"origin" : [105,171],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween2.img/outside-obj_ani-0-3",
					"origin" : [105,171],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween2.img/outside-obj_ani-0-4",
					"origin" : [105,170],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween2.img/outside-obj_ani-0-5",
					"origin" : [105,171],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "halloween2.img/outside-obj_ani-0-6",
					"origin" : [105,171],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "halloween2.img/outside-obj_ani-0-7",
					"origin" : [105,172],
					"z" : 0,
					"delay" : 150,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "halloween2.img/outside-obj_ani-1-0",
					"origin" : [58,175],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween2.img/outside-obj_ani-1-1",
					"origin" : [57,175],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween2.img/outside-obj_ani-1-2",
					"origin" : [57,174],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween2.img/outside-obj_ani-1-3",
					"origin" : [57,174],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween2.img/outside-obj_ani-1-4",
					"origin" : [56,173],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween2.img/outside-obj_ani-1-5",
					"origin" : [57,174],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "halloween2.img/outside-obj_ani-1-6",
					"origin" : [57,174],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "halloween2.img/outside-obj_ani-1-7",
					"origin" : [57,175],
					"z" : 0,
					"delay" : 150,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-0",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"1" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-1",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"2" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-2",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"3" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-3",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"4" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-4",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"5" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-5",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"6" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-6",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"7" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-7",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"8" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-8",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"9" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-9",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"10" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-10",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"11" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-11",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"12" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-12",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"13" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-13",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
				"14" :  {
					"png_path": "halloween2.img/outside-obj_ani-2-14",
					"origin" : [264,315],
					"z" : 0,
					"delay" : 150,
				},
			},
		},
	},
};

