var ObjhouseFV = ObjhouseFV || { }; 
ObjhouseFV =   {
	"id":"houseFV",
	"house0" :  {
		"basic" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house0-basic-0-0",
					"origin" : [316,156],
					"z" : 0,
				},
			},
		},
		"deco" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house0-deco-0-0",
					"origin" : [55,41],
					"z" : 0,
					"delay" : 220,
				},
				"1" :  {
					"png_path": "houseFV.img/house0-deco-0-1",
					"origin" : [55,63],
					"z" : 0,
					"delay" : 220,
				},
				"2" :  {
					"png_path": "houseFV.img/house0-deco-0-2",
					"origin" : [62,57],
					"z" : 0,
					"delay" : 220,
				},
				"3" :  {
					"png_path": "houseFV.img/house0-deco-0-3",
					"origin" : [86,67],
					"z" : 0,
					"delay" : 220,
				},
				"4" :  {
					"png_path": "houseFV.img/house0-deco-0-4",
					"origin" : [77,69],
					"z" : 0,
					"delay" : 220,
				},
				"5" :  {
					"png_path": "houseFV.img/house0-deco-0-5",
					"origin" : [55,12],
					"z" : 0,
					"delay" : 220,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "houseFV.img/house0-deco-1-0",
					"origin" : [24,31],
					"z" : 0,
					"delay" : 200,
				},
				"1" :  {
					"png_path": "houseFV.img/house0-deco-1-1",
					"origin" : [24,31],
					"z" : 0,
					"delay" : 200,
				},
				"2" :  {
					"png_path": "houseFV.img/house0-deco-1-2",
					"origin" : [24,31],
					"z" : 0,
					"delay" : 200,
				},
				"3" :  {
					"png_path": "houseFV.img/house0-deco-1-3",
					"origin" : [24,31],
					"z" : 0,
					"delay" : 200,
				},
				"4" :  {
					"png_path": "houseFV.img/house0-deco-1-4",
					"origin" : [24,31],
					"z" : 0,
					"delay" : 200,
				},
				"5" :  {
					"png_path": "houseFV.img/house0-deco-1-5",
					"origin" : [24,31],
					"z" : 0,
					"delay" : 200,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "houseFV.img/house0-deco-2-0",
					"origin" : [114,130],
					"z" : 0,
				},
			},
		},
	},
	"house1" :  {
		"basic" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house1-basic-0-0",
					"origin" : [296,131],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "houseFV.img/house1-basic-1-0",
					"origin" : [110,29],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "houseFV.img/house1-basic-2-0",
					"origin" : [45,32],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "houseFV.img/house1-basic-3-0",
					"origin" : [158,33],
					"z" : 0,
				},
			},
		},
		"deco" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house1-deco-0-0",
					"origin" : [42,74],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "houseFV.img/house1-deco-1-0",
					"origin" : [120,40],
					"z" : 0,
				},
			},
		},
	},
	"house3" :  {
		"basic" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house3-basic-0-0",
					"origin" : [194,126],
					"z" : 0,
				},
			},
		},
		"deco" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house3-deco-0-0",
					"origin" : [192,61],
					"z" : 0,
				},
			},
		},
	},
	"house4" :  {
		"basic" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house4-basic-0-0",
					"origin" : [282,189],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "houseFV.img/house4-basic-1-0",
					"origin" : [363,104],
					"z" : 0,
				},
			},
		},
	},
	"house5" :  {
		"basic" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house5-basic-0-0",
					"origin" : [264,177],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "houseFV.img/house5-basic-1-0",
					"origin" : [105,47],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "houseFV.img/house5-basic-2-0",
					"origin" : [189,64],
					"z" : 0,
				},
			},
		},
		"deco" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house5-deco-0-0",
					"origin" : [202,79],
					"z" : 0,
				},
			},
		},
	},
	"house7" :  {
		"basic" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-basic-0-0",
					"origin" : [158,81],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-basic-1-0",
					"origin" : [158,81],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-basic-2-0",
					"origin" : [196,74],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-basic-3-0",
					"origin" : [196,74],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-basic-4-0",
					"origin" : [194,34],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-basic-5-0",
					"origin" : [183,82],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-basic-6-0",
					"origin" : [168,11],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-basic-7-0",
					"origin" : [110,29],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-basic-8-0",
					"origin" : [45,32],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-basic-9-0",
					"origin" : [157,33],
					"z" : 0,
				},
			},
		},
		"deco" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-0-0",
					"origin" : [121,18],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-1-0",
					"origin" : [56,10],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-2-0",
					"origin" : [60,40],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-3-0",
					"origin" : [26,23],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-4-0",
					"origin" : [39,34],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-5-0",
					"origin" : [51,27],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-6-0",
					"origin" : [24,30],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-7-0",
					"origin" : [24,27],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-8-0",
					"origin" : [17,19],
					"z" : 0,
				},
			},
			"9" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-9-0",
					"origin" : [79,24],
					"z" : 0,
				},
			},
			"10" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-10-0",
					"origin" : [20,30],
					"z" : 0,
				},
			},
			"11" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-11-0",
					"origin" : [13,24],
					"z" : 0,
				},
			},
			"12" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-12-0",
					"origin" : [13,16],
					"z" : 0,
				},
			},
			"13" :  {
				"0" :  {
					"png_path": "houseFV.img/house7-deco-13-0",
					"origin" : [194,61],
					"z" : 0,
				},
			},
		},
	},
	"house8" :  {
		"basic" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house8-basic-0-0",
					"origin" : [270,169],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "houseFV.img/house8-basic-1-0",
					"origin" : [79,37],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "houseFV.img/house8-basic-2-0",
					"origin" : [78,43],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "houseFV.img/house8-basic-3-0",
					"origin" : [206,51],
					"z" : 0,
				},
			},
		},
	},
	"house9" :  {
		"basic" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house9-basic-0-0",
					"origin" : [278,130],
					"z" : 0,
				},
			},
		},
	},
	"house2" :  {
		"basic" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house2-basic-0-0",
					"origin" : [297,146],
					"z" : 0,
					"delay" : 300,
				},
				"1" :  {
					"png_path": "houseFV.img/house2-basic-0-1",
					"origin" : [319,146],
					"z" : 0,
					"delay" : 300,
				},
			},
		},
	},
	"house6" :  {
		"basic" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-basic-0-0",
					"origin" : [163,97],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-basic-1-0",
					"origin" : [163,97],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-basic-2-0",
					"origin" : [196,72],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-basic-3-0",
					"origin" : [195,38],
					"z" : 0,
				},
			},
			"4" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-basic-4-0",
					"origin" : [187,83],
					"z" : 0,
				},
			},
			"5" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-basic-5-0",
					"origin" : [168,11],
					"z" : 0,
				},
			},
			"6" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-basic-6-0",
					"origin" : [105,21],
					"z" : 0,
				},
			},
			"7" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-basic-7-0",
					"origin" : [172,29],
					"z" : 0,
				},
			},
			"8" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-basic-8-0",
					"origin" : [0,0],
				},
			},
		},
		"deco" :  {
			"0" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-deco-0-0",
					"origin" : [117,19],
					"z" : 0,
				},
			},
			"1" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-deco-1-0",
					"origin" : [56,10],
					"z" : 0,
				},
			},
			"2" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-deco-2-0",
					"origin" : [34,30],
					"z" : 0,
				},
			},
			"3" :  {
				"0" :  {
					"png_path": "houseFV.img/house6-deco-3-0",
					"origin" : [39,42],
					"z" : 0,
				},
			},
		},
	},
};

