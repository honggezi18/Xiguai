var BacktoyCastle = BacktoyCastle || { }; 
BacktoyCastle =   {
	"id":"toyCastle",
	"back" :  {
		"0" :  {
			"png_path": "toyCastle.img/back-0",
			"origin" : [64,64],
			"z" : 0,
		},
		"1" :  {
			"png_path": "toyCastle.img/back-1",
			"origin" : [11,261],
			"z" : 0,
		},
		"2" :  {
			"png_path": "toyCastle.img/back-2",
			"origin" : [502,76],
			"z" : 0,
		},
		"3" :  {
			"png_path": "toyCastle.img/back-3",
			"origin" : [202,118],
			"z" : 0,
		},
		"4" :  {
			"png_path": "toyCastle.img/back-4",
			"origin" : [176,63],
			"z" : 0,
		},
		"5" :  {
			"png_path": "toyCastle.img/back-5",
			"origin" : [262,221],
			"z" : 0,
		},
		"6" :  {
			"png_path": "toyCastle.img/back-6",
			"origin" : [305,273],
			"z" : 0,
		},
		"7" :  {
			"png_path": "toyCastle.img/back-7",
			"origin" : [392,47],
			"z" : 0,
		},
		"8" :  {
			"png_path": "toyCastle.img/back-8",
			"origin" : [223,81],
			"z" : 0,
		},
		"9" :  {
			"png_path": "toyCastle.img/back-9",
			"origin" : [373,138],
			"z" : 0,
		},
		"10" :  {
			"png_path": "toyCastle.img/back-10",
			"origin" : [119,44],
			"z" : 0,
		},
		"11" :  {
			"png_path": "toyCastle.img/back-11",
			"origin" : [208,67],
			"z" : 0,
		},
		"12" :  {
			"png_path": "toyCastle.img/back-12",
			"origin" : [271,95],
			"z" : 0,
		},
		"13" :  {
			"png_path": "toyCastle.img/back-13",
			"origin" : [63,216],
			"z" : 0,
		},
		"14" :  {
			"png_path": "toyCastle.img/back-14",
			"origin" : [121,278],
			"z" : 0,
		},
		"15" :  {
			"png_path": "toyCastle.img/back-15",
			"origin" : [100,61],
			"z" : 0,
		},
		"16" :  {
			"png_path": "toyCastle.img/back-16",
			"origin" : [233,111],
			"z" : 0,
		},
		"17" :  {
			"png_path": "toyCastle.img/back-17",
			"origin" : [352,229],
			"z" : 0,
		},
		"18" :  {
			"png_path": "toyCastle.img/back-18",
			"origin" : [23,6],
			"z" : 0,
		},
		"19" :  {
			"png_path": "toyCastle.img/back-19",
			"origin" : [104,119],
			"z" : 0,
		},
	},
	"ani" :  {
		"0" :  {
			"0" :  {
				"png_path": "toyCastle.img/ani-0-0",
				"origin" : [42,95],
				"z" : 0,
				"delay" : 120,
			},
			"1" :  {
				"png_path": "toyCastle.img/ani-0-1",
				"origin" : [42,77],
				"z" : 0,
				"delay" : 120,
			},
			"2" :  {
				"png_path": "toyCastle.img/ani-0-2",
				"origin" : [55,27],
				"z" : 0,
				"delay" : 120,
			},
			"3" :  {
				"png_path": "toyCastle.img/ani-0-3",
				"origin" : [42,77],
				"z" : 0,
				"delay" : 120,
			},
		},
	},
};

