var Backhalloween2 = Backhalloween2 || { }; 
Backhalloween2 =   {
	"id":"halloween2",
	"back" :  {
		"0" :  {
			"png_path": "halloween2.img/back-0",
			"origin" : [90,515],
			"z" : 0,
		},
		"1" :  {
			"png_path": "halloween2.img/back-1",
			"origin" : [99,36],
			"z" : 0,
		},
		"2" :  {
			"png_path": "halloween2.img/back-2",
			"origin" : [22,43],
			"z" : 0,
		},
		"3" :  {
			"png_path": "halloween2.img/back-3",
			"origin" : [90,275],
			"z" : 0,
		},
		"4" :  {
			"png_path": "halloween2.img/back-4",
			"origin" : [533,84],
			"z" : 0,
		},
		"5" :  {
			"png_path": "halloween2.img/back-5",
			"origin" : [90,142],
			"z" : 0,
		},
		"6" :  {
			"png_path": "halloween2.img/back-6",
			"origin" : [125,46],
			"z" : 0,
		},
		"7" :  {
			"png_path": "halloween2.img/back-7",
			"origin" : [610,246],
			"z" : 0,
		},
		"8" :  {
			"png_path": "halloween2.img/back-8",
			"origin" : [606,284],
			"z" : 0,
		},
		"9" :  {
			"png_path": "halloween2.img/back-9",
			"origin" : [602,283],
			"z" : 0,
		},
		"10" :  {
			"png_path": "halloween2.img/back-10",
			"origin" : [765,308],
			"z" : 0,
		},
		"11" :  {
			"png_path": "halloween2.img/back-11",
			"origin" : [706,308],
			"z" : 0,
		},
		"12" :  {
			"png_path": "halloween2.img/back-12",
			"origin" : [1100,308],
			"z" : 0,
		},
		"13" :  {
			"png_path": "halloween2.img/back-13",
			"origin" : [609,249],
			"z" : 0,
		},
	},
};

