var BacksnowyDarkrock = BacksnowyDarkrock || { }; 
BacksnowyDarkrock =   {
	"id":"snowyDarkrock",
	"back" :  {
		"1" :  {
			"png_path": "snowyDarkrock.img/back-1",
			"origin" : [40,210],
			"z" : 0,
		},
		"2" :  {
			"png_path": "snowyDarkrock.img/back-2",
			"origin" : [151,151],
			"z" : 0,
		},
		"3" :  {
			"png_path": "snowyDarkrock.img/back-3",
			"origin" : [400,91],
			"z" : 0,
		},
		"4" :  {
			"png_path": "snowyDarkrock.img/back-4",
			"origin" : [254,137],
			"z" : 0,
		},
		"5" :  {
			"png_path": "snowyDarkrock.img/back-5",
			"origin" : [341,146],
			"z" : 0,
		},
		"6" :  {
			"png_path": "snowyDarkrock.img/back-6",
			"origin" : [116,156],
			"z" : 0,
		},
		"7" :  {
			"png_path": "snowyDarkrock.img/back-7",
			"origin" : [82,120],
			"z" : 0,
		},
		"8" :  {
			"png_path": "snowyDarkrock.img/back-8",
			"origin" : [94,157],
			"z" : 0,
		},
		"9" :  {
			"png_path": "snowyDarkrock.img/back-9",
			"origin" : [94,143],
			"z" : 0,
		},
		"10" :  {
			"png_path": "snowyDarkrock.img/back-10",
			"origin" : [97,153],
			"z" : 0,
		},
		"0" :  {
			"png_path": "snowyDarkrock.img/back-0",
			"origin" : [40,40],
			"z" : 0,
		},
	},
	"ani" :  {
		"5" :  {
			"0" :  {
				"png_path": "snowyDarkrock.img/ani-5-0",
				"origin" : [196,133],
				"z" : 0,
			},
			"1" :  {
				"png_path": "snowyDarkrock.img/ani-5-1",
				"origin" : [196,133],
				"z" : 0,
			},
			"2" :  {
				"png_path": "snowyDarkrock.img/ani-5-2",
				"origin" : [196,133],
				"z" : 0,
			},
			"3" :  {
				"png_path": "snowyDarkrock.img/ani-5-3",
				"origin" : [196,133],
				"z" : 0,
			},
			"4" :  {
				"png_path": "snowyDarkrock.img/ani-5-4",
				"origin" : [196,133],
				"z" : 0,
			},
			"5" :  {
				"png_path": "snowyDarkrock.img/ani-5-5",
				"origin" : [196,133],
				"z" : 0,
			},
			"6" :  {
				"png_path": "snowyDarkrock.img/ani-5-6",
				"origin" : [196,133],
				"z" : 0,
			},
			"7" :  {
				"png_path": "snowyDarkrock.img/ani-5-7",
				"origin" : [196,133],
				"z" : 0,
			},
			"8" :  {
				"png_path": "snowyDarkrock.img/ani-5-8",
				"origin" : [196,133],
				"z" : 0,
			},
		},
		"0" :  {
			"0" :  {
				"png_path": "snowyDarkrock.img/ani-0-0",
				"origin" : [100,143],
				"z" : 0,
				"delay" : 700,
			},
			"1" :  {
				"png_path": "snowyDarkrock.img/ani-0-1",
				"origin" : [107,143],
				"z" : 0,
				"delay" : 700,
			},
			"2" :  {
				"png_path": "snowyDarkrock.img/ani-0-2",
				"origin" : [107,143],
				"z" : 0,
				"delay" : 700,
			},
		},
		"1" :  {
			"0" :  {
				"png_path": "snowyDarkrock.img/ani-1-0",
				"origin" : [97,155],
				"z" : 0,
				"delay" : 700,
			},
			"1" :  {
				"png_path": "snowyDarkrock.img/ani-1-1",
				"origin" : [97,147],
				"z" : 0,
				"delay" : 700,
			},
			"2" :  {
				"png_path": "snowyDarkrock.img/ani-1-2",
				"origin" : [97,155],
				"z" : 0,
				"delay" : 700,
			},
		},
		"2" :  {
			"0" :  {
				"png_path": "snowyDarkrock.img/ani-2-0",
				"origin" : [100,155],
				"z" : 0,
				"delay" : 700,
			},
			"1" :  {
				"png_path": "snowyDarkrock.img/ani-2-1",
				"origin" : [90,155],
				"z" : 0,
				"delay" : 700,
			},
			"2" :  {
				"png_path": "snowyDarkrock.img/ani-2-2",
				"origin" : [100,154],
				"z" : 0,
				"delay" : 700,
			},
		},
		"4" :  {
			"0" :  {
				"png_path": "snowyDarkrock.img/ani-4-0",
				"origin" : [189,145],
				"z" : 0,
			},
			"1" :  {
				"png_path": "snowyDarkrock.img/ani-4-1",
				"origin" : [189,145],
				"z" : 0,
			},
			"2" :  {
				"png_path": "snowyDarkrock.img/ani-4-2",
				"origin" : [189,145],
				"z" : 0,
			},
			"3" :  {
				"png_path": "snowyDarkrock.img/ani-4-3",
				"origin" : [189,145],
				"z" : 0,
			},
			"4" :  {
				"png_path": "snowyDarkrock.img/ani-4-4",
				"origin" : [170,143],
				"z" : 0,
			},
			"5" :  {
				"png_path": "snowyDarkrock.img/ani-4-5",
				"origin" : [188,129],
				"z" : 0,
			},
			"6" :  {
				"png_path": "snowyDarkrock.img/ani-4-6",
				"origin" : [189,143],
				"z" : 0,
			},
			"7" :  {
				"png_path": "snowyDarkrock.img/ani-4-7",
				"origin" : [191,144],
				"z" : 0,
			},
		},
		"3" :  {
			"0" :  {
				"png_path": "snowyDarkrock.img/ani-3-0",
				"origin" : [65,15],
				"z" : 0,
				"delay" : 150,
			},
			"1" :  {
				"png_path": "snowyDarkrock.img/ani-3-1",
				"origin" : [66,15],
				"z" : 0,
				"delay" : 150,
			},
			"2" :  {
				"png_path": "snowyDarkrock.img/ani-3-2",
				"origin" : [66,16],
				"z" : 0,
				"delay" : 150,
			},
			"3" :  {
				"png_path": "snowyDarkrock.img/ani-3-3",
				"origin" : [68,19],
				"z" : 0,
				"delay" : 150,
			},
			"4" :  {
				"png_path": "snowyDarkrock.img/ani-3-4",
				"origin" : [66,16],
				"z" : 0,
				"delay" : 150,
			},
			"5" :  {
				"png_path": "snowyDarkrock.img/ani-3-5",
				"origin" : [67,14],
				"z" : 0,
				"delay" : 150,
			},
			"6" :  {
				"png_path": "snowyDarkrock.img/ani-3-6",
				"origin" : [67,13],
				"z" : 0,
				"delay" : 150,
			},
			"7" :  {
				"png_path": "snowyDarkrock.img/ani-3-7",
				"origin" : [64,11],
				"z" : 0,
				"delay" : 150,
			},
			"8" :  {
				"png_path": "snowyDarkrock.img/ani-3-8",
				"origin" : [64,11],
				"z" : 0,
				"delay" : 150,
			},
			"9" :  {
				"png_path": "snowyDarkrock.img/ani-3-9",
				"origin" : [64,11],
				"z" : 0,
				"delay" : 150,
			},
		},
	},
};

