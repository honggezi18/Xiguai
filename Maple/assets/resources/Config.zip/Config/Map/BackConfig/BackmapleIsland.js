var BackmapleIsland = BackmapleIsland || { }; 
BackmapleIsland =   {
	"id":"mapleIsland",
	"back" :  {
		"0" :  {
			"png_path": "mapleIsland.img/back-0",
			"origin" : [450,5],
			"z" : 0,
		},
		"1" :  {
			"png_path": "mapleIsland.img/back-1",
			"origin" : [450,292],
			"z" : 0,
		},
		"2" :  {
			"png_path": "mapleIsland.img/back-2",
			"origin" : [450,5],
			"z" : 0,
		},
		"3" :  {
			"png_path": "mapleIsland.img/back-3",
			"origin" : [400,187],
			"z" : 0,
		},
		"4" :  {
			"png_path": "mapleIsland.img/back-4",
			"origin" : [280,65],
			"z" : 0,
		},
		"5" :  {
			"png_path": "mapleIsland.img/back-5",
			"origin" : [258,81],
			"z" : 0,
		},
		"6" :  {
			"png_path": "mapleIsland.img/back-6",
			"origin" : [258,5],
			"z" : 0,
		},
		"7" :  {
			"png_path": "mapleIsland.img/back-7",
			"origin" : [315,146],
			"z" : 0,
		},
		"8" :  {
			"png_path": "mapleIsland.img/back-8",
			"origin" : [315,5],
			"z" : 0,
		},
		"9" :  {
			"png_path": "mapleIsland.img/back-9",
			"origin" : [306,62],
			"z" : 0,
		},
		"10" :  {
			"png_path": "mapleIsland.img/back-10",
			"origin" : [300,121],
			"z" : 0,
		},
		"11" :  {
			"png_path": "mapleIsland.img/back-11",
			"origin" : [300,101],
			"z" : 0,
		},
		"12" :  {
			"png_path": "mapleIsland.img/back-12",
			"origin" : [300,5],
			"z" : 0,
		},
		"13" :  {
			"png_path": "mapleIsland.img/back-13",
			"origin" : [450,5],
			"z" : 0,
		},
		"14" :  {
			"png_path": "mapleIsland.img/back-14",
			"origin" : [450,133],
			"z" : 0,
		},
		"15" :  {
			"png_path": "mapleIsland.img/back-15",
			"origin" : [82,242],
			"z" : 0,
		},
		"16" :  {
			"png_path": "mapleIsland.img/back-16",
			"origin" : [211,178],
			"z" : 0,
		},
		"17" :  {
			"png_path": "mapleIsland.img/back-17",
			"origin" : [211,178],
			"z" : 0,
		},
		"18" :  {
			"png_path": "mapleIsland.img/back-18",
			"origin" : [250,173],
			"z" : 0,
		},
		"19" :  {
			"png_path": "mapleIsland.img/back-19",
			"origin" : [250,165],
			"z" : 0,
		},
		"20" :  {
			"png_path": "mapleIsland.img/back-20",
			"origin" : [250,155],
			"z" : 0,
		},
		"21" :  {
			"png_path": "mapleIsland.img/back-21",
			"origin" : [250,189],
			"z" : 0,
		},
		"22" :  {
			"png_path": "mapleIsland.img/back-22",
			"origin" : [306,62],
		},
		"24" :  {
			"png_path": "mapleIsland.img/back-24",
			"origin" : [307,163],
			"z" : 0,
		},
		"25" :  {
			"png_path": "mapleIsland.img/back-25",
			"origin" : [270,132],
			"z" : 0,
		},
		"26" :  {
			"png_path": "mapleIsland.img/back-26",
			"origin" : [568,617],
			"z" : 0,
		},
	},
	"ani" :  {
		"0" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-0-0",
				"origin" : [324,85],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-0-1",
				"origin" : [324,85],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-0-2",
				"origin" : [324,85],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-0-3",
				"origin" : [324,85],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-0-4",
				"origin" : [324,85],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-0-5",
				"origin" : [324,85],
				"z" : 0,
			},
			"6" :  {
				"png_path": "mapleIsland.img/ani-0-6",
				"origin" : [324,85],
				"z" : 0,
			},
			"7" :  {
				"png_path": "mapleIsland.img/ani-0-7",
				"origin" : [324,85],
				"z" : 0,
			},
			"8" :  {
				"png_path": "mapleIsland.img/ani-0-8",
				"origin" : [319,83],
				"z" : 0,
			},
			"9" :  {
				"png_path": "mapleIsland.img/ani-0-9",
				"origin" : [311,82],
				"z" : 0,
			},
			"10" :  {
				"png_path": "mapleIsland.img/ani-0-10",
				"origin" : [274,74],
				"z" : 0,
				"delay" : 1000,
			},
		},
		"1" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-1-0",
				"origin" : [195,-19],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-1-1",
				"origin" : [195,-19],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-1-2",
				"origin" : [195,-19],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-1-3",
				"origin" : [195,-19],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-1-4",
				"origin" : [195,-19],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-1-5",
				"origin" : [195,-19],
				"z" : 0,
			},
			"6" :  {
				"png_path": "mapleIsland.img/ani-1-6",
				"origin" : [195,-19],
				"z" : 0,
			},
			"7" :  {
				"png_path": "mapleIsland.img/ani-1-7",
				"origin" : [195,-19],
				"z" : 0,
			},
			"8" :  {
				"png_path": "mapleIsland.img/ani-1-8",
				"origin" : [192,-20],
				"z" : 0,
			},
			"9" :  {
				"png_path": "mapleIsland.img/ani-1-9",
				"origin" : [189,-21],
				"z" : 0,
			},
			"10" :  {
				"png_path": "mapleIsland.img/ani-1-10",
				"origin" : [165,-27],
				"z" : 0,
				"delay" : 600,
			},
		},
		"2" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-2-0",
				"origin" : [162,36],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-2-1",
				"origin" : [175,36],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-2-2",
				"origin" : [175,37],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-2-3",
				"origin" : [175,37],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-2-4",
				"origin" : [174,38],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-2-5",
				"origin" : [148,37],
				"z" : 0,
			},
			"6" :  {
				"png_path": "mapleIsland.img/ani-2-6",
				"origin" : [174,37],
				"z" : 0,
			},
			"7" :  {
				"png_path": "mapleIsland.img/ani-2-7",
				"origin" : [174,40],
				"z" : 0,
			},
			"8" :  {
				"png_path": "mapleIsland.img/ani-2-8",
				"origin" : [172,40],
				"z" : 0,
			},
			"9" :  {
				"png_path": "mapleIsland.img/ani-2-9",
				"origin" : [173,41],
				"z" : 0,
			},
			"10" :  {
				"png_path": "mapleIsland.img/ani-2-10",
				"origin" : [172,41],
				"z" : 0,
			},
			"11" :  {
				"png_path": "mapleIsland.img/ani-2-11",
				"origin" : [172,41],
				"z" : 0,
			},
			"12" :  {
				"png_path": "mapleIsland.img/ani-2-12",
				"origin" : [161,35],
				"z" : 0,
			},
			"13" :  {
				"png_path": "mapleIsland.img/ani-2-13",
				"origin" : [160,35],
				"z" : 0,
			},
		},
		"3" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-3-0",
				"origin" : [24,79],
				"z" : 0,
				"delay" : 600,
				"a0" : 255,
				"a1" : 130,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-3-1",
				"origin" : [24,79],
				"z" : 0,
				"delay" : 600,
				"a0" : 130,
				"a1" : 255,
			},
		},
		"4" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-4-0",
				"origin" : [236,-61],
				"z" : 0,
				"delay" : 600,
				"a0" : 255,
				"a1" : 130,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-4-1",
				"origin" : [236,-61],
				"z" : 0,
				"delay" : 600,
				"a0" : 130,
				"a1" : 255,
			},
		},
		"5" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-5-0",
				"origin" : [66,96],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-5-1",
				"origin" : [71,83],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-5-2",
				"origin" : [69,83],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-5-3",
				"origin" : [63,88],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-5-4",
				"origin" : [64,90],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-5-5",
				"origin" : [65,81],
				"z" : 0,
			},
		},
		"6" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-6-0",
				"origin" : [10,89],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-6-1",
				"origin" : [10,93],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-6-2",
				"origin" : [11,94],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-6-3",
				"origin" : [11,89],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-6-4",
				"origin" : [11,93],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-6-5",
				"origin" : [11,86],
				"z" : 0,
			},
		},
		"7" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-7-0",
				"origin" : [77,157],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-7-1",
				"origin" : [77,166],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-7-2",
				"origin" : [80,168],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-7-3",
				"origin" : [78,158],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-7-4",
				"origin" : [79,174],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-7-5",
				"origin" : [79,151],
				"z" : 0,
			},
		},
		"8" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-8-0",
				"origin" : [44,267],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-8-1",
				"origin" : [44,282],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-8-2",
				"origin" : [49,286],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-8-3",
				"origin" : [46,280],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-8-4",
				"origin" : [47,296],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-8-5",
				"origin" : [48,272],
				"z" : 0,
			},
		},
		"9" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-9-0",
				"origin" : [31,178],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-9-1",
				"origin" : [31,184],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-9-2",
				"origin" : [33,185],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-9-3",
				"origin" : [32,178],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-9-4",
				"origin" : [32,183],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-9-5",
				"origin" : [33,174],
				"z" : 0,
			},
		},
		"10" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-10-0",
				"origin" : [12,260],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-10-1",
				"origin" : [12,262],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-10-2",
				"origin" : [15,266],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-10-3",
				"origin" : [13,260],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-10-4",
				"origin" : [14,271],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-10-5",
				"origin" : [14,255],
				"z" : 0,
			},
		},
		"11" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-11-0",
				"origin" : [119,76],
				"z" : 0,
				"delay" : 600,
				"a0" : 255,
				"a1" : 130,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-11-1",
				"origin" : [119,76],
				"z" : 0,
				"delay" : 600,
				"a0" : 130,
				"a1" : 255,
			},
		},
		"12" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-12-0",
				"origin" : [125,84],
				"z" : 0,
				"delay" : 600,
				"a0" : 255,
				"a1" : 130,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-12-1",
				"origin" : [125,84],
				"z" : 0,
				"delay" : 600,
				"a0" : 130,
				"a1" : 255,
			},
		},
		"13" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-13-0",
				"origin" : [247,73],
				"z" : 0,
				"delay" : 600,
				"a0" : 255,
				"a1" : 130,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-13-1",
				"origin" : [247,73],
				"z" : 0,
				"delay" : 600,
				"a0" : 130,
				"a1" : 255,
			},
		},
		"14" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-14-0",
				"origin" : [191,103],
				"z" : 0,
				"delay" : 600,
				"a0" : 255,
				"a1" : 130,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-14-1",
				"origin" : [191,103],
				"z" : 0,
				"delay" : 600,
				"a0" : 130,
				"a1" : 255,
			},
		},
		"15" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-15-0",
				"origin" : [110,186],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-15-1",
				"origin" : [121,163],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-15-2",
				"origin" : [118,163],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-15-3",
				"origin" : [109,172],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-15-4",
				"origin" : [108,175],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-15-5",
				"origin" : [108,168],
				"z" : 0,
			},
		},
		"16" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-16-0",
				"origin" : [20,162],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-16-1",
				"origin" : [20,163],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-16-2",
				"origin" : [22,167],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-16-3",
				"origin" : [21,163],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-16-4",
				"origin" : [22,171],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-16-5",
				"origin" : [22,159],
				"z" : 0,
			},
		},
		"17" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-17-0",
				"origin" : [62,142],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-17-1",
				"origin" : [63,132],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-17-2",
				"origin" : [60,136],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-17-3",
				"origin" : [60,143],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-17-4",
				"origin" : [66,146],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-17-5",
				"origin" : [64,134],
				"z" : 0,
			},
		},
		"18" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-18-0",
				"origin" : [2,176],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-18-1",
				"origin" : [3,181],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-18-2",
				"origin" : [4,183],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-18-3",
				"origin" : [3,181],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-18-4",
				"origin" : [3,186],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-18-5",
				"origin" : [4,178],
				"z" : 0,
			},
		},
		"19" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-19-0",
				"origin" : [64,268],
				"z" : 0,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-19-1",
				"origin" : [64,245],
				"z" : 0,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-19-2",
				"origin" : [61,244],
				"z" : 0,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-19-3",
				"origin" : [79,254],
				"z" : 0,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-19-4",
				"origin" : [84,257],
				"z" : 0,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-19-5",
				"origin" : [74,249],
				"z" : 0,
			},
		},
		"20" :  {
			"0" :  {
				"png_path": "mapleIsland.img/ani-20-0",
				"origin" : [31,27],
				"z" : 0,
				"delay" : 200,
			},
			"1" :  {
				"png_path": "mapleIsland.img/ani-20-1",
				"origin" : [35,31],
				"z" : 0,
				"delay" : 200,
			},
			"2" :  {
				"png_path": "mapleIsland.img/ani-20-2",
				"origin" : [40,34],
				"z" : 0,
				"delay" : 200,
			},
			"3" :  {
				"png_path": "mapleIsland.img/ani-20-3",
				"origin" : [42,37],
				"z" : 0,
				"delay" : 200,
			},
			"4" :  {
				"png_path": "mapleIsland.img/ani-20-4",
				"origin" : [41,42],
				"z" : 0,
				"delay" : 200,
			},
			"5" :  {
				"png_path": "mapleIsland.img/ani-20-5",
				"origin" : [39,43],
				"z" : 0,
				"delay" : 200,
			},
			"6" :  {
				"png_path": "mapleIsland.img/ani-20-6",
				"origin" : [38,47],
				"z" : 0,
				"delay" : 200,
			},
			"7" :  {
				"png_path": "mapleIsland.img/ani-20-7",
				"origin" : [23,16],
				"z" : 0,
				"delay" : 200,
			},
			"8" :  {
				"png_path": "mapleIsland.img/ani-20-8",
				"origin" : [22,17],
				"z" : 0,
				"delay" : 200,
			},
			"9" :  {
				"png_path": "mapleIsland.img/ani-20-9",
				"origin" : [20,18],
				"z" : 0,
				"delay" : 200,
			},
			"10" :  {
				"png_path": "mapleIsland.img/ani-20-10",
				"origin" : [2,18],
				"z" : 0,
				"delay" : 200,
			},
			"11" :  {
				"png_path": "mapleIsland.img/ani-20-11",
				"origin" : [5,22],
				"z" : 0,
				"delay" : 200,
			},
		},
	},
};

