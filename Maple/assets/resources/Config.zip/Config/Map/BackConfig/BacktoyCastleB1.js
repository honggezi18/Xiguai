var BacktoyCastleB1 = BacktoyCastleB1 || { }; 
BacktoyCastleB1 =   {
	"id":"toyCastleB1",
	"back" :  {
		"0" :  {
			"png_path": "toyCastleB1.img/back-0",
			"origin" : [200,256],
			"z" : 0,
		},
		"1" :  {
			"png_path": "toyCastleB1.img/back-1",
			"origin" : [159,256],
			"z" : 0,
		},
		"2" :  {
			"png_path": "toyCastleB1.img/back-2",
			"origin" : [211,135],
			"z" : 0,
		},
		"3" :  {
			"png_path": "toyCastleB1.img/back-3",
			"origin" : [211,135],
			"z" : 0,
		},
		"4" :  {
			"png_path": "toyCastleB1.img/back-4",
			"origin" : [211,135],
			"z" : 0,
		},
		"5" :  {
			"png_path": "toyCastleB1.img/back-5",
			"origin" : [211,135],
			"z" : 0,
		},
		"6" :  {
			"png_path": "toyCastleB1.img/back-6",
			"origin" : [211,135],
			"z" : 0,
		},
		"7" :  {
			"png_path": "toyCastleB1.img/back-7",
			"origin" : [211,135],
			"z" : 0,
		},
		"8" :  {
			"png_path": "toyCastleB1.img/back-8",
			"origin" : [132,178],
			"z" : 0,
		},
		"9" :  {
			"png_path": "toyCastleB1.img/back-9",
			"origin" : [41,12],
			"z" : 0,
		},
		"10" :  {
			"png_path": "toyCastleB1.img/back-10",
			"origin" : [146,178],
			"z" : 0,
		},
	},
	"ani" :  {
		"0" :  {
			"0" :  {
				"png_path": "toyCastleB1.img/ani-0-0",
				"origin" : [77,124],
				"z" : 0,
				"delay" : 150,
			},
			"1" :  {
				"png_path": "toyCastleB1.img/ani-0-1",
				"origin" : [77,124],
				"z" : 0,
				"delay" : 150,
			},
			"2" :  {
				"png_path": "toyCastleB1.img/ani-0-2",
				"origin" : [77,124],
				"z" : 0,
				"delay" : 150,
			},
			"3" :  {
				"png_path": "toyCastleB1.img/ani-0-3",
				"origin" : [77,124],
				"z" : 0,
				"delay" : 150,
			},
			"4" :  {
				"png_path": "toyCastleB1.img/ani-0-4",
				"origin" : [77,124],
				"z" : 0,
				"delay" : 150,
			},
			"5" :  {
				"png_path": "toyCastleB1.img/ani-0-5",
				"origin" : [77,124],
				"z" : 0,
				"delay" : 150,
			},
			"6" :  {
				"png_path": "toyCastleB1.img/ani-0-6",
				"origin" : [77,124],
				"z" : 0,
				"delay" : 150,
			},
			"7" :  {
				"png_path": "toyCastleB1.img/ani-0-7",
				"origin" : [77,124],
				"z" : 0,
				"delay" : 1000,
			},
		},
		"1" :  {
			"0" :  {
				"png_path": "toyCastleB1.img/ani-1-0",
				"origin" : [131,123],
				"z" : 0,
				"delay" : 150,
			},
			"1" :  {
				"png_path": "toyCastleB1.img/ani-1-1",
				"origin" : [131,123],
				"z" : 0,
				"delay" : 150,
			},
			"2" :  {
				"png_path": "toyCastleB1.img/ani-1-2",
				"origin" : [131,123],
				"z" : 0,
				"delay" : 150,
			},
			"3" :  {
				"png_path": "toyCastleB1.img/ani-1-3",
				"origin" : [131,123],
				"z" : 0,
				"delay" : 150,
			},
			"4" :  {
				"png_path": "toyCastleB1.img/ani-1-4",
				"origin" : [131,123],
				"z" : 0,
				"delay" : 150,
			},
			"5" :  {
				"png_path": "toyCastleB1.img/ani-1-5",
				"origin" : [131,123],
				"z" : 0,
				"delay" : 150,
			},
			"6" :  {
				"png_path": "toyCastleB1.img/ani-1-6",
				"origin" : [131,123],
				"z" : 0,
				"delay" : 150,
			},
			"7" :  {
				"png_path": "toyCastleB1.img/ani-1-7",
				"origin" : [131,123],
				"z" : 0,
				"delay" : 150,
			},
		},
		"2" :  {
			"0" :  {
				"png_path": "toyCastleB1.img/ani-2-0",
				"origin" : [65,81],
				"z" : 0,
				"delay" : 150,
			},
			"1" :  {
				"png_path": "toyCastleB1.img/ani-2-1",
				"origin" : [65,81],
				"z" : 0,
				"delay" : 150,
			},
			"2" :  {
				"png_path": "toyCastleB1.img/ani-2-2",
				"origin" : [65,81],
				"z" : 0,
				"delay" : 150,
			},
			"3" :  {
				"png_path": "toyCastleB1.img/ani-2-3",
				"origin" : [65,81],
				"z" : 0,
				"delay" : 150,
			},
		},
		"3" :  {
			"0" :  {
				"png_path": "toyCastleB1.img/ani-3-0",
				"origin" : [132,77],
				"z" : 0,
				"delay" : 150,
			},
			"1" :  {
				"png_path": "toyCastleB1.img/ani-3-1",
				"origin" : [132,77],
				"z" : 0,
				"delay" : 150,
			},
			"2" :  {
				"png_path": "toyCastleB1.img/ani-3-2",
				"origin" : [132,77],
				"z" : 0,
				"delay" : 150,
			},
			"3" :  {
				"png_path": "toyCastleB1.img/ani-3-3",
				"origin" : [132,77],
				"z" : 0,
				"delay" : 150,
			},
		},
	},
};

