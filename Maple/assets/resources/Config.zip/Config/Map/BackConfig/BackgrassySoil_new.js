var BackgrassySoil_new = BackgrassySoil_new || { }; 
BackgrassySoil_new =   {
	"id":"grassySoil_new",
	"back" :  {
		"0" :  {
			"png_path": "grassySoil_new.img/back-0",
			"origin" : [11,369],
			"z" : 0,
		},
		"1" :  {
			"png_path": "grassySoil_new.img/back-1",
			"origin" : [11,11],
			"z" : 0,
		},
		"2" :  {
			"png_path": "grassySoil_new.img/back-2",
			"origin" : [11,11],
			"z" : 0,
		},
		"3" :  {
			"png_path": "grassySoil_new.img/back-3",
			"origin" : [425,111],
			"z" : 0,
		},
		"4" :  {
			"png_path": "grassySoil_new.img/back-4",
			"origin" : [425,6],
			"z" : 0,
		},
		"5" :  {
			"png_path": "grassySoil_new.img/back-5",
			"origin" : [258,81],
			"z" : 0,
		},
		"6" :  {
			"png_path": "grassySoil_new.img/back-6",
			"origin" : [315,119],
			"z" : 0,
		},
		"7" :  {
			"png_path": "grassySoil_new.img/back-7",
			"origin" : [315,5],
			"z" : 0,
		},
		"8" :  {
			"png_path": "grassySoil_new.img/back-8",
			"origin" : [306,62],
			"z" : 0,
		},
		"9" :  {
			"png_path": "grassySoil_new.img/back-9",
			"origin" : [300,86],
			"z" : 0,
		},
		"10" :  {
			"png_path": "grassySoil_new.img/back-10",
			"origin" : [171,58],
			"z" : 0,
		},
		"11" :  {
			"png_path": "grassySoil_new.img/back-11",
			"origin" : [300,5],
			"z" : 0,
		},
		"12" :  {
			"png_path": "grassySoil_new.img/back-12",
			"origin" : [11,133],
			"z" : 0,
		},
		"13" :  {
			"png_path": "grassySoil_new.img/back-13",
			"origin" : [11,11],
			"z" : 0,
		},
		"14" :  {
			"png_path": "grassySoil_new.img/back-14",
			"origin" : [11,11],
			"z" : 0,
		},
		"15" :  {
			"png_path": "grassySoil_new.img/back-15",
			"origin" : [82,242],
			"z" : 0,
		},
		"16" :  {
			"png_path": "grassySoil_new.img/back-16",
			"origin" : [250,164],
			"z" : 0,
		},
		"17" :  {
			"png_path": "grassySoil_new.img/back-17",
			"origin" : [250,177],
			"z" : 0,
		},
		"18" :  {
			"png_path": "grassySoil_new.img/back-18",
			"origin" : [250,189],
			"z" : 0,
		},
		"19" :  {
			"png_path": "grassySoil_new.img/back-19",
			"origin" : [307,163],
			"z" : 0,
		},
		"20" :  {
			"png_path": "grassySoil_new.img/back-20",
			"origin" : [270,132],
			"z" : 0,
		},
		"21" :  {
			"png_path": "grassySoil_new.img/back-21",
			"origin" : [300,102],
			"z" : 0,
		},
		"22" :  {
			"png_path": "grassySoil_new.img/back-22",
			"origin" : [250,166],
			"z" : 0,
		},
		"23" :  {
			"png_path": "grassySoil_new.img/back-23",
			"origin" : [250,162],
			"z" : 0,
		},
	},
	"ani" : "",
};

