var Backdowntown3 = Backdowntown3 || { }; 
Backdowntown3 =   {
	"id":"downtown3",
	"back" :  {
		"0" :  {
			"png_path": "downtown3.img/back-0",
			"origin" : [84,68],
			"z" : 0,
		},
		"1" :  {
			"png_path": "downtown3.img/back-1",
			"origin" : [23,326],
			"z" : 0,
		},
		"2" :  {
			"png_path": "downtown3.img/back-2",
			"origin" : [424,118],
			"z" : 0,
		},
		"3" :  {
			"png_path": "downtown3.img/back-3",
			"origin" : [505,100],
			"z" : 0,
		},
		"4" :  {
			"png_path": "downtown3.img/back-4",
			"origin" : [471,181],
			"z" : 0,
		},
		"5" :  {
			"png_path": "downtown3.img/back-5",
			"origin" : [468,168],
			"z" : 0,
		},
		"6" :  {
			"png_path": "downtown3.img/back-6",
			"origin" : [405,154],
			"z" : 0,
		},
		"7" :  {
			"png_path": "downtown3.img/back-7",
			"origin" : [340,98],
			"z" : 0,
		},
		"8" :  {
			"png_path": "downtown3.img/back-8",
			"origin" : [480,208],
			"z" : 0,
		},
		"9" :  {
			"png_path": "downtown3.img/back-9",
			"origin" : [350,200],
			"z" : 0,
		},
		"10" :  {
			"png_path": "downtown3.img/back-10",
			"origin" : [150,115],
			"z" : 0,
		},
		"11" :  {
			"png_path": "downtown3.img/back-11",
			"origin" : [260,124],
			"z" : 0,
		},
		"12" :  {
			"png_path": "downtown3.img/back-12",
			"origin" : [185,99],
			"z" : 0,
		},
		"13" :  {
			"png_path": "downtown3.img/back-13",
			"origin" : [150,240],
			"z" : 0,
		},
		"14" :  {
			"png_path": "downtown3.img/back-14",
			"origin" : [220,124],
			"z" : 0,
		},
		"15" :  {
			"png_path": "downtown3.img/back-15",
			"origin" : [269,124],
			"z" : 0,
		},
		"16" :  {
			"png_path": "downtown3.img/back-16",
			"origin" : [283,67],
			"z" : 0,
		},
		"17" :  {
			"png_path": "downtown3.img/back-17",
			"origin" : [128,67],
			"z" : 0,
		},
		"18" :  {
			"png_path": "downtown3.img/back-18",
			"origin" : [166,166],
			"z" : 0,
		},
		"19" :  {
			"png_path": "downtown3.img/back-19",
			"origin" : [121,32],
			"z" : 0,
		},
		"20" :  {
			"png_path": "downtown3.img/back-20",
			"origin" : [110,43],
			"z" : 0,
		},
		"21" :  {
			"png_path": "downtown3.img/back-21",
			"origin" : [254,53],
			"z" : 0,
		},
		"22" :  {
			"png_path": "downtown3.img/back-22",
			"origin" : [189,36],
			"z" : 0,
		},
	},
};

