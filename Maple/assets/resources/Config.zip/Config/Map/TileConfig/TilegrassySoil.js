var TilegrassySoil = TilegrassySoil || { }; 
TilegrassySoil =   {
	"id":"grassySoil",
	"info" : "",
	"bsc" :  {
		"0" :  {
			"png_path": "grassySoil.img/bsc-0",
			"origin" : [0,0],
			"z" : 0,
		},
		"1" :  {
			"png_path": "grassySoil.img/bsc-1",
			"origin" : [0,0],
			"z" : 0,
		},
		"2" :  {
			"png_path": "grassySoil.img/bsc-2",
			"origin" : [0,0],
			"z" : 0,
		},
		"3" :  {
			"png_path": "grassySoil.img/bsc-3",
			"origin" : [0,0],
			"z" : 0,
		},
		"4" :  {
			"png_path": "grassySoil.img/bsc-4",
			"origin" : [0,0],
			"z" : 0,
		},
		"5" :  {
			"png_path": "grassySoil.img/bsc-5",
			"origin" : [0,0],
			"z" : 0,
		},
	},
	"enH0" :  {
		"0" :  {
			"png_path": "grassySoil.img/enH0-0",
			"origin" : [0,39],
			"map" : "",
			"z" : -3,
		},
		"1" :  {
			"png_path": "grassySoil.img/enH0-1",
			"origin" : [0,40],
			"map" : "",
			"z" : -3,
		},
		"2" :  {
			"png_path": "grassySoil.img/enH0-2",
			"origin" : [0,40],
			"z" : -3,
			"map" : "",
		},
		"3" :  {
			"png_path": "grassySoil.img/enH0-3",
			"origin" : [0,40],
			"z" : -3,
			"map" : "",
		},
	},
	"enH1" :  {
		"0" :  {
			"png_path": "grassySoil.img/enH1-0",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
		"1" :  {
			"png_path": "grassySoil.img/enH1-1",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
		"2" :  {
			"png_path": "grassySoil.img/enH1-2",
			"origin" : [0,0],
			"z" : -3,
			"map" : "",
		},
		"3" :  {
			"png_path": "grassySoil.img/enH1-3",
			"origin" : [0,0],
			"z" : -3,
			"map" : "",
		},
	},
	"enV0" :  {
		"0" :  {
			"png_path": "grassySoil.img/enV0-0",
			"origin" : [30,0],
			"map" : "",
			"z" : -2,
		},
		"1" :  {
			"png_path": "grassySoil.img/enV0-1",
			"origin" : [30,0],
			"map" : "",
			"z" : -2,
		},
		"2" :  {
			"png_path": "grassySoil.img/enV0-2",
			"origin" : [33,0],
			"z" : -2,
			"map" : "",
		},
	},
	"enV1" :  {
		"0" :  {
			"png_path": "grassySoil.img/enV1-0",
			"origin" : [0,0],
			"map" : "",
			"z" : -2,
		},
		"1" :  {
			"png_path": "grassySoil.img/enV1-1",
			"origin" : [0,0],
			"map" : "",
			"z" : -2,
		},
		"2" :  {
			"png_path": "grassySoil.img/enV1-2",
			"origin" : [0,0],
			"z" : -2,
			"map" : "",
		},
	},
	"edU" :  {
		"0" :  {
			"png_path": "grassySoil.img/edU-0",
			"origin" : [32,38],
			"z" : -4,
		},
		"1" :  {
			"png_path": "grassySoil.img/edU-1",
			"origin" : [29,40],
			"z" : -4,
		},
	},
	"edD" :  {
		"0" :  {
			"png_path": "grassySoil.img/edD-0",
			"origin" : [27,0],
			"z" : -4,
			"map" : "",
		},
		"1" :  {
			"png_path": "grassySoil.img/edD-1",
			"origin" : [27,0],
			"z" : -4,
			"map" : "",
		},
	},
	"slLU" :  {
		"0" :  {
			"png_path": "grassySoil.img/slLU-0",
			"origin" : [90,96],
			"z" : -3,
			"map" : "",
		},
	},
	"slRU" :  {
		"0" :  {
			"png_path": "grassySoil.img/slRU-0",
			"origin" : [0,96],
			"map" : "",
			"z" : -3,
		},
	},
	"slLD" :  {
		"0" :  {
			"png_path": "grassySoil.img/slLD-0",
			"origin" : [90,0],
			"map" : "",
			"z" : -3,
		},
		"1" :  {
			"png_path": "grassySoil.img/slLD-1",
			"origin" : [90,0],
			"map" : "",
			"z" : -3,
		},
	},
	"slRD" :  {
		"0" :  {
			"png_path": "grassySoil.img/slRD-0",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
		"1" :  {
			"png_path": "grassySoil.img/slRD-1",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
	},
};

