var TiledarkMountain3 = TiledarkMountain3 || { }; 
TiledarkMountain3 =   {
	"id":"darkMountain3",
	"info" : "",
	"bsc" :  {
		"0" :  {
			"png_path": "darkMountain3.img/bsc-0",
			"origin" : [0,0],
			"z" : 0,
		},
		"1" :  {
			"png_path": "darkMountain3.img/bsc-1",
			"origin" : [0,0],
			"z" : 0,
		},
		"2" :  {
			"png_path": "darkMountain3.img/bsc-2",
			"origin" : [0,0],
			"z" : 0,
		},
		"3" :  {
			"png_path": "darkMountain3.img/bsc-3",
			"origin" : [0,0],
			"z" : 0,
		},
		"4" :  {
			"png_path": "darkMountain3.img/bsc-4",
			"origin" : [0,0],
			"z" : 0,
		},
		"5" :  {
			"png_path": "darkMountain3.img/bsc-5",
			"origin" : [0,0],
			"z" : 0,
		},
	},
	"enH0" :  {
		"0" :  {
			"png_path": "darkMountain3.img/enH0-0",
			"origin" : [0,35],
			"map" : "",
			"z" : -3,
		},
		"1" :  {
			"png_path": "darkMountain3.img/enH0-1",
			"origin" : [0,35],
			"map" : "",
			"z" : -3,
		},
		"2" :  {
			"png_path": "darkMountain3.img/enH0-2",
			"origin" : [0,35],
			"map" : "",
			"z" : -3,
		},
	},
	"enH1" :  {
		"0" :  {
			"png_path": "darkMountain3.img/enH1-0",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
		"1" :  {
			"png_path": "darkMountain3.img/enH1-1",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
		"2" :  {
			"png_path": "darkMountain3.img/enH1-2",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
	},
	"enV0" :  {
		"0" :  {
			"png_path": "darkMountain3.img/enV0-0",
			"origin" : [20,0],
			"map" : "",
			"z" : -2,
		},
		"1" :  {
			"png_path": "darkMountain3.img/enV0-1",
			"origin" : [24,0],
			"map" : "",
			"z" : -2,
		},
	},
	"enV1" :  {
		"0" :  {
			"png_path": "darkMountain3.img/enV1-0",
			"origin" : [0,0],
			"map" : "",
			"z" : -2,
		},
		"1" :  {
			"png_path": "darkMountain3.img/enV1-1",
			"origin" : [0,0],
			"map" : "",
			"z" : -2,
		},
	},
	"edU" :  {
		"0" :  {
			"png_path": "darkMountain3.img/edU-0",
			"origin" : [28,35],
			"z" : -4,
		},
		"1" :  {
			"png_path": "darkMountain3.img/edU-1",
			"origin" : [28,34],
			"z" : -4,
		},
		"2" :  {
			"png_path": "darkMountain3.img/edU-2",
			"origin" : [28,35],
			"z" : -4,
		},
	},
	"edD" :  {
		"0" :  {
			"png_path": "darkMountain3.img/edD-0",
			"origin" : [16,0],
			"map" : "",
			"z" : -4,
		},
		"1" :  {
			"png_path": "darkMountain3.img/edD-1",
			"origin" : [18,0],
			"map" : "",
			"z" : -4,
		},
		"2" :  {
			"png_path": "darkMountain3.img/edD-2",
			"origin" : [16,0],
			"map" : "",
			"z" : -4,
		},
		"3" :  {
			"png_path": "darkMountain3.img/edD-3",
			"origin" : [15,0],
			"z" : -4,
		},
	},
	"slLU" :  {
		"0" :  {
			"png_path": "darkMountain3.img/slLU-0",
			"origin" : [90,94],
			"map" : "",
			"z" : -3,
		},
	},
	"slRU" :  {
		"0" :  {
			"png_path": "darkMountain3.img/slRU-0",
			"origin" : [0,95],
			"map" : "",
			"z" : -3,
		},
	},
	"slLD" :  {
		"0" :  {
			"png_path": "darkMountain3.img/slLD-0",
			"origin" : [90,0],
			"map" : "",
			"z" : -3,
		},
	},
	"slRD" :  {
		"0" :  {
			"png_path": "darkMountain3.img/slRD-0",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
	},
};

