var TilesnowyRord = TilesnowyRord || { }; 
TilesnowyRord =   {
	"id":"snowyRord",
	"info" : "",
	"bsc" :  {
		"0" :  {
			"png_path": "snowyRord.img/bsc-0",
			"origin" : [0,0],
			"map" : "",
			"z" : 0,
		},
		"1" :  {
			"png_path": "snowyRord.img/bsc-1",
			"origin" : [0,0],
			"map" : "",
			"z" : 0,
		},
		"2" :  {
			"png_path": "snowyRord.img/bsc-2",
			"origin" : [0,0],
			"map" : "",
			"z" : 0,
		},
		"3" :  {
			"png_path": "snowyRord.img/bsc-3",
			"origin" : [0,0],
			"map" : "",
			"z" : 0,
		},
		"4" :  {
			"png_path": "snowyRord.img/bsc-4",
			"origin" : [0,0],
			"map" : "",
			"z" : 0,
		},
		"5" :  {
			"png_path": "snowyRord.img/bsc-5",
			"origin" : [0,0],
			"map" : "",
			"z" : 0,
		},
	},
	"enH0" :  {
		"0" :  {
			"png_path": "snowyRord.img/enH0-0",
			"origin" : [0,39],
			"map" : "",
			"z" : -3,
		},
		"1" :  {
			"png_path": "snowyRord.img/enH0-1",
			"origin" : [0,40],
			"map" : "",
			"z" : -3,
		},
		"2" :  {
			"png_path": "snowyRord.img/enH0-2",
			"origin" : [0,39],
			"map" : "",
			"z" : -3,
		},
	},
	"enH1" :  {
		"0" :  {
			"png_path": "snowyRord.img/enH1-0",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
		"1" :  {
			"png_path": "snowyRord.img/enH1-1",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
		"2" :  {
			"png_path": "snowyRord.img/enH1-2",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
	},
	"enV0" :  {
		"0" :  {
			"png_path": "snowyRord.img/enV0-0",
			"origin" : [25,0],
			"map" : "",
			"z" : -2,
		},
		"1" :  {
			"png_path": "snowyRord.img/enV0-1",
			"origin" : [24,0],
			"map" : "",
			"z" : -2,
		},
	},
	"enV1" :  {
		"0" :  {
			"png_path": "snowyRord.img/enV1-0",
			"origin" : [0,0],
			"map" : "",
			"z" : -2,
		},
		"1" :  {
			"png_path": "snowyRord.img/enV1-1",
			"origin" : [0,0],
			"map" : "",
			"z" : -2,
		},
	},
	"edU" :  {
		"0" :  {
			"png_path": "snowyRord.img/edU-0",
			"origin" : [33,40],
			"map" : "",
			"z" : -4,
		},
		"1" :  {
			"png_path": "snowyRord.img/edU-1",
			"origin" : [31,39],
			"map" : "",
			"z" : -4,
		},
	},
	"edD" :  {
		"0" :  {
			"png_path": "snowyRord.img/edD-0",
			"origin" : [18,0],
			"map" : "",
			"z" : -4,
		},
		"1" :  {
			"png_path": "snowyRord.img/edD-1",
			"origin" : [20,0],
			"map" : "",
			"z" : -4,
		},
	},
	"slLU" :  {
		"0" :  {
			"png_path": "snowyRord.img/slLU-0",
			"origin" : [90,98],
			"map" : "",
			"z" : -3,
		},
	},
	"slRU" :  {
		"0" :  {
			"png_path": "snowyRord.img/slRU-0",
			"origin" : [0,98],
			"map" : "",
			"z" : -3,
		},
	},
	"slLD" :  {
		"0" :  {
			"png_path": "snowyRord.img/slLD-0",
			"origin" : [90,0],
			"map" : "",
			"z" : -3,
		},
	},
	"slRD" :  {
		"0" :  {
			"png_path": "snowyRord.img/slRD-0",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
	},
};

