var TiledarkblueToyCastle = TiledarkblueToyCastle || { }; 
TiledarkblueToyCastle =   {
	"id":"darkblueToyCastle",
	"info" : "",
	"bsc" :  {
		"0" :  {
			"png_path": "darkblueToyCastle.img/bsc-0",
			"origin" : [0,0],
			"z" : 0,
		},
		"1" :  {
			"png_path": "darkblueToyCastle.img/bsc-1",
			"origin" : [0,0],
			"z" : 0,
		},
		"2" :  {
			"png_path": "darkblueToyCastle.img/bsc-2",
			"origin" : [0,0],
			"z" : 0,
		},
		"3" :  {
			"png_path": "darkblueToyCastle.img/bsc-3",
			"origin" : [0,0],
			"z" : 0,
		},
		"4" :  {
			"png_path": "darkblueToyCastle.img/bsc-4",
			"origin" : [0,0],
			"z" : 0,
		},
		"5" :  {
			"png_path": "darkblueToyCastle.img/bsc-5",
			"origin" : [0,0],
			"z" : 0,
		},
	},
	"enH0" :  {
		"0" :  {
			"png_path": "darkblueToyCastle.img/enH0-0",
			"origin" : [0,18],
			"map" : "",
			"z" : -3,
		},
		"1" :  {
			"png_path": "darkblueToyCastle.img/enH0-1",
			"origin" : [0,18],
			"map" : "",
			"z" : -3,
		},
		"2" :  {
			"png_path": "darkblueToyCastle.img/enH0-2",
			"origin" : [0,18],
			"map" : "",
			"z" : -3,
		},
	},
	"enH1" :  {
		"0" :  {
			"png_path": "darkblueToyCastle.img/enH1-0",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
		"1" :  {
			"png_path": "darkblueToyCastle.img/enH1-1",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
		"2" :  {
			"png_path": "darkblueToyCastle.img/enH1-2",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
	},
	"enV0" :  {
		"0" :  {
			"png_path": "darkblueToyCastle.img/enV0-0",
			"origin" : [22,0],
			"map" : "",
			"z" : -2,
		},
		"1" :  {
			"png_path": "darkblueToyCastle.img/enV0-1",
			"origin" : [22,0],
			"map" : "",
			"z" : -2,
		},
	},
	"enV1" :  {
		"0" :  {
			"png_path": "darkblueToyCastle.img/enV1-0",
			"origin" : [0,0],
			"map" : "",
			"z" : -2,
		},
		"1" :  {
			"png_path": "darkblueToyCastle.img/enV1-1",
			"origin" : [0,0],
			"map" : "",
			"z" : -2,
		},
	},
	"edU" :  {
		"0" :  {
			"png_path": "darkblueToyCastle.img/edU-0",
			"origin" : [22,18],
			"z" : -4,
		},
	},
	"edD" :  {
		"0" :  {
			"png_path": "darkblueToyCastle.img/edD-0",
			"origin" : [22,0],
			"map" : "",
			"z" : -4,
		},
	},
	"slLU" :  {
		"0" :  {
			"png_path": "darkblueToyCastle.img/slLU-0",
			"origin" : [90,75],
			"map" : "",
			"z" : -3,
		},
	},
	"slRU" :  {
		"0" :  {
			"png_path": "darkblueToyCastle.img/slRU-0",
			"origin" : [0,78],
			"map" : "",
			"z" : -3,
		},
	},
	"slLD" :  {
		"0" :  {
			"png_path": "darkblueToyCastle.img/slLD-0",
			"origin" : [90,0],
			"map" : "",
			"z" : -3,
		},
	},
	"slRD" :  {
		"0" :  {
			"png_path": "darkblueToyCastle.img/slRD-0",
			"origin" : [0,0],
			"map" : "",
			"z" : -3,
		},
	},
};

