var Mob9700000 = Mob9700000 || { }; 
Mob9700000 =   {
	"id":"9700000",
	"move" :  {
		"0" :  {
			"png_path": "move-0",
			"origin" : [29,51],
			"delay" : "200",
		},
		"1" :  {
			"png_path": "move-1",
			"origin" : [31,53],
			"delay" : "50",
		},
		"2" :  {
			"png_path": "move-2",
			"origin" : [27,71],
			"delay" : "150",
		},
		"3" :  {
			"png_path": "move-3",
			"origin" : [27,71],
			"delay" : "150",
		},
		"4" :  {
			"png_path": "move-4",
			"origin" : [27,94],
			"delay" : "100",
		},
		"5" :  {
			"png_path": "move-5",
			"origin" : [28,71],
			"delay" : "100",
		},
		"6" :  {
			"png_path": "move-6",
			"origin" : [27,46],
			"delay" : "300",
		},
	},
	"stand" :  {
		"0" :  {
			"png_path": "stand-0",
			"origin" : [27,49],
			"delay" : "200",
		},
		"1" :  {
			"png_path": "stand-1",
			"origin" : [28,49],
			"delay" : "300",
		},
		"2" :  {
			"png_path": "stand-2",
			"origin" : [26,50],
			"delay" : "250",
		},
	},
	"jump" :  {
		"0" :  {
			"png_path": "jump-0",
			"origin" : [27,54],
			"delay" : "150",
		},
	},
	"hit1" :  {
		"0" :  {
			"png_path": "hit1-0",
			"origin" : [23,66],
			"delay" : 600,
		},
	},
	"die1" :  {
		"0" :  {
			"png_path": "die1-0",
			"origin" : [23,66],
			"delay" : 150,
		},
		"1" :  {
			"png_path": "die1-1",
			"origin" : [0,146],
			"delay" : 150,
		},
		"2" :  {
			"png_path": "die1-2",
			"origin" : [-8,187],
			"delay" : 150,
		},
		"3" :  {
			"png_path": "die1-3",
			"origin" : [-15,234],
			"delay" : 150,
			"a0" : 255,
			"a1" : 0,
		},
		"4" :  {
			"png_path": "die1-4",
			"origin" : [-24,263],
			"delay" : 150,
		},
		"5" :  {
			"png_path": "die1-5",
			"origin" : [-62,273],
			"delay" : 150,
		},
		"6" :  {
			"png_path": "die1-6",
			"origin" : [-67,276],
			"delay" : 150,
		},
	},
	"die2" :  {
		"0" :  {
			"png_path": "die2-0",
			"origin" : [23,66],
			"delay" : 150,
		},
		"1" :  {
			"png_path": "die2-1",
			"origin" : [-33,121],
			"delay" : 150,
		},
		"2" :  {
			"png_path": "die2-2",
			"origin" : [-53,157],
			"delay" : 150,
		},
		"3" :  {
			"png_path": "die2-3",
			"origin" : [-64,185],
			"delay" : 150,
			"a0" : 255,
			"a1" : 0,
		},
		"4" :  {
			"png_path": "die2-4",
			"origin" : [-71,198],
			"delay" : 150,
		},
		"5" :  {
			"png_path": "die2-5",
			"origin" : [-152,203],
			"delay" : 150,
		},
		"6" :  {
			"png_path": "die2-6",
			"origin" : [-4,301],
			"delay" : 150,
		},
	},
	"dieF" :  {
		"0" :  {
			"png_path": "dieF-0",
			"origin" : [23,66],
			"delay" : 150,
		},
		"1" :  {
			"png_path": "dieF-1",
			"origin" : [-5,71],
			"delay" : 150,
		},
		"2" :  {
			"png_path": "dieF-2",
			"origin" : [-12,54],
			"delay" : 150,
		},
		"3" :  {
			"png_path": "dieF-3",
			"origin" : [-11,44],
			"delay" : 150,
			"a0" : 255,
			"a1" : 0,
		},
		"4" :  {
			"png_path": "dieF-4",
			"origin" : [-19,44],
			"delay" : 150,
		},
		"5" :  {
			"png_path": "dieF-5",
			"origin" : [-94,43],
			"delay" : 150,
		},
		"6" :  {
			"png_path": "dieF-6",
			"origin" : [-85,83],
			"delay" : 150,
		},
	},
	"miss" :  {
		"0" :  {
			"png_path": "miss-0",
			"origin" : [29,50],
			"delay" : "200",
		},
		"1" :  {
			"png_path": "miss-1",
			"origin" : [31,53],
			"delay" : "50",
		},
		"2" :  {
			"png_path": "miss-2",
			"origin" : [27,71],
			"delay" : "150",
		},
		"3" :  {
			"png_path": "miss-3",
			"origin" : [27,71],
			"delay" : "150",
		},
		"4" :  {
			"png_path": "miss-4",
			"origin" : [27,94],
			"delay" : "100",
		},
		"5" :  {
			"png_path": "miss-5",
			"origin" : [28,71],
			"delay" : "100",
		},
		"6" :  {
			"png_path": "miss-6",
			"origin" : [27,46],
			"delay" : "300",
			"a0" : 255,
			"a1" : 0,
		},
	},
};

