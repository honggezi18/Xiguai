var Mob0100100 = Mob0100100 || { }; 
Mob0100100 =   {
	"id":"0100100",
	"move" :  {
		"zigzag" : 1,
		"0" :  {
			"png_path": "move-0",
			"origin" : [18,26],
			"delay" : 180,
		},
		"1" :  {
			"png_path": "move-1",
			"origin" : [17,25],
			"delay" : 180,
		},
		"2" :  {
			"png_path": "move-2",
			"origin" : [17,25],
			"delay" : 180,
		},
		"3" :  {
			"png_path": "move-3",
			"origin" : [17,24],
			"delay" : 180,
		},
		"4" :  {
			"png_path": "move-4",
			"origin" : [18,24],
			"delay" : 180,
		},
	},
	"stand" :  {
		"0" :  {
			"png_path": "stand-0",
			"origin" : [18,26],
		},
	},
	"hit1" :  {
		"0" :  {
			"png_path": "hit1-0",
			"origin" : [21,33],
			"delay" : 600,
		},
	},
	"die1" :  {
		"0" :  {
			"png_path": "die1-0",
			"origin" : [21,33],
			"delay" : 120,
		},
		"1" :  {
			"png_path": "die1-1",
			"origin" : [22,31],
			"delay" : 120,
		},
		"2" :  {
			"png_path": "die1-2",
			"origin" : [14,24],
			"delay" : 120,
		},
		"3" :  {
			"png_path": "die1-3",
			"origin" : [14,24],
			"delay" : 120,
		},
		"4" :  {
			"png_path": "die1-4",
			"origin" : [13,23],
			"delay" : 120,
		},
		"5" :  {
			"png_path": "die1-5",
			"origin" : [13,18],
			"delay" : 120,
		},
		"6" :  {
			"png_path": "die1-6",
			"origin" : [13,14],
			"delay" : 120,
		},
		"7" :  {
			"png_path": "die1-7",
			"origin" : [13,10],
			"delay" : 120,
		},
		"8" :  {
			"png_path": "die1-8",
			"origin" : [13,6],
			"delay" : 300,
			"a0" : 255,
			"a1" : 0,
		},
	},
};

