var Mob9303002 = Mob9303002 || { }; 
Mob9303002 =   {
	"id":"9303002",
	"move" :  {
		"0" :  {
			"png_path": "move-0",
			"origin" : [75,153],
			"delay" : 200,
		},
		"1" :  {
			"png_path": "move-1",
			"origin" : [75,180],
			"delay" : 50,
		},
		"2" :  {
			"png_path": "move-2",
			"origin" : [71,230],
			"delay" : 150,
		},
		"3" :  {
			"png_path": "move-3",
			"origin" : [71,225],
			"delay" : 150,
		},
		"4" :  {
			"png_path": "move-4",
			"origin" : [71,254],
			"delay" : 100,
		},
		"5" :  {
			"png_path": "move-5",
			"origin" : [75,216],
			"delay" : 100,
		},
		"6" :  {
			"png_path": "move-6",
			"origin" : [73,142],
			"delay" : 300,
		},
	},
	"stand" :  {
		"0" :  {
			"png_path": "stand-0",
			"origin" : [73,142],
			"delay" : 300,
		},
		"1" :  {
			"png_path": "stand-1",
			"origin" : [76,139],
			"delay" : 250,
		},
	},
	"jump" :  {
		"0" :  {
			"png_path": "jump-0",
			"origin" : [71,155],
		},
	},
	"attack1" :  {
		"0" :  {
			"png_path": "attack1-0",
			"origin" : [73,142],
			"delay" : 300,
		},
		"1" :  {
			"png_path": "attack1-1",
			"origin" : [75,153],
			"delay" : 100,
		},
		"2" :  {
			"png_path": "attack1-2",
			"origin" : [75,180],
			"delay" : 100,
		},
		"3" :  {
			"png_path": "attack1-3",
			"origin" : [71,230],
			"delay" : 150,
		},
		"4" :  {
			"png_path": "attack1-4",
			"origin" : [71,225],
			"delay" : 150,
		},
		"5" :  {
			"png_path": "attack1-5",
			"origin" : [71,254],
			"delay" : 100,
		},
		"6" :  {
			"png_path": "attack1-6",
			"origin" : [75,216],
			"delay" : 100,
		},
		"7" :  {
			"png_path": "attack1-7",
			"origin" : [73,142],
			"delay" : 500,
		},
	},
	"skill1" :  {
		"0" :  {
			"png_path": "skill1-0",
			"origin" : [73,142],
			"delay" : 120,
		},
		"1" :  {
			"png_path": "skill1-1",
			"origin" : [73,226],
			"delay" : 120,
		},
		"2" :  {
			"png_path": "skill1-2",
			"origin" : [73,224],
			"delay" : 120,
		},
		"3" :  {
			"png_path": "skill1-3",
			"origin" : [73,224],
			"delay" : 120,
		},
		"4" :  {
			"png_path": "skill1-4",
			"origin" : [73,234],
			"delay" : 120,
		},
		"5" :  {
			"png_path": "skill1-5",
			"origin" : [73,240],
			"delay" : 120,
		},
		"6" :  {
			"png_path": "skill1-6",
			"origin" : [73,250],
			"delay" : 120,
		},
		"7" :  {
			"png_path": "skill1-7",
			"origin" : [73,264],
			"delay" : 120,
		},
		"8" :  {
			"png_path": "skill1-8",
			"origin" : [73,280],
			"delay" : 120,
		},
		"9" :  {
			"png_path": "skill1-9",
			"origin" : [73,279],
			"delay" : 120,
		},
		"10" :  {
			"png_path": "skill1-10",
			"origin" : [73,224],
			"delay" : 120,
		},
	},
	"hit1" :  {
		"0" :  {
			"png_path": "hit1-0",
			"origin" : [66,218],
			"delay" : 600,
		},
	},
	"die1" :  {
		"0" :  {
			"png_path": "die1-0",
			"origin" : [66,218],
			"delay" : 80,
		},
		"1" :  {
			"png_path": "die1-1",
			"origin" : [66,218],
			"delay" : 80,
		},
		"2" :  {
			"png_path": "die1-2",
			"origin" : [66,218],
			"delay" : 80,
		},
		"3" :  {
			"png_path": "die1-3",
			"origin" : [90,218],
			"delay" : 130,
		},
		"4" :  {
			"png_path": "die1-4",
			"origin" : [123,218],
			"delay" : 130,
		},
		"5" :  {
			"png_path": "die1-5",
			"origin" : [122,218],
			"delay" : 130,
		},
		"6" :  {
			"png_path": "die1-6",
			"origin" : [115,218],
			"delay" : 140,
		},
		"7" :  {
			"png_path": "die1-7",
			"origin" : [102,153],
			"delay" : 150,
			"a0" : 255,
			"a1" : 0,
		},
	},
};

