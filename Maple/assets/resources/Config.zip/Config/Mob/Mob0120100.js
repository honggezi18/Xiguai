var Mob0120100 = Mob0120100 || { }; 
Mob0120100 =   {
	"id":"0120100",
	"move" :  {
		"0" :  {
			"png_path": "move-0",
			"origin" : [18,36],
			"delay" : 180,
		},
		"1" :  {
			"png_path": "move-1",
			"origin" : [20,37],
			"delay" : 180,
		},
		"2" :  {
			"png_path": "move-2",
			"origin" : [21,36],
			"delay" : 180,
		},
		"3" :  {
			"png_path": "move-3",
			"origin" : [23,36],
			"delay" : 180,
		},
	},
	"stand" :  {
		"zigzag" : 1,
		"0" :  {
			"png_path": "stand-0",
			"origin" : [18,36],
			"delay" : 180,
		},
		"1" :  {
			"png_path": "stand-1",
			"origin" : [18,36],
			"delay" : 100,
		},
		"2" :  {
			"png_path": "stand-2",
			"origin" : [18,36],
			"delay" : 180,
		},
	},
	"hit1" :  {
		"0" :  {
			"png_path": "hit1-0",
			"origin" : [18,36],
			"delay" : 600,
		},
	},
	"die1" :  {
		"0" :  {
			"png_path": "die1-0",
			"origin" : [20,32],
			"delay" : 120,
		},
		"1" :  {
			"png_path": "die1-1",
			"origin" : [11,33],
			"delay" : 120,
		},
		"2" :  {
			"png_path": "die1-2",
			"origin" : [-2,37],
			"delay" : 120,
		},
		"3" :  {
			"png_path": "die1-3",
			"origin" : [-8,27],
			"delay" : 300,
			"a0" : 255,
			"a1" : 0,
		},
	},
};

