var Mob9300422 = Mob9300422 || { }; 
Mob9300422 =   {
	"id":"9300422",
	"stand" :  {
		"0" :  {
			"png_path": "stand-0",
			"origin" : [26,50],
		},
		"1" :  {
			"png_path": "stand-1",
			"origin" : [27,50],
		},
		"2" :  {
			"png_path": "stand-2",
			"origin" : [26,50],
		},
		"3" :  {
			"png_path": "stand-3",
			"origin" : [25,51],
		},
	},
	"move" :  {
		"0" :  {
			"png_path": "move-0",
			"origin" : [27,54],
		},
		"1" :  {
			"png_path": "move-1",
			"origin" : [25,52],
		},
		"2" :  {
			"png_path": "move-2",
			"origin" : [23,72],
		},
		"3" :  {
			"png_path": "move-3",
			"origin" : [23,73],
		},
		"4" :  {
			"png_path": "move-4",
			"origin" : [23,94],
		},
		"5" :  {
			"png_path": "move-5",
			"origin" : [24,72],
		},
	},
	"hit1" :  {
		"0" :  {
			"png_path": "hit1-0",
			"origin" : [18,67],
			"delay" : 600,
		},
	},
	"die1" :  {
		"0" :  {
			"png_path": "die1-0",
			"origin" : [18,67],
		},
		"1" :  {
			"png_path": "die1-1",
			"origin" : [19,61],
		},
		"2" :  {
			"png_path": "die1-2",
			"origin" : [23,60],
		},
		"3" :  {
			"png_path": "die1-3",
			"origin" : [19,55],
		},
		"4" :  {
			"png_path": "die1-4",
			"origin" : [7,41],
		},
	},
};

