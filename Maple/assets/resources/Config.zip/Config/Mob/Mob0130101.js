var Mob0130101 = Mob0130101 || { }; 
Mob0130101 =   {
	"id":"0130101",
	"move" :  {
		"zigzag" : 1,
		"0" :  {
			"png_path": "move-0",
			"origin" : [16,34],
			"delay" : 120,
		},
		"1" :  {
			"png_path": "move-1",
			"origin" : [15,34],
			"delay" : 120,
		},
		"2" :  {
			"png_path": "move-2",
			"origin" : [14,34],
			"delay" : 120,
		},
		"3" :  {
			"png_path": "move-3",
			"origin" : [13,34],
			"delay" : 120,
		},
	},
	"stand" :  {
		"0" :  {
			"png_path": "stand-0",
			"origin" : [16,34],
		},
	},
	"hit1" :  {
		"0" :  {
			"png_path": "hit1-0",
			"origin" : [16,39],
			"delay" : 600,
		},
	},
	"die1" :  {
		"0" :  {
			"png_path": "die1-0",
			"origin" : [19,32],
			"delay" : 180,
		},
		"1" :  {
			"png_path": "die1-1",
			"origin" : [23,29],
			"delay" : 180,
		},
		"2" :  {
			"png_path": "die1-2",
			"origin" : [30,27],
			"delay" : 300,
			"a0" : 255,
			"a1" : 0,
		},
	},
};

