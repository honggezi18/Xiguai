var Mob2220100 = Mob2220100 || { }; 
Mob2220100 =   {
	"id":"2220100",
	"move" :  {
		"0" :  {
			"png_path": "move-0",
			"origin" : [32,55],
			"delay" : 180,
		},
		"1" :  {
			"png_path": "move-1",
			"origin" : [31,67],
			"delay" : 120,
		},
		"2" :  {
			"png_path": "move-2",
			"origin" : [31,55],
			"delay" : 180,
		},
	},
	"stand" :  {
		"0" :  {
			"png_path": "stand-0",
			"origin" : [27,58],
			"delay" : 180,
		},
		"1" :  {
			"png_path": "stand-1",
			"origin" : [27,55],
			"delay" : 180,
		},
	},
	"jump" :  {
		"0" :  {
			"png_path": "jump-0",
			"origin" : [28,64],
		},
	},
	"hit1" :  {
		"0" :  {
			"png_path": "hit1-0",
			"origin" : [28,65],
			"delay" : 600,
		},
	},
	"die1" :  {
		"0" :  {
			"png_path": "die1-0",
			"origin" : [30,59],
			"delay" : 180,
		},
		"1" :  {
			"png_path": "die1-1",
			"origin" : [32,52],
			"delay" : 180,
		},
		"2" :  {
			"png_path": "die1-2",
			"origin" : [34,44],
			"delay" : 300,
			"a0" : 255,
			"a1" : 0,
		},
	},
};

