var Mob9700001 = Mob9700001 || { }; 
Mob9700001 =   {
	"id":"9700001",
	"move" :  {
		"0" :  {
			"png_path": "move-0",
			"origin" : [32,55],
			"delay" : 180,
		},
		"1" :  {
			"png_path": "move-1",
			"origin" : [31,67],
			"delay" : 120,
		},
		"2" :  {
			"png_path": "move-2",
			"origin" : [31,55],
			"delay" : 180,
		},
	},
	"stand" :  {
		"0" :  {
			"png_path": "stand-0",
			"origin" : [27,58],
			"delay" : 180,
		},
		"1" :  {
			"png_path": "stand-1",
			"origin" : [27,55],
			"delay" : 180,
		},
	},
	"hit1" :  {
		"0" :  {
			"png_path": "hit1-0",
			"origin" : [28,65],
			"delay" : 600,
		},
	},
	"die1" :  {
		"0" :  {
			"png_path": "die1-0",
			"origin" : [28,65],
			"delay" : 150,
		},
		"1" :  {
			"png_path": "die1-1",
			"origin" : [7,149],
			"delay" : 150,
		},
		"2" :  {
			"png_path": "die1-2",
			"origin" : [5,206],
			"delay" : 150,
		},
		"3" :  {
			"png_path": "die1-3",
			"origin" : [2,250],
			"delay" : 150,
		},
		"4" :  {
			"png_path": "die1-4",
			"origin" : [-22,275],
			"delay" : 150,
		},
		"5" :  {
			"png_path": "die1-5",
			"origin" : [-26,271],
			"delay" : 150,
		},
		"6" :  {
			"png_path": "die1-6",
			"origin" : [-30,282],
			"delay" : 150,
		},
	},
	"die2" :  {
		"0" :  {
			"png_path": "die2-0",
			"origin" : [28,65],
			"delay" : 150,
		},
		"1" :  {
			"png_path": "die2-1",
			"origin" : [-66,130],
			"delay" : 150,
		},
		"2" :  {
			"png_path": "die2-2",
			"origin" : [-122,176],
			"delay" : 150,
		},
		"3" :  {
			"png_path": "die2-3",
			"origin" : [-164,206],
			"delay" : 150,
		},
		"4" :  {
			"png_path": "die2-4",
			"origin" : [-191,224],
			"delay" : 150,
		},
		"5" :  {
			"png_path": "die2-5",
			"origin" : [-210,234],
			"delay" : 150,
		},
		"6" :  {
			"png_path": "die2-6",
			"origin" : [-219,239],
			"delay" : 150,
		},
	},
	"dieF" :  {
		"0" :  {
			"png_path": "dieF-0",
			"origin" : [28,65],
			"delay" : 150,
		},
		"1" :  {
			"png_path": "dieF-1",
			"origin" : [-41,79],
			"delay" : 150,
		},
		"2" :  {
			"png_path": "dieF-2",
			"origin" : [-38,73],
			"delay" : 150,
		},
		"3" :  {
			"png_path": "dieF-3",
			"origin" : [-37,70],
			"delay" : 150,
		},
		"4" :  {
			"png_path": "dieF-4",
			"origin" : [-122,59],
			"delay" : 150,
		},
		"5" :  {
			"png_path": "dieF-5",
			"origin" : [-130,52],
			"delay" : 150,
		},
		"6" :  {
			"png_path": "dieF-6",
			"origin" : [-145,44],
			"delay" : 150,
		},
	},
	"miss" :  {
		"0" :  {
			"png_path": "miss-0",
			"origin" : [32,55],
			"delay" : 180,
		},
		"1" :  {
			"png_path": "miss-1",
			"origin" : [31,67],
			"delay" : 120,
		},
		"2" :  {
			"png_path": "miss-2",
			"origin" : [31,55],
			"delay" : 180,
			"a0" : 255,
			"a1" : 0,
		},
	},
};

