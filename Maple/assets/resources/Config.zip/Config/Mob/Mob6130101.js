var Mob6130101 = Mob6130101 || { }; 
Mob6130101 =   {
	"id":"6130101",
	"move" :  {
		"0" :  {
			"png_path": "move-0",
			"origin" : [59,110],
			"delay" : 500,
		},
		"1" :  {
			"png_path": "move-1",
			"origin" : [60,105],
			"delay" : 100,
		},
		"2" :  {
			"png_path": "move-2",
			"origin" : [59,102],
			"delay" : 100,
		},
		"3" :  {
			"png_path": "move-3",
			"origin" : [59,180],
			"delay" : 300,
		},
		"4" :  {
			"png_path": "move-4",
			"origin" : [59,160],
			"delay" : 100,
		},
		"5" :  {
			"png_path": "move-1",
			"origin" : [60,105],
			"delay" : 100,
		},
	},
	"stand" :  {
		"0" :  {
			"png_path": "stand-0",
			"origin" : [59,110],
		},
	},
	"jump" :  {
		"0" :  {
			"png_path": "jump-0",
			"origin" : [59,125],
		},
	},
	"attack1" :  {
		"0" :  {
			"png_path": "attack1-0",
			"origin" : [59,102],
			"delay" : 800,
		},
		"1" :  {
			"png_path": "attack1-1",
			"origin" : [59,213],
			"delay" : 200,
		},
		"2" :  {
			"png_path": "attack1-2",
			"origin" : [60,195],
			"delay" : 50,
		},
		"3" :  {
			"png_path": "attack1-3",
			"origin" : [60,133],
			"delay" : 50,
		},
		"4" :  {
			"png_path": "attack1-4",
			"origin" : [58,105],
			"delay" : 750,
		},
	},
	"hit1" :  {
		"0" :  {
			"png_path": "hit1-0",
			"origin" : [59,140],
			"delay" : 600,
		},
	},
	"die1" :  {
		"0" :  {
			"png_path": "die1-0",
			"origin" : [60,140],
			"delay" : 200,
		},
		"1" :  {
			"png_path": "die1-1",
			"origin" : [82,61],
			"delay" : 150,
		},
		"2" :  {
			"png_path": "die1-2",
			"origin" : [90,61],
			"delay" : 150,
		},
		"3" :  {
			"png_path": "die1-3",
			"origin" : [90,61],
			"delay" : 150,
		},
		"4" :  {
			"png_path": "die1-4",
			"origin" : [104,61],
			"delay" : 150,
		},
		"5" :  {
			"png_path": "die1-5",
			"origin" : [96,61],
			"delay" : 300,
			"a0" : 255,
			"a1" : 0,
		},
	},
};

