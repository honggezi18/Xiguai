var Mob1110100 = Mob1110100 || { }; 
Mob1110100 =   {
	"id":"1110100",
	"move" :  {
		"0" :  {
			"png_path": "move-0",
			"origin" : [27,52],
			"delay" : 150,
		},
		"1" :  {
			"png_path": "move-1",
			"origin" : [27,51],
			"delay" : 150,
		},
		"2" :  {
			"png_path": "move-2",
			"origin" : [27,52],
			"delay" : 150,
		},
		"3" :  {
			"png_path": "move-3",
			"origin" : [27,51],
			"delay" : 150,
		},
	},
	"stand" :  {
		"0" :  {
			"png_path": "stand-0",
			"origin" : [27,52],
			"delay" : 180,
		},
		"1" :  {
			"png_path": "stand-1",
			"origin" : [27,52],
			"delay" : 100,
		},
		"2" :  {
			"png_path": "stand-2",
			"origin" : [27,52],
			"delay" : 180,
		},
	},
	"hit1" :  {
		"0" :  {
			"png_path": "hit1-0",
			"origin" : [27,56],
			"delay" : 600,
		},
	},
	"die1" :  {
		"0" :  {
			"png_path": "die1-0",
			"origin" : [28,49],
			"delay" : 180,
		},
		"1" :  {
			"png_path": "die1-1",
			"origin" : [27,48],
			"delay" : 180,
		},
		"2" :  {
			"png_path": "die1-2",
			"origin" : [28,46],
			"delay" : 180,
		},
		"3" :  {
			"png_path": "die1-3",
			"origin" : [29,46],
			"delay" : 300,
			"a0" : 255,
			"a1" : 0,
		},
	},
};

