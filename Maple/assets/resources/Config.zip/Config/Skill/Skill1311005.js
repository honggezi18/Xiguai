var Skill1311005 = Skill1311005 || { }; 
Skill1311005 =   {
	"id":"1311005",
	"effect" :  {
		"0" :  {
			"png_path": "effect-0",
			"origin" : [81,152],
			"delay" : 400,
			"a0" : 0,
			"a1" : 255,
		},
		"1" :  {
			"png_path": "effect-1",
			"origin" : [81,152],
			"delay" : 200,
			"a0" : 212,
			"a1" : 64,
			"z0" : 100,
			"z1" : 200,
		},
		"z" : -1,
	},
};

