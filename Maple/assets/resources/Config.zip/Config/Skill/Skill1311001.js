var Skill1311001 = Skill1311001 || { }; 
Skill1311001 =   {
	"id":"1311001",
	"effect" :  {
		"0" :  {
			"png_path": "effect-0",
			"origin" : [56,192],
			"a0" : 0,
			"a1" : 255,
			"delay" : 450,
		},
		"1" :  {
			"png_path": "effect-1",
			"origin" : [56,192],
			"a0" : 255,
			"a1" : 0,
			"delay" : 450,
		},
	},
	"effect0" :  {
		"0" :  {
			"png_path": "effect0-0",
			"origin" : [0,0],
			"delay" : 300,
			"a0" : 0,
		},
		"1" :  {
			"png_path": "effect0-1",
			"origin" : [78,94],
			"delay" : 200,
			"a0" : 212,
			"a1" : 64,
			"z0" : 100,
			"z1" : 200,
		},
		"2" :  {
			"png_path": "effect0-2",
			"origin" : [105,97],
			"delay" : 200,
			"a0" : 212,
			"a1" : 64,
			"z0" : 100,
			"z1" : 200,
		},
	},
	"effect1" :  {
		"0" :  {
			"png_path": "effect1-0",
			"origin" : [0,0],
			"delay" : 600,
			"a0" : 0,
		},
		"1" :  {
			"png_path": "effect1-1",
			"origin" : [173,60],
			"delay" : 30,
			"a0" : 255,
		},
		"2" :  {
			"png_path": "effect1-2",
			"origin" : [190,66],
			"delay" : "200",
			"a1" : 0,
		},
	},
	"effect2" :  {
		"0" :  {
			"png_path": "effect2-0",
			"origin" : [0,0],
			"delay" : 750,
			"a0" : 0,
		},
		"1" :  {
			"png_path": "effect2-1",
			"origin" : [165,53],
			"delay" : 30,
			"a0" : 255,
		},
		"2" :  {
			"png_path": "effect2-2",
			"origin" : [182,45],
			"delay" : "200",
			"a1" : 0,
		},
	},
	"effect3" :  {
		"0" :  {
			"png_path": "effect3-0",
			"origin" : [0,0],
			"delay" : 900,
			"a0" : 0,
		},
		"1" :  {
			"png_path": "effect3-1",
			"origin" : [174,71],
			"delay" : 30,
			"a0" : 255,
		},
		"2" :  {
			"png_path": "effect3-2",
			"origin" : [178,72],
			"delay" : "200",
			"a1" : 0,
		},
	},
	"hit" :  {
		"0" :  {
			"0" :  {
				"png_path": "hit-0-0",
				"origin" : [24,72],
				"delay" : 100,
			},
			"1" :  {
				"png_path": "hit-0-1",
				"origin" : [22,70],
				"delay" : 100,
			},
			"2" :  {
				"png_path": "hit-0-2",
				"origin" : [9,62],
				"delay" : 100,
			},
			"3" :  {
				"png_path": "hit-0-3",
				"origin" : [3,56],
				"delay" : 100,
			},
		},
	},
};

