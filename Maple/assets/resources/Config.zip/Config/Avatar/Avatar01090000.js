var Avatar01090000 = Avatar01090000 || { }; 
Avatar01090000 =   {
	"id":"01090000",
	"info" :  {
		"icon" :  {
			"png_path": "01090000|info-icon",
			"origin" : [0,31],
		},
		"iconRaw" :  {
			"png_path": "01090000|info-iconRaw",
			"origin" : [-1,31],
		},
		"islot" : "Si",
		"vslot" : "Si",
		"reqJob" : 0,
		"reqLevel" : 0,
		"incPAD" : 1,
		"tuc" : 7,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"pickUpBlock" : 1,
		"notSale" : 1,
		"timeLimited" : 1,
		"cash" : 0,
	},
	"walk1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|walk1-0-shield",
				"origin" : [25,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shield",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|walk1-1-shield",
				"origin" : [22,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shield",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01090000|walk1-0-shield",
				"origin" : [25,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shield",
			},
		},
		"3" :  {
			"shield" :  {
				"png_path": "01090000|walk1-3-shield",
				"origin" : [28,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shield",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|stand1-0-shield",
				"origin" : [19,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|stand1-1-shield",
				"origin" : [21,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01090000|stand1-2-shield",
				"origin" : [22,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|alert-0-shield",
				"origin" : [24,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|alert-1-shield",
				"origin" : [24,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01090000|alert-2-shield",
				"origin" : [24,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|swingO1-0-shield",
				"origin" : [16,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|swingO1-1-shield",
				"origin" : [4,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01090000|swingO1-2-shield",
				"origin" : [25,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|swingO2-0-shield",
				"origin" : [21,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|swingO2-1-shield",
				"origin" : [26,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01090000|swingO2-2-shield",
				"origin" : [32,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|swingO3-0-shield",
				"origin" : [41,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|swingO3-1-shield",
				"origin" : [15,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01090000|swingO3-2-shield",
				"origin" : [11,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|swingOF-0-shield",
				"origin" : [27,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|swingOF-1-shield",
				"origin" : [-1,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backShieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01090000|swingOF-2-shield",
				"origin" : [16,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"3" :  {
			"shield" :  {
				"png_path": "01090000|swingOF-3-shield",
				"origin" : [33,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|stabO1-0-shield",
				"origin" : [38,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|stabO1-1-shield",
				"origin" : [22,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|stabO2-0-shield",
				"origin" : [41,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|stabO2-1-shield",
				"origin" : [17,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|stabOF-0-shield",
				"origin" : [20,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|stabOF-1-shield",
				"origin" : [47,25],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01090000|stabOF-2-shield",
				"origin" : [36,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|proneStab-0-shield",
				"origin" : [49,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|proneStab-0-shield",
				"origin" : [49,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|proneStab-0-shield",
				"origin" : [49,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|alert-1-shield",
				"origin" : [24,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|swingO2-1-shield",
				"origin" : [26,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01090000|swingO2-0-shield",
				"origin" : [21,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|fly-0-shield",
				"origin" : [27,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|fly-0-shield",
				"origin" : [27,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|jump-0-shield",
				"origin" : [26,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|ladder-0-shield",
				"origin" : [14,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shield",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|ladder-1-shield",
				"origin" : [13,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shield",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01090000|rope-0-shield",
				"origin" : [14,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shield",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01090000|rope-1-shield",
				"origin" : [13,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shield",
			},
		},
	},
};

