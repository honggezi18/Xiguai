var Avatar01000061 = Avatar01000061 || { }; 
Avatar01000061 =   {
	"id":"01000061",
	"info" :  {
		"icon" :  {
			"png_path": "00Cap|01000061-info-icon",
			"origin" : [-1,28],
		},
		"iconRaw" :  {
			"png_path": "00Cap|01000061-info-iconRaw",
			"origin" : [-1,28],
		},
		"islot" : "Cp",
		"vslot" : "CpH1H5",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"default" :  {
		"default" :  {
			"png_path": "00Cap|01000061-default-default",
			"origin" : [18,21],
			"map" :  {
				"brow" : [0,0],
			},
			"z" : "cap",
		},
	},
	"backDefault" :  {
		"default" :  {
			"png_path": "00Cap|01000061-backDefault-default",
			"origin" : [19,20],
			"map" :  {
				"brow" : [0,0],
			},
			"z" : "backCapOverHair",
		},
	},
	"walk1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-backDefault-default",
				"origin" : [19,20],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backCapOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-backDefault-default",
				"origin" : [19,20],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backCapOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"4" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-default-default",
				"origin" : [18,21],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "cap",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-backDefault-default",
				"origin" : [19,20],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backCapOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-backDefault-default",
				"origin" : [19,20],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backCapOverHair",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01000061-backDefault-default",
				"origin" : [19,20],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backCapOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01000061-backDefault-default",
				"origin" : [19,20],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backCapOverHair",
			},
		},
	},
};

