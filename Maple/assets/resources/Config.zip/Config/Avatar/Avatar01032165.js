var Avatar01032165 = Avatar01032165 || { }; 
Avatar01032165 =   {
	"id":"01032165",
	"info" :  {
		"islot" : "Ae",
		"vslot" : "Ae",
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqJob" : 0,
		"reqLUK" : 0,
		"reqSTR" : 0,
		"reqLevel" : 105,
		"incSTR" : 3,
		"incDEX" : 3,
		"incINT" : 3,
		"incLUK" : 3,
		"incMDD" : 80,
		"incPDD" : 80,
		"incMHP" : 100,
		"incMMP" : 100,
		"price" : 1,
		"tradeBlock" : 1,
		"tuc" : 7,
		"cash" : 0,
		"nActivatedSocket" : "1",
		"icon" :  {
			"png_path": "00Earrings|01032165-info-icon",
			"origin" : [-1,31],
		},
		"iconRaw" :  {
			"png_path": "00Earrings|01032165-info-iconRaw",
			"origin" : [-1,31],
		},
	},
	"walk1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-backDefault-default",
				"origin" : [15,3],
				"map" :  {
					"brow" : [0,-18],
				},
				"z" : "backAccessoryEar",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingTF" :  {
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-backDefault-default",
				"origin" : [15,3],
				"map" :  {
					"brow" : [0,-18],
				},
				"z" : "backAccessoryEar",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"4" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [1,-40],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-backDefault-default",
				"origin" : [15,3],
				"map" :  {
					"brow" : [0,-18],
				},
				"z" : "backAccessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-backDefault-default",
				"origin" : [15,3],
				"map" :  {
					"brow" : [0,-18],
				},
				"z" : "backAccessoryEar",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-backDefault-default",
				"origin" : [15,3],
				"map" :  {
					"brow" : [0,-18],
				},
				"z" : "backAccessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032165-backDefault-default",
				"origin" : [15,3],
				"map" :  {
					"brow" : [0,-18],
				},
				"z" : "backAccessoryEar",
			},
		},
	},
	"default" :  {
		"default" :  {
			"png_path": "00Earrings|01032165-default-default",
			"origin" : [15,25],
			"map" :  {
				"brow" : [1,-40],
			},
			"z" : "accessoryEar",
		},
	},
	"backDefault" :  {
		"default" :  {
			"png_path": "00Earrings|01032165-backDefault-default",
			"origin" : [15,3],
			"map" :  {
				"brow" : [0,-18],
			},
			"z" : "backAccessoryEar",
		},
	},
};

