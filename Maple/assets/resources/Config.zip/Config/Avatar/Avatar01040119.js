var Avatar01040119 = Avatar01040119 || { }; 
Avatar01040119 =   {
	"id":"01040119",
	"info" :  {
		"icon" :  {
			"png_path": "01040119|info-icon",
			"origin" : [-1,30],
		},
		"iconRaw" :  {
			"png_path": "01040119|info-iconRaw",
			"origin" : [-1,30],
		},
		"islot" : "Ma",
		"vslot" : "Ma",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|walk1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|walk1-0-mailArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-10,7],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|walk1-1-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,-1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|walk1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|walk1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|walk1-0-mailArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-10,7],
				},
				"z" : "mailArm",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040119|walk1-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|walk1-3-mailArm",
				"origin" : [4,2],
				"map" :  {
					"navel" : [-10,9],
				},
				"z" : "mailArm",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|walk2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|walk2-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|walk2-1-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,-1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|walk2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-8,4],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|walk2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|walk2-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040119|walk2-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|walk2-3-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-8,6],
				},
				"z" : "mailArm",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|stand1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,-1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stand1-0-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-10,5],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|stand1-1-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stand1-1-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-10,6],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|stand1-2-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-4,-1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stand1-2-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-10,5],
				},
				"z" : "mailArm",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|stand2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,-1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stand2-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|stand2-1-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stand2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|stand2-2-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-4,-1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stand2-2-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-9,5],
				},
				"z" : "mailArm",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|alert-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|alert-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,5],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|alert-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|alert-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,4],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|alert-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|alert-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-8,4],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|swingO1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingO1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [4,5],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingO1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-7,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingO1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [1,6],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|swingO1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingO1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-4,8],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|swingO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingO2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [2,6],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingO2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,5],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|swingO2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingO2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|swingO3-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingO3-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-6,6],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingO3-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingO3-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [4,6],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|swingO3-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingO3-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [1,4],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|swingOF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,2],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingOF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,3],
				},
				"z" : "backMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|swingOF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChest",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040119|swingOF-3-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingOF-3-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [10,4],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|swingT1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,-1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingT1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-2,8],
				},
				"z" : "mailArmOverHairBelowWeapon",
			},
			"mailArmOverHair" :  {
				"png_path": "01040119|swingT1-0-mailArmOverHair",
				"origin" : [6,8],
				"map" :  {
					"navel" : [-12,5],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingT1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingT1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,3],
				},
				"z" : "mailArmOverHairBelowWeapon",
			},
			"mailArmOverHair" :  {
				"png_path": "01040119|swingT1-1-mailArmOverHair",
				"origin" : [7,6],
				"map" :  {
					"navel" : [-1,5],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|swingT1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingT1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,1],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|swingT2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,1],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingT2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingT2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|swingT2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingT2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,8],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|swingT3-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingT3-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [1,4],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingT3-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,-1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingT3-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [5,3],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|swingT3-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingT3-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [8,4],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|swingTF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,1],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingTF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [4,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingTF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-5,4],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|swingTF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingTF-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [5,8],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040119|swingTF-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingTF-3-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [8,3],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|swingP1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingP1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "mailArmOverHairBelowWeapon",
			},
			"mailArmOverHair" :  {
				"png_path": "01040119|swingP1-0-mailArmOverHair",
				"origin" : [6,8],
				"map" :  {
					"navel" : [-11,6],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingP1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingP1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [3,7],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|swingP1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingP1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [7,2],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|swingP2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingP2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [2,4],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingP2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingP2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [1,2],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|swingP2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingP2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,7],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|swingPF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingPF-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-11,11],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingPF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingPF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-10,9],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|swingPF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingPF-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [8,8],
				},
				"z" : "mailArmOverHair",
			},
			"mailArmOverHair" :  {
				"png_path": "01040119|swingPF-2-mailArmOverHair",
				"origin" : [6,8],
				"map" :  {
					"navel" : [-7,8],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040119|swingPF-3-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingPF-3-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [8,2],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|stabO1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabO1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,7],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|stabO1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabO1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [7,6],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|stabO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabO2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-11,5],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|stabO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabO2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [5,5],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|stabOF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [2,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabOF-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-1,9],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|stabOF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [5,-1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabOF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-1,4],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|stabOF-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [2,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabOF-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [7,5],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|stabT1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabT1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-5,9],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|stabT1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,-1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabT1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-4,7],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|stabT1-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabT1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|stabT2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabT2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-6,11],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|stabT2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [3,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabT2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [2,10],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|stabT2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabT2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-3,8],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|swingPF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingPF-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-11,11],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingPF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingPF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-10,9],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|stabTF-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [2,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabTF-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-6,9],
				},
				"z" : "mailArmBelowHead",
			},
			"mailArmOverHair" :  {
				"png_path": "01040119|stabTF-2-mailArmOverHair",
				"origin" : [6,8],
				"map" :  {
					"navel" : [0,1],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040119|stabT1-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|stabT1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|shoot1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|shoot1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,8],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|shoot1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|shoot1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,3],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|shoot1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|shoot1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,3],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|shoot2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|shoot2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,8],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|shoot2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|shoot2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-4,8],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|shoot2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChest",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040119|shoot2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|shoot2-3-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-8,6],
				},
				"z" : "mailArmOverHair",
			},
		},
		"4" :  {
			"mail" :  {
				"png_path": "01040119|shoot2-4-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|shoot2-4-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,7],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|shootF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [3,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|shootF-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-8,5],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|shootF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|shootF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-11,1],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|shootF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|shootF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-11,1],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|proneStab-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [19,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|proneStab-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-2,-1],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|proneStab-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [19,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|proneStab-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [5,-2],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|proneStab-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [19,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|proneStab-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-2,-1],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|alert-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|alert-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,4],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|swingO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingO2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,5],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040119|swingO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|swingO2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [2,6],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|fly-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|fly-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-12,6],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|fly-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|fly-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-12,6],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|jump-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|jump-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-12,5],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|sit-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040119|sit-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,5],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|ladder-0-mail",
				"origin" : [7,7],
				"map" :  {
					"navel" : [2,2],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|ladder-1-mail",
				"origin" : [7,7],
				"map" :  {
					"navel" : [1,2],
				},
				"z" : "backMailChest",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040119|rope-0-mail",
				"origin" : [7,7],
				"map" :  {
					"navel" : [2,2],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040119|rope-1-mail",
				"origin" : [7,7],
				"map" :  {
					"navel" : [1,1],
				},
				"z" : "backMailChest",
			},
		},
	},
};

