var Avatar01070000 = Avatar01070000 || { }; 
Avatar01070000 =   {
	"id":"01070000",
	"info" :  {
		"icon" :  {
			"png_path": "01070000|info-icon",
			"origin" : [-2,22],
		},
		"iconRaw" :  {
			"png_path": "01070000|info-iconRaw",
			"origin" : [-2,22],
		},
		"islot" : "So",
		"vslot" : "So",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|walk1-0-shoes",
				"origin" : [5,5],
				"map" :  {
					"navel" : [-9,-14],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|walk1-1-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-3,-15],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|walk1-2-shoes",
				"origin" : [6,5],
				"map" :  {
					"navel" : [-4,-17],
				},
				"z" : "shoes",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070000|walk1-3-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-2,-12],
				},
				"z" : "shoes",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|walk1-0-shoes",
				"origin" : [5,5],
				"map" :  {
					"navel" : [-9,-14],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|walk1-1-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-3,-15],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|walk1-2-shoes",
				"origin" : [6,5],
				"map" :  {
					"navel" : [-4,-17],
				},
				"z" : "shoes",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070000|walk1-3-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-2,-12],
				},
				"z" : "shoes",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|stand1-0-shoes",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-21],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|stand1-1-shoes",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-20],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|stand1-2-shoes",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-21],
				},
				"z" : "shoes",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|stand1-0-shoes",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-21],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|stand1-1-shoes",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-20],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|stand1-2-shoes",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-21],
				},
				"z" : "shoes",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|alert-0-shoes",
				"origin" : [12,5],
				"map" :  {
					"navel" : [1,-18],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|alert-1-shoes",
				"origin" : [12,5],
				"map" :  {
					"navel" : [1,-19],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|alert-2-shoes",
				"origin" : [12,5],
				"map" :  {
					"navel" : [1,-20],
				},
				"z" : "shoes",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|swingO1-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-1,-12],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingO1-1-shoes",
				"origin" : [14,5],
				"map" :  {
					"navel" : [-11,-17],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|swingO1-2-shoes",
				"origin" : [14,5],
				"map" :  {
					"navel" : [-6,-16],
				},
				"z" : "shoes",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|swingO2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-20],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingO2-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-17],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|swingO2-2-shoes",
				"origin" : [14,5],
				"map" :  {
					"navel" : [-2,-16],
				},
				"z" : "shoes",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|swingO3-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-3,-15],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingO3-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-9,-14],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|swingO3-2-shoes",
				"origin" : [14,5],
				"map" :  {
					"navel" : [-8,-12],
				},
				"z" : "shoes",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|swingOF-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [3,-17],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingOF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-2,-18],
				},
				"z" : "backShoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|swingOF-2-shoes",
				"origin" : [14,5],
				"map" :  {
					"navel" : [-20,-8],
				},
				"z" : "shoes",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070000|swingOF-3-shoes",
				"origin" : [14,5],
				"map" :  {
					"navel" : [2,-9],
				},
				"z" : "shoes",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|swingT1-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-21],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingT1-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-17],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|swingT1-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-1,-16],
				},
				"z" : "shoes",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|swingT2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [4,-13],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingT2-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-16],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|swingT2-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-15],
				},
				"z" : "shoes",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|swingT3-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-17],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingT3-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-7,-14],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|swingT3-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-16],
				},
				"z" : "shoes",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|swingTF-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-9,-15],
				},
				"z" : "backShoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingTF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-4,-15],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|swingTF-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-5,-13],
				},
				"z" : "shoes",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070000|swingTF-3-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-14],
				},
				"z" : "shoes",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|swingP1-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-20],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingP1-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-16],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|swingP1-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-1,-15],
				},
				"z" : "shoes",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|swingP2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-18],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingP2-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-17],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|swingP2-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-15],
				},
				"z" : "shoes",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|swingPF-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-10],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingPF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-10],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|swingPF-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-2,-16],
				},
				"z" : "shoes",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070000|swingPF-3-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-1,-13],
				},
				"z" : "shoes",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|stabO1-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [9,-18],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|stabO1-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-13],
				},
				"z" : "shoes",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|stabO2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-19],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|stabO2-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-1,-17],
				},
				"z" : "shoes",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|stabOF-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-1,-10],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|stabOF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [9,-13],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|stabOF-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-15],
				},
				"z" : "shoes",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|stabT1-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [5,-19],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|stabT1-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-4,-15],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|stabT1-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-14],
				},
				"z" : "shoes",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|stabT2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-1,-16],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|stabT2-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-13],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|stabT2-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [4,-15],
				},
				"z" : "shoes",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|swingPF-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-10],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingPF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-10],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|stabTF-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-2,-16],
				},
				"z" : "shoes",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070000|stabT1-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-14],
				},
				"z" : "shoes",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|shoot1-0-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [0,-20],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|shoot1-0-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [0,-20],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|shoot1-0-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [0,-20],
				},
				"z" : "shoes",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|shoot2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-19],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|shoot2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-19],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|shoot2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-19],
				},
				"z" : "shoes",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070000|shoot2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-19],
				},
				"z" : "shoes",
			},
		},
		"4" :  {
			"shoes" :  {
				"png_path": "01070000|shoot2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-19],
				},
				"z" : "shoes",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|shootF-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [4,-19],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|shootF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [5,-18],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|shootF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [5,-18],
				},
				"z" : "shoes",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|proneStab-0-shoes",
				"origin" : [5,3],
				"map" :  {
					"navel" : [-17,0],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|proneStab-0-shoes",
				"origin" : [5,3],
				"map" :  {
					"navel" : [-17,0],
				},
				"z" : "shoes",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|proneStab-0-shoes",
				"origin" : [5,3],
				"map" :  {
					"navel" : [-17,0],
				},
				"z" : "shoes",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|alert-1-shoes",
				"origin" : [12,5],
				"map" :  {
					"navel" : [1,-19],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|swingO2-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-17],
				},
				"z" : "shoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070000|swingO2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-20],
				},
				"z" : "shoes",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|fly-0-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-18,-10],
				},
				"z" : "shoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|fly-1-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-20,-14],
				},
				"z" : "shoes",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|jump-0-shoes",
				"origin" : [17,6],
				"map" :  {
					"navel" : [0,-11],
				},
				"z" : "shoes",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|sit-0-shoes",
				"origin" : [17,6],
				"map" :  {
					"navel" : [0,-16],
				},
				"z" : "shoes",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|ladder-0-shoes",
				"origin" : [8,6],
				"map" :  {
					"navel" : [0,-17],
				},
				"z" : "backShoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|ladder-1-shoes",
				"origin" : [8,6],
				"map" :  {
					"navel" : [0,-17],
				},
				"z" : "backShoes",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070000|rope-0-shoes",
				"origin" : [7,5],
				"map" :  {
					"navel" : [-1,-19],
				},
				"z" : "backShoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070000|rope-1-shoes",
				"origin" : [9,5],
				"map" :  {
					"navel" : [-4,-13],
				},
				"z" : "backShoes",
			},
		},
	},
};

