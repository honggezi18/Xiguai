var Avatar01382008 = Avatar01382008 || { }; 
Avatar01382008 =   {
	"id":"01382008",
	"info" :  {
		"icon" :  {
			"png_path": "01382008|info-icon",
			"origin" : [3,35],
		},
		"iconRaw" :  {
			"png_path": "01382008|info-iconRaw",
			"origin" : [3,35],
		},
		"islot" : "Wp",
		"vslot" : "Wp",
		"walk" : 1,
		"stand" : 1,
		"attack" : 6,
		"afterImage" : "mace",
		"sfx" : "mace",
		"reqJob" : 2,
		"reqLevel" : 85,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 258,
		"reqLUK" : 0,
		"incPAD" : 65,
		"incMAD" : 100,
		"tuc" : 7,
		"price" : 4800,
		"attackSpeed" : 8,
		"cash" : 0,
	},
	"walk1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|walk1-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [24,7],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|walk1-1-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [20,13],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382008|walk1-2-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [23,15],
				},
				"z" : "weapon",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01382008|walk1-3-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [24,10],
				},
				"z" : "weapon",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|stand1-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [22,2],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|stand1-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [22,2],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382008|stand1-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [22,2],
				},
				"z" : "weapon",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|alert-0-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [22,9],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|alert-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [21,8],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382008|alert-2-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [22,7],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|swingO1-0-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [20,41],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|swingO1-1-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [32,9],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382008|swingO1-2-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-15,61],
				},
				"z" : "weapon",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|swingO2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [17,55],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|swingO2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [26,52],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382008|swingO2-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [-16,30],
				},
				"z" : "weapon",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|swingO3-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [-16,53],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|swingO3-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [54,12],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382008|swingO3-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [24,11],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|stabO1-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [22,7],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|stabO1-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [58,22],
				},
				"z" : "weapon",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|stabO2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [21,26],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|stabO2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [55,20],
				},
				"z" : "weapon",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|shoot1-0-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [8,35],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|shoot1-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [22,35],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382008|shoot1-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [22,35],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|shootF-0-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [10,39],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|shootF-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [27,41],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382008|shootF-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [27,41],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|proneStab-0-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [55,13],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|proneStab-1-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [70,13],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|proneStab-0-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [55,13],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|alert-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [21,8],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|swingO2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [26,52],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382008|swingO2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [17,55],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|fly-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-4,48],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382008|fly-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-4,48],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382008|jump-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-5,47],
				},
				"z" : "weaponOverArm",
			},
		},
	},
};

