var Avatar01032243 = Avatar01032243 || { }; 
Avatar01032243 =   {
	"id":"01032243",
	"info" :  {
		"icon" :  {
			"png_path": "00Earrings|01032243-info-icon",
			"origin" : [-1,32],
		},
		"iconRaw" :  {
			"png_path": "00Earrings|01032243-info-iconRaw",
			"origin" : [-1,32],
		},
		"islot" : "Ae",
		"vslot" : "Ae",
		"reqJob" : 0,
		"reqLevel" : 60,
		"incSTR" : 2,
		"incDEX" : 2,
		"incINT" : 2,
		"incLUK" : 2,
		"tuc" : 2,
		"price" : 1,
		"cash" : 0,
		"tradeBlock" : 1,
		"incMHP" : 50,
		"incMMP" : 50,
		"setItemID" : 996,
	},
	"default" :  {
		"default" :  {
			"png_path": "00Earrings|01032243-default-default",
			"origin" : [15,-16],
			"map" :  {
				"brow" : [0,0],
			},
			"z" : "accessoryEar",
		},
	},
	"backDefault" :  {
		"default" :  {
			"png_path": "00Earrings|01032243-backDefault-default",
			"origin" : [15,-16],
			"map" :  {
				"brow" : [0,0],
			},
			"z" : "backAccessoryEar",
		},
	},
	"walk1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" : "",
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingTF" :  {
		"0" : "",
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"4" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-default-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-backDefault-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backAccessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-backDefault-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backAccessoryEar",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-backDefault-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backAccessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032243-backDefault-default",
				"origin" : [15,-16],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backAccessoryEar",
			},
		},
	},
};

