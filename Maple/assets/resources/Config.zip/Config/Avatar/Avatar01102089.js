var Avatar01102089 = Avatar01102089 || { }; 
Avatar01102089 =   {
	"id":"01102089",
	"info" :  {
		"icon" :  {
			"png_path": "01102089|info-icon",
			"origin" : [1,28],
		},
		"iconRaw" :  {
			"png_path": "01102089|info-iconRaw",
			"origin" : [1,28],
		},
		"islot" : "Sr",
		"vslot" : "Sr",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"pachinko" : 1,
	},
	"walk1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|walk1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|walk1-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [0,8],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|walk1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|walk1-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-1,7],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|walk1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|walk1-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [0,8],
				},
				"z" : "cape",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102089|walk1-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|walk1-3-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [0,8],
				},
				"z" : "cape",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|walk1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|walk1-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [0,8],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|walk1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|walk1-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-1,7],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|walk1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|walk1-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [0,8],
				},
				"z" : "cape",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102089|walk1-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|walk1-3-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [0,8],
				},
				"z" : "cape",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|stand1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stand1-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-2,6],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|stand1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stand1-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-1,7],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|stand1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stand1-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [0,6],
				},
				"z" : "cape",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|stand1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stand1-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-2,6],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|stand1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stand1-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-1,7],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|stand1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stand1-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [0,6],
				},
				"z" : "cape",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|alert-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|alert-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [2,7],
				},
				"z" : "gloveWristBelowMailArm",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|alert-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|alert-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [2,7],
				},
				"z" : "gloveWristBelowMailArm",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|alert-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|alert-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [2,7],
				},
				"z" : "gloveWristBelowMailArm",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|swingO1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,4],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingO1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,4],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|swingO1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingO1-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-3,8],
				},
				"z" : "gloveWristBelowMailArm",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|swingO2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,2],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingO2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,5],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|swingO2-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingO2-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-5,9],
				},
				"z" : "gloveWristBelowMailArm",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|swingO3-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingO3-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [5,9],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingO3-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,5],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|swingO3-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,4],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|swingOF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingOF-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [3,8],
				},
				"z" : "gloveWristBelowMailArm",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingOF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,2],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|swingOF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,5],
				},
				"z" : "capeOverHead",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102089|swingOF-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,5],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingOF-3-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [8,9],
				},
				"z" : "gloveWristBelowMailArm",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|swingT1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingT1-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-1,9],
				},
				"z" : "gloveWristBelowMailArm",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingT1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,5],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingT1-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [3,9],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|swingT1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|swingT2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,3],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingT2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingT2-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-1,8],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|swingT2-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingT2-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [3,8],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|swingT3-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingT3-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [2,9],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingT3-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingT3-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [4,6],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|swingT3-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|swingTF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,2],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingTF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [5,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingTF-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [7,3],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|swingTF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingTF-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [3,7],
				},
				"z" : "capeOverHead",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102089|swingTF-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,5],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|swingP1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingP1-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [0,9],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingP1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,6],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingP1-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [1,11],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|swingP1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,4],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|swingP2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,2],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingP2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,5],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingP2-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-2,9],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|swingP2-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingP2-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [3,8],
				},
				"z" : "mailChestTop",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|swingPF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingPF-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [1,10],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingPF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingPF-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [1,10],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|swingPF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingPF-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [5,9],
				},
				"z" : "capeOverHead",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102089|swingPF-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,5],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|stabO1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stabO1-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [3,8],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|stabO1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,5],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|stabO2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stabO2-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|stabO2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,4],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|stabOF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [3,6],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stabOF-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [8,11],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|stabOF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [3,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stabOF-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [8,7],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|stabOF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,5],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|stabT1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,5],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stabT1-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [3,10],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|stabT1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|stabT1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stabT1-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-5,8],
				},
				"z" : "mailChestTop",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|stabT2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,6],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stabT2-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [3,12],
				},
				"z" : "mailChestTop",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|stabT2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,5],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stabT2-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [9,11],
				},
				"z" : "mailChestTop",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|stabT2-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stabT2-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [5,9],
				},
				"z" : "mailChestTop",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|swingPF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingPF-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [1,10],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingPF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|swingPF-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [1,10],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|stabTF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stabTF-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [5,10],
				},
				"z" : "mailChestTop",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102089|stabTF-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|stabTF-3-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-5,8],
				},
				"z" : "mailChestTop",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|shoot1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|shoot1-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "mailChestTop",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|shoot1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|shoot1-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "mailChestTop",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|shoot1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|shoot1-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "mailChestTop",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|shoot2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|shoot2-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-1,10],
				},
				"z" : "mailChestTop",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|shoot2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|shoot2-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-1,7],
				},
				"z" : "mailChestTop",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|shoot2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|shoot2-2-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-1,7],
				},
				"z" : "mailChestTop",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102089|shoot2-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|shoot2-3-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-1,9],
				},
				"z" : "mailChestTop",
			},
		},
		"4" :  {
			"cape" :  {
				"png_path": "01102089|shoot2-4-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|shoot2-4-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-1,9],
				},
				"z" : "mailChestTop",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|shootF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|shootF-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [5,8],
				},
				"z" : "mailChestTop",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|shootF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [3,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|shootF-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [7,8],
				},
				"z" : "mailChestTop",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|shootF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [3,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|shootF-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [7,8],
				},
				"z" : "mailChestTop",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|proneStab-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [13,12],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|proneStab-1-cape",
				"origin" : [12,9],
				"map" :  {
					"navel" : [12,12],
				},
				"z" : "cape",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|proneStab-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [13,12],
				},
				"z" : "cape",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|alert-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|alert-1-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [2,7],
				},
				"z" : "gloveWristBelowMailArm",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|swingO2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,5],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102089|swingO2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,2],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|fly-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,5],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|fly-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "mailChestTop",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|fly-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,5],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|fly-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "mailChestTop",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|jump-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,4],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|jump-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [0,7],
				},
				"z" : "mailChestTop",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|sit-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,3],
				},
				"z" : "capeBelowBody",
			},
			"capeArm" :  {
				"png_path": "01102089|sit-0-capeArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-2,7],
				},
				"z" : "gloveWristBelowMailArm",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|ladder-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,-1],
				},
				"z" : "backCape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|ladder-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,-1],
				},
				"z" : "backCape",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102089|rope-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,-1],
				},
				"z" : "backCape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102089|rope-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,0],
				},
				"z" : "backCape",
			},
		},
	},
};

