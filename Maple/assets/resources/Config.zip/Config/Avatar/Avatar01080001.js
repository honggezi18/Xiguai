var Avatar01080001 = Avatar01080001 || { }; 
Avatar01080001 =   {
	"id":"01080001",
	"info" :  {
		"icon" :  {
			"png_path": "01080001|info-icon",
			"origin" : [-4,30],
		},
		"iconRaw" :  {
			"png_path": "01080001|info-iconRaw",
			"origin" : [-5,30],
		},
		"islot" : "Gv",
		"vslot" : "GlGw",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|walk1-0-lGlove",
				"origin" : [4,3],
				"map" :  {
					"navel" : [9,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|walk1-0-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-20,-3],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|walk1-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [5,-3],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|walk1-1-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-11,-8],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|walk1-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [10,-2],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|walk1-0-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-20,-3],
				},
				"z" : "glove",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080001|walk1-3-lGlove",
				"origin" : [4,2],
				"map" :  {
					"navel" : [11,7],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|walk1-3-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-22,0],
				},
				"z" : "glove",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|walk2-0-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [7,-3],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|walk2-0-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-11,-3],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|walk2-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [8,-5],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|walk2-1-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-10,-4],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|walk2-0-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [7,-3],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|walk2-0-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-11,-3],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080001|walk2-3-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,-1],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|walk2-3-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-12,-2],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|stand1-0-lGlove",
				"origin" : [3,4],
				"map" :  {
					"navel" : [5,-3],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|stand1-0-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-19,-7],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|stand1-1-lGlove",
				"origin" : [3,4],
				"map" :  {
					"navel" : [7,-2],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|stand1-1-rGlove",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-18,-6],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|stand1-2-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [8,-2],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|stand1-2-rGlove",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-18,-7],
				},
				"z" : "glove",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|stand2-0-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [7,-5],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|stand2-0-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-11,-4],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|stand2-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [7,-3],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|stand2-1-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-11,-3],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|stand2-2-lGlove",
				"origin" : [3,4],
				"map" :  {
					"navel" : [7,-3],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|stand2-2-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-11,-4],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|alert-0-lGlove",
				"origin" : [15,24],
				"map" :  {
					"handMove" : [-11,-20],
				},
				"z" : "gloveBelowWeapon",
			},
			"rGlove" :  {
				"png_path": "01080001|alert-0-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-11,-6],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|alert-1-lGlove",
				"origin" : [15,23],
				"map" :  {
					"handMove" : [-13,-19],
				},
				"z" : "gloveBelowWeapon",
			},
			"rGlove" :  {
				"png_path": "01080001|alert-1-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-11,-7],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|alert-2-lGlove",
				"origin" : [15,22],
				"map" :  {
					"handMove" : [-15,-17],
				},
				"z" : "gloveBelowWeapon",
			},
			"rGlove" :  {
				"png_path": "01080001|alert-2-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-11,-9],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"swingO1" :  {
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|swingO1-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-11,2],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingO1-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [2,-1],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|swingO1-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,3],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingO1-2-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-21,16],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|swingO2-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [8,-1],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingO2-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [12,9],
				},
				"z" : "gloveBelowHead",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|swingO2-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [8,8],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingO2-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [15,5],
				},
				"z" : "gloveBelowHead",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|swingO2-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [16,8],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingO2-2-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-22,-2],
				},
				"z" : "glove",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|swingO3-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [24,5],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingO3-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-21,7],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080001|swingO3-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [13,-2],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|swingOF-0-lGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [5,-6],
				},
				"z" : "glove",
			},
			"rGlove" :  {
				"png_path": "01080001|swingOF-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-21,4],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080001|swingOF-3-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [15,-7],
				},
				"z" : "glove",
			},
			"rGlove" :  {
				"png_path": "01080001|swingOF-3-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-19,10],
				},
				"z" : "gloveOverBody",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|swingT1-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-5,23],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|swingT1-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-21,20],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|swingT1-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [20,11],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|swingT1-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [9,15],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|swingT1-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [9,-8],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingT1-2-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [9,-11],
				},
				"z" : "glove",
			},
		},
	},
	"swingT2" :  {
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|swingT2-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [18,8],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingT2-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [9,-1],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|swingT2-2-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "glove",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|swingT3-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "glove",
			},
			"rGlove" :  {
				"png_path": "01080001|swingT3-0-rGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-10,1],
				},
				"z" : "gloveOverBody",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|swingT3-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [1,-1],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"swingTF" :  {
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|swingTF-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,12],
				},
				"z" : "gloveBelowHead",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|swingTF-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [13,29],
				},
				"z" : "gloveWristOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080001|swingTF-3-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [14,-5],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingTF-3-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [11,-9],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|swingP1-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [1,26],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|swingP1-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-20,22],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|swingP1-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [22,7],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|swingP1-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [9,16],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|swingP1-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [9,-7],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingP1-2-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [9,-10],
				},
				"z" : "glove",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"rGlove" :  {
				"png_path": "01080001|swingP2-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [12,8],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080001|swingP2-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [13,-3],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|swingP2-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-3,0],
				},
				"z" : "glove",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|swingPF-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [19,5],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|swingPF-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-26,5],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|swingPF-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [18,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|swingPF-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-25,6],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|swingPF-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [7,25],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|swingPF-2-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-18,23],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080001|swingPF-3-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [11,-7],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingPF-3-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [12,-12],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|stabO1-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [21,5],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|stabO1-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-20,-4],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080001|stabO1-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [20,2],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|stabO2-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [21,7],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|stabO2-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-16,6],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080001|stabO2-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [17,1],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|stabOF-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [1,2],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|stabOF-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-13,0],
				},
				"z" : "gloveBelowMailArm",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|stabOF-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [32,8],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|stabOF-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-16,-3],
				},
				"z" : "gloveBelowMailArm",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|stabOF-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [20,5],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|stabOF-2-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [22,1],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|stabT1-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [4,-2],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|stabT1-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-22,1],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|stabT1-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,-5],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|stabT1-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-22,1],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|stabT1-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [26,3],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|stabT1-2-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,-1],
				},
				"z" : "glove",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|stabT2-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [12,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|stabT2-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-19,1],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|stabT2-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [16,-3],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|stabT2-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-17,3],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|stabT2-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [27,3],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|stabT2-2-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-12,-4],
				},
				"z" : "glove",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|swingPF-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [19,5],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|swingPF-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-26,5],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|swingPF-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [18,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|swingPF-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-25,6],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|stabTF-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-5,2],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|stabTF-2-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-25,6],
				},
				"z" : "glove",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080001|stabT1-2-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [26,3],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|stabT1-2-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,-1],
				},
				"z" : "glove",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|shoot1-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [23,8],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|shoot1-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [3,6],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|shoot1-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [24,7],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|shoot1-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-11,6],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|shoot1-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [24,7],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|shoot1-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-11,6],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|shoot2-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [14,6],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|shoot2-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-9,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|shoot2-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [14,6],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|shoot2-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [5,7],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|shoot2-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [14,6],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|shoot2-2-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,7],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080001|shoot2-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [14,6],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|shoot2-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-9,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"4" :  {
			"lGlove" :  {
				"png_path": "01080001|shoot2-4-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [12,6],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|shoot2-4-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-12,1],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|shootF-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [25,13],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|shootF-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [2,8],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|shootF-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [28,12],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|shootF-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-12,5],
				},
				"z" : "gloveBelowMailArm",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|shootF-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [28,12],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|shootF-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-12,5],
				},
				"z" : "gloveBelowMailArm",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|proneStab-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [36,2],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|proneStab-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [4,-3],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|proneStab-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [36,2],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|proneStab-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [19,-4],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|proneStab-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [36,2],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|proneStab-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [4,-3],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|alert-1-lGlove",
				"origin" : [15,23],
				"map" :  {
					"handMove" : [-13,-19],
				},
				"z" : "gloveBelowWeapon",
			},
			"rGlove" :  {
				"png_path": "01080001|alert-1-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-11,-7],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|swingO2-1-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [8,8],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingO2-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [15,5],
				},
				"z" : "gloveBelowHead",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080001|swingO2-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [8,-1],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|swingO2-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [12,9],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|fly-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [8,4],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|fly-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-9,3],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080001|fly-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [8,4],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|fly-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-9,3],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|jump-0-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [7,3],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080001|jump-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-10,2],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080001|sit-0-lGlove",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,-1],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080001|sit-0-rGlove",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-10,-6],
				},
				"z" : "glove",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"rGlove" :  {
				"png_path": "01080001|ladder-0-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,12],
				},
				"z" : "backGlove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080001|ladder-1-rGlove",
				"origin" : [10,10],
				"map" :  {
					"navel" : [2,12],
				},
				"z" : "backGlove",
			},
		},
	},
};

