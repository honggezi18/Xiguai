var Avatar01098003 = Avatar01098003 || { }; 
Avatar01098003 =   {
	"id":"01098003",
	"info" :  {
		"icon" :  {
			"png_path": "01098003|info-icon",
			"origin" : [4,36],
		},
		"iconRaw" :  {
			"png_path": "01098003|info-iconRaw",
			"origin" : [4,36],
		},
		"islot" : "Si",
		"vslot" : "Si",
		"reqJob" : 1,
		"reqLevel" : 100,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPDD" : 85,
		"incMDD" : 45,
		"incSTR" : 12,
		"incDEX" : 12,
		"tuc" : 0,
		"price" : 1,
		"cash" : 0,
		"incMMP" : 110,
		"incMHP" : 600,
		"level" :  {
			"info" :  {
				"1" :  {
					"incPDDMin" : 2,
					"incPDDMax" : 2,
					"incMDDMin" : 1,
					"incMDDMax" : 1,
					"incMHPMin" : 20,
					"incMHPMax" : 20,
					"incSTRMin" : 1,
					"incSTRMax" : 1,
					"incDEXMin" : 1,
					"incDEXMax" : 1,
					"exp" : 10,
				},
				"2" :  {
					"incPDDMin" : 2,
					"incPDDMax" : 2,
					"incMDDMin" : 1,
					"incMDDMax" : 1,
					"incMHPMin" : 20,
					"incMHPMax" : 20,
					"exp" : 9,
				},
				"3" :  {
					"incPDDMin" : 2,
					"incPDDMax" : 2,
					"incMDDMin" : 1,
					"incMDDMax" : 1,
					"incMHPMin" : 20,
					"incMHPMax" : 20,
					"incSTRMin" : 1,
					"incSTRMax" : 1,
					"incDEXMin" : 1,
					"incDEXMax" : 1,
					"exp" : 8,
				},
				"4" :  {
					"incPDDMin" : 2,
					"incPDDMax" : 2,
					"incMDDMin" : 1,
					"incMDDMax" : 1,
					"incMHPMin" : 20,
					"incMHPMax" : 20,
					"exp" : 7,
				},
				"5" :  {
					"incPDDMin" : 2,
					"incPDDMax" : 2,
					"incMDDMin" : 1,
					"incMDDMax" : 1,
					"incMHPMin" : 20,
					"incMHPMax" : 20,
					"incSTRMin" : 1,
					"incSTRMax" : 1,
					"incDEXMin" : 1,
					"incDEXMax" : 1,
					"exp" : 6,
				},
				"6" :  {
					"incPDDMin" : 2,
					"incPDDMax" : 2,
					"incMDDMin" : 1,
					"incMDDMax" : 1,
					"incMHPMin" : 20,
					"incMHPMax" : 20,
					"exp" : 5,
				},
				"7" :  {
					"incPDDMin" : 2,
					"incPDDMax" : 2,
					"incMDDMin" : 1,
					"incMDDMax" : 1,
					"incMHPMin" : 20,
					"incMHPMax" : 20,
					"incSTRMin" : 1,
					"incSTRMax" : 1,
					"incDEXMin" : 1,
					"incDEXMax" : 1,
					"exp" : 4,
				},
				"8" :  {
					"incPDDMin" : 2,
					"incPDDMax" : 2,
					"incMDDMin" : 1,
					"incMDDMax" : 1,
					"incMHPMin" : 20,
					"incMHPMax" : 20,
					"incSTRMin" : 1,
					"incSTRMax" : 1,
					"incDEXMin" : 1,
					"incDEXMax" : 1,
					"exp" : 3,
				},
				"9" :  {
					"incPDDMin" : 2,
					"incPDDMax" : 2,
					"incMDDMin" : 1,
					"incMDDMax" : 1,
					"incMHPMin" : 20,
					"incMHPMax" : 20,
					"incSTRMin" : 2,
					"incSTRMax" : 2,
					"incDEXMin" : 2,
					"incDEXMax" : 2,
					"exp" : 2,
				},
				"10" :  {
					"incPDDMin" : 2,
					"incPDDMax" : 2,
					"incMDDMin" : 1,
					"incMDDMax" : 1,
					"incMHPMin" : 20,
					"incMHPMax" : 20,
					"incSTRMin" : 2,
					"incSTRMax" : 2,
					"incDEXMin" : 2,
					"incDEXMax" : 2,
					"exp" : 1,
				},
				"11" :  {
					"exp" : 0,
				},
			},
			"case" :  {
				"0" :  {
					"prob" : 10,
				},
			},
		},
		"equipTradeBlock" : 1,
	},
	"walk1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|walk1-0-shield",
				"origin" : [33,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|walk1-1-shield",
				"origin" : [30,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098003|walk1-0-shield",
				"origin" : [33,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"3" :  {
			"shield" :  {
				"png_path": "01098003|walk1-3-shield",
				"origin" : [35,24],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|stand1-0-shield",
				"origin" : [27,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|stand1-1-shield",
				"origin" : [29,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098003|stand1-2-shield",
				"origin" : [31,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|alert-0-shield",
				"origin" : [32,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|alert-1-shield",
				"origin" : [32,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098003|alert-2-shield",
				"origin" : [32,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|swingO1-0-shield",
				"origin" : [21,29],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|swingO1-1-shield",
				"origin" : [17,24],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098003|swingO1-2-shield",
				"origin" : [30,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|swingO2-0-shield",
				"origin" : [32,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|swingO2-1-shield",
				"origin" : [32,28],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098003|swingO2-2-shield",
				"origin" : [41,31],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|swingO3-0-shield",
				"origin" : [42,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|swingO3-1-shield",
				"origin" : [23,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098003|swingO3-2-shield",
				"origin" : [18,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|swingOF-0-shield",
				"origin" : [31,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|swingOF-1-shield",
				"origin" : [6,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098003|swingOF-2-shield",
				"origin" : [21,27],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"3" :  {
			"shield" :  {
				"png_path": "01098003|swingOF-3-shield",
				"origin" : [36,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|stabO1-0-shield",
				"origin" : [45,25],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|stabO1-1-shield",
				"origin" : [23,27],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|stabO2-0-shield",
				"origin" : [45,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|stabO2-1-shield",
				"origin" : [21,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|stabOF-0-shield",
				"origin" : [21,21],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|stabOF-1-shield",
				"origin" : [55,28],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098003|stabOF-2-shield",
				"origin" : [45,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|proneStab-0-shield",
				"origin" : [58,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|proneStab-0-shield",
				"origin" : [58,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|proneStab-0-shield",
				"origin" : [58,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|alert-1-shield",
				"origin" : [32,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|swingO2-1-shield",
				"origin" : [32,28],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098003|swingO2-0-shield",
				"origin" : [32,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|fly-0-shield",
				"origin" : [33,24],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|fly-0-shield",
				"origin" : [33,24],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|jump-0-shield",
				"origin" : [32,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|rope-0-shield",
				"origin" : [21,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|rope-1-shield",
				"origin" : [20,25],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098003|ladder-0-shield",
				"origin" : [23,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098003|ladder-1-shield",
				"origin" : [21,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
	},
};

