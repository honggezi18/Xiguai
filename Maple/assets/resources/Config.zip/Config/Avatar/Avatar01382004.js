var Avatar01382004 = Avatar01382004 || { }; 
Avatar01382004 =   {
	"id":"01382004",
	"info" :  {
		"icon" :  {
			"png_path": "01382004|info-icon",
			"origin" : [-1,33],
		},
		"iconRaw" :  {
			"png_path": "01382004|info-iconRaw",
			"origin" : [-1,33],
		},
		"islot" : "Wp",
		"vslot" : "Wp",
		"walk" : 1,
		"stand" : 1,
		"attack" : 6,
		"afterImage" : "mace",
		"sfx" : "mace",
		"reqJob" : 2,
		"reqLevel" : 20,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 62,
		"reqLUK" : 0,
		"incPAD" : 26,
		"incMAD" : 35,
		"tuc" : 7,
		"price" : 900,
		"attackSpeed" : 8,
		"cash" : 0,
	},
	"walk1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|walk1-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [20,4],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382004|walk1-1-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [18,15],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382004|walk1-2-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [21,5],
				},
				"z" : "weapon",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01382004|walk1-3-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [19,6],
				},
				"z" : "weapon",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|stand1-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [18,3],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382004|stand1-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [18,3],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382004|stand1-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [18,3],
				},
				"z" : "weapon",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|alert-0-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [22,11],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382004|alert-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [21,10],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382004|alert-2-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [22,9],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|swingO1-0-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [20,33],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382004|swingO1-1-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [28,5],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382004|swingO1-2-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-20,59],
				},
				"z" : "weapon",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|swingO2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [11,55],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382004|swingO2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [24,50],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382004|swingO2-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [-20,32],
				},
				"z" : "weapon",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|swingO3-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [-22,51],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382004|swingO3-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [50,17],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382004|swingO3-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [20,7],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|stabO1-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [19,3],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382004|stabO1-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [58,23],
				},
				"z" : "weapon",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|shoot1-0-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [-3,32],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382004|shoot1-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [11,32],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382004|shoot1-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [11,32],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|shootF-0-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [-1,36],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382004|shootF-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [16,38],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382004|shootF-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [16,38],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|proneStab-0-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [50,9],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382004|proneStab-1-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [65,8],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|proneStab-0-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [50,9],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|alert-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [21,10],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382004|swingO2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [24,50],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382004|swingO2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [11,55],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|fly-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-7,47],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382004|fly-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-7,47],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382004|jump-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-8,46],
				},
				"z" : "weaponOverArm",
			},
		},
	},
};

