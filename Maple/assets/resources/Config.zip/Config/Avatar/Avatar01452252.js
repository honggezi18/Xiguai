var Avatar01452252 = Avatar01452252 || { }; 
Avatar01452252 =   {
	"id":"01452252",
	"info" :  {
		"icon" :  {
			"png_path": "01452252|info-icon",
			"origin" : [3,35],
		},
		"iconRaw" :  {
			"png_path": "01452252|info-iconRaw",
			"origin" : [3,35],
		},
		"islot" : "WpSi",
		"vslot" : "WpSi",
		"walk" : 1,
		"stand" : 1,
		"attack" : 3,
		"afterImage" : "bow",
		"sfx" : "bow",
		"reqJob" : 4,
		"reqLevel" : 160,
		"reqSTR" : 0,
		"reqDEX" : 480,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incDEX" : 60,
		"incSTR" : 60,
		"incPAD" : 192,
		"price" : 1,
		"attackSpeed" : 6,
		"cash" : 0,
		"knockback" : 75,
		"equipTradeBlock" : 1,
		"setItemID" : 506,
		"imdR" : 10,
		"bdR" : 30,
		"incACC" : 140,
		"tuc" : 8,
		"incSpeed" : 12,
		"bossReward" : 1,
		"tradeAvailable" : 2,
		"exItem" : 1,
		"charmEXP" : 100,
		"limitBreak" : 19999999,
	},
	"walk1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452252|walk1-0-weapon",
				"origin" : [47,12],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452252|walk1-1-weapon",
				"origin" : [45,23],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452252|walk1-2-weapon",
				"origin" : [47,13],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01452252|walk1-3-weapon",
				"origin" : [45,23],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452252|stand1-0-weapon",
				"origin" : [46,11],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452252|stand1-1-weapon",
				"origin" : [46,11],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452252|stand1-2-weapon",
				"origin" : [46,11],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452252|alert-0-weapon",
				"origin" : [37,43],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452252|alert-1-weapon",
				"origin" : [36,42],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452252|alert-2-weapon",
				"origin" : [37,41],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452252|swingT1-0-weapon",
				"origin" : [36,34],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452252|swingT1-1-weapon",
				"origin" : [32,54],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452252|swingT1-2-weapon",
				"origin" : [42,23],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452252|swingT3-0-weapon",
				"origin" : [42,23],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452252|swingT3-1-weapon",
				"origin" : [50,13],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452252|swingT3-2-weapon",
				"origin" : [27,63],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452252|shoot1-0-weapon",
				"origin" : [46,42],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452252|shoot1-1-weapon",
				"origin" : [60,42],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452252|shoot1-2-weapon",
				"origin" : [60,42],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452252|shootF-0-weapon",
				"origin" : [48,45],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452252|shootF-1-weapon",
				"origin" : [65,48],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452252|shootF-1-weapon",
				"origin" : [65,48],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452252|proneStab-0-weapon",
				"origin" : [82,34],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452252|proneStab-1-weapon",
				"origin" : [83,35],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452252|proneStab-0-weapon",
				"origin" : [82,34],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452252|fly-0-weapon",
				"origin" : [47,41],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452252|fly-1-weapon",
				"origin" : [46,42],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452252|jump-0-weapon",
				"origin" : [47,41],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
};

