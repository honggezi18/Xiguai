var Avatar01070011 = Avatar01070011 || { }; 
Avatar01070011 =   {
	"id":"01070011",
	"info" :  {
		"icon" :  {
			"png_path": "01070011|info-icon",
			"origin" : [-3,31],
		},
		"iconRaw" :  {
			"png_path": "01070011|info-iconRaw",
			"origin" : [-4,31],
		},
		"islot" : "So",
		"vslot" : "So",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|walk1-0-shoes",
				"origin" : [5,5],
				"map" :  {
					"navel" : [-9,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|walk1-1-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-3,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|walk1-2-shoes",
				"origin" : [6,5],
				"map" :  {
					"navel" : [-4,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070011|walk1-3-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-2,-12],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|walk1-0-shoes",
				"origin" : [5,5],
				"map" :  {
					"navel" : [-9,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|walk1-1-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-3,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|walk1-2-shoes",
				"origin" : [6,5],
				"map" :  {
					"navel" : [-4,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070011|walk1-3-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-2,-12],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|stand1-0-shoes",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-17],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|stand1-1-shoes",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-16],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|stand1-2-shoes",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-17],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|stand1-0-shoes",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-17],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|stand1-1-shoes",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-16],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|stand1-2-shoes",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-17],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|alert-0-shoes",
				"origin" : [12,5],
				"map" :  {
					"navel" : [2,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|alert-1-shoes",
				"origin" : [12,5],
				"map" :  {
					"navel" : [2,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|alert-2-shoes",
				"origin" : [12,5],
				"map" :  {
					"navel" : [2,-16],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|swingO1-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-11],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingO1-1-shoes",
				"origin" : [14,5],
				"map" :  {
					"navel" : [-10,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|swingO1-2-shoes",
				"origin" : [14,5],
				"map" :  {
					"navel" : [-4,-13],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|swingO2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-16],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingO2-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|swingO2-2-shoes",
				"origin" : [14,5],
				"map" :  {
					"navel" : [-2,-12],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|swingO3-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-3,-11],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingO3-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-10,-12],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|swingO3-2-shoes",
				"origin" : [14,5],
				"map" :  {
					"navel" : [-7,-11],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|swingOF-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [3,-13],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingOF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-2,-16],
				},
				"z" : "backShoes",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|swingOF-2-shoes",
				"origin" : [14,5],
				"map" :  {
					"navel" : [-16,-8],
				},
				"z" : "shoesOverPants",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070011|swingOF-3-shoes",
				"origin" : [14,5],
				"map" :  {
					"navel" : [3,-8],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|swingT1-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-16],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingT1-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|swingT1-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-13],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|swingT2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [4,-10],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingT2-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-13],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|swingT2-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-12],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|swingT3-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingT3-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-6,-11],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|swingT3-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-13],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|swingTF-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-8,-14],
				},
				"z" : "backShoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingTF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-4,-12],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|swingTF-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-3,-11],
				},
				"z" : "shoesOverPants",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070011|swingTF-3-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [3,-11],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|swingP1-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-16],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingP1-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-13],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|swingP1-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-12],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|swingP2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingP2-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|swingP2-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-12],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|swingPF-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-9],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingPF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-8],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|swingPF-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-13],
				},
				"z" : "shoesOverPants",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070011|swingPF-3-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-12],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|stabO1-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [9,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|stabO1-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-11],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|stabO2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [3,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|stabO2-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-12],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|stabOF-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-9],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|stabOF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [10,-12],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|stabOF-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [4,-11],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|stabT1-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [6,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|stabT1-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-4,-13],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|stabT1-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [3,-10],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|stabT2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-12],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|stabT2-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-11],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|stabT2-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [4,-10],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|swingPF-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-9],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingPF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-8],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|stabTF-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-12],
				},
				"z" : "shoesOverPants",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070011|stabT1-2-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [3,-10],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|shoot1-0-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [1,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|shoot1-0-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [1,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|shoot1-0-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [1,-15],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|shoot2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|shoot2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|shoot2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"3" :  {
			"shoes" :  {
				"png_path": "01070011|shoot2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"4" :  {
			"shoes" :  {
				"png_path": "01070011|shoot2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [1,-14],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|shootF-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [4,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|shootF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [5,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|shootF-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [5,-14],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|proneStab-0-shoes",
				"origin" : [5,3],
				"map" :  {
					"navel" : [-16,1],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|proneStab-0-shoes",
				"origin" : [5,3],
				"map" :  {
					"navel" : [-16,1],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|proneStab-0-shoes",
				"origin" : [5,3],
				"map" :  {
					"navel" : [-16,1],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|alert-1-shoes",
				"origin" : [12,5],
				"map" :  {
					"navel" : [2,-15],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|swingO2-1-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [2,-14],
				},
				"z" : "shoesOverPants",
			},
		},
		"2" :  {
			"shoes" :  {
				"png_path": "01070011|swingO2-0-shoes",
				"origin" : [11,5],
				"map" :  {
					"navel" : [0,-16],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|fly-0-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-12,-10],
				},
				"z" : "shoesOverPants",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|fly-1-shoes",
				"origin" : [13,5],
				"map" :  {
					"navel" : [-15,-14],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|jump-0-shoes",
				"origin" : [17,6],
				"map" :  {
					"navel" : [0,-11],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|sit-0-shoes",
				"origin" : [17,6],
				"map" :  {
					"navel" : [0,-11],
				},
				"z" : "shoesOverPants",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|ladder-0-shoes",
				"origin" : [8,6],
				"map" :  {
					"navel" : [0,-13],
				},
				"z" : "backShoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|ladder-1-shoes",
				"origin" : [8,6],
				"map" :  {
					"navel" : [1,-13],
				},
				"z" : "backShoes",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"shoes" :  {
				"png_path": "01070011|rope-0-shoes",
				"origin" : [7,5],
				"map" :  {
					"navel" : [2,-16],
				},
				"z" : "backShoes",
			},
		},
		"1" :  {
			"shoes" :  {
				"png_path": "01070011|rope-1-shoes",
				"origin" : [9,5],
				"map" :  {
					"navel" : [-1,-13],
				},
				"z" : "backShoes",
			},
		},
	},
};

