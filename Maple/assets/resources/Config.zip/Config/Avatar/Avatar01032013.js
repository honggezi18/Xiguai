var Avatar01032013 = Avatar01032013 || { }; 
Avatar01032013 =   {
	"id":"01032013",
	"info" :  {
		"icon" :  {
			"png_path": "00Earrings|01032013-info-icon",
			"origin" : [-3,26],
		},
		"iconRaw" :  {
			"png_path": "00Earrings|01032013-info-iconRaw",
			"origin" : [-3,26],
		},
		"islot" : "Ae",
		"vslot" : "Ae",
		"reqJob" : 0,
		"reqLevel" : 50,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incMDD" : 30,
		"tuc" : 5,
		"price" : 11000,
		"cash" : 0,
	},
	"default" :  {
		"default" :  {
			"png_path": "00Earrings|01032013-default-default",
			"origin" : [15,25],
			"map" :  {
				"brow" : [-1,-41],
			},
			"z" : "accessoryEar",
		},
	},
	"backDefault" :  {
		"default" :  {
			"png_path": "00Earrings|01032013-backDefault-default",
			"origin" : [15,3],
			"map" :  {
				"brow" : [-1,-19],
			},
			"z" : "backAccessoryEar",
		},
	},
	"walk1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-backDefault-default",
				"origin" : [15,3],
				"map" :  {
					"brow" : [-1,-19],
				},
				"z" : "backAccessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-backDefault-default",
				"origin" : [15,3],
				"map" :  {
					"brow" : [-1,-19],
				},
				"z" : "backAccessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"4" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-1,-41],
				},
				"z" : "accessoryEar",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-backDefault-default",
				"origin" : [15,3],
				"map" :  {
					"brow" : [-1,-19],
				},
				"z" : "backAccessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-backDefault-default",
				"origin" : [15,3],
				"map" :  {
					"brow" : [-1,-19],
				},
				"z" : "backAccessoryEar",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-backDefault-default",
				"origin" : [15,3],
				"map" :  {
					"brow" : [-1,-19],
				},
				"z" : "backAccessoryEar",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Earrings|01032013-backDefault-default",
				"origin" : [15,3],
				"map" :  {
					"brow" : [-1,-19],
				},
				"z" : "backAccessoryEar",
			},
		},
	},
};

