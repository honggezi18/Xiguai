var Avatar01099002 = Avatar01099002 || { }; 
Avatar01099002 =   {
	"id":"01099002",
	"info" :  {
		"icon" :  {
			"png_path": "01099002|info-icon",
			"origin" : [-1,31],
		},
		"iconRaw" :  {
			"png_path": "01099002|info-iconRaw",
			"origin" : [-1,31],
		},
		"islot" : "Si",
		"vslot" : "Si",
		"reqJob" : 1,
		"reqLevel" : 30,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPDD" : 30,
		"incMDD" : 15,
		"incLUK" : 0,
		"tuc" : 0,
		"price" : 1,
		"cash" : 0,
		"tradeBlock" : 1,
		"notSale" : 1,
		"unchangeable" : 1,
		"incMMP" : 50,
		"incMHP" : 150,
		"level" :  {
			"info" :  {
				"1" :  {
					"incPDDMin" : 5,
					"incPDDMax" : 5,
					"incMDDMin" : 3,
					"incMDDMax" : 3,
					"incMHPMin" : 50,
					"incMHPMax" : 50,
					"exp" : 10,
				},
				"2" :  {
					"incPDDMin" : 5,
					"incPDDMax" : 5,
					"incMDDMin" : 3,
					"incMDDMax" : 3,
					"incMHPMin" : 50,
					"incMHPMax" : 50,
					"exp" : 5,
				},
				"3" :  {
					"incPDDMin" : 5,
					"incPDDMax" : 5,
					"incMDDMin" : 3,
					"incMDDMax" : 3,
					"incMHPMin" : 50,
					"incMHPMax" : 50,
					"exp" : 3,
				},
				"4" :  {
					"incPDDMin" : 5,
					"incPDDMax" : 5,
					"incMDDMin" : 3,
					"incMDDMax" : 3,
					"incMHPMin" : 50,
					"incMHPMax" : 50,
					"exp" : 1,
				},
				"5" :  {
					"exp" : 0,
				},
			},
			"case" :  {
				"0" :  {
					"prob" : 10,
				},
			},
		},
	},
	"walk1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|walk1-0-shield",
				"origin" : [22,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|walk1-1-shield",
				"origin" : [17,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01099002|walk1-0-shield",
				"origin" : [22,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"3" :  {
			"shield" :  {
				"png_path": "01099002|walk1-3-shield",
				"origin" : [24,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|stand1-0-shield",
				"origin" : [17,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|stand1-1-shield",
				"origin" : [19,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01099002|stand1-2-shield",
				"origin" : [21,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|alert-0-shield",
				"origin" : [20,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|alert-1-shield",
				"origin" : [20,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01099002|alert-2-shield",
				"origin" : [20,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|swingO1-0-shield",
				"origin" : [7,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|swingO1-1-shield",
				"origin" : [2,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01099002|swingO1-2-shield",
				"origin" : [21,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|swingO2-0-shield",
				"origin" : [20,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|swingO2-1-shield",
				"origin" : [25,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01099002|swingO2-2-shield",
				"origin" : [28,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|swingO3-0-shield",
				"origin" : [33,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|swingO3-1-shield",
				"origin" : [6,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01099002|swingO3-2-shield",
				"origin" : [1,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|swingOF-0-shield",
				"origin" : [22,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shield",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|swingOF-1-shield",
				"origin" : [-6,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backShieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01099002|swingOF-2-shield",
				"origin" : [7,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"3" :  {
			"shield" :  {
				"png_path": "01099002|swingOF-3-shield",
				"origin" : [27,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|stabO1-0-shield",
				"origin" : [32,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|stabO1-1-shield",
				"origin" : [5,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|stabO2-0-shield",
				"origin" : [32,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|stabO2-1-shield",
				"origin" : [4,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|stabOF-0-shield",
				"origin" : [8,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shield",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|stabOF-1-shield",
				"origin" : [41,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01099002|stabOF-2-shield",
				"origin" : [31,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|proneStab-0-shield",
				"origin" : [47,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|proneStab-0-shield",
				"origin" : [47,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|proneStab-0-shield",
				"origin" : [47,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|alert-1-shield",
				"origin" : [20,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|swingO2-1-shield",
				"origin" : [25,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01099002|swingO2-0-shield",
				"origin" : [20,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|fly-0-shield",
				"origin" : [20,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01099002|fly-0-shield",
				"origin" : [20,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01099002|jump-0-shield",
				"origin" : [18,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
};

