var Avatar01012028 = Avatar01012028 || { }; 
Avatar01012028 =   {
	"id":"01012028",
	"info" :  {
		"icon" :  {
			"png_path": "00FaceAccessory|01012028-info-icon",
			"origin" : [-4,30],
		},
		"iconRaw" :  {
			"png_path": "00FaceAccessory|01012028-info-iconRaw",
			"origin" : [-5,30],
		},
		"islot" : "Af",
		"vslot" : "Af",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"default" :  {
		"default" :  {
			"png_path": "00FaceAccessory|01012028-default-default",
			"origin" : [14,27],
			"map" :  {
				"brow" : [-4,-41],
			},
			"z" : "accessoryFace",
		},
	},
	"blink" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"hit" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-hit-0-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"smile" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-smile-0-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"troubled" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-troubled-0-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"cry" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-cry-0-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"angry" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-angry-0-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-5,-38],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"bewildered" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"stunned" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"vomit" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-vomit-0-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-5,-38],
				},
				"z" : "accessoryFace",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-vomit-0-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-5,-38],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"oops" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-troubled-0-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"cheers" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"chu" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"wink" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"pain" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"glitter" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"despair" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"love" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"shine" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"blaze" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"hum" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"bowing" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"hot" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
	"dam" :  {
		"0" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00FaceAccessory|01012028-default-default",
				"origin" : [14,27],
				"map" :  {
					"brow" : [-4,-41],
				},
				"z" : "accessoryFace",
			},
		},
	},
};

