var Avatar01062167 = Avatar01062167 || { }; 
Avatar01062167 =   {
	"id":"01062167",
	"info" :  {
		"icon" :  {
			"png_path": "01062167|info-icon",
			"origin" : [-3,29],
		},
		"iconRaw" :  {
			"png_path": "01062167|info-iconRaw",
			"origin" : [-5,29],
		},
		"islot" : "Pn",
		"vslot" : "Pn",
		"tuc" : 7,
		"reqJob" : 4,
		"reqLevel" : 150,
		"reqSTR" : 0,
		"reqDEX" : 450,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPDD" : 135,
		"incMDD" : 135,
		"incSTR" : 30,
		"incDEX" : 30,
		"incACC" : 48,
		"incEVA" : 12,
		"price" : 1,
		"cash" : 0,
		"incPAD" : 2,
		"equipTradeBlock" : 1,
		"tradeAvailable" : 2,
		"setItemID" : 249,
		"charmEXP" : 50,
		"bossReward" : 1,
		"imdR" : 5,
		"exItem" : 1,
	},
	"walk1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|walk1-0-pants",
				"origin" : [4,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|walk1-1-pants",
				"origin" : [7,-2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|walk1-2-pants",
				"origin" : [4,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01062167|walk1-3-pants",
				"origin" : [4,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|walk1-0-pants",
				"origin" : [4,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|walk1-1-pants",
				"origin" : [7,-2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|walk1-2-pants",
				"origin" : [4,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01062167|walk1-3-pants",
				"origin" : [4,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|stand1-0-pants",
				"origin" : [4,-2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|stand1-1-pants",
				"origin" : [5,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|stand1-2-pants",
				"origin" : [6,-2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|stand1-0-pants",
				"origin" : [4,-2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|stand1-1-pants",
				"origin" : [5,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|stand1-2-pants",
				"origin" : [6,-2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|alert-0-pants",
				"origin" : [9,-2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|alert-1-pants",
				"origin" : [8,-2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|alert-2-pants",
				"origin" : [8,-2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|swingO1-0-pants",
				"origin" : [7,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingO1-1-pants",
				"origin" : [3,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|swingO1-2-pants",
				"origin" : [7,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|swingO2-0-pants",
				"origin" : [6,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingO2-1-pants",
				"origin" : [8,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|swingO2-2-pants",
				"origin" : [7,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|swingO3-0-pants",
				"origin" : [6,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingO3-1-pants",
				"origin" : [3,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|swingO3-2-pants",
				"origin" : [3,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|swingOF-0-pants",
				"origin" : [14,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingOF-1-pants",
				"origin" : [23,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backPantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|swingOF-2-pants",
				"origin" : [3,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01062167|swingOF-3-pants",
				"origin" : [14,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|swingT1-0-pants",
				"origin" : [7,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingT1-1-pants",
				"origin" : [7,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|swingT1-2-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|swingT2-0-pants",
				"origin" : [11,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingT2-1-pants",
				"origin" : [8,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|swingT2-2-pants",
				"origin" : [10,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|swingT3-0-pants",
				"origin" : [8,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingT3-1-pants",
				"origin" : [6,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|swingT3-2-pants",
				"origin" : [10,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|swingTF-0-pants",
				"origin" : [15,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backPantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingTF-1-pants",
				"origin" : [11,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|swingTF-2-pants",
				"origin" : [8,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01062167|swingTF-3-pants",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|swingP1-0-pants",
				"origin" : [8,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingP1-1-pants",
				"origin" : [7,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|swingP1-2-pants",
				"origin" : [9,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|swingP2-0-pants",
				"origin" : [8,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingP2-1-pants",
				"origin" : [7,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|swingP2-2-pants",
				"origin" : [10,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|swingPF-0-pants",
				"origin" : [10,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingPF-1-pants",
				"origin" : [11,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|swingPF-2-pants",
				"origin" : [12,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01062167|swingPF-3-pants",
				"origin" : [9,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|stabO1-0-pants",
				"origin" : [19,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|stabO1-1-pants",
				"origin" : [9,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|stabO2-0-pants",
				"origin" : [9,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|stabO2-1-pants",
				"origin" : [7,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|stabOF-0-pants",
				"origin" : [9,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|stabOF-1-pants",
				"origin" : [14,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|stabOF-2-pants",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|stabT1-0-pants",
				"origin" : [11,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|stabT1-1-pants",
				"origin" : [4,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|stabT1-2-pants",
				"origin" : [10,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|stabT2-0-pants",
				"origin" : [8,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|stabT2-1-pants",
				"origin" : [8,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|stabT2-2-pants",
				"origin" : [12,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|swingPF-0-pants",
				"origin" : [10,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingPF-1-pants",
				"origin" : [11,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|stabTF-2-pants",
				"origin" : [9,5],
				"map" :  {
					"navel" : [3,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01062167|stabT1-2-pants",
				"origin" : [10,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|shoot1-0-pants",
				"origin" : [9,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|shoot1-0-pants",
				"origin" : [9,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|shoot1-0-pants",
				"origin" : [9,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|shoot2-0-pants",
				"origin" : [7,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|shoot2-0-pants",
				"origin" : [7,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|shoot2-0-pants",
				"origin" : [7,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01062167|shoot2-0-pants",
				"origin" : [7,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"4" :  {
			"pants" :  {
				"png_path": "01062167|shoot2-0-pants",
				"origin" : [7,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|shootF-0-pants",
				"origin" : [14,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|shootF-1-pants",
				"origin" : [15,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|shootF-1-pants",
				"origin" : [15,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|proneStab-0-pants",
				"origin" : [-1,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|proneStab-0-pants",
				"origin" : [-1,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|proneStab-0-pants",
				"origin" : [-1,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|alert-1-pants",
				"origin" : [8,-2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|swingO2-1-pants",
				"origin" : [8,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01062167|swingO2-0-pants",
				"origin" : [6,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|fly-0-pants",
				"origin" : [5,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|fly-1-pants",
				"origin" : [5,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|jump-0-pants",
				"origin" : [10,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|sit-0-pants",
				"origin" : [12,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|ladder-0-pants",
				"origin" : [15,-3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backPantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|ladder-1-pants",
				"origin" : [17,-3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backPantsBelowShoes",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01062167|rope-0-pants",
				"origin" : [16,-2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backPantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01062167|rope-1-pants",
				"origin" : [16,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backPantsBelowShoes",
			},
		},
	},
};

