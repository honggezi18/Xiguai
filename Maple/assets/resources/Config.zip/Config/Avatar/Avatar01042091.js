var Avatar01042091 = Avatar01042091 || { }; 
Avatar01042091 =   {
	"id":"01042091",
	"info" :  {
		"icon" :  {
			"png_path": "01042091|info-icon",
			"origin" : [-1,29],
		},
		"iconRaw" :  {
			"png_path": "01042091|info-iconRaw",
			"origin" : [-1,29],
		},
		"islot" : "Ma",
		"vslot" : "Ma",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|walk1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|walk1-0-mailArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-10,7],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|walk1-1-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|walk1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,4],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|walk1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|walk1-0-mailArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-10,7],
				},
				"z" : "mailArm",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042091|walk1-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|walk1-3-mailArm",
				"origin" : [4,2],
				"map" :  {
					"navel" : [-10,9],
				},
				"z" : "mailArm",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|walk2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|walk2-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|walk2-1-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|walk2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-8,3],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|walk2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|walk2-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042091|walk2-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|walk2-3-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-10,6],
				},
				"z" : "mailArm",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|stand1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stand1-0-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|stand1-1-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stand1-1-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-9,5],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|stand1-2-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-2,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stand1-2-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-10,4],
				},
				"z" : "mailArm",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|stand2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stand2-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,3],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|stand2-1-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stand2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|stand2-2-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-2,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stand2-2-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|alert-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|alert-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-8,5],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|alert-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|alert-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,4],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|alert-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|alert-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,4],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|swingO1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingO1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [8,6],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingO1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingO1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [7,6],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|swingO1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingO1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-4,14],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|swingO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingO2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [13,9],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingO2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [14,5],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|swingO2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingO2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|swingO3-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [9,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingO3-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-6,8],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingO3-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingO3-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [12,6],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|swingO3-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingO3-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [5,5],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|swingOF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [4,7],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingOF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [3,6],
				},
				"z" : "backMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|swingOF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [6,6],
				},
				"z" : "mailChest",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042091|swingOF-3-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [3,9],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingOF-3-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [11,4],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|swingT1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingT1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-1,16],
				},
				"z" : "mailArmOverHairBelowWeapon",
			},
			"mailArmOverHair" :  {
				"png_path": "01042091|swingT1-0-mailArmOverHair",
				"origin" : [6,8],
				"map" :  {
					"navel" : [-11,15],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingT1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingT1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [15,3],
				},
				"z" : "mailArmOverHairBelowWeapon",
			},
			"mailArmOverHair" :  {
				"png_path": "01042091|swingT1-1-mailArmOverHair",
				"origin" : [7,6],
				"map" :  {
					"navel" : [5,10],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|swingT1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingT1-2-mailArm",
				"origin" : [6,8],
				"map" :  {
					"navel" : [8,-1],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|swingT2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,4],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingT2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [5,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingT2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [7,4],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|swingT2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingT2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,7],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|swingT3-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingT3-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [2,5],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingT3-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingT3-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [5,4],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|swingT3-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingT3-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [16,8],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|swingTF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,8],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingTF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingTF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-3,8],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|swingTF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingTF-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [9,18],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042091|swingTF-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingTF-3-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [14,4],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|swingP1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingP1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [5,17],
				},
				"z" : "mailArmOverHairBelowWeapon",
			},
			"mailArmOverHair" :  {
				"png_path": "01042091|swingP1-0-mailArmOverHair",
				"origin" : [6,8],
				"map" :  {
					"navel" : [-10,16],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingP1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [6,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingP1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [9,12],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|swingP1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingP1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [11,3],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|swingP2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,10],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingP2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [13,5],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingP2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [7,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingP2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [10,3],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|swingP2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingP2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,7],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|swingPF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [6,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingPF-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-11,13],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingPF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [4,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingPF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-10,11],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|swingPF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingPF-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [11,16],
				},
				"z" : "mailArmOverHair",
			},
			"mailArmOverHair" :  {
				"png_path": "01042091|swingPF-2-mailArmOverHair",
				"origin" : [6,8],
				"map" :  {
					"navel" : [-6,16],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042091|swingPF-3-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [2,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingPF-3-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [13,3],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|stabO1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [6,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabO1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-8,8],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|stabO1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabO1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [17,6],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|stabO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [6,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabO2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,7],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|stabO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabO2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [16,5],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|stabOF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [3,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabOF-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [0,9],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|stabOF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [16,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabOF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [0,4],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|stabOF-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [7,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabOF-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [18,5],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|stabT1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabT1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [5,9],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|stabT1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabT1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-5,8],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|stabT1-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [11,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabT1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-4,8],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|stabT2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [3,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabT2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-6,11],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|stabT2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [4,10],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabT2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [2,11],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|stabT2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [9,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabT2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-3,7],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|swingPF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [6,8],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingPF-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-11,13],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingPF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [4,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingPF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-10,11],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|stabTF-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [2,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabTF-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-6,11],
				},
				"z" : "mailArmBelowHead",
			},
			"mailArmOverHair" :  {
				"png_path": "01042091|stabTF-2-mailArmOverHair",
				"origin" : [6,8],
				"map" :  {
					"navel" : [3,2],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042091|stabT1-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [11,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|stabT1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-4,8],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|shoot1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [9,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|shoot1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [0,10],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|shoot1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [9,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|shoot1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,9],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|shoot1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [9,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|shoot1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,9],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|shoot2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|shoot2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,8],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|shoot2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|shoot2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [3,8],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|shoot2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|shoot2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-10,7],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042091|shoot2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|shoot2-3-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-8,7],
				},
				"z" : "mailArmOverHair",
			},
		},
		"4" :  {
			"mail" :  {
				"png_path": "01042091|shoot2-4-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|shoot2-4-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,7],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|shootF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [11,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|shootF-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-1,12],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|shootF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [12,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|shootF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-11,5],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|shootF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [12,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|shootF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-11,5],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|proneStab-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [22,9],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|proneStab-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [0,1],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|proneStab-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [22,9],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|proneStab-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [16,0],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|proneStab-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [22,9],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|proneStab-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [0,1],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|alert-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|alert-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,4],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|swingO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingO2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [14,5],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042091|swingO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|swingO2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [13,9],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|fly-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|fly-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-10,7],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|fly-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|fly-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-10,7],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|jump-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|jump-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-10,5],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|sit-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042091|sit-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-8,6],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|ladder-0-mail",
				"origin" : [7,7],
				"map" :  {
					"navel" : [4,8],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|ladder-1-mail",
				"origin" : [7,7],
				"map" :  {
					"navel" : [4,8],
				},
				"z" : "backMailChest",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042091|rope-0-mail",
				"origin" : [7,7],
				"map" :  {
					"navel" : [3,9],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042091|rope-1-mail",
				"origin" : [7,7],
				"map" :  {
					"navel" : [2,4],
				},
				"z" : "backMailChest",
			},
		},
	},
};

