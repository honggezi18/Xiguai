var Avatar01452166 = Avatar01452166 || { }; 
Avatar01452166 =   {
	"id":"01452166",
	"info" :  {
		"icon" :  {
			"png_path": "01452166|info-icon",
			"origin" : [0,33],
		},
		"iconRaw" :  {
			"png_path": "01452166|info-iconRaw",
			"origin" : [0,33],
		},
		"islot" : "WpSi",
		"vslot" : "WpSi",
		"walk" : 1,
		"stand" : 1,
		"attack" : 3,
		"afterImage" : "bow",
		"sfx" : "bow",
		"reqJob" : 4,
		"reqLevel" : 40,
		"reqSTR" : 0,
		"reqDEX" : 125,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPAD" : 55,
		"tuc" : 7,
		"price" : 17000,
		"attackSpeed" : 6,
		"cash" : 0,
		"knockback" : 40,
	},
	"walk1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|walk1-0-weapon",
				"origin" : [63,11],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452166|walk1-1-weapon",
				"origin" : [54,16],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452166|walk1-2-weapon",
				"origin" : [63,19],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01452166|walk1-3-weapon",
				"origin" : [66,13],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|stand1-0-weapon",
				"origin" : [57,19],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452166|stand1-1-weapon",
				"origin" : [58,19],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452166|stand1-2-weapon",
				"origin" : [59,19],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|alert-0-weapon",
				"origin" : [60,12],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452166|alert-1-weapon",
				"origin" : [59,13],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452166|alert-2-weapon",
				"origin" : [60,14],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|swingT1-0-weapon",
				"origin" : [63,18],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponBelowBody",
			},
			"weaponWrist" :  {
				"png_path": "01452166|swingT1-0-weaponWrist",
				"origin" : [7,46],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponWristOverGlove",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452166|swingT1-1-weapon",
				"origin" : [64,40],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponBelowBody",
			},
			"weaponWrist" :  {
				"png_path": "01452166|swingT1-1-weaponWrist",
				"origin" : [8,39],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponWristOverGlove",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452166|swingT1-2-weapon",
				"origin" : [62,113],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponBelowBody",
			},
			"weaponWrist" :  {
				"png_path": "01452166|swingT1-2-weaponWrist",
				"origin" : [8,77],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponWristOverGlove",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|swingT3-0-weapon",
				"origin" : [80,39],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponBelowBody",
			},
			"weaponWrist" :  {
				"png_path": "01452166|swingT3-0-weaponWrist",
				"origin" : [8,49],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponWristOverGlove",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452166|swingT3-1-weapon",
				"origin" : [108,73],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponBelowBody",
			},
			"weaponWrist" :  {
				"png_path": "01452166|swingT3-1-weaponWrist",
				"origin" : [33,42],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponWristOverGlove",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452166|swingT3-2-weapon",
				"origin" : [113,59],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponBelowBody",
			},
			"weaponWrist" :  {
				"png_path": "01452166|swingT3-2-weaponWrist",
				"origin" : [23,43],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponWristOverGlove",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|shoot1-0-weapon",
				"origin" : [48,-4],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452166|shoot1-1-weapon",
				"origin" : [50,5],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452166|shoot1-2-weapon",
				"origin" : [61,3],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|shootF-0-weapon",
				"origin" : [50,-5],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452166|shootF-1-weapon",
				"origin" : [64,1],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|proneStab-0-weapon",
				"origin" : [60,17],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452166|proneStab-1-weapon",
				"origin" : [48,18],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|proneStab-0-weapon",
				"origin" : [60,17],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|jump-0-weapon",
				"origin" : [58,13],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|fly-0-weapon",
				"origin" : [52,6],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452166|fly-1-weapon",
				"origin" : [54,7],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|sit-0-weapon",
				"origin" : [24,3],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452166|alert-1-weapon",
				"origin" : [59,13],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452166|heal-1-weapon",
				"origin" : [63,51],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452166|heal-2-weapon",
				"origin" : [49,26],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
};

