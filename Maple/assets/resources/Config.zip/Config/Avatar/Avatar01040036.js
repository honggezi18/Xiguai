var Avatar01040036 = Avatar01040036 || { }; 
Avatar01040036 =   {
	"id":"01040036",
	"info" :  {
		"icon" :  {
			"png_path": "01040036|info-icon",
			"origin" : [-4,29],
		},
		"iconRaw" :  {
			"png_path": "01040036|info-iconRaw",
			"origin" : [-5,29],
		},
		"islot" : "Ma",
		"vslot" : "Ma",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPDD" : 1,
		"tuc" : 0,
		"price" : 1,
		"cash" : 0,
	},
	"walk1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|walk1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|walk1-1-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|walk1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040036|walk1-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|walk2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|walk2-1-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|walk2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040036|walk2-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|stand1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|stand1-1-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|stand1-2-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|stand2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|stand2-1-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|stand2-2-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|alert-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|alert-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|alert-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|swingO1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingO1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-7,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|swingO1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|swingO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|swingO2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|swingO3-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingO3-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|swingO3-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|swingOF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingOF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,2],
				},
				"z" : "backMailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|swingOF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040036|swingOF-3-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|swingT1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,-1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingT1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|swingT1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|swingT2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingT2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|swingT2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|swingT3-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingT3-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,-1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|swingT3-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|swingTF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,0],
				},
				"z" : "backMailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingTF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|swingTF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040036|swingTF-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|swingP1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingP1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,4],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|swingP1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|swingP2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingP2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|swingP2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|swingPF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingPF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|swingPF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040036|swingPF-3-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|stabO1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|stabO1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|stabO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|stabO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|stabOF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|stabOF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,-1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|stabOF-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|stabT1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|stabT1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|stabT1-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|stabT2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,4],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|stabT2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|stabT2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|swingPF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingPF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|stabTF-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040036|stabT1-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|shoot1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|shoot1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|shoot1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|shoot2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|shoot2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|shoot2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040036|shoot2-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"4" :  {
			"mail" :  {
				"png_path": "01040036|shoot2-4-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|shootF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|shootF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|shootF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|proneStab-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [13,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|proneStab-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [13,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|proneStab-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [13,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|alert-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|swingO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040036|swingO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|fly-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|fly-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,2],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|jump-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|sit-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-7,1],
				},
				"z" : "mailChestBelowPants",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|ladder-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,-3],
				},
				"z" : "backMailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|ladder-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,-3],
				},
				"z" : "backMailChestBelowPants",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040036|rope-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,-3],
				},
				"z" : "backMailChestBelowPants",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040036|rope-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,-2],
				},
				"z" : "backMailChestBelowPants",
			},
		},
	},
};

