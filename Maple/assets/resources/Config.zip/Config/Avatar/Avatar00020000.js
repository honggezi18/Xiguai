var Avatar00020000 = Avatar00020000 || { }; 
Avatar00020000 =   {
	"id":"00020000",
	"info" :  {
		"islot" : "Fc",
		"vslot" : "Fc",
		"cash" : 1,
	},
	"default" :  {
		"face" :  {
			"png_path": "00020000|default-face",
			"origin" : [13,8],
			"map" :  {
				"brow" : [-1,-12],
			},
			"z" : "face",
		},
	},
	"blink" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|blink-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [-1,-12],
				},
				"z" : "face",
			},
			"delay" : 60,
		},
		"1" :  {
			"face" :  {
				"png_path": "00020000|blink-1-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [-1,-12],
				},
				"z" : "face",
			},
			"delay" : 60,
		},
		"2" :  {
			"face" :  {
				"png_path": "00020000|blink-2-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [-1,-12],
				},
				"z" : "face",
			},
			"delay" : 60,
		},
	},
	"hit" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|hit-0-face",
				"origin" : [12,7],
				"map" :  {
					"brow" : [0,-11],
				},
				"z" : "face",
			},
		},
	},
	"smile" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|smile-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [-1,-12],
				},
				"z" : "face",
			},
		},
	},
	"troubled" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|troubled-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [-1,-12],
				},
				"z" : "face",
			},
		},
	},
	"cry" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|cry-0-face",
				"origin" : [13,6],
				"map" :  {
					"brow" : [-1,-10],
				},
				"z" : "face",
			},
		},
	},
	"angry" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|angry-0-face",
				"origin" : [12,11],
				"map" :  {
					"brow" : [0,-13],
				},
				"z" : "face",
			},
		},
	},
	"bewildered" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|bewildered-0-face",
				"origin" : [13,10],
				"map" :  {
					"brow" : [-1,-11],
				},
				"z" : "face",
			},
		},
	},
	"stunned" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|stunned-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [-1,-12],
				},
				"z" : "face",
			},
		},
	},
	"vomit" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|vomit-0-face",
				"origin" : [14,24],
				"map" :  {
					"brow" : [0,-28],
				},
				"z" : "face",
			},
			"delay" : 120,
		},
		"1" :  {
			"face" :  {
				"png_path": "00020000|vomit-1-face",
				"origin" : [14,24],
				"map" :  {
					"brow" : [0,-28],
				},
				"z" : "face",
			},
			"delay" : 120,
		},
	},
	"oops" :  {
		"delay" : 1640,
		"0" :  {
			"face" :  {
				"png_path": "00020000|oops-0-face",
				"origin" : [12,7],
				"map" :  {
					"brow" : [0,-11],
				},
				"z" : "face",
			},
		},
	},
	"cheers" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|cheers-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [-1,-11],
				},
				"z" : "face",
			},
		},
	},
	"chu" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|chu-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [-1,-12],
				},
				"z" : "face",
			},
		},
	},
	"wink" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|wink-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [-1,-12],
				},
				"z" : "face",
			},
		},
	},
	"pain" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|pain-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [1,-8],
				},
				"z" : "face",
			},
		},
	},
	"glitter" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|glitter-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [0,-9],
				},
				"z" : "face",
			},
			"delay" : 150,
		},
		"1" :  {
			"face" :  {
				"png_path": "00020000|glitter-1-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [0,-9],
				},
				"z" : "face",
			},
			"delay" : 150,
		},
	},
	"despair" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|despair-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [14,-12],
				},
				"z" : "face",
			},
			"delay" : 150,
		},
		"1" :  {
			"face" :  {
				"png_path": "00020000|despair-1-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [16,-12],
				},
				"z" : "face",
			},
			"delay" : 150,
		},
	},
	"love" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|love-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [0,-9],
				},
				"z" : "face",
			},
			"delay" : 150,
		},
		"1" :  {
			"face" :  {
				"png_path": "00020000|love-1-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [0,-9],
				},
				"z" : "face",
			},
			"delay" : 150,
		},
	},
	"shine" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|shine-0-face",
				"origin" : [13,6],
				"map" :  {
					"brow" : [0,-8],
				},
				"z" : "face",
			},
		},
	},
	"blaze" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|blaze-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [0,-10],
				},
				"z" : "face",
			},
			"delay" : 110,
		},
		"1" :  {
			"face" :  {
				"png_path": "00020000|blaze-1-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [0,-8],
				},
				"z" : "face",
			},
			"delay" : 110,
		},
	},
	"hum" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|hum-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [-2,-9],
				},
				"z" : "face",
			},
			"delay" : 110,
		},
		"1" :  {
			"face" :  {
				"png_path": "00020000|hum-1-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [-2,-9],
				},
				"z" : "face",
			},
			"delay" : 110,
		},
	},
	"bowing" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|bowing-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [11,-11],
				},
				"z" : "face",
			},
			"delay" : 110,
		},
		"1" :  {
			"face" :  {
				"png_path": "00020000|bowing-1-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [12,-11],
				},
				"z" : "face",
			},
			"delay" : 110,
		},
	},
	"hot" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|hot-0-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [16,-10],
				},
				"z" : "face",
			},
			"delay" : 110,
		},
		"1" :  {
			"face" :  {
				"png_path": "00020000|hot-1-face",
				"origin" : [13,8],
				"map" :  {
					"brow" : [21,-9],
				},
				"z" : "face",
			},
			"delay" : 110,
		},
	},
	"dam" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|dam-0-face",
				"origin" : [11,-2],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "face",
			},
			"delay" : 240,
		},
		"1" :  {
			"face" :  {
				"png_path": "00020000|dam-1-face",
				"origin" : [11,-1],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "face",
			},
			"delay" : 240,
		},
	},
	"qBlue" :  {
		"0" :  {
			"face" :  {
				"png_path": "00020000|qBlue-0-face",
				"origin" : [14,11],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "face",
			},
		},
	},
};

