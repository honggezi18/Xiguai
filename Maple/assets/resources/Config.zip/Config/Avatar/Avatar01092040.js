var Avatar01092040 = Avatar01092040 || { }; 
Avatar01092040 =   {
	"id":"01092040",
	"info" :  {
		"icon" :  {
			"png_path": "01092040|info-icon",
			"origin" : [6,39],
		},
		"iconRaw" :  {
			"png_path": "01092040|info-iconRaw",
			"origin" : [4,37],
		},
		"islot" : "Si",
		"vslot" : "Si",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|walk1-0-shield",
				"origin" : [9,7],
				"map" :  {
					"navel" : [24,15],
				},
				"z" : "shield",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|walk1-1-shield",
				"origin" : [9,6],
				"map" :  {
					"navel" : [23,15],
				},
				"z" : "shield",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092040|walk1-0-shield",
				"origin" : [9,7],
				"map" :  {
					"navel" : [24,15],
				},
				"z" : "shield",
			},
		},
		"3" :  {
			"shield" :  {
				"png_path": "01092040|walk1-3-shield",
				"origin" : [9,6],
				"map" :  {
					"navel" : [24,17],
				},
				"z" : "shield",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|stand1-0-shield",
				"origin" : [9,6],
				"map" :  {
					"navel" : [18,11],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|stand1-1-shield",
				"origin" : [9,6],
				"map" :  {
					"navel" : [20,12],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092040|stand1-2-shield",
				"origin" : [9,6],
				"map" :  {
					"navel" : [22,11],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|alert-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [22,16],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|alert-1-shield",
				"origin" : [10,6],
				"map" :  {
					"navel" : [22,15],
				},
				"z" : "shieldOverHair",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092040|alert-2-shield",
				"origin" : [9,6],
				"map" :  {
					"navel" : [23,15],
				},
				"z" : "shieldOverHair",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|swingO1-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [9,26],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|swingO1-1-shield",
				"origin" : [10,6],
				"map" :  {
					"navel" : [3,19],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092040|swingO1-2-shield",
				"origin" : [9,6],
				"map" :  {
					"navel" : [19,21],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|swingO2-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [21,17],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|swingO2-1-shield",
				"origin" : [10,6],
				"map" :  {
					"navel" : [18,27],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092040|swingO2-2-shield",
				"origin" : [9,6],
				"map" :  {
					"navel" : [28,27],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|swingO3-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [36,24],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|swingO3-1-shield",
				"origin" : [10,6],
				"map" :  {
					"navel" : [10,25],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092040|swingO3-2-shield",
				"origin" : [9,6],
				"map" :  {
					"navel" : [6,25],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|swingOF-0-shield",
				"origin" : [9,7],
				"map" :  {
					"navel" : [26,14],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|swingOF-1-shield",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-8,18],
				},
				"z" : "backShield",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092040|swingOF-2-shield",
				"origin" : [9,6],
				"map" :  {
					"navel" : [10,28],
				},
				"z" : "shieldBelowBody",
			},
		},
		"3" :  {
			"shield" :  {
				"png_path": "01092040|swingOF-3-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [29,21],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|stabO1-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [34,25],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|stabO1-1-shield",
				"origin" : [10,6],
				"map" :  {
					"navel" : [12,22],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|stabO2-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [34,25],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|stabO2-1-shield",
				"origin" : [10,6],
				"map" :  {
					"navel" : [9,21],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|stabOF-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [23,21],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|stabOF-1-shield",
				"origin" : [10,6],
				"map" :  {
					"navel" : [44,26],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092040|stabOF-2-shield",
				"origin" : [10,6],
				"map" :  {
					"navel" : [31,24],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|proneStab-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [50,22],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|proneStab-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [50,22],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|proneStab-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [50,22],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|alert-1-shield",
				"origin" : [10,6],
				"map" :  {
					"navel" : [22,15],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|swingO2-1-shield",
				"origin" : [10,6],
				"map" :  {
					"navel" : [18,27],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092040|swingO2-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [21,17],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|fly-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [21,22],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|fly-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [21,22],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|jump-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [20,21],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|ladder-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [13,20],
				},
				"z" : "backShield",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|ladder-1-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [12,20],
				},
				"z" : "backShield",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092040|rope-0-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [13,20],
				},
				"z" : "backShield",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092040|rope-1-shield",
				"origin" : [10,5],
				"map" :  {
					"navel" : [12,21],
				},
				"z" : "backShield",
			},
		},
	},
};

