var Avatar01432124 = Avatar01432124 || { }; 
Avatar01432124 =   {
	"id":"01432124",
	"info" :  {
		"icon" :  {
			"png_path": "01432124|info-icon",
			"origin" : [0,33],
		},
		"iconRaw" :  {
			"png_path": "01432124|info-iconRaw",
			"origin" : [0,33],
		},
		"islot" : "Wp",
		"vslot" : "Wp",
		"walk" : 2,
		"stand" : 2,
		"attack" : 2,
		"afterImage" : "spear",
		"sfx" : "spear",
		"reqJob" : 1,
		"reqLevel" : 100,
		"reqSTR" : 310,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPAD" : 107,
		"tuc" : 7,
		"price" : 1,
		"attackSpeed" : 6,
		"cash" : 0,
		"equipTradeBlock" : 1,
		"epicItem" : 1,
	},
	"walk2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|walk2-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [0,43],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432124|walk2-1-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [-1,46],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432124|walk2-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [0,43],
				},
				"z" : "weaponOverArm",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01432124|walk2-3-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [0,42],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|stand2-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [0,46],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432124|stand2-1-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [2,43],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432124|stand2-2-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [3,38],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|alert-0-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [42,43],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432124|alert-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [41,42],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432124|alert-2-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [42,41],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|swingT2-0-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [5,67],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432124|swingT2-1-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [28,81],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432124|swingT2-2-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [55,-1],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|swingP1-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [8,41],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432124|swingP1-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [14,84],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432124|swingP1-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [74,-4],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|swingP2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [18,67],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432124|swingP2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [12,79],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432124|swingP2-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [54,0],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|swingPF-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [63,6],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432124|swingPF-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [58,8],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432124|swingPF-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [10,41],
				},
				"z" : "weaponBelowArm",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01432124|swingPF-3-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [74,-4],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|stabT1-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [54,5],
				},
				"z" : "weaponOverBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432124|stabT1-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [58,3],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432124|stabT1-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [81,7],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|stabT2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [61,4],
				},
				"z" : "weaponOverBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432124|stabT2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [64,5],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432124|stabT2-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [70,17],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|swingPF-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [63,6],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432124|swingPF-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [58,8],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432124|stabTF-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [28,19],
				},
				"z" : "weaponOverBody",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01432124|stabT1-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [81,7],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|proneStab-0-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [92,6],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432124|proneStab-1-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [107,6],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|proneStab-0-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [92,6],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|fly-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [11,49],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432124|fly-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [11,49],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432124|jump-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [9,49],
				},
				"z" : "weaponOverArm",
			},
		},
	},
};

