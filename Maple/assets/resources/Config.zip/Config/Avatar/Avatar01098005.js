var Avatar01098005 = Avatar01098005 || { }; 
Avatar01098005 =   {
	"id":"01098005",
	"info" :  {
		"icon" :  {
			"png_path": "01098005|info-icon",
			"origin" : [1,35],
		},
		"iconRaw" :  {
			"png_path": "01098005|info-iconRaw",
			"origin" : [1,35],
		},
		"islot" : "Si",
		"vslot" : "Si",
		"reqJob" : 1,
		"reqLevel" : 100,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPDD" : 81,
		"incMDD" : 42,
		"incSTR" : 10,
		"incDEX" : 10,
		"tuc" : 0,
		"price" : 1,
		"cash" : 0,
		"incMMP" : 100,
		"incMHP" : 560,
		"exItem" : 1,
		"setItemID" : 275,
		"equipTradeBlock" : 1,
		"exGrade" : 1,
	},
	"walk1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|walk1-0-shield",
				"origin" : [34,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|walk1-1-shield",
				"origin" : [29,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098005|walk1-0-shield",
				"origin" : [34,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"3" :  {
			"shield" :  {
				"png_path": "01098005|walk1-3-shield",
				"origin" : [36,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|stand1-0-shield",
				"origin" : [29,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|stand1-1-shield",
				"origin" : [31,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098005|stand1-2-shield",
				"origin" : [33,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|alert-0-shield",
				"origin" : [33,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|alert-1-shield",
				"origin" : [33,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098005|alert-2-shield",
				"origin" : [33,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|swingO1-0-shield",
				"origin" : [22,27],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|swingO1-1-shield",
				"origin" : [16,24],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098005|swingO1-2-shield",
				"origin" : [31,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|swingO2-0-shield",
				"origin" : [35,21],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|swingO2-1-shield",
				"origin" : [35,31],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098005|swingO2-2-shield",
				"origin" : [41,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|swingO3-0-shield",
				"origin" : [42,28],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|swingO3-1-shield",
				"origin" : [24,28],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098005|swingO3-2-shield",
				"origin" : [18,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|swingOF-0-shield",
				"origin" : [31,21],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|swingOF-1-shield",
				"origin" : [6,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098005|swingOF-2-shield",
				"origin" : [19,30],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"3" :  {
			"shield" :  {
				"png_path": "01098005|swingOF-3-shield",
				"origin" : [38,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|stabO1-0-shield",
				"origin" : [47,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|stabO1-1-shield",
				"origin" : [21,25],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|stabO2-0-shield",
				"origin" : [47,28],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|stabO2-1-shield",
				"origin" : [23,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|stabOF-0-shield",
				"origin" : [25,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|stabOF-1-shield",
				"origin" : [57,31],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098005|stabOF-2-shield",
				"origin" : [45,28],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|proneStab-0-shield",
				"origin" : [57,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|proneStab-0-shield",
				"origin" : [57,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|proneStab-0-shield",
				"origin" : [57,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|alert-1-shield",
				"origin" : [33,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|swingO2-1-shield",
				"origin" : [35,31],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01098005|swingO2-0-shield",
				"origin" : [35,21],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|fly-0-shield",
				"origin" : [33,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|fly-0-shield",
				"origin" : [33,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|jump-0-shield",
				"origin" : [32,25],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|rope-0-shield",
				"origin" : [21,21],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|rope-1-shield",
				"origin" : [20,24],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01098005|ladder-0-shield",
				"origin" : [22,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01098005|ladder-1-shield",
				"origin" : [20,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
	},
};

