var Avatar01042037 = Avatar01042037 || { }; 
Avatar01042037 =   {
	"id":"01042037",
	"walk1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|walk1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|walk1-0-mailArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-10,7],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|walk1-1-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|walk1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|walk1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|walk1-0-mailArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-10,7],
				},
				"z" : "mailArm",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042037|walk1-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|walk1-3-mailArm",
				"origin" : [4,2],
				"map" :  {
					"navel" : [-10,10],
				},
				"z" : "mailArm",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|walk2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|walk2-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|walk2-1-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|walk2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,3],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|walk2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|walk2-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042037|walk2-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|walk2-3-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-10,6],
				},
				"z" : "mailArm",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|stand1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stand1-0-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-12,4],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|stand1-1-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stand1-1-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-11,5],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|stand1-2-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-1,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stand1-2-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-11,4],
				},
				"z" : "mailArm",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|stand2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stand2-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,3],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|stand2-1-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stand2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|stand2-2-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-2,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stand2-2-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArm",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|alert-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|alert-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,5],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|alert-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|alert-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-8,4],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|alert-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|alert-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-8,4],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|swingO1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingO1-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [9,4],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingO1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingO1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [7,6],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|swingO1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingO1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-4,14],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|swingO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingO2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [12,9],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingO2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [13,5],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|swingO2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingO2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|swingO3-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [10,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingO3-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-7,9],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingO3-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingO3-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [11,6],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|swingO3-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingO3-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [5,4],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|swingOF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [4,4],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingOF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [9,6],
				},
				"z" : "backMailChestOverPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|swingOF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [6,5],
				},
				"z" : "mailChest",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042037|swingOF-3-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [2,7],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingOF-3-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [11,5],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|swingT1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingT1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-2,16],
				},
				"z" : "mailArmOverHairBelowWeapon",
			},
			"mailArmOverHair" :  {
				"png_path": "01042037|swingT1-0-mailArmOverHair",
				"origin" : [6,8],
				"map" :  {
					"navel" : [-12,14],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingT1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingT1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [15,3],
				},
				"z" : "mailArmOverHairBelowWeapon",
			},
			"mailArmOverHair" :  {
				"png_path": "01042037|swingT1-1-mailArmOverHair",
				"origin" : [7,6],
				"map" :  {
					"navel" : [5,11],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|swingT1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingT1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [11,2],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|swingT2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,4],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingT2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [5,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingT2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [7,4],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|swingT2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingT2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,7],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|swingT3-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingT3-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [1,4],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingT3-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingT3-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [5,3],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|swingT3-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingT3-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [16,10],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|swingTF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,9],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingTF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [10,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingTF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-5,8],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|swingTF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingTF-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [9,18],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042037|swingTF-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingTF-3-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [13,4],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|swingP1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingP1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [4,17],
				},
				"z" : "mailArmOverHairBelowWeapon",
			},
			"mailArmOverHair" :  {
				"png_path": "01042037|swingP1-0-mailArmOverHair",
				"origin" : [6,8],
				"map" :  {
					"navel" : [-11,15],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingP1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [6,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingP1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [9,13],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|swingP1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingP1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [11,3],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|swingP2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,9],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingP2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [12,5],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingP2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [5,6],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingP2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [9,2],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|swingP2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingP2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [6,7],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|swingPF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [6,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingPF-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-11,13],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingPF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [4,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingPF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-10,11],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|swingPF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingPF-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [11,15],
				},
				"z" : "mailArmOverHair",
			},
			"mailArmOverHair" :  {
				"png_path": "01042037|swingPF-2-mailArmOverHair",
				"origin" : [6,8],
				"map" :  {
					"navel" : [-7,15],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042037|swingPF-3-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [2,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingPF-3-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [13,3],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|stabO1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [6,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabO1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,7],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|stabO1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabO1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [17,7],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|stabO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [6,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabO2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-11,7],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|stabO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabO2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [16,5],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|stabOF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [3,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabOF-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-1,9],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|stabOF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [15,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabOF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-1,4],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|stabOF-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [6,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabOF-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [17,6],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|stabT1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabT1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-5,9],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|stabT1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,1],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabT1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-5,8],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|stabT1-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [11,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabT1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-5,6],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|stabT2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [3,5],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabT2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-7,11],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|stabT2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [3,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabT2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [1,11],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|stabT2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [9,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabT2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-4,7],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|swingPF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [6,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingPF-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-11,13],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingPF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [4,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingPF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-10,11],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|stabTF-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabTF-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-6,11],
				},
				"z" : "mailArmBelowHead",
			},
			"mailArmOverHair" :  {
				"png_path": "01042037|stabTF-2-mailArmOverHair",
				"origin" : [6,8],
				"map" :  {
					"navel" : [0,1],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042037|stabT1-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [11,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|stabT1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-5,6],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|shoot1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [7,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|shoot1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-1,10],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|shoot1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [8,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|shoot1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,8],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|shoot1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [8,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|shoot1-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,8],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|shoot2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|shoot2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,8],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|shoot2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|shoot2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [2,8],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|shoot2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|shoot2-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-10,7],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01042037|shoot2-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|shoot2-3-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-8,7],
				},
				"z" : "mailArmOverHair",
			},
		},
		"4" :  {
			"mail" :  {
				"png_path": "01042037|shoot2-4-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|shoot2-4-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,7],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|shootF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [9,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|shootF-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-2,12],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|shootF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [10,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|shootF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-11,6],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|shootF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [10,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|shootF-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-11,6],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|proneStab-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [23,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|proneStab-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|proneStab-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [23,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|proneStab-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [16,0],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|proneStab-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [23,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|proneStab-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|alert-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|alert-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-8,4],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|swingO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingO2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [13,5],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01042037|swingO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|swingO2-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [12,9],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|fly-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|fly-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,7],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|fly-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,4],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|fly-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,7],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|jump-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,3],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|jump-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-10,6],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|sit-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,2],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01042037|sit-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-8,5],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|ladder-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,5],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|ladder-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,5],
				},
				"z" : "backMailChest",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01042037|rope-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,7],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01042037|rope-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,1],
				},
				"z" : "backMailChest",
			},
		},
	},
	"info" :  {
		"icon" :  {
			"png_path": "01042037|info-icon",
			"origin" : [-2,30],
		},
		"iconRaw" :  {
			"png_path": "01042037|info-iconRaw",
			"origin" : [-2,30],
		},
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
		"islot" : "Ma",
		"vslot" : "Ma",
	},
};

