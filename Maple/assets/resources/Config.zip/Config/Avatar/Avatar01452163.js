var Avatar01452163 = Avatar01452163 || { }; 
Avatar01452163 =   {
	"id":"01452163",
	"info" :  {
		"icon" :  {
			"png_path": "01452163|info-icon",
			"origin" : [1,32],
		},
		"iconRaw" :  {
			"png_path": "01452163|info-iconRaw",
			"origin" : [1,32],
		},
		"islot" : "WpSi",
		"vslot" : "WpSi",
		"walk" : 1,
		"stand" : 1,
		"attack" : 3,
		"afterImage" : "bow",
		"sfx" : "bow",
		"tuc" : 7,
		"reqJob" : 4,
		"reqLevel" : 120,
		"reqSTR" : 0,
		"reqDEX" : 305,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPAD" : 105,
		"knockback" : 75,
		"attackSpeed" : 6,
		"price" : 1,
		"cash" : 0,
		"tradeAvailable" : 2,
		"equipTradeBlock" : 1,
		"bossReward" : 1,
		"exItem" : 1,
		"setItemID" : 454,
	},
	"walk1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452163|walk1-0-weapon",
				"origin" : [40,22],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452163|walk1-1-weapon",
				"origin" : [37,29],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452163|walk1-0-weapon",
				"origin" : [40,22],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01452163|walk1-3-weapon",
				"origin" : [43,28],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452163|stand1-0-weapon",
				"origin" : [39,20],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452163|stand1-1-weapon",
				"origin" : [39,20],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452163|stand1-2-weapon",
				"origin" : [39,20],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452163|alert-0-weapon",
				"origin" : [38,49],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452163|alert-1-weapon",
				"origin" : [37,48],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452163|alert-2-weapon",
				"origin" : [38,47],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452163|swingT1-0-weapon",
				"origin" : [31,21],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452163|swingT1-1-weapon",
				"origin" : [18,49],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452163|swingT1-2-weapon",
				"origin" : [42,28],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452163|swingT3-0-weapon",
				"origin" : [37,29],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452163|swingT3-1-weapon",
				"origin" : [42,21],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452163|swingT3-2-weapon",
				"origin" : [36,57],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452163|shoot1-0-weapon",
				"origin" : [33,37],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452163|shoot1-1-weapon",
				"origin" : [47,37],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452163|shoot1-2-weapon",
				"origin" : [47,37],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452163|shootF-0-weapon",
				"origin" : [35,40],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452163|shootF-1-weapon",
				"origin" : [52,42],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452163|shootF-1-weapon",
				"origin" : [52,42],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452163|proneStab-0-weapon",
				"origin" : [73,16],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452163|proneStab-1-weapon",
				"origin" : [73,17],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452163|proneStab-0-weapon",
				"origin" : [73,16],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452163|fly-0-weapon",
				"origin" : [34,32],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452163|fly-1-weapon",
				"origin" : [33,33],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452163|jump-0-weapon",
				"origin" : [34,32],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
};

