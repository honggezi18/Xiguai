var Avatar01040194 = Avatar01040194 || { }; 
Avatar01040194 =   {
	"id":"01040194",
	"info" :  {
		"icon" :  {
			"png_path": "01040194|info-icon",
			"origin" : [-4,27],
		},
		"iconRaw" :  {
			"png_path": "01040194|info-iconRaw",
			"origin" : [-5,27],
		},
		"islot" : "Ma",
		"vslot" : "Ma",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|walk1-0-mail",
				"origin" : [4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|walk1-0-mailArm",
				"origin" : [-6,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|walk1-1-mail",
				"origin" : [4,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|walk1-1-mailArm",
				"origin" : [-6,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|walk1-2-mail",
				"origin" : [4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|walk1-2-mailArm",
				"origin" : [-6,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArm",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040194|walk1-3-mail",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|walk1-3-mailArm",
				"origin" : [-6,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArm",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|walk2-0-mail",
				"origin" : [4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|walk2-0-mailArm",
				"origin" : [-6,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|walk2-1-mail",
				"origin" : [4,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|walk2-1-mailArm",
				"origin" : [-5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|walk2-2-mail",
				"origin" : [4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|walk2-2-mailArm",
				"origin" : [-6,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArm",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040194|walk2-3-mail",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|walk2-3-mailArm",
				"origin" : [-6,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArm",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|stand1-0-mail",
				"origin" : [3,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|stand1-1-mail",
				"origin" : [4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|stand1-2-mail",
				"origin" : [5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|stand2-0-mail",
				"origin" : [3,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|stand2-0-mailArm",
				"origin" : [-6,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|stand2-1-mail",
				"origin" : [4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|stand2-1-mailArm",
				"origin" : [-6,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|stand2-2-mail",
				"origin" : [5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|stand2-2-mailArm",
				"origin" : [-6,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArm",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|alert-0-mail",
				"origin" : [6,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|alert-0-mailArm",
				"origin" : [-5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|alert-1-mail",
				"origin" : [5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|alert-1-mailArm",
				"origin" : [-5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|alert-2-mail",
				"origin" : [6,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|alert-2-mailArm",
				"origin" : [-5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|swingO1-0-mail",
				"origin" : [6,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|swingO1-0-mailArm",
				"origin" : [6,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingO1-1-mail",
				"origin" : [3,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|swingO1-1-mailArm",
				"origin" : [1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|swingO1-2-mail",
				"origin" : [5,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|swingO1-2-mailArm",
				"origin" : [-2,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|swingO2-0-mail",
				"origin" : [5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingO2-1-mail",
				"origin" : [6,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|swingO2-2-mail",
				"origin" : [5,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|swingO3-0-mail",
				"origin" : [7,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingO3-1-mail",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|swingO3-2-mail",
				"origin" : [2,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|swingO3-2-mailArm",
				"origin" : [2,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|swingOF-0-mail",
				"origin" : [6,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingOF-1-mail",
				"origin" : [7,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backMailChestOverPants",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|swingOF-2-mail",
				"origin" : [3,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040194|swingOF-3-mail",
				"origin" : [11,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|swingOF-3-mailArm",
				"origin" : [12,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|swingT1-0-mail",
				"origin" : [4,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingT1-1-mail",
				"origin" : [5,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|swingT1-2-mail",
				"origin" : [6,9],
				"map" :  {
					"navel" : [0,-1],
				},
				"z" : "mailChest",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|swingT2-0-mail",
				"origin" : [4,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
				"navel" : [0,0],
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingT2-1-mail",
				"origin" : [5,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|swingT2-2-mail",
				"origin" : [7,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|swingT2-2-mailArm",
				"origin" : [6,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|swingT3-0-mail",
				"origin" : [6,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingT3-1-mail",
				"origin" : [7,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|swingT3-1-mailArm",
				"origin" : [7,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmBelowHeadOverMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|swingT3-2-mail",
				"origin" : [8,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|swingTF-0-mail",
				"origin" : [7,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingTF-1-mail",
				"origin" : [9,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|swingTF-2-mail",
				"origin" : [6,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|swingTF-2-mailArm",
				"origin" : [7,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040194|swingTF-3-mail",
				"origin" : [8,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|swingP1-0-mail",
				"origin" : [5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|swingP1-0-mailArm",
				"origin" : [1,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHairBelowWeapon",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingP1-1-mail",
				"origin" : [5,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|swingP1-2-mail",
				"origin" : [6,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|swingP2-0-mail",
				"origin" : [5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingP2-1-mail",
				"origin" : [5,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|swingP2-2-mail",
				"origin" : [7,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|swingP2-2-mailArm",
				"origin" : [6,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|swingPF-0-mail",
				"origin" : [5,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingPF-1-mail",
				"origin" : [5,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|swingPF-2-mail",
				"origin" : [9,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|swingPF-2-mailArm",
				"origin" : [7,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040194|swingPF-3-mail",
				"origin" : [8,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|stabO1-0-mail",
				"origin" : [7,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|stabO1-0-mailArm",
				"origin" : [-4,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|stabO1-1-mail",
				"origin" : [7,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|stabO2-0-mail",
				"origin" : [5,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|stabO2-1-mail",
				"origin" : [5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|stabOF-0-mail",
				"origin" : [12,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|stabOF-0-mailArm",
				"origin" : [3,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|stabOF-1-mail",
				"origin" : [12,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|stabOF-2-mail",
				"origin" : [8,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|stabT1-0-mail",
				"origin" : [7,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|stabT1-1-mail",
				"origin" : [5,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|stabT1-2-mail",
				"origin" : [8,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|stabT2-0-mail",
				"origin" : [6,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|stabT2-0-mailArm",
				"origin" : [-3,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmBelowHead",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|stabT2-1-mail",
				"origin" : [11,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|stabT2-2-mail",
				"origin" : [9,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|stabT2-2-mailArm",
				"origin" : [-1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmBelowHead",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|swingPF-0-mail",
				"origin" : [5,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingPF-1-mail",
				"origin" : [5,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|stabTF-2-mail",
				"origin" : [9,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040194|stabT1-2-mail",
				"origin" : [8,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|shoot1-0-mail",
				"origin" : [6,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|shoot1-0-mailArm",
				"origin" : [-5,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|shoot1-1-mail",
				"origin" : [6,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|shoot1-1-mailArm",
				"origin" : [-5,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|shoot1-1-mail",
				"origin" : [6,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|shoot1-1-mailArm",
				"origin" : [-5,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|shoot2-0-mail",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|shoot2-0-mailArm",
				"origin" : [-5,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|shoot2-1-mail",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|shoot2-1-mailArm",
				"origin" : [-4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|shoot2-2-mail",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040194|shoot2-3-mail",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|shoot2-3-mailArm",
				"origin" : [-6,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"4" :  {
			"mail" :  {
				"png_path": "01040194|shoot2-4-mail",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|shoot2-4-mailArm",
				"origin" : [-7,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|shootF-0-mail",
				"origin" : [10,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|shootF-0-mailArm",
				"origin" : [-4,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|shootF-1-mail",
				"origin" : [10,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|shootF-1-mail",
				"origin" : [10,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|proneStab-0-mail",
				"origin" : [27,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|proneStab-0-mail",
				"origin" : [27,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|proneStab-0-mail",
				"origin" : [27,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|alert-1-mail",
				"origin" : [5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|alert-1-mailArm",
				"origin" : [-5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|swingO2-1-mail",
				"origin" : [6,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040194|swingO2-0-mail",
				"origin" : [5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|fly-0-mail",
				"origin" : [5,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|fly-1-mail",
				"origin" : [5,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|jump-0-mail",
				"origin" : [4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|sit-0-mail",
				"origin" : [3,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailChest",
			},
			"mailArm" :  {
				"png_path": "01040194|sit-0-mailArm",
				"origin" : [-5,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|ladder-0-mail",
				"origin" : [8,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|ladder-1-mail",
				"origin" : [7,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backMailChest",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040194|rope-0-mail",
				"origin" : [8,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040194|rope-1-mail",
				"origin" : [7,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backMailChest",
			},
		},
	},
};

