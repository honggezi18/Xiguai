var Avatar01080007 = Avatar01080007 || { }; 
Avatar01080007 =   {
	"id":"01080007",
	"info" :  {
		"icon" :  {
			"png_path": "01080007|info-icon",
			"origin" : [-1,31],
		},
		"iconRaw" :  {
			"png_path": "01080007|info-iconRaw",
			"origin" : [-1,31],
		},
		"islot" : "Gv",
		"vslot" : "GlGw",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|walk1-0-lGlove",
				"origin" : [13,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|walk1-0-rGlove",
				"origin" : [-9,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|walk1-1-lGlove",
				"origin" : [8,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|walk1-1-rGlove",
				"origin" : [0,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|walk1-2-lGlove",
				"origin" : [13,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|walk1-0-rGlove",
				"origin" : [-9,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080007|walk1-3-lGlove",
				"origin" : [15,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|walk1-3-rGlove",
				"origin" : [-11,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|walk2-0-lGlove",
				"origin" : [10,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|walk2-0-rGlove",
				"origin" : [0,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|walk2-1-lGlove",
				"origin" : [11,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|walk2-1-rGlove",
				"origin" : [1,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|walk2-0-lGlove",
				"origin" : [10,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|walk2-0-rGlove",
				"origin" : [0,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080007|walk2-3-lGlove",
				"origin" : [9,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|walk2-3-rGlove",
				"origin" : [-1,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|stand1-0-lGlove",
				"origin" : [8,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|stand1-0-rGlove",
				"origin" : [-8,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|stand1-1-lGlove",
				"origin" : [10,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|stand1-1-rGlove",
				"origin" : [-8,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|stand1-2-lGlove",
				"origin" : [12,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|stand1-2-rGlove",
				"origin" : [-8,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|stand2-0-lGlove",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|stand2-1-lGlove",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|stand2-2-lGlove",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|alert-0-lGlove",
				"origin" : [12,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|alert-1-lGlove",
				"origin" : [12,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|alert-2-lGlove",
				"origin" : [12,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"swingO1" :  {
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|swingO1-1-lGlove",
				"origin" : [12,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|swingO1-1-rGlove",
				"origin" : [-8,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|swingO1-2-lGlove",
				"origin" : [-10,25],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|swingO1-2-rGlove",
				"origin" : [9,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|swingO2-0-lGlove",
				"origin" : [12,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingO2-0-rGlove",
				"origin" : [22,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|swingO2-1-lGlove",
				"origin" : [11,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingO2-1-rGlove",
				"origin" : [25,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|swingO2-2-lGlove",
				"origin" : [19,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingO2-2-rGlove",
				"origin" : [-11,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|swingO3-0-lGlove",
				"origin" : [28,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingO3-0-rGlove",
				"origin" : [-12,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080007|swingO3-1-rGlove",
				"origin" : [23,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|swingOF-0-lGlove",
				"origin" : [15,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
			"rGlove" :  {
				"png_path": "01080007|swingOF-0-rGlove",
				"origin" : [-12,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080007|swingOF-3-lGlove",
				"origin" : [-9,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingOF-3-rGlove",
				"origin" : [18,-4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|swingT1-0-lGlove",
				"origin" : [-11,30],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|swingT1-0-rGlove",
				"origin" : [0,27],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|swingT1-1-lGlove",
				"origin" : [19,25],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|swingT1-1-rGlove",
				"origin" : [23,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|swingT1-2-lGlove",
				"origin" : [12,-3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingT1-2-rGlove",
				"origin" : [20,-4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"swingT2" :  {
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|swingT2-1-lGlove",
				"origin" : [21,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingT2-1-rGlove",
				"origin" : [19,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"rGlove" :  {
				"png_path": "01080007|swingT2-2-rGlove",
				"origin" : [1,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
			"lGlove" :  {
				"png_path": "01080007|swingT2-2-lGlove",
				"origin" : [1,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "armOverHair",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|swingT3-0-lGlove",
				"origin" : [-7,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingT3-0-rGlove",
				"origin" : [0,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|swingT3-1-lGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|swingT3-1-rGlove",
				"origin" : [4,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "armOverHair",
			},
		},
	},
	"swingTF" :  {
		"2" :  {
			"rGlove" :  {
				"png_path": "01080007|swingTF-2-rGlove",
				"origin" : [16,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"lGlove" :  {
				"png_path": "01080007|swingTF-2-lGlove",
				"origin" : [16,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080007|swingTF-3-lGlove",
				"origin" : [17,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingTF-3-rGlove",
				"origin" : [22,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|swingP1-0-lGlove",
				"origin" : [-10,32],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|swingP1-0-rGlove",
				"origin" : [5,30],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|swingP1-1-lGlove",
				"origin" : [19,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|swingP1-1-rGlove",
				"origin" : [25,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|swingP1-2-lGlove",
				"origin" : [12,-2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingP1-2-rGlove",
				"origin" : [20,-3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"rGlove" :  {
				"png_path": "01080007|swingP2-0-rGlove",
				"origin" : [22,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080007|swingP2-1-rGlove",
				"origin" : [23,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|swingP2-2-lGlove",
				"origin" : [1,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|swingPF-0-lGlove",
				"origin" : [-16,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|swingPF-0-rGlove",
				"origin" : [23,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|swingPF-1-lGlove",
				"origin" : [-15,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|swingPF-1-rGlove",
				"origin" : [21,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|swingPF-2-lGlove",
				"origin" : [-6,32],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|swingPF-2-rGlove",
				"origin" : [11,30],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080007|swingPF-3-lGlove",
				"origin" : [14,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingPF-3-rGlove",
				"origin" : [22,-3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|stabO1-0-lGlove",
				"origin" : [25,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|stabO1-0-rGlove",
				"origin" : [-10,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080007|stabO1-1-rGlove",
				"origin" : [30,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|stabO2-0-lGlove",
				"origin" : [25,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|stabO2-0-rGlove",
				"origin" : [-6,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080007|stabO2-1-rGlove",
				"origin" : [28,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|stabOF-0-lGlove",
				"origin" : [4,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|stabOF-0-rGlove",
				"origin" : [-3,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowMailArm",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|stabOF-1-lGlove",
				"origin" : [35,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|stabOF-1-rGlove",
				"origin" : [-7,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowMailArm",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|stabOF-2-lGlove",
				"origin" : [32,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|stabOF-2-rGlove",
				"origin" : [32,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|stabT1-0-lGlove",
				"origin" : [10,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|stabT1-0-rGlove",
				"origin" : [-13,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|stabT1-1-lGlove",
				"origin" : [10,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|stabT1-1-rGlove",
				"origin" : [-12,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|stabT1-2-lGlove",
				"origin" : [29,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|stabT1-2-rGlove",
				"origin" : [7,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|stabT2-0-lGlove",
				"origin" : [16,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|stabT2-0-rGlove",
				"origin" : [-9,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|stabT2-1-lGlove",
				"origin" : [19,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|stabT2-1-rGlove",
				"origin" : [-7,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|stabT2-2-lGlove",
				"origin" : [30,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|stabT2-2-rGlove",
				"origin" : [-1,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|swingPF-0-lGlove",
				"origin" : [-16,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|swingPF-0-rGlove",
				"origin" : [23,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|swingPF-1-lGlove",
				"origin" : [-15,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|swingPF-1-rGlove",
				"origin" : [21,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|stabTF-2-lGlove",
				"origin" : [-3,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|stabTF-2-rGlove",
				"origin" : [-16,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080007|stabT1-2-lGlove",
				"origin" : [29,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080007|stabT1-2-rGlove",
				"origin" : [7,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"rGlove" :  {
				"png_path": "01080007|shoot1-0-rGlove",
				"origin" : [27,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080007|shoot1-1-rGlove",
				"origin" : [27,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"rGlove" :  {
				"png_path": "01080007|shoot1-2-rGlove",
				"origin" : [27,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|shoot2-0-lGlove",
				"origin" : [18,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|shoot2-1-lGlove",
				"origin" : [18,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|shoot2-2-lGlove",
				"origin" : [18,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080007|shoot2-3-lGlove",
				"origin" : [18,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"4" :  {
			"lGlove" :  {
				"png_path": "01080007|shoot2-4-lGlove",
				"origin" : [16,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|shootF-0-lGlove",
				"origin" : [29,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|shootF-1-lGlove",
				"origin" : [31,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|shootF-1-lGlove",
				"origin" : [31,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|proneStab-0-lGlove",
				"origin" : [40,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080007|proneStab-1-rGlove",
				"origin" : [40,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|proneStab-0-lGlove",
				"origin" : [40,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|alert-1-lGlove",
				"origin" : [12,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|swingO2-1-lGlove",
				"origin" : [11,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingO2-1-rGlove",
				"origin" : [25,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080007|swingO2-0-lGlove",
				"origin" : [12,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|swingO2-0-rGlove",
				"origin" : [22,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|fly-0-lGlove",
				"origin" : [12,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080007|fly-1-lGlove",
				"origin" : [12,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|jump-0-lGlove",
				"origin" : [11,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080007|sit-0-lGlove",
				"origin" : [9,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080007|sit-0-rGlove",
				"origin" : [1,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"rGlove" :  {
				"png_path": "01080007|ladder-0-rGlove",
				"origin" : [12,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backGlove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080007|ladder-1-rGlove",
				"origin" : [12,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backGlove",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"rGlove" :  {
				"png_path": "01080007|rope-0-rGlove",
				"origin" : [9,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backGlove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080007|rope-1-rGlove",
				"origin" : [7,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backGlove",
			},
		},
	},
};

