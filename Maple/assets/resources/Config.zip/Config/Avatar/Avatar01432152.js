var Avatar01432152 = Avatar01432152 || { }; 
Avatar01432152 =   {
	"id":"01432152",
	"info" :  {
		"icon" :  {
			"png_path": "01432152|info-icon",
			"origin" : [0,34],
		},
		"iconRaw" :  {
			"png_path": "01432152|info-iconRaw",
			"origin" : [0,34],
		},
		"islot" : "Wp",
		"vslot" : "Wp",
		"walk" : 2,
		"stand" : 2,
		"attack" : 2,
		"afterImage" : "spear",
		"sfx" : "spear",
		"reqJob" : 1,
		"reqLevel" : 80,
		"reqSTR" : 250,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPAD" : 97,
		"tuc" : 7,
		"price" : 1,
		"attackSpeed" : 6,
		"cash" : 0,
		"equipTradeBlock" : 1,
		"epicItem" : 1,
	},
	"walk2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|walk2-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [6,56],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432152|walk2-1-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [3,61],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432152|walk2-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [6,56],
				},
				"z" : "weaponOverArm",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01432152|walk2-3-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [7,58],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|stand2-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [2,63],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432152|stand2-1-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [5,57],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432152|stand2-2-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [8,54],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|alert-0-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [70,61],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432152|alert-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [69,60],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432152|alert-2-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [70,59],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|swingT2-0-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [14,49],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432152|swingT2-1-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [49,97],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432152|swingT2-2-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [70,0],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|swingP1-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [2,64],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432152|swingP1-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [13,100],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432152|swingP1-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [91,-5],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|swingP2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [22,83],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432152|swingP2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [13,95],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432152|swingP2-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [72,-1],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|swingPF-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [67,19],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432152|swingPF-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [65,10],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432152|swingPF-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [7,65],
				},
				"z" : "weaponBelowArm",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01432152|swingPF-3-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [87,-4],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|stabT1-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [65,4],
				},
				"z" : "weaponOverBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432152|stabT1-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [67,4],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432152|stabT1-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [89,19],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|stabT2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [70,5],
				},
				"z" : "weaponOverBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432152|stabT2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [72,7],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432152|stabT2-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [78,36],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|swingPF-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [67,19],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432152|swingPF-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [65,10],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432152|stabTF-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [53,13],
				},
				"z" : "weaponOverBody",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01432152|stabT1-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [89,19],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|proneStab-0-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [99,19],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432152|proneStab-1-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [115,19],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|proneStab-0-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [99,19],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|fly-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [18,64],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432152|fly-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [18,64],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432152|jump-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [17,64],
				},
				"z" : "weaponOverArm",
			},
		},
	},
};

