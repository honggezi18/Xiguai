var Avatar01382009 = Avatar01382009 || { }; 
Avatar01382009 =   {
	"id":"01382009",
	"info" :  {
		"islot" : "Wp",
		"vslot" : "Wp",
		"walk" : 1,
		"stand" : 1,
		"attack" : 6,
		"afterImage" : "mace",
		"sfx" : "mace",
		"reqJob" : 2,
		"reqLevel" : 35,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPAD" : 35,
		"incMAD" : 48,
		"incMHP" : 100,
		"tuc" : 7,
		"price" : 900,
		"attackSpeed" : 6,
		"cash" : 0,
		"icon" :  {
			"png_path": "01382009|info-icon",
			"origin" : [3,35],
		},
		"iconRaw" :  {
			"png_path": "01382009|info-iconRaw",
			"origin" : [3,35],
		},
	},
	"walk1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|walk1-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [22,11],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|walk1-1-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [21,19],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382009|walk1-2-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [22,12],
				},
				"z" : "weapon",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01382009|walk1-3-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [21,5],
				},
				"z" : "weapon",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|stand1-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [17,5],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|stand1-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [17,5],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382009|stand1-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [17,5],
				},
				"z" : "weapon",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|alert-0-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [24,32],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|alert-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [23,31],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382009|alert-2-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [24,30],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|swingO1-0-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [36,14],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|swingO1-1-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [33,6],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382009|swingO1-2-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [-18,63],
				},
				"z" : "weapon",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|swingO2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [35,45],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|swingO2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [21,54],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382009|swingO2-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [-18,36],
				},
				"z" : "weapon",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|swingO3-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [-20,54],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|swingO3-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [56,15],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382009|swingO3-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [30,14],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|stabO1-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [21,10],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|stabO1-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [60,26],
				},
				"z" : "weapon",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|stabO2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [23,29],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|stabO2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [56,24],
				},
				"z" : "weapon",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|shoot1-0-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [8,34],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|shoot1-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [22,34],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382009|shoot1-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [22,34],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|shootF-0-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [10,38],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|shootF-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [27,40],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382009|shootF-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [27,40],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|proneStab-0-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [61,15],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|proneStab-1-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [76,15],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|proneStab-0-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [61,15],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|alert-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [23,31],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|swingO2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [21,54],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382009|swingO2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [35,45],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|fly-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [14,40],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382009|fly-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [14,40],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382009|jump-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [13,39],
				},
				"z" : "weaponOverArm",
			},
		},
	},
};

