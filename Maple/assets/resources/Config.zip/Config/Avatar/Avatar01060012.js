var Avatar01060012 = Avatar01060012 || { }; 
Avatar01060012 =   {
	"id":"01060012",
	"info" :  {
		"icon" :  {
			"png_path": "01060012|info-icon",
			"origin" : [-4,30],
		},
		"iconRaw" :  {
			"png_path": "01060012|info-iconRaw",
			"origin" : [-5,30],
		},
		"islot" : "Pn",
		"vslot" : "Pn",
		"reqJob" : 2,
		"reqLevel" : 8,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPDD" : 6,
		"incMDD" : 4,
		"tuc" : 7,
		"price" : 200,
		"cash" : 0,
	},
	"walk1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|walk1-0-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|walk1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-1,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|walk1-2-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060012|walk1-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|walk1-0-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|walk1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-1,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|walk1-2-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060012|walk1-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|stand1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|stand1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|stand1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|stand1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|stand1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|stand1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|alert-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|alert-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|alert-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|swingO1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|swingO1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-7,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|swingO1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|swingO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|swingO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|swingO2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|swingO3-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|swingO3-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-8,-1],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|swingO3-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|swingOF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [4,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|swingOF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "backPantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|swingOF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060012|swingOF-3-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [6,0],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|swingT1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|swingT1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|swingT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|swingT2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [2,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|swingT2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|swingT2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|swingT3-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|swingT3-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-4,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|swingT3-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|swingTF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-4],
				},
				"z" : "backPants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|swingTF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|swingTF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060012|swingTF-3-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-1],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|swingP1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|swingP1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|swingP1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|swingP2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|swingP2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|swingP2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|swingPF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|swingPF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|swingPF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [5,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060012|swingPF-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [2,-2],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|stabO1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [8,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|stabO1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-2],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|stabO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|stabO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|stabOF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|stabOF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [5,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|stabOF-2-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [1,-2],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|stabT1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [3,-2],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|stabT1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-2],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|stabT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [2,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|stabT2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-1],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|stabT2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,0],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|stabT2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [5,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|stabTF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|stabTF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [3,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|stabTF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [5,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060012|stabT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [2,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060012|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"4" :  {
			"pants" :  {
				"png_path": "01060012|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|shootF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [5,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|shootF-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [6,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|shootF-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [6,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|alert-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|swingO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060012|swingO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|fly-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|fly-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|jump-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [2,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|sit-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [3,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|ladder-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "backPants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|ladder-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "backPants",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060012|rope-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "backPants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060012|rope-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "backPants",
			},
		},
	},
};

