var Avatar01004685 = Avatar01004685 || { }; 
Avatar01004685 =   {
	"id":"01004685",
	"info" :  {
		"icon" :  {
			"png_path": "00Cap|01004685-info-icon",
			"origin" : [-4,31],
		},
		"iconRaw" :  {
			"png_path": "00Cap|01004685-info-iconRaw",
			"origin" : [-4,31],
		},
		"islot" : "Cp",
		"vslot" : "CpH5",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : "1",
	},
	"default" :  {
		"default" :  {
			"png_path": "00Cap|01004685-default-default",
			"origin" : [-13,19],
			"map" :  {
				"brow" : [0,0],
			},
			"z" : "capOverHair",
		},
	},
	"backDefault" :  {
		"default" :  {
			"png_path": "00Cap|01004685-backDefault-default",
			"origin" : [20,19],
			"map" :  {
				"brow" : [0,0],
			},
			"z" : "backCap",
		},
	},
	"walk1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-backDefault-default",
				"origin" : [20,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-backDefault-default",
				"origin" : [20,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"4" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-default-default",
				"origin" : [-13,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "capOverHair",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-backDefault-default",
				"origin" : [20,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-backDefault-default",
				"origin" : [20,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backCap",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"default" :  {
				"png_path": "00Cap|01004685-backDefault-default",
				"origin" : [20,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00Cap|01004685-backDefault-default",
				"origin" : [20,19],
				"map" :  {
					"brow" : [0,0],
				},
				"z" : "backCap",
			},
		},
	},
};

