var Avatar01080003 = Avatar01080003 || { }; 
Avatar01080003 =   {
	"id":"01080003",
	"info" :  {
		"icon" :  {
			"png_path": "01080003|info-icon",
			"origin" : [-2,28],
		},
		"iconRaw" :  {
			"png_path": "01080003|info-iconRaw",
			"origin" : [-2,28],
		},
		"islot" : "Gv",
		"vslot" : "GlGw",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
		"setItemID" : 144,
	},
	"walk1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|walk1-0-lGlove",
				"origin" : [13,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|walk1-0-rGlove",
				"origin" : [-9,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|walk1-1-lGlove",
				"origin" : [8,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|walk1-1-rGlove",
				"origin" : [-1,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|walk1-2-lGlove",
				"origin" : [13,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|walk1-2-rGlove",
				"origin" : [-9,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080003|walk1-3-lGlove",
				"origin" : [15,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|walk1-3-rGlove",
				"origin" : [-11,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|walk2-0-lGlove",
				"origin" : [10,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|walk2-0-rGlove",
				"origin" : [-2,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|walk2-1-lGlove",
				"origin" : [11,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|walk2-1-rGlove",
				"origin" : [0,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|walk2-0-lGlove",
				"origin" : [10,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|walk2-0-rGlove",
				"origin" : [-2,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080003|walk2-3-lGlove",
				"origin" : [9,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|walk2-3-rGlove",
				"origin" : [-3,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|stand1-0-lGlove",
				"origin" : [8,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|stand1-0-rGlove",
				"origin" : [-8,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|stand1-1-lGlove",
				"origin" : [10,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|stand1-1-rGlove",
				"origin" : [-8,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|stand1-2-lGlove",
				"origin" : [12,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|stand1-2-rGlove",
				"origin" : [-8,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|stand2-0-lGlove",
				"origin" : [10,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|stand2-0-rGlove",
				"origin" : [-2,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|stand2-1-lGlove",
				"origin" : [10,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|stand2-1-rGlove",
				"origin" : [-2,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|stand2-2-lGlove",
				"origin" : [10,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|stand2-2-rGlove",
				"origin" : [-2,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|alert-0-lGlove",
				"origin" : [12,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowWeapon",
			},
			"rGlove" :  {
				"png_path": "01080003|alert-0-rGlove",
				"origin" : [-2,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|alert-1-lGlove",
				"origin" : [12,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowWeapon",
			},
			"rGlove" :  {
				"png_path": "01080003|alert-1-rGlove",
				"origin" : [-2,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|alert-2-lGlove",
				"origin" : [12,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowWeapon",
			},
			"rGlove" :  {
				"png_path": "01080003|alert-2-rGlove",
				"origin" : [-2,-1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"swingO1" :  {
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|swingO1-1-lGlove",
				"origin" : [-8,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingO1-1-rGlove",
				"origin" : [12,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|swingO1-2-lGlove",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingO1-2-rGlove",
				"origin" : [-11,25],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|swingO2-0-lGlove",
				"origin" : [12,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingO2-0-rGlove",
				"origin" : [20,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|swingO2-1-lGlove",
				"origin" : [24,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingO2-1-rGlove",
				"origin" : [10,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|swingO2-2-lGlove",
				"origin" : [19,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingO2-2-rGlove",
				"origin" : [-12,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|swingO3-0-lGlove",
				"origin" : [24,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingO3-0-rGlove",
				"origin" : [-12,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080003|swingO3-1-rGlove",
				"origin" : [23,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|swingOF-0-lGlove",
				"origin" : [15,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
			"rGlove" :  {
				"png_path": "01080003|swingOF-0-rGlove",
				"origin" : [-12,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080003|swingOF-3-lGlove",
				"origin" : [18,-5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
			"rGlove" :  {
				"png_path": "01080003|swingOF-3-rGlove",
				"origin" : [-11,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|swingT1-0-lGlove",
				"origin" : [-1,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|swingT1-0-rGlove",
				"origin" : [-13,28],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|swingT1-1-lGlove",
				"origin" : [23,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|swingT1-1-rGlove",
				"origin" : [17,24],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|swingT1-2-lGlove",
				"origin" : [12,-6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingT1-2-rGlove",
				"origin" : [20,-5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"swingT2" :  {
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|swingT2-1-lGlove",
				"origin" : [21,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingT2-1-rGlove",
				"origin" : [18,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|swingT2-2-lGlove",
				"origin" : [-1,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingT2-2-rGlove",
				"origin" : [-5,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|swingT3-0-lGlove",
				"origin" : [-1,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
			"rGlove" :  {
				"png_path": "01080003|swingT3-0-rGlove",
				"origin" : [-9,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|swingT3-1-lGlove",
				"origin" : [3,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
			"rGlove" :  {
				"png_path": "01080003|swingT3-1-rGlove",
				"origin" : [-6,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"swingTF" :  {
		"2" :  {
			"rGlove" :  {
				"png_path": "01080003|swingTF-2-rGlove",
				"origin" : [16,27],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"lGlove" :  {
				"png_path": "01080003|swingTF-2-lGlove",
				"origin" : [7,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080003|swingTF-3-lGlove",
				"origin" : [16,-3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingTF-3-rGlove",
				"origin" : [22,-3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|swingP1-0-lGlove",
				"origin" : [4,30],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|swingP1-0-rGlove",
				"origin" : [-10,30],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|swingP1-1-lGlove",
				"origin" : [25,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveWristOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingP1-1-rGlove",
				"origin" : [17,25],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"rGlove" :  {
				"png_path": "01080003|swingP1-2-rGlove",
				"origin" : [20,-4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"rGlove" :  {
				"png_path": "01080003|swingP2-0-rGlove",
				"origin" : [22,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080003|swingP2-1-rGlove",
				"origin" : [20,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|swingP2-2-lGlove",
				"origin" : [-1,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingP2-2-rGlove",
				"origin" : [-5,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|swingPF-0-lGlove",
				"origin" : [23,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|swingPF-0-rGlove",
				"origin" : [-16,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|swingPF-1-lGlove",
				"origin" : [21,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|swingPF-1-rGlove",
				"origin" : [-14,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|swingPF-2-lGlove",
				"origin" : [10,30],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|swingPF-2-rGlove",
				"origin" : [-7,30],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080003|swingPF-3-lGlove",
				"origin" : [13,-7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingPF-3-rGlove",
				"origin" : [23,-4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|stabO1-0-lGlove",
				"origin" : [25,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|stabO1-0-rGlove",
				"origin" : [-10,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080003|stabO1-1-rGlove",
				"origin" : [30,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|stabO2-0-lGlove",
				"origin" : [25,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|stabO2-0-rGlove",
				"origin" : [-6,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080003|stabO2-1-rGlove",
				"origin" : [27,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|stabOF-0-lGlove",
				"origin" : [3,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|stabOF-0-rGlove",
				"origin" : [-2,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowMailArm",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|stabOF-1-lGlove",
				"origin" : [33,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|stabOF-1-rGlove",
				"origin" : [-6,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowMailArm",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|stabOF-2-lGlove",
				"origin" : [23,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|stabOF-2-rGlove",
				"origin" : [31,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|stabT1-0-lGlove",
				"origin" : [8,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|stabT1-0-rGlove",
				"origin" : [-14,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|stabT1-1-lGlove",
				"origin" : [9,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|stabT1-1-rGlove",
				"origin" : [-13,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|stabT1-2-lGlove",
				"origin" : [28,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|stabT1-2-rGlove",
				"origin" : [7,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|stabT2-0-lGlove",
				"origin" : [16,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|stabT2-0-rGlove",
				"origin" : [-9,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|stabT2-1-lGlove",
				"origin" : [19,0],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|stabT2-1-rGlove",
				"origin" : [-7,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|stabT2-2-lGlove",
				"origin" : [30,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|stabT2-2-rGlove",
				"origin" : [-3,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|swingPF-0-lGlove",
				"origin" : [23,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|swingPF-0-rGlove",
				"origin" : [-16,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|swingPF-1-lGlove",
				"origin" : [21,4],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|swingPF-1-rGlove",
				"origin" : [-14,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|stabTF-2-lGlove",
				"origin" : [-4,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|stabTF-2-rGlove",
				"origin" : [-17,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080003|stabT1-2-lGlove",
				"origin" : [28,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|stabT1-2-rGlove",
				"origin" : [7,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|shoot1-0-lGlove",
				"origin" : [27,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|shoot1-0-rGlove",
				"origin" : [12,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|shoot1-1-lGlove",
				"origin" : [27,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|shoot1-1-rGlove",
				"origin" : [-2,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|shoot1-1-lGlove",
				"origin" : [27,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|shoot1-1-rGlove",
				"origin" : [-2,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|shoot2-0-lGlove",
				"origin" : [18,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|shoot2-0-rGlove",
				"origin" : [2,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|shoot2-0-lGlove",
				"origin" : [18,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|shoot2-1-rGlove",
				"origin" : [16,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|shoot2-0-lGlove",
				"origin" : [18,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|shoot2-2-rGlove",
				"origin" : [3,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"3" :  {
			"lGlove" :  {
				"png_path": "01080003|shoot2-0-lGlove",
				"origin" : [18,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|shoot2-0-rGlove",
				"origin" : [2,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"4" :  {
			"lGlove" :  {
				"png_path": "01080003|shoot2-4-lGlove",
				"origin" : [16,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|shoot2-4-rGlove",
				"origin" : [0,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|shootF-0-lGlove",
				"origin" : [29,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|shootF-0-rGlove",
				"origin" : [12,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|shootF-1-lGlove",
				"origin" : [31,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|shootF-1-rGlove",
				"origin" : [-4,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowMailArm",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|shootF-1-lGlove",
				"origin" : [31,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|shootF-1-rGlove",
				"origin" : [-4,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowMailArm",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|proneStab-0-lGlove",
				"origin" : [40,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|proneStab-0-rGlove",
				"origin" : [14,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|proneStab-0-lGlove",
				"origin" : [40,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|proneStab-1-rGlove",
				"origin" : [30,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|proneStab-0-lGlove",
				"origin" : [40,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|proneStab-0-rGlove",
				"origin" : [14,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|alert-1-lGlove",
				"origin" : [12,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowWeapon",
			},
			"rGlove" :  {
				"png_path": "01080003|alert-1-rGlove",
				"origin" : [-2,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|swingO2-1-lGlove",
				"origin" : [24,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingO2-1-rGlove",
				"origin" : [10,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
		"2" :  {
			"lGlove" :  {
				"png_path": "01080003|swingO2-0-lGlove",
				"origin" : [12,1],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|swingO2-0-rGlove",
				"origin" : [20,17],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveBelowHead",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|fly-0-lGlove",
				"origin" : [12,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|fly-0-rGlove",
				"origin" : [-1,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
		"1" :  {
			"lGlove" :  {
				"png_path": "01080003|fly-0-lGlove",
				"origin" : [12,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|fly-0-rGlove",
				"origin" : [-1,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|jump-0-lGlove",
				"origin" : [11,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
			"rGlove" :  {
				"png_path": "01080003|jump-0-rGlove",
				"origin" : [-1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverHair",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|sit-0-lGlove",
				"origin" : [9,2],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "gloveOverBody",
			},
			"rGlove" :  {
				"png_path": "01080003|sit-0-rGlove",
				"origin" : [1,3],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "glove",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"lGlove" :  {
				"png_path": "01080003|ladder-0-lGlove",
				"origin" : [-4,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backGlove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080003|ladder-1-rGlove",
				"origin" : [12,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backGlove",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"rGlove" :  {
				"png_path": "01080003|rope-0-rGlove",
				"origin" : [7,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backGlove",
			},
		},
		"1" :  {
			"rGlove" :  {
				"png_path": "01080003|rope-1-rGlove",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backGlove",
			},
		},
	},
};

