var Avatar01060026 = Avatar01060026 || { }; 
Avatar01060026 =   {
	"id":"01060026",
	"info" :  {
		"icon" :  {
			"png_path": "01060026|info-icon",
			"origin" : [-4,25],
		},
		"iconRaw" :  {
			"png_path": "01060026|info-iconRaw",
			"origin" : [-5,25],
		},
		"islot" : "Pn",
		"vslot" : "Pn",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPDD" : 1,
		"tuc" : 7,
		"price" : 1,
		"cash" : 0,
	},
	"walk1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|walk1-0-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|walk1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|walk1-2-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060026|walk1-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|walk1-0-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|walk1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|walk1-2-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060026|walk1-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|stand1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-6,-7],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|stand1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-6],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|stand1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-7],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|stand1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-6,-7],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|stand1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-6],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|stand1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-7],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|alert-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|alert-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-4,-6],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|alert-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-7],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|swingO1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingO1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-8,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|swingO1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-6,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|swingO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|swingO2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|swingO3-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingO3-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-8,-1],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|swingO3-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-7,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|swingOF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingOF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "backPantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|swingOF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-8,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060026|swingOF-3-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|swingT1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-6,-6],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingT1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-6,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|swingT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|swingT2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingT2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|swingT2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|swingT3-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingT3-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-6,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|swingT3-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|swingTF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-4],
				},
				"z" : "backPantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingTF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|swingTF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060026|swingTF-3-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-1],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|swingP1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingP1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-6,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|swingP1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|swingP2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingP2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-6,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|swingP2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|swingPF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingPF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|swingPF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060026|swingPF-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-2],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|stabO1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|stabO1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-2],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|stabO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|stabO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-7,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|stabOF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|stabOF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|stabOF-2-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-3,-2],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|stabT1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|stabT1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-8,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|stabT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|stabT2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-2],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|stabT2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|stabT2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-2,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|swingPF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingPF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|stabTF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060026|stabT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-6,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-6,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-6,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060026|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-6,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"4" :  {
			"pants" :  {
				"png_path": "01060026|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-6,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|shootF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|shootF-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|shootF-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|alert-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-4,-6],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|swingO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060026|swingO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|fly-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "pantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|fly-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|jump-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-6,-4],
				},
				"z" : "pantsBelowShoes",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|sit-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pants",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|ladder-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-6],
				},
				"z" : "backPantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|ladder-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-6],
				},
				"z" : "backPantsBelowShoes",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060026|rope-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-6],
				},
				"z" : "backPantsBelowShoes",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060026|rope-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-5],
				},
				"z" : "backPantsBelowShoes",
			},
		},
	},
};

