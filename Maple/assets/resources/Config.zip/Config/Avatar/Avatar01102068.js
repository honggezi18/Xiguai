var Avatar01102068 = Avatar01102068 || { }; 
Avatar01102068 =   {
	"id":"01102068",
	"info" :  {
		"icon" :  {
			"png_path": "01102068|info-icon",
			"origin" : [0,32],
		},
		"iconRaw" :  {
			"png_path": "01102068|info-iconRaw",
			"origin" : [0,32],
		},
		"islot" : "Sr",
		"vslot" : "Sr",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|walk1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|walk1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|walk1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,9],
				},
				"z" : "capeBelowBody",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102068|walk1-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,10],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|walk1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|walk1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|walk1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,9],
				},
				"z" : "capeBelowBody",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102068|walk1-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,10],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|stand1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|stand1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,9],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|stand1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|stand1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|stand1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,9],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|stand1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|alert-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [9,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|alert-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|alert-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [6,12],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|swingO1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,14],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingO1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,15],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|swingO1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [23,27],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|swingO2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,11],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingO2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,13],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|swingO2-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [24,15],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|swingO3-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [10,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingO3-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,20],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|swingO3-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [6,14],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|swingOF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [20,13],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingOF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [26,14],
				},
				"z" : " backCape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|swingOF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,20],
				},
				"z" : "capeOverHead",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102068|swingOF-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [38,37],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|swingT1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [3,10],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingT1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,13],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|swingT1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-14,22],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|swingT2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-17,13],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingT2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|swingT2-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [27,29],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|swingT3-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [14,10],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingT3-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [7,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|swingT3-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-10,18],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|swingTF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [18,19],
				},
				"z" : " backCape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingTF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [25,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|swingTF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [7,13],
				},
				"z" : "capeBelowBody",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102068|swingTF-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-12,24],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|swingP1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,11],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingP1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,15],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|swingP1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-14,23],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|swingP2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-16,12],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingP2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,11],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|swingP2-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [27,29],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|swingPF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,13],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingPF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|swingPF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [11,13],
				},
				"z" : "capeBelowBody",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102068|swingPF-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-10,18],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|stabO1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [14,10],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|stabO1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,19],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|stabO2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [3,9],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|stabO2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,18],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|stabOF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [5,15],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|stabOF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [13,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|stabOF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-12,24],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|stabT1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|stabT1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,13],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|stabT1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [24,13],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|stabT2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,14],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|stabT2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [10,13],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|stabT2-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [27,13],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|swingPF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,13],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingPF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|stabTF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [18,15],
				},
				"z" : "capeBelowBody",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102068|stabTF-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [24,13],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|shoot1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,13],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|shoot1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,13],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|shoot1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,13],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|shoot2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|shoot2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|shoot2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102068|shoot2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"4" :  {
			"cape" :  {
				"png_path": "01102068|shoot2-4-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [7,12],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|shootF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [22,15],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|shootF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [29,14],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|shootF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [29,14],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|proneStab-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [27,46],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|proneStab-1-cape",
				"origin" : [12,9],
				"map" :  {
					"navel" : [26,46],
				},
				"z" : "cape",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|proneStab-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [27,46],
				},
				"z" : "cape",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|alert-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|swingO2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,13],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102068|swingO2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,11],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|fly-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [23,15],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|fly-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,14],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|jump-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [19,12],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|sit-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,12],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|ladder-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,8],
				},
				"z" : "backCape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|ladder-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [7,8],
				},
				"z" : "backCape",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102068|rope-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [8,8],
				},
				"z" : "backCape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102068|rope-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [7,9],
				},
				"z" : "backCape",
			},
		},
	},
};

