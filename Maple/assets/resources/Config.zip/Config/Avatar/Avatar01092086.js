var Avatar01092086 = Avatar01092086 || { }; 
Avatar01092086 =   {
	"id":"01092086",
	"info" :  {
		"icon" :  {
			"png_path": "01092086|info-icon",
			"origin" : [-1,34],
		},
		"iconRaw" :  {
			"png_path": "01092086|info-iconRaw",
			"origin" : [-1,34],
		},
		"islot" : "Si",
		"vslot" : "Si",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|walk1-0-shield",
				"origin" : [28,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|walk1-1-shield",
				"origin" : [28,16],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092086|walk1-0-shield",
				"origin" : [28,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"3" :  {
			"shield" :  {
				"png_path": "01092086|walk1-3-shield",
				"origin" : [31,21],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|stand1-0-shield",
				"origin" : [27,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|stand1-1-shield",
				"origin" : [29,20],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092086|stand1-2-shield",
				"origin" : [31,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|alert-0-shield",
				"origin" : [33,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|alert-1-shield",
				"origin" : [32,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092086|alert-2-shield",
				"origin" : [31,18],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|swingO1-0-shield",
				"origin" : [17,30],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|swingO1-1-shield",
				"origin" : [9,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092086|swingO1-2-shield",
				"origin" : [26,29],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|swingO2-0-shield",
				"origin" : [29,21],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|swingO2-1-shield",
				"origin" : [27,32],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092086|swingO2-2-shield",
				"origin" : [36,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|swingO3-0-shield",
				"origin" : [44,29],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|swingO3-1-shield",
				"origin" : [21,32],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092086|swingO3-2-shield",
				"origin" : [13,30],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|swingOF-0-shield",
				"origin" : [28,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|swingOF-1-shield",
				"origin" : [-4,23],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092086|swingOF-2-shield",
				"origin" : [16,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"3" :  {
			"shield" :  {
				"png_path": "01092086|swingOF-3-shield",
				"origin" : [40,29],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|stabO1-0-shield",
				"origin" : [40,25],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|stabO1-1-shield",
				"origin" : [20,29],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|stabO2-0-shield",
				"origin" : [44,31],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|stabO2-1-shield",
				"origin" : [19,27],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|stabOF-0-shield",
				"origin" : [24,22],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|stabOF-1-shield",
				"origin" : [51,32],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092086|stabOF-2-shield",
				"origin" : [39,29],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|proneStab-0-shield",
				"origin" : [59,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|proneStab-0-shield",
				"origin" : [59,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|proneStab-0-shield",
				"origin" : [59,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|alert-1-shield",
				"origin" : [32,19],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldOverHair",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|swingO2-1-shield",
				"origin" : [27,32],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"2" :  {
			"shield" :  {
				"png_path": "01092086|swingO2-0-shield",
				"origin" : [29,21],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|fly-0-shield",
				"origin" : [28,27],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
		"1" :  {
			"shield" :  {
				"png_path": "01092086|fly-0-shield",
				"origin" : [28,27],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"shield" :  {
				"png_path": "01092086|jump-0-shield",
				"origin" : [27,26],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "shieldBelowBody",
			},
		},
	},
};

