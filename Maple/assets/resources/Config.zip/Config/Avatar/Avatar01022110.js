var Avatar01022110 = Avatar01022110 || { }; 
Avatar01022110 =   {
	"id":"01022110",
	"info" :  {
		"icon" :  {
			"png_path": "00EyeAccessory|01022110-info-icon",
			"origin" : [0,27],
		},
		"iconRaw" :  {
			"png_path": "00EyeAccessory|01022110-info-iconRaw",
			"origin" : [0,27],
		},
		"islot" : "Ay",
		"vslot" : "Ay",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"default" :  {
		"default" :  {
			"png_path": "00EyeAccessory|01022110-default-default",
			"origin" : [19,7],
			"map" :  {
				"brow" : [-3,-11],
			},
			"z" : "accessoryEye",
		},
	},
	"walk1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"swingTF" :  {
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"4" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022110-default-default",
				"origin" : [19,7],
				"map" :  {
					"brow" : [-3,-11],
				},
				"z" : "accessoryEye",
			},
		},
	},
};

