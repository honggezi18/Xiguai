var Avatar01432153 = Avatar01432153 || { }; 
Avatar01432153 =   {
	"id":"01432153",
	"info" :  {
		"icon" :  {
			"png_path": "01432153|info-icon",
			"origin" : [0,34],
		},
		"iconRaw" :  {
			"png_path": "01432153|info-iconRaw",
			"origin" : [0,34],
		},
		"islot" : "Wp",
		"vslot" : "Wp",
		"walk" : 2,
		"stand" : 2,
		"attack" : 2,
		"afterImage" : "spear",
		"sfx" : "spear",
		"reqJob" : 1,
		"reqLevel" : 90,
		"reqSTR" : 280,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPAD" : 102,
		"tuc" : 7,
		"price" : 1,
		"attackSpeed" : 6,
		"cash" : 0,
		"equipTradeBlock" : 1,
		"epicItem" : 1,
	},
	"walk2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|walk2-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [1,49],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432153|walk2-1-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [0,52],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432153|walk2-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [1,49],
				},
				"z" : "weaponOverArm",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01432153|walk2-3-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [1,51],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|stand2-0-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [1,52],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432153|stand2-1-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [4,48],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432153|stand2-2-weapon",
				"origin" : [25,7],
				"map" :  {
					"hand" : [5,47],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|alert-0-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [48,50],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432153|alert-1-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [47,49],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432153|alert-2-weapon",
				"origin" : [23,10],
				"map" :  {
					"hand" : [48,48],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|swingT2-0-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [6,72],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432153|swingT2-1-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [30,89],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432153|swingT2-2-weapon",
				"origin" : [11,5],
				"map" :  {
					"navel" : [63,-2],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|swingP1-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [12,43],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432153|swingP1-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [14,92],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432153|swingP1-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [82,-6],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|swingP2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [19,73],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432153|swingP2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [12,88],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432153|swingP2-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [62,-3],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|swingPF-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [67,4],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432153|swingPF-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [66,6],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432153|swingPF-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [19,42],
				},
				"z" : "weaponBelowArm",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01432153|swingPF-3-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [83,-7],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|stabT1-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [62,3],
				},
				"z" : "weaponOverBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432153|stabT1-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [66,1],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432153|stabT1-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [87,4],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|stabT2-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [67,2],
				},
				"z" : "weaponOverBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432153|stabT2-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [71,3],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432153|stabT2-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [78,16],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|swingPF-0-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [67,4],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432153|swingPF-1-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [66,6],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432153|stabTF-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [31,20],
				},
				"z" : "weaponOverBody",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01432153|stabT1-2-weapon",
				"origin" : [12,5],
				"map" :  {
					"navel" : [87,4],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|proneStab-0-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [98,3],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432153|proneStab-1-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [113,3],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|proneStab-0-weapon",
				"origin" : [5,3],
				"map" :  {
					"navel" : [98,3],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|fly-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [13,57],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432153|fly-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [13,57],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432153|jump-0-weapon",
				"origin" : [13,5],
				"map" :  {
					"navel" : [11,57],
				},
				"z" : "weaponOverArm",
			},
		},
	},
};

