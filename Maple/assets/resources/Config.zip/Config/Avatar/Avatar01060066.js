var Avatar01060066 = Avatar01060066 || { }; 
Avatar01060066 =   {
	"id":"01060066",
	"info" :  {
		"icon" :  {
			"png_path": "01060066|info-icon",
			"origin" : [-4,29],
		},
		"iconRaw" :  {
			"png_path": "01060066|info-iconRaw",
			"origin" : [-4,29],
		},
		"islot" : "Pn",
		"vslot" : "Pn",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|walk1-0-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|walk1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-1,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|walk1-2-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060066|walk1-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|walk1-0-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|walk1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-1,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|walk1-2-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060066|walk1-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|stand1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|stand1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|stand1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-2,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|stand1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|stand1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|stand1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-2,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|alert-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|alert-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|alert-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-7],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|swingO1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingO1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-8,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|swingO1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|swingO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|swingO2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|swingO3-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingO3-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-8,-1],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|swingO3-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|swingOF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [5,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingOF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "backPantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|swingOF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-6,0],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060066|swingOF-3-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [5,0],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|swingT1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingT1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|swingT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|swingT2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [3,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingT2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|swingT2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|swingT3-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingT3-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-4,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|swingT3-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|swingTF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-4],
				},
				"z" : "backPantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingTF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|swingTF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060066|swingTF-3-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-1],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|swingP1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingP1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|swingP1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|swingP2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingP2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|swingP2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|swingPF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingPF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|swingPF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [4,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060066|swingPF-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-2],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|stabO1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [9,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|stabO1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-2],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|stabO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|stabO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-2,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|stabOF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|stabOF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [5,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|stabOF-2-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [1,-2],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|stabT1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [3,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|stabT1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|stabT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [2,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|stabT2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-2],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|stabT2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,1],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|stabT2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [5,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|swingPF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingPF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|stabTF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [4,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060066|stabT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [2,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060066|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"4" :  {
			"pants" :  {
				"png_path": "01060066|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|shootF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [6,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|shootF-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [8,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|shootF-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [8,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-6,6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-6,6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-6,6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|alert-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|swingO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060066|swingO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|fly-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|fly-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|jump-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [2,-4],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|sit-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [3,-5],
				},
				"z" : "pantsOverShoesBelowMailChest",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|ladder-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-6],
				},
				"z" : "backPantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|ladder-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "backPantsOverShoesBelowMailChest",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060066|rope-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "backPantsOverShoesBelowMailChest",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060066|rope-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "backPantsOverShoesBelowMailChest",
			},
		},
	},
};

