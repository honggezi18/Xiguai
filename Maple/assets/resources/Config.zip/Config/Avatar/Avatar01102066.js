var Avatar01102066 = Avatar01102066 || { }; 
Avatar01102066 =   {
	"id":"01102066",
	"info" :  {
		"icon" :  {
			"png_path": "01102066|info-icon",
			"origin" : [-1,32],
		},
		"iconRaw" :  {
			"png_path": "01102066|info-iconRaw",
			"origin" : [-1,32],
		},
		"islot" : "Sr",
		"vslot" : "Sr",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|walk1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,5],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|walk1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,4],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|walk1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,5],
				},
				"z" : "capeBelowBody",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102066|walk1-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,6],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|walk1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,5],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|walk1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,4],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|walk1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,5],
				},
				"z" : "capeBelowBody",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102066|walk1-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,6],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|stand1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,4],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|stand1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,5],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|stand1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,3],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|stand1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,4],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|stand1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,5],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|stand1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,3],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|alert-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [7,3],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|alert-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [6,3],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|alert-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,3],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|swingO1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,10],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingO1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,10],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|swingO1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,9],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|swingO2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,7],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingO2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|swingO2-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,7],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|swingO3-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,4],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingO3-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,8],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|swingO3-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,10],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|swingOF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [16,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingOF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [19,9],
				},
				"z" : " backCape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|swingOF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,9],
				},
				"z" : "capeOverHead",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102066|swingOF-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [6,9],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|swingT1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,6],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingT1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [3,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|swingT1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,9],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|swingT2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,5],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingT2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,7],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|swingT2-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,10],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|swingT3-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,9],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingT3-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [3,7],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|swingT3-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,7],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|swingTF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [11,9],
				},
				"z" : " backCape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingTF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,7],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|swingTF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,7],
				},
				"z" : "capeBelowBody",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102066|swingTF-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [7,10],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|swingP1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [6,7],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingP1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [3,9],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|swingP1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,10],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|swingP2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,5],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingP2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,7],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|swingP2-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,11],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|swingPF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,9],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingPF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,7],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|swingPF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,9],
				},
				"z" : "capeBelowBody",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102066|swingPF-3-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,7],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|stabO1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [16,6],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|stabO1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,8],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|stabO2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,4],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|stabO2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|stabOF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,11],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|stabOF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|stabOF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [7,10],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|stabT1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [15,6],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|stabT1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|stabT1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,10],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|stabT2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [13,7],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|stabT2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [6,12],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|stabT2-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,10],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|swingPF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,9],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingPF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,7],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|stabTF-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,9],
				},
				"z" : "capeBelowBody",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102066|stabT1-2-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,10],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|shoot1-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|shoot1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|shoot1-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [2,8],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|shoot2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|shoot2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|shoot2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01102066|shoot2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"4" :  {
			"cape" :  {
				"png_path": "01102066|shoot2-4-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [1,8],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|shootF-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [15,7],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|shootF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [23,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|shootF-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [23,8],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|proneStab-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [26,24],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|proneStab-1-cape",
				"origin" : [12,9],
				"map" :  {
					"navel" : [25,24],
				},
				"z" : "cape",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|proneStab-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [26,24],
				},
				"z" : "cape",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|alert-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [6,3],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|swingO2-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01102066|swingO2-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,7],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|fly-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,8],
				},
				"z" : "capeBelowBody",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|fly-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-2,8],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|jump-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,8],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|sit-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,8],
				},
				"z" : "capeBelowBody",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|ladder-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [10,7],
				},
				"z" : "backCape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|ladder-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [3,7],
				},
				"z" : "backCape",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01102066|rope-0-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [4,7],
				},
				"z" : "backCape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01102066|rope-1-cape",
				"origin" : [11,9],
				"map" :  {
					"navel" : [3,8],
				},
				"z" : "backCape",
			},
		},
	},
};

