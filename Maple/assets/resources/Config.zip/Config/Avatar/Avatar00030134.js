var Avatar00030134 = Avatar00030134 || { }; 
Avatar00030134 =   {
	"id":"00030134",
	"info" :  {
		"islot" : "Hr",
		"vslot" : "H1H2H3H4H5H6HfHsHb",
		"cash" : 1,
	},
	"default" :  {
		"hairOverHead" :  {
			"png_path": "00Hair|00030134-default-hairOverHead",
			"origin" : [24,15],
			"map" :  {
				"brow" : [3,8],
			},
			"z" : "hairOverHead",
		},
		"hair" :  {
			"png_path": "00Hair|00030134-default-hair",
			"origin" : [17,11],
			"map" :  {
				"brow" : [-3,1],
			},
			"z" : "hair",
		},
	},
	"backDefault" :  {
		"backHair" :  {
			"png_path": "00Hair|00030134-backDefault-backHair",
			"origin" : [13,7],
			"map" :  {
				"brow" : [8,16],
			},
			"z" : "backHair",
		},
		"backHairBelowCap" :  {
			"png_path": "00Hair|00030134-backDefault-backHairBelowCap",
			"origin" : [17,16],
			"map" :  {
				"brow" : [-4,-4],
			},
			"z" : "backHairBelowCap",
		},
	},
	"walk1" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"3" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"3" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"backHair" :  {
				"png_path": "00Hair|00030134-backDefault-backHair",
				"origin" : [13,7],
				"map" :  {
					"brow" : [8,16],
				},
				"z" : "backHair",
			},
			"backHairBelowCap" :  {
				"png_path": "00Hair|00030134-backDefault-backHairBelowCap",
				"origin" : [17,16],
				"map" :  {
					"brow" : [-4,-4],
				},
				"z" : "backHairBelowCap",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"3" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"backHair" :  {
				"png_path": "00Hair|00030134-backDefault-backHair",
				"origin" : [13,7],
				"map" :  {
					"brow" : [8,16],
				},
				"z" : "backHair",
			},
			"backHairBelowCap" :  {
				"png_path": "00Hair|00030134-backDefault-backHairBelowCap",
				"origin" : [17,16],
				"map" :  {
					"brow" : [-4,-4],
				},
				"z" : "backHairBelowCap",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"3" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"3" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"3" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"3" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"4" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"2" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
		"1" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"hairOverHead" :  {
				"png_path": "00Hair|00030134-default-hairOverHead",
				"origin" : [24,15],
				"map" :  {
					"brow" : [3,8],
				},
				"z" : "hairOverHead",
			},
			"hair" :  {
				"png_path": "00Hair|00030134-default-hair",
				"origin" : [17,11],
				"map" :  {
					"brow" : [-3,1],
				},
				"z" : "hair",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"backHair" :  {
				"png_path": "00Hair|00030134-backDefault-backHair",
				"origin" : [13,7],
				"map" :  {
					"brow" : [8,16],
				},
				"z" : "backHair",
			},
			"backHairBelowCap" :  {
				"png_path": "00Hair|00030134-backDefault-backHairBelowCap",
				"origin" : [17,16],
				"map" :  {
					"brow" : [-4,-4],
				},
				"z" : "backHairBelowCap",
			},
		},
		"1" :  {
			"backHair" :  {
				"png_path": "00Hair|00030134-backDefault-backHair",
				"origin" : [13,7],
				"map" :  {
					"brow" : [8,16],
				},
				"z" : "backHair",
			},
			"backHairBelowCap" :  {
				"png_path": "00Hair|00030134-backDefault-backHairBelowCap",
				"origin" : [17,16],
				"map" :  {
					"brow" : [-4,-4],
				},
				"z" : "backHairBelowCap",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"backHair" :  {
				"png_path": "00Hair|00030134-backDefault-backHair",
				"origin" : [13,7],
				"map" :  {
					"brow" : [8,16],
				},
				"z" : "backHair",
			},
			"backHairBelowCap" :  {
				"png_path": "00Hair|00030134-backDefault-backHairBelowCap",
				"origin" : [17,16],
				"map" :  {
					"brow" : [-4,-4],
				},
				"z" : "backHairBelowCap",
			},
		},
		"1" :  {
			"backHair" :  {
				"png_path": "00Hair|00030134-backDefault-backHair",
				"origin" : [13,7],
				"map" :  {
					"brow" : [8,16],
				},
				"z" : "backHair",
			},
			"backHairBelowCap" :  {
				"png_path": "00Hair|00030134-backDefault-backHairBelowCap",
				"origin" : [17,16],
				"map" :  {
					"brow" : [-4,-4],
				},
				"z" : "backHairBelowCap",
			},
		},
	},
};

