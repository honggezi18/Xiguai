var Avatar01060108 = Avatar01060108 || { }; 
Avatar01060108 =   {
	"id":"01060108",
	"info" :  {
		"icon" :  {
			"png_path": "01060108|info-icon",
			"origin" : [-4,29],
		},
		"iconRaw" :  {
			"png_path": "01060108|info-iconRaw",
			"origin" : [-4,29],
		},
		"islot" : "Pn",
		"vslot" : "Pn",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|walk1-0-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|walk1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-2,-7],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|walk1-2-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060108|walk1-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pants",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|walk1-0-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|walk1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-2,-7],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|walk1-2-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060108|walk1-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pants",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|stand1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|stand1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-6],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|stand1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-7],
				},
				"z" : "pants",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|stand1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|stand1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-6],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|stand1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-7],
				},
				"z" : "pants",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|alert-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|alert-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|alert-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-7],
				},
				"z" : "pants",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|swingO1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingO1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-8,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|swingO1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pants",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|swingO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-5],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|swingO2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-1,-3],
				},
				"z" : "pants",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|swingO3-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-3],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingO3-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-7,-2],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|swingO3-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-4],
				},
				"z" : "pants",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|swingOF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-3],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingOF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "backPants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|swingOF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-6,0],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060108|swingOF-3-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [5,0],
				},
				"z" : "pants",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|swingT1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-6],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingT1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|swingT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pants",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|swingT2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-3],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingT2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|swingT2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-3],
				},
				"z" : "pants",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|swingT3-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-3],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingT3-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-2,-3],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|swingT3-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pants",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|swingTF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-4],
				},
				"z" : "backPants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingTF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|swingTF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060108|swingTF-3-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-1],
				},
				"z" : "pants",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|swingP1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-5],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingP1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-3],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|swingP1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-3],
				},
				"z" : "pants",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|swingP2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingP2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|swingP2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-3],
				},
				"z" : "pants",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|swingPF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingPF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|swingPF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [5,-4],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060108|swingPF-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-2],
				},
				"z" : "pants",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|stabO1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [7,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|stabO1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-2],
				},
				"z" : "pants",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|stabO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [2,-5],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|stabO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-2,-3],
				},
				"z" : "pants",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|stabOF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|stabOF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [5,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|stabOF-2-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [1,-2],
				},
				"z" : "pants",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|stabT1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [5,-2],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|stabT1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|stabT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [4,-3],
				},
				"z" : "pants",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|stabT2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-1],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|stabT2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,0],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|stabT2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [5,-3],
				},
				"z" : "pants",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|swingPF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingPF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|stabTF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [5,-4],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060108|stabT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [4,-3],
				},
				"z" : "pants",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pants",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060108|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pants",
			},
		},
		"4" :  {
			"pants" :  {
				"png_path": "01060108|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pants",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|shootF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [5,-5],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|shootF-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [5,-5],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|shootF-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [5,-5],
				},
				"z" : "pants",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-8,6],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-8,6],
				},
				"z" : "pants",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-8,6],
				},
				"z" : "pants",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|alert-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|swingO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060108|swingO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-5],
				},
				"z" : "pants",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|fly-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|fly-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-4],
				},
				"z" : "pants",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|jump-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pants",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|sit-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [2,-5],
				},
				"z" : "pants",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|ladder-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-6],
				},
				"z" : "backPants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|ladder-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "backPants",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060108|rope-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "backPants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060108|rope-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "backPants",
			},
		},
	},
};

