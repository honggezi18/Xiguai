var Avatar01022042 = Avatar01022042 || { }; 
Avatar01022042 =   {
	"id":"01022042",
	"info" :  {
		"icon" :  {
			"png_path": "00EyeAccessory|01022042-info-icon",
			"origin" : [-1,31],
		},
		"iconRaw" :  {
			"png_path": "00EyeAccessory|01022042-info-iconRaw",
			"origin" : [-1,31],
		},
		"islot" : "Ay",
		"vslot" : "Ay",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"default" :  {
		"default" :  {
			"png_path": "00EyeAccessory|01022042-default-default",
			"origin" : [15,25],
			"map" :  {
				"brow" : [-14,-14],
			},
			"z" : "accessoryEyeOverCap",
		},
	},
	"walk1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"swingTF" :  {
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"3" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"4" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"2" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
		"1" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"default" :  {
				"png_path": "00EyeAccessory|01022042-default-default",
				"origin" : [15,25],
				"map" :  {
					"brow" : [-14,-14],
				},
				"z" : "accessoryEyeOverCap",
			},
		},
	},
};

