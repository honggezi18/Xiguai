var Avatar01432180 = Avatar01432180 || { }; 
Avatar01432180 =   {
	"id":"01432180",
	"info" :  {
		"icon" :  {
			"png_path": "01432180|info-icon",
			"origin" : [3,38],
		},
		"iconRaw" :  {
			"png_path": "01432180|info-iconRaw",
			"origin" : [3,38],
		},
		"islot" : "Wp",
		"vslot" : "Wp",
		"walk" : 2,
		"stand" : 2,
		"attack" : 2,
		"afterImage" : "spear",
		"sfx" : "spear",
		"reqJob" : 1,
		"reqLevel" : 100,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPAD" : "123",
		"tuc" : 8,
		"price" : 1,
		"attackSpeed" : 6,
		"cash" : 0,
		"exItem" : 1,
		"tradeBlock" : 1,
	},
	"walk2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|walk2-0-weapon",
				"origin" : [22,63],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432180|walk2-1-weapon",
				"origin" : [23,68],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432180|walk2-0-weapon",
				"origin" : [22,63],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01432180|walk2-3-weapon",
				"origin" : [23,58],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|stand2-0-weapon",
				"origin" : [25,62],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432180|stand2-1-weapon",
				"origin" : [25,62],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432180|stand2-2-weapon",
				"origin" : [25,62],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|alert-0-weapon",
				"origin" : [86,48],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432180|alert-1-weapon",
				"origin" : [85,47],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432180|alert-2-weapon",
				"origin" : [86,46],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|swingT2-0-weapon",
				"origin" : [19,49],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432180|swingT2-1-weapon",
				"origin" : [29,92],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432180|swingT2-2-weapon",
				"origin" : [85,11],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|swingP1-0-weapon",
				"origin" : [14,31],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432180|swingP1-1-weapon",
				"origin" : [11,85],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432180|swingP1-2-weapon",
				"origin" : [82,16],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|swingP2-0-weapon",
				"origin" : [15,63],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432180|swingP2-1-weapon",
				"origin" : [7,99],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432180|swingP2-2-weapon",
				"origin" : [91,11],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|swingPF-0-weapon",
				"origin" : [107,18],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432180|swingPF-1-weapon",
				"origin" : [100,8],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432180|swingPF-2-weapon",
				"origin" : [35,27],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01432180|swingPF-3-weapon",
				"origin" : [73,13],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|stabT1-0-weapon",
				"origin" : [102,8],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432180|stabT1-1-weapon",
				"origin" : [94,9],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432180|stabT1-2-weapon",
				"origin" : [100,18],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|stabT2-0-weapon",
				"origin" : [99,9],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432180|stabT2-1-weapon",
				"origin" : [96,7],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432180|stabT2-2-weapon",
				"origin" : [98,32],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|swingPF-0-weapon",
				"origin" : [107,18],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432180|swingPF-1-weapon",
				"origin" : [100,8],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01432180|stabTF-2-weapon",
				"origin" : [71,-7],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01432180|stabT1-2-weapon",
				"origin" : [100,18],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|proneStab-0-weapon",
				"origin" : [96,18],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432180|proneStab-1-weapon",
				"origin" : [97,19],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|proneStab-0-weapon",
				"origin" : [96,18],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|fly-0-weapon",
				"origin" : [25,56],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01432180|fly-0-weapon",
				"origin" : [25,56],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01432180|jump-0-weapon",
				"origin" : [28,55],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
};

