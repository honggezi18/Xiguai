var Avatar00012000 = Avatar00012000 || { }; 
Avatar00012000 =   {
	"id":"00012000",
	"info" :  {
		"islot" : "Hd",
		"vslot" : "Hd",
		"cash" : 0,
	},
	"front" :  {
		"head" :  {
			"png_path": "00Head|00012000-front-head",
			"origin" : [19,17],
			"map" :  {
				"neck" : [0,15],
				"earOverHead" : [15,10],
				"earBelowHead" : [-17,9],
				"brow" : [-4,-5],
			},
			"z" : "head",
			"group" : "skin",
		},
		"ear" :  {
			"png_path": "00Head|00012000-front-ear",
			"origin" : [23,-1],
			"map" :  {
				"neck" : [0,15],
				"earOverHead" : [15,10],
				"earBelowHead" : [-17,9],
				"brow" : [-4,-5],
			},
			"z" : "accessoryOverHair",
			"group" : "skin",
		},
	},
	"back" :  {
		"head" :  {
			"png_path": "00Head|00012000-back-head",
			"origin" : [20,17],
			"map" :  {
				"neck" : [0,15],
				"brow" : [-4,-5],
			},
			"z" : "backHead",
			"group" : "skin",
		},
		"ear" :  {
			"png_path": "00Head|00012000-back-ear",
			"origin" : [24,-1],
			"map" :  {
				"neck" : [0,15],
				"brow" : [-4,-5],
			},
			"z" : "backAccessoryOverHead",
			"group" : "skin",
		},
	},
	"walk1" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"3" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"3" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-back-head",
				"origin" : [20,17],
				"map" :  {
					"neck" : [0,15],
					"brow" : [-4,-5],
				},
				"z" : "backHead",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-back-ear",
				"origin" : [24,-1],
				"map" :  {
					"neck" : [0,15],
					"brow" : [-4,-5],
				},
				"z" : "backAccessoryOverHead",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"3" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-back-head",
				"origin" : [20,17],
				"map" :  {
					"neck" : [0,15],
					"brow" : [-4,-5],
				},
				"z" : "backHead",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-back-ear",
				"origin" : [24,-1],
				"map" :  {
					"neck" : [0,15],
					"brow" : [-4,-5],
				},
				"z" : "backAccessoryOverHead",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"3" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"3" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"3" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"3" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"4" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"2" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-front-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-front-ear",
				"origin" : [23,-1],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "accessoryOverHair",
				"group" : "skin",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-back-head",
				"origin" : [20,17],
				"map" :  {
					"neck" : [0,15],
					"brow" : [-4,-5],
				},
				"z" : "backHead",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-back-ear",
				"origin" : [24,-1],
				"map" :  {
					"neck" : [0,15],
					"brow" : [-4,-5],
				},
				"z" : "backAccessoryOverHead",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-back-head",
				"origin" : [20,17],
				"map" :  {
					"neck" : [0,15],
					"brow" : [-4,-5],
				},
				"z" : "backHead",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-back-ear",
				"origin" : [24,-1],
				"map" :  {
					"neck" : [0,15],
					"brow" : [-4,-5],
				},
				"z" : "backAccessoryOverHead",
				"group" : "skin",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-back-head",
				"origin" : [20,17],
				"map" :  {
					"neck" : [0,15],
					"brow" : [-4,-5],
				},
				"z" : "backHead",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-back-ear",
				"origin" : [24,-1],
				"map" :  {
					"neck" : [0,15],
					"brow" : [-4,-5],
				},
				"z" : "backAccessoryOverHead",
				"group" : "skin",
			},
		},
		"1" :  {
			"head" :  {
				"png_path": "00Head|00012000-back-head",
				"origin" : [20,17],
				"map" :  {
					"neck" : [0,15],
					"brow" : [-4,-5],
				},
				"z" : "backHead",
				"group" : "skin",
			},
			"ear" :  {
				"png_path": "00Head|00012000-back-ear",
				"origin" : [24,-1],
				"map" :  {
					"neck" : [0,15],
					"brow" : [-4,-5],
				},
				"z" : "backAccessoryOverHead",
				"group" : "skin",
			},
		},
	},
	"blink" :  {
		"0" :  {
			"head" :  {
				"png_path": "00Head|00012000-blink-0-head",
				"origin" : [19,17],
				"map" :  {
					"neck" : [0,15],
					"earOverHead" : [15,10],
					"earBelowHead" : [-17,9],
					"brow" : [-4,-5],
				},
				"z" : "head",
				"group" : "skin",
			},
		},
	},
};

