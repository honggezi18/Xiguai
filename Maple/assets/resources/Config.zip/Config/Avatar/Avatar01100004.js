var Avatar01100004 = Avatar01100004 || { }; 
Avatar01100004 =   {
	"id":"01100004",
	"info" :  {
		"icon" :  {
			"png_path": "01100004|info-icon",
			"origin" : [1,31],
		},
		"iconRaw" :  {
			"png_path": "01100004|info-iconRaw",
			"origin" : [1,31],
		},
		"islot" : "Sr",
		"vslot" : "Sr",
		"tuc" : 0,
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"price" : 0,
		"cash" : 1,
		"setItemID" : 494,
	},
	"walk1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|walk1-0-cape",
				"origin" : [34,32],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|walk1-0-capeOverHead",
				"origin" : [-4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|walk1-0-capeArm",
				"origin" : [14,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|walk1-1-cape",
				"origin" : [34,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|walk1-1-capeOverHead",
				"origin" : [-3,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|walk1-1-capeArm",
				"origin" : [13,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|walk1-2-cape",
				"origin" : [34,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|walk1-2-capeOverHead",
				"origin" : [-4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|walk1-2-capeArm",
				"origin" : [14,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01100004|walk1-3-cape",
				"origin" : [34,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|walk1-3-capeOverHead",
				"origin" : [-5,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|walk1-3-capeArm",
				"origin" : [13,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|walk1-0-cape",
				"origin" : [34,32],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|walk2-0-capeOverHead",
				"origin" : [-6,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|walk2-0-capeArm",
				"origin" : [13,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|walk1-1-cape",
				"origin" : [34,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|walk2-1-capeOverHead",
				"origin" : [-4,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|walk2-1-capeArm",
				"origin" : [12,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|walk1-2-cape",
				"origin" : [34,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|walk2-2-capeOverHead",
				"origin" : [-6,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|walk2-2-capeArm",
				"origin" : [13,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01100004|walk1-3-cape",
				"origin" : [34,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|walk2-3-capeOverHead",
				"origin" : [-5,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|walk2-3-capeArm",
				"origin" : [12,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|stand1-0-cape",
				"origin" : [32,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stand1-0-capeOverHead",
				"origin" : [-4,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stand1-0-capeArm",
				"origin" : [12,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|stand1-1-cape",
				"origin" : [33,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stand1-1-capeOverHead",
				"origin" : [-4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stand1-1-capeArm",
				"origin" : [14,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|stand1-2-cape",
				"origin" : [34,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stand1-2-capeOverHead",
				"origin" : [-4,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stand1-2-capeArm",
				"origin" : [14,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|stand1-0-cape",
				"origin" : [32,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stand2-0-capeOverHead",
				"origin" : [-4,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
			"capeArm" :  {
				"png_path": "01100004|stand2-0-capeArm",
				"origin" : [12,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|stand1-1-cape",
				"origin" : [33,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stand2-1-capeOverHead",
				"origin" : [-4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
			"capeArm" :  {
				"png_path": "01100004|stand2-1-capeArm",
				"origin" : [14,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|stand1-2-cape",
				"origin" : [34,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stand2-2-capeOverHead",
				"origin" : [-4,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
			"capeArm" :  {
				"png_path": "01100004|stand2-2-capeArm",
				"origin" : [14,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|alert-0-cape",
				"origin" : [37,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|alert-0-capeOverHead",
				"origin" : [-1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|alert-0-capeArm",
				"origin" : [14,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|alert-1-cape",
				"origin" : [37,31],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|alert-1-capeOverHead",
				"origin" : [-1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|alert-1-capeArm",
				"origin" : [14,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|alert-2-cape",
				"origin" : [37,31],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|alert-2-capeOverHead",
				"origin" : [-1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|alert-2-capeArm",
				"origin" : [14,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|swingO1-0-cape",
				"origin" : [38,38],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingO1-0-capeOverHead",
				"origin" : [8,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingO1-1-cape",
				"origin" : [40,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingO1-1-capeOverHead",
				"origin" : [1,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|swingO1-2-cape",
				"origin" : [27,37],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingO1-2-capeOverHead",
				"origin" : [1,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingO1-2-capeArm",
				"origin" : [16,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|swingO2-0-cape",
				"origin" : [44,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingO2-0-capeOverHead",
				"origin" : [1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingO2-0-capeArm",
				"origin" : [7,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingO2-1-cape",
				"origin" : [41,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingO2-1-capeOverHead",
				"origin" : [3,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingO2-1-capeArm",
				"origin" : [10,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|swingO2-2-cape",
				"origin" : [39,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingO2-2-capeOverHead",
				"origin" : [0,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingO2-2-capeArm",
				"origin" : [16,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|swingO3-0-cape",
				"origin" : [37,38],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingO3-0-capeOverHead",
				"origin" : [0,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingO3-0-capeArm",
				"origin" : [18,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingO3-1-cape",
				"origin" : [40,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingO3-1-capeOverHead",
				"origin" : [2,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingO3-1-capeArm",
				"origin" : [11,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|swingO3-2-cape",
				"origin" : [34,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingO3-2-capeOverHead",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|swingOF-0-cape",
				"origin" : [41,37],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingOF-0-capeOverHead",
				"origin" : [-1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingOF-0-capeArm",
				"origin" : [15,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingOF-1-cape",
				"origin" : [40,28],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingOF-1-capeOverHead",
				"origin" : [1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|swingOF-2-cape",
				"origin" : [44,31],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingOF-2-capeOverHead",
				"origin" : [3,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01100004|swingOF-3-cape",
				"origin" : [36,43],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingOF-3-capeOverHead",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingOF-3-capeArm",
				"origin" : [19,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|swingT1-0-cape",
				"origin" : [32,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingT1-0-capeOverHead",
				"origin" : [11,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingT1-1-cape",
				"origin" : [40,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingT1-1-capeOverHead",
				"origin" : [16,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|swingT1-2-cape",
				"origin" : [33,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingT1-2-capeOverHead",
				"origin" : [4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingT1-2-capeArm",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "body",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|swingT2-0-cape",
				"origin" : [43,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingT2-0-capeOverHead",
				"origin" : [-4,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingT2-0-capeArm",
				"origin" : [7,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingT2-1-cape",
				"origin" : [39,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingT2-1-capeOverHead",
				"origin" : [15,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|swingT2-2-cape",
				"origin" : [33,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingT2-2-capeOverHead",
				"origin" : [16,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|swingT3-0-cape",
				"origin" : [40,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingT3-0-capeOverHead",
				"origin" : [10,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingT3-1-cape",
				"origin" : [36,37],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingT3-1-capeOverHead",
				"origin" : [1,9],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingT3-1-capeArm",
				"origin" : [14,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|swingT3-2-cape",
				"origin" : [33,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingT3-2-capeOverHead",
				"origin" : [7,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|swingTF-0-cape",
				"origin" : [42,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingTF-0-capeOverHead",
				"origin" : [6,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingTF-1-cape",
				"origin" : [44,31],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingTF-1-capeOverHead",
				"origin" : [7,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingTF-1-capeArm",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|swingTF-2-cape",
				"origin" : [37,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingTF-2-capeOverHead",
				"origin" : [17,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01100004|swingTF-3-cape",
				"origin" : [34,40],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingTF-3-capeOverHead",
				"origin" : [15,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|swingP1-0-cape",
				"origin" : [33,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingP1-0-capeOverHead",
				"origin" : [13,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingP1-1-cape",
				"origin" : [40,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingP1-1-capeOverHead",
				"origin" : [6,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingP1-1-capeArm",
				"origin" : [16,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|swingP1-2-cape",
				"origin" : [33,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingP1-2-capeOverHead",
				"origin" : [4,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingP1-2-capeArm",
				"origin" : [9,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|swingP2-0-cape",
				"origin" : [42,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingP2-0-capeOverHead",
				"origin" : [1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingP2-0-capeArm",
				"origin" : [6,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingP2-1-cape",
				"origin" : [40,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingP2-1-capeOverHead",
				"origin" : [16,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|swingP2-2-cape",
				"origin" : [36,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingP2-2-capeOverHead",
				"origin" : [16,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|swingPF-0-cape",
				"origin" : [31,39],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingPF-0-capeOverHead",
				"origin" : [-5,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingPF-0-capeArm",
				"origin" : [15,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingPF-1-cape",
				"origin" : [33,39],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingPF-1-capeOverHead",
				"origin" : [-5,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingPF-1-capeArm",
				"origin" : [15,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|swingPF-2-cape",
				"origin" : [41,25],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingPF-2-capeOverHead",
				"origin" : [17,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01100004|swingPF-3-cape",
				"origin" : [50,39],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingPF-3-capeOverHead",
				"origin" : [13,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|stabO1-0-cape",
				"origin" : [41,37],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabO1-0-capeOverHead",
				"origin" : [-2,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabO1-0-capeArm",
				"origin" : [16,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|stabO1-1-cape",
				"origin" : [44,40],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabO1-1-capeOverHead",
				"origin" : [3,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabO1-1-capeArm",
				"origin" : [13,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|stabO2-0-cape",
				"origin" : [38,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabO2-0-capeOverHead",
				"origin" : [-3,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabO2-0-capeArm",
				"origin" : [15,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|stabO2-1-cape",
				"origin" : [41,39],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabO2-1-capeOverHead",
				"origin" : [3,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabO2-1-capeArm",
				"origin" : [10,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|stabOF-0-cape",
				"origin" : [49,41],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabOF-0-capeOverHead",
				"origin" : [5,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabOF-0-capeArm",
				"origin" : [19,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|stabOF-1-cape",
				"origin" : [39,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabOF-1-capeOverHead",
				"origin" : [5,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabOF-1-capeArm",
				"origin" : [23,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|stabOF-2-cape",
				"origin" : [38,37],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabOF-2-capeOverHead",
				"origin" : [5,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabOF-2-capeArm",
				"origin" : [12,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|stabT1-0-cape",
				"origin" : [45,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabT1-0-capeOverHead",
				"origin" : [0,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabT1-0-capeArm",
				"origin" : [16,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|stabT1-1-cape",
				"origin" : [32,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabT1-1-capeOverHead",
				"origin" : [-2,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabT1-1-capeArm",
				"origin" : [14,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|stabT1-2-cape",
				"origin" : [42,38],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabT1-2-capeOverHead",
				"origin" : [19,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|stabT2-0-cape",
				"origin" : [43,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabT2-0-capeOverHead",
				"origin" : [-1,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabT2-0-capeArm",
				"origin" : [14,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|stabT2-1-cape",
				"origin" : [36,37],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabT2-1-capeOverHead",
				"origin" : [5,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabT2-1-capeArm",
				"origin" : [14,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|stabT2-2-cape",
				"origin" : [45,38],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabT2-2-capeOverHead",
				"origin" : [1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabT2-2-capeArm",
				"origin" : [19,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|swingPF-0-cape",
				"origin" : [31,39],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingPF-0-capeOverHead",
				"origin" : [-5,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingPF-0-capeArm",
				"origin" : [15,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingPF-1-cape",
				"origin" : [33,39],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingPF-1-capeOverHead",
				"origin" : [-5,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingPF-1-capeArm",
				"origin" : [15,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|stabTF-2-cape",
				"origin" : [39,30],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabTF-2-capeOverHead",
				"origin" : [-2,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|stabTF-2-capeArm",
				"origin" : [11,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01100004|stabT1-2-cape",
				"origin" : [42,38],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|stabT1-2-capeOverHead",
				"origin" : [19,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|shoot1-0-cape",
				"origin" : [42,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|shoot1-0-capeOverHead",
				"origin" : [16,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|shoot1-1-cape",
				"origin" : [42,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|shoot1-1-capeOverHead",
				"origin" : [16,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|shoot1-2-cape",
				"origin" : [42,33],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|shoot1-2-capeOverHead",
				"origin" : [16,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|shoot2-0-cape",
				"origin" : [39,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|shoot2-0-capeOverHead",
				"origin" : [13,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|shoot2-1-cape",
				"origin" : [39,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|shoot2-1-capeOverHead",
				"origin" : [13,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|shoot2-2-cape",
				"origin" : [39,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|shoot2-2-capeOverHead",
				"origin" : [13,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"3" :  {
			"cape" :  {
				"png_path": "01100004|shoot2-3-cape",
				"origin" : [39,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|shoot2-3-capeOverHead",
				"origin" : [13,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"4" :  {
			"cape" :  {
				"png_path": "01100004|shoot2-4-cape",
				"origin" : [39,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|shoot2-4-capeOverHead",
				"origin" : [12,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|shootF-0-cape",
				"origin" : [44,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|shootF-0-capeOverHead",
				"origin" : [17,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|shootF-1-cape",
				"origin" : [41,37],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|shootF-1-capeOverHead",
				"origin" : [17,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|shootF-1-cape",
				"origin" : [41,37],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|shootF-1-capeOverHead",
				"origin" : [17,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|proneStab-0-cape",
				"origin" : [52,41],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|proneStab-0-capeOverHead",
				"origin" : [2,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|proneStab-1-cape",
				"origin" : [52,40],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|proneStab-1-capeOverHead",
				"origin" : [5,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|proneStab-0-cape",
				"origin" : [52,41],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|proneStab-0-capeOverHead",
				"origin" : [2,5],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|alert-1-cape",
				"origin" : [37,31],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|alert-1-capeOverHead",
				"origin" : [-1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|alert-1-capeArm",
				"origin" : [14,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|swingO2-1-cape",
				"origin" : [41,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingO2-1-capeOverHead",
				"origin" : [3,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingO2-1-capeArm",
				"origin" : [10,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"2" :  {
			"cape" :  {
				"png_path": "01100004|swingO2-0-cape",
				"origin" : [44,34],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|swingO2-0-capeOverHead",
				"origin" : [1,11],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|swingO2-0-capeArm",
				"origin" : [7,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|fly-0-cape",
				"origin" : [40,30],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|fly-0-capeOverHead",
				"origin" : [-1,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
			"capeArm" :  {
				"png_path": "01100004|fly-0-capeArm",
				"origin" : [13,15],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|fly-1-cape",
				"origin" : [41,29],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|fly-1-capeOverHead",
				"origin" : [0,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
			"capeArm" :  {
				"png_path": "01100004|fly-1-capeArm",
				"origin" : [14,14],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|jump-0-cape",
				"origin" : [39,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|jump-0-capeOverHead",
				"origin" : [-1,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
			"capeArm" :  {
				"png_path": "01100004|jump-0-capeArm",
				"origin" : [13,13],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|sit-0-cape",
				"origin" : [36,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
			"capeOverHead" :  {
				"png_path": "01100004|sit-0-capeOverHead",
				"origin" : [-3,10],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "capeOverHead",
			},
			"capeArm" :  {
				"png_path": "01100004|sit-0-capeArm",
				"origin" : [15,12],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "cape",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|ladder-0-cape",
				"origin" : [42,35],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|ladder-0-capeOverHead",
				"origin" : [6,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|ladder-1-cape",
				"origin" : [41,36],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|ladder-1-capeOverHead",
				"origin" : [5,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"cape" :  {
				"png_path": "01100004|rope-0-cape",
				"origin" : [43,31],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|rope-0-capeOverHead",
				"origin" : [6,7],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
		},
		"1" :  {
			"cape" :  {
				"png_path": "01100004|rope-1-cape",
				"origin" : [42,38],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "back",
			},
			"capeOverHead" :  {
				"png_path": "01100004|rope-1-capeOverHead",
				"origin" : [5,8],
				"map" :  {
					"navel" : [0,0],
				},
				"z" : "backCape",
			},
		},
	},
};

