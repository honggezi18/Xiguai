var Avatar01452165 = Avatar01452165 || { }; 
Avatar01452165 =   {
	"id":"01452165",
	"info" :  {
		"icon" :  {
			"png_path": "01452165|info-icon",
			"origin" : [3,35],
		},
		"iconRaw" :  {
			"png_path": "01452165|info-iconRaw",
			"origin" : [3,35],
		},
		"islot" : "WpSi",
		"vslot" : "WpSi",
		"walk" : 1,
		"stand" : 1,
		"attack" : 3,
		"afterImage" : "bow",
		"sfx" : "bow",
		"attackSpeed" : 6,
		"tuc" : 9,
		"reqJob" : 4,
		"reqLevel" : 79,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPAD" : 89,
		"knockback" : 55,
		"price" : 0,
		"cash" : 0,
		"setItemID" : 100,
		"cubeExBaseOptionLevel" : 110,
	},
	"walk1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452165|walk1-0-weapon",
				"origin" : [50,21],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452165|walk1-1-weapon",
				"origin" : [48,28],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452165|walk1-0-weapon",
				"origin" : [50,21],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01452165|walk1-3-weapon",
				"origin" : [48,28],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452165|stand1-0-weapon",
				"origin" : [50,21],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452165|stand1-1-weapon",
				"origin" : [50,21],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452165|stand1-2-weapon",
				"origin" : [50,21],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452165|alert-0-weapon",
				"origin" : [28,48],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452165|alert-1-weapon",
				"origin" : [28,48],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452165|alert-2-weapon",
				"origin" : [28,48],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452165|swingT1-0-weapon",
				"origin" : [50,21],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452165|swingT1-1-weapon",
				"origin" : [28,48],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452165|swingT1-2-weapon",
				"origin" : [48,28],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452165|swingT3-0-weapon",
				"origin" : [48,28],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452165|swingT3-1-weapon",
				"origin" : [50,21],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452165|swingT3-2-weapon",
				"origin" : [28,48],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452165|shoot1-0-weapon",
				"origin" : [42,47],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452165|shoot1-1-weapon",
				"origin" : [56,47],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452165|shoot1-2-weapon",
				"origin" : [56,47],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452165|shootF-0-weapon",
				"origin" : [44,50],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452165|shootF-1-weapon",
				"origin" : [61,52],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01452165|shootF-1-weapon",
				"origin" : [61,52],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452165|proneStab-0-weapon",
				"origin" : [50,21],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452165|proneStab-1-weapon",
				"origin" : [50,21],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452165|proneStab-0-weapon",
				"origin" : [50,21],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452165|fly-0-weapon",
				"origin" : [28,48],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01452165|fly-1-weapon",
				"origin" : [28,48],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01452165|jump-0-weapon",
				"origin" : [28,48],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
};

