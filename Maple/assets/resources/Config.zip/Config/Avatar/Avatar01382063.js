var Avatar01382063 = Avatar01382063 || { }; 
Avatar01382063 =   {
	"id":"01382063",
	"info" :  {
		"icon" :  {
			"png_path": "01382063|info-icon",
			"origin" : [3,34],
		},
		"iconRaw" :  {
			"png_path": "01382063|info-iconRaw",
			"origin" : [3,34],
		},
		"islot" : "Wp",
		"vslot" : "Wp",
		"walk" : 1,
		"stand" : 1,
		"attack" : 6,
		"afterImage" : "mace",
		"sfx" : "mace",
		"reqJob" : 2,
		"reqLevel" : 115,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 344,
		"reqLUK" : 80,
		"incPAD" : 78,
		"incLUK" : 2,
		"incMAD" : 123,
		"incMHP" : 50,
		"tuc" : 7,
		"price" : 6900,
		"attackSpeed" : 4,
		"cash" : 0,
		"level" :  {
			"info" :  {
				"1" :  {
					"incPADMin" : 0,
					"incPADMax" : 2,
					"incSTRMin" : 1,
					"incSTRMax" : 2,
					"incDEXMin" : 0,
					"incDEXMax" : 1,
					"exp" : 80,
				},
			},
			"case" :  {
				"0" :  {
					"prob" : 1,
				},
				"1" :  {
					"prob" : 9,
					"1" :  {
						"hs" : "h1",
						"ItemSkill" :  {
							"0" :  {
								"id" : 10005,
								"level" : 1,
							},
						},
					},
				},
			},
		},
	},
	"walk1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|walk1-0-weapon",
				"origin" : [11,6],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|walk1-1-weapon",
				"origin" : [12,8],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382063|walk1-2-weapon",
				"origin" : [11,6],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01382063|walk1-3-weapon",
				"origin" : [11,6],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|stand1-0-weapon",
				"origin" : [11,3],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|stand1-0-weapon",
				"origin" : [11,3],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382063|stand1-0-weapon",
				"origin" : [11,3],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|alert-0-weapon",
				"origin" : [15,8],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|alert-1-weapon",
				"origin" : [14,7],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382063|alert-2-weapon",
				"origin" : [15,6],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|swingO1-0-weapon",
				"origin" : [7,60],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|swingO1-1-weapon",
				"origin" : [7,15],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382063|swingO1-2-weapon",
				"origin" : [119,92],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|swingO2-0-weapon",
				"origin" : [4,38],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|swingO2-1-weapon",
				"origin" : [7,106],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382063|swingO2-2-weapon",
				"origin" : [116,66],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|swingO3-0-weapon",
				"origin" : [6,91],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|swingO3-1-weapon",
				"origin" : [73,104],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382063|swingO3-2-weapon",
				"origin" : [118,99],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|swingOF-0-weapon",
				"origin" : [24,39],
				"map" :  {
					"hand" : [-17,-32],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|swingOF-1-weapon",
				"origin" : [44,50],
				"map" :  {
					"hand" : [-2,-22],
				},
				"z" : "backWeapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382063|swingOF-2-weapon",
				"origin" : [37,66],
				"map" :  {
					"hand" : [-40,24],
				},
				"z" : "weaponBelowBody",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01382063|swingOF-3-weapon",
				"origin" : [146,30],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|stabO1-0-weapon",
				"origin" : [89,23],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|stabO1-1-weapon",
				"origin" : [113,35],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|stabO2-0-weapon",
				"origin" : [82,15],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|stabO2-1-weapon",
				"origin" : [116,33],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|stabOF-0-weapon",
				"origin" : [70,25],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|stabOF-1-weapon",
				"origin" : [63,56],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382063|stabOF-2-weapon",
				"origin" : [102,50],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|shoot1-0-weapon",
				"origin" : [48,56],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|shoot1-1-weapon",
				"origin" : [62,62],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382063|shoot1-2-weapon",
				"origin" : [59,69],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|shootF-0-weapon",
				"origin" : [55,58],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|shootF-1-weapon",
				"origin" : [69,66],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382063|shootF-1-weapon",
				"origin" : [69,66],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|proneStab-0-weapon",
				"origin" : [85,24],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|proneStab-1-weapon",
				"origin" : [121,34],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|proneStab-0-weapon",
				"origin" : [85,24],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|alert-1-weapon",
				"origin" : [14,7],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|swingO2-1-weapon",
				"origin" : [7,106],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382063|swingO2-0-weapon",
				"origin" : [4,38],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|fly-0-weapon",
				"origin" : [5,11],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382063|fly-1-weapon",
				"origin" : [4,12],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382063|jump-0-weapon",
				"origin" : [5,10],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverArm",
			},
		},
	},
};

