var Avatar01040114 = Avatar01040114 || { }; 
Avatar01040114 =   {
	"id":"01040114",
	"info" :  {
		"icon" :  {
			"png_path": "01040114|info-icon",
			"origin" : [-4,27],
		},
		"iconRaw" :  {
			"png_path": "01040114|info-iconRaw",
			"origin" : [-7,27],
		},
		"islot" : "Ma",
		"vslot" : "Ma",
		"reqJob" : 0,
		"reqLevel" : 0,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"cash" : 1,
	},
	"walk1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|walk1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,1],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|walk1-0-mailArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-10,6],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|walk1-1-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,0],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|walk1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,1],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|walk1-0-mailArm",
				"origin" : [4,3],
				"map" :  {
					"navel" : [-10,6],
				},
				"z" : "mailArm",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040114|walk1-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,2],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|walk1-3-mailArm",
				"origin" : [4,2],
				"map" :  {
					"navel" : [-9,8],
				},
				"z" : "mailArm",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|walk2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,1],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|walk2-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,3],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|walk2-1-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,0],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|walk2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,2],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|walk2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,1],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|walk2-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-9,3],
				},
				"z" : "mailArm",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040114|walk2-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,2],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|walk2-3-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-10,6],
				},
				"z" : "mailArm",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|stand1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|stand1-1-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-7,2],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|stand1-2-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|stand1-2-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-11,3],
				},
				"z" : "mailArm",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|stand2-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,0],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|stand2-1-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-7,1],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|stand2-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-10,3],
				},
				"z" : "mailArm",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|stand2-2-mail",
				"origin" : [10,9],
				"map" :  {
					"navel" : [-6,0],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|stand2-2-mailArm",
				"origin" : [3,4],
				"map" :  {
					"navel" : [-10,4],
				},
				"z" : "mailArm",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|alert-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|alert-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-8,6],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|alert-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|alert-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,5],
				},
				"z" : "mailArmOverHair",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|alert-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|alert-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,5],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|swingO1-0-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,1],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|swingO1-0-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [3,3],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingO1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-12,0],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|swingO1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|swingO1-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|swingO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-7,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|swingO2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|swingO3-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,1],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|swingO3-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-7,6],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingO3-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-7,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|swingO3-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-10,1],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|swingO3-2-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-2,3],
				},
				"z" : "mailArm",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|swingOF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,0],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingOF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-10,2],
				},
				"z" : "backMailChest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|swingOF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-7,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040114|swingOF-3-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|swingT1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-10,-1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingT1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|swingT1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,2],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|swingT2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingT2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|swingT2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|swingT3-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-7,2],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingT3-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,0],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|swingT3-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-1,0],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|swingTF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingTF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-13,-4],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|swingTF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040114|swingTF-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-4,4],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|swingP1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-8,0],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|swingP1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-3,5],
				},
				"z" : "mailArmOverHairBelowWeapon",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingP1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-1,2],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|swingP1-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|swingP2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,0],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingP2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|swingP2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|swingPF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingPF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,2],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|swingPF-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040114|swingPF-3-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|stabO1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|stabO1-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,6],
				},
				"z" : "mailArm",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|stabO1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [1,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|stabO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|stabO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,0],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|stabOF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [0,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|stabOF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [3,-1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|stabOF-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [2,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|stabT1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|stabT1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|stabT1-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|stabT2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,4],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|stabT2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [2,2],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|stabT2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-3,2],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|swingPF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingPF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,2],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|stabTF-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040114|stabT1-2-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-3,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|shoot1-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|shoot1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|shoot1-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|shoot2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-7,2],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|shoot2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-7,2],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|shoot2-2-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"3" :  {
			"mail" :  {
				"png_path": "01040114|shoot2-3-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-8,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"4" :  {
			"mail" :  {
				"png_path": "01040114|shoot2-4-mail",
				"origin" : [11,9],
				"map" :  {
					"navel" : [-9,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|shootF-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-4,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|shootF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|shootF-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|alert-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,0],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|alert-1-mailArm",
				"origin" : [3,5],
				"map" :  {
					"navel" : [-7,5],
				},
				"z" : "mailArmOverHair",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|swingO2-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-2,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"2" :  {
			"mail" :  {
				"png_path": "01040114|swingO2-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-7,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|fly-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|fly-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,3],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|jump-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,1],
				},
				"z" : "mailChestOverHighest",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|sit-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,0],
				},
				"z" : "mailChestOverHighest",
			},
			"mailArm" :  {
				"png_path": "01040114|sit-0-mailArm",
				"origin" : [4,4],
				"map" :  {
					"navel" : [-9,4],
				},
				"z" : "mailArmOverHair",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|ladder-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|ladder-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,-3],
				},
				"z" : "backMailChest",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"mail" :  {
				"png_path": "01040114|rope-0-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "backMailChest",
			},
		},
		"1" :  {
			"mail" :  {
				"png_path": "01040114|rope-1-mail",
				"origin" : [10,10],
				"map" :  {
					"navel" : [-6,-2],
				},
				"z" : "backMailChest",
			},
		},
	},
};

