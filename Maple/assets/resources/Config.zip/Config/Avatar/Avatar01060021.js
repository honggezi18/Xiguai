var Avatar01060021 = Avatar01060021 || { }; 
Avatar01060021 =   {
	"id":"01060021",
	"info" :  {
		"icon" :  {
			"png_path": "01060021|info-icon",
			"origin" : [-4,28],
		},
		"iconRaw" :  {
			"png_path": "01060021|info-iconRaw",
			"origin" : [-5,28],
		},
		"islot" : "Pn",
		"vslot" : "Pn",
		"reqJob" : 8,
		"reqLevel" : 10,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPDD" : 9,
		"tuc" : 7,
		"price" : 300,
		"cash" : 0,
	},
	"walk1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|walk1-0-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|walk1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-2,-7],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|walk1-2-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060021|walk1-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pants",
			},
		},
	},
	"walk2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|walk1-0-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|walk1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-2,-7],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|walk1-2-pants",
				"origin" : [9,7],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060021|walk1-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-5],
				},
				"z" : "pants",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|stand1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|stand1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-6],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|stand1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-7],
				},
				"z" : "pants",
			},
		},
	},
	"stand2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|stand1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-7],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|stand1-1-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-4,-6],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|stand1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-3,-7],
				},
				"z" : "pants",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|alert-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|alert-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|alert-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-7],
				},
				"z" : "pants",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|swingO1-0-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingO1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-8,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|swingO1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pants",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|swingO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-5],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|swingO2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-1,-3],
				},
				"z" : "pants",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|swingO3-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-3],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingO3-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-7,-2],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|swingO3-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-5,-4],
				},
				"z" : "pants",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|swingOF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-3],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingOF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "backPants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|swingOF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [-6,0],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060021|swingOF-3-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [5,0],
				},
				"z" : "pants",
			},
		},
	},
	"swingT1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|swingT1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-6],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingT1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|swingT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pants",
			},
		},
	},
	"swingT2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|swingT2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [2,-3],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingT2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|swingT2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [2,-3],
				},
				"z" : "pants",
			},
		},
	},
	"swingT3" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|swingT3-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-3],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingT3-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-2,-3],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|swingT3-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [2,-4],
				},
				"z" : "pants",
			},
		},
	},
	"swingTF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|swingTF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-3,-4],
				},
				"z" : "backPants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingTF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|swingTF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060021|swingTF-3-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [2,-1],
				},
				"z" : "pants",
			},
		},
	},
	"swingP1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|swingP1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-5],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingP1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-3],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|swingP1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [1,-3],
				},
				"z" : "pants",
			},
		},
	},
	"swingP2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|swingP2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingP2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|swingP2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [2,-3],
				},
				"z" : "pants",
			},
		},
	},
	"swingPF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|swingPF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingPF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [2,-5],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|swingPF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [5,-4],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060021|swingPF-3-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [0,-2],
				},
				"z" : "pants",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|stabO1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [3,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|stabO1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,-2],
				},
				"z" : "pants",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|stabO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-5],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|stabO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-3,-4],
				},
				"z" : "pants",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|stabOF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|stabOF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [2,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|stabOF-2-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [2,-2],
				},
				"z" : "pants",
			},
		},
	},
	"stabT1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|stabT1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [2,-2],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|stabT1-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|stabT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [2,-4],
				},
				"z" : "pants",
			},
		},
	},
	"stabT2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|stabT2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-1],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|stabT2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-1,0],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|stabT2-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [4,-3],
				},
				"z" : "pants",
			},
		},
	},
	"stabTF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|swingPF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingPF-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [2,-5],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|stabTF-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [5,-4],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060021|stabT1-2-pants",
				"origin" : [9,6],
				"map" :  {
					"navel" : [2,-4],
				},
				"z" : "pants",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-5],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-5],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|shoot1-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-5],
				},
				"z" : "pants",
			},
		},
	},
	"shoot2" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-4],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-4],
				},
				"z" : "pants",
			},
		},
		"3" :  {
			"pants" :  {
				"png_path": "01060021|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-4],
				},
				"z" : "pants",
			},
		},
		"4" :  {
			"pants" :  {
				"png_path": "01060021|shoot2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-4],
				},
				"z" : "pants",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|shootF-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [2,-5],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|shootF-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [2,-5],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|shootF-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [2,-5],
				},
				"z" : "pants",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-8,6],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-8,6],
				},
				"z" : "pants",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|proneStab-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-8,6],
				},
				"z" : "pants",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|alert-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|swingO2-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [0,-4],
				},
				"z" : "pants",
			},
		},
		"2" :  {
			"pants" :  {
				"png_path": "01060021|swingO2-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-4,-5],
				},
				"z" : "pants",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|fly-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-5,-3],
				},
				"z" : "pants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|fly-1-pants",
				"origin" : [10,6],
				"map" :  {
					"navel" : [-5,-4],
				},
				"z" : "pants",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|jump-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-2,-4],
				},
				"z" : "pants",
			},
		},
	},
	"sit" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|sit-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "pants",
			},
		},
	},
	"ladder" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|ladder-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [-1,-6],
				},
				"z" : "backPants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|ladder-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "backPants",
			},
		},
	},
	"rope" :  {
		"0" :  {
			"pants" :  {
				"png_path": "01060021|rope-0-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [0,-6],
				},
				"z" : "backPants",
			},
		},
		"1" :  {
			"pants" :  {
				"png_path": "01060021|rope-1-pants",
				"origin" : [10,5],
				"map" :  {
					"navel" : [1,-5],
				},
				"z" : "backPants",
			},
		},
	},
};

