var Avatar01382062 = Avatar01382062 || { }; 
Avatar01382062 =   {
	"id":"01382062",
	"info" :  {
		"icon" :  {
			"png_path": "01382062|info-icon",
			"origin" : [0,30],
		},
		"iconRaw" :  {
			"png_path": "01382062|info-iconRaw",
			"origin" : [0,30],
		},
		"islot" : "Wp",
		"vslot" : "Wp",
		"walk" : 1,
		"stand" : 1,
		"attack" : 6,
		"afterImage" : "mace",
		"sfx" : "mace",
		"reqJob" : 2,
		"reqLevel" : 30,
		"reqSTR" : 0,
		"reqDEX" : 0,
		"reqINT" : 0,
		"reqLUK" : 0,
		"incPAD" : 35,
		"incMAD" : 48,
		"incMHP" : 100,
		"incSTR" : 3,
		"incDEX" : 3,
		"incINT" : 3,
		"incLUK" : 3,
		"notSale" : 1,
		"timeLimited" : 1,
		"tradeBlock" : 1,
		"tuc" : 7,
		"price" : 1,
		"attackSpeed" : 6,
		"cash" : 0,
	},
	"walk1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|walk1-0-weapon",
				"origin" : [15,22],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|walk1-1-weapon",
				"origin" : [14,27],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382062|walk1-2-weapon",
				"origin" : [12,19],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01382062|walk1-3-weapon",
				"origin" : [13,20],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"stand1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|stand1-0-weapon",
				"origin" : [15,20],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|stand1-0-weapon",
				"origin" : [15,20],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382062|stand1-0-weapon",
				"origin" : [15,20],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"alert" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|alert-0-weapon",
				"origin" : [17,22],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverGlove",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|alert-1-weapon",
				"origin" : [15,25],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverGlove",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382062|alert-2-weapon",
				"origin" : [14,19],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverGlove",
			},
		},
	},
	"swingO1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|swingO1-0-weapon",
				"origin" : [12,49],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|swingO1-1-weapon",
				"origin" : [2,25],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382062|swingO1-2-weapon",
				"origin" : [109,96],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"swingO2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|swingO2-0-weapon",
				"origin" : [9,46],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|swingO2-1-weapon",
				"origin" : [24,97],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382062|swingO2-2-weapon",
				"origin" : [152,103],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"swingO3" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|swingO3-0-weapon",
				"origin" : [30,67],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|swingO3-1-weapon",
				"origin" : [92,114],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382062|swingO3-2-weapon",
				"origin" : [104,97],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"swingOF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|swingOF-0-weapon",
				"origin" : [14,49],
				"map" :  {
					"hand" : [4,-10],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|swingOF-1-weapon",
				"origin" : [56,47],
				"map" :  {
					"hand" : [-27,10],
				},
				"z" : "backWeapon",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382062|swingOF-2-weapon",
				"origin" : [61,81],
				"map" :  {
					"hand" : [-52,11],
				},
				"z" : "weaponBelowBody",
			},
		},
		"3" :  {
			"weapon" :  {
				"png_path": "01382062|swingOF-3-weapon",
				"origin" : [133,46],
				"map" :  {
					"hand" : [0,-1],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"stabO1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|stabO1-0-weapon",
				"origin" : [49,27],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|stabO1-1-weapon",
				"origin" : [77,41],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"stabO2" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|stabO2-0-weapon",
				"origin" : [46,23],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|stabO2-1-weapon",
				"origin" : [82,42],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"stabOF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|stabOF-0-weapon",
				"origin" : [47,26],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|stabOF-1-weapon",
				"origin" : [31,37],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverHand",
			},
		},
	},
	"shoot1" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|shoot1-0-weapon",
				"origin" : [74,69],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|shoot1-1-weapon",
				"origin" : [87,81],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382062|shoot1-2-weapon",
				"origin" : [75,95],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"shootF" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|shootF-0-weapon",
				"origin" : [76,82],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|shootF-1-weapon",
				"origin" : [89,100],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382062|shootF-1-weapon",
				"origin" : [89,100],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowArm",
			},
		},
	},
	"proneStab" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|proneStab-0-weapon",
				"origin" : [45,29],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverGlove",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|proneStab-1-weapon",
				"origin" : [78,45],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverGlove",
			},
		},
	},
	"prone" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|proneStab-0-weapon",
				"origin" : [45,29],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverGlove",
			},
		},
	},
	"heal" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|alert-1-weapon",
				"origin" : [15,25],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverGlove",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|swingO2-1-weapon",
				"origin" : [24,97],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
		"2" :  {
			"weapon" :  {
				"png_path": "01382062|swingO2-0-weapon",
				"origin" : [9,46],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponBelowBody",
			},
		},
	},
	"fly" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|fly-0-weapon",
				"origin" : [13,18],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverGlove",
			},
		},
		"1" :  {
			"weapon" :  {
				"png_path": "01382062|fly-1-weapon",
				"origin" : [11,25],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverGlove",
			},
		},
	},
	"jump" :  {
		"0" :  {
			"weapon" :  {
				"png_path": "01382062|jump-0-weapon",
				"origin" : [11,24],
				"map" :  {
					"hand" : [0,0],
				},
				"z" : "weaponOverGlove",
			},
		},
	},
};

